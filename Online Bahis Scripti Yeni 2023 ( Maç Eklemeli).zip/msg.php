<?php 
$header=array();
$header[] = 'Origin: http://localhost';
$header[] = 'Host : lodge.live:1935';
$header[] = 'Referer : http://localhost/gir.php';
$ch = curl_init();
curl_setopt($ch, CURLOPT_TIMEOUT,20);
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 20); 
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0");
curl_setopt($ch, CURLOPT_URL, "http://lodge.live/match/live/49936");
curl_setopt($ch, CURLOPT_REFERER, "http://www.polobet.tv/index.html?sub=YTU2NTg4OGRkODhkc2U1NTg3b2lmZw==");
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST,  2);
echo$calistir = curl_exec($ch);
//echo preg_replace('#http://lodge.live/channel/polobettv.png#','',$calistir);
exit;