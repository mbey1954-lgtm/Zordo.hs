function SadeceRakam(e,allowedchars){var key=e.charCode==undefined?e.keyCode:e.charCode;if((/^[0-9]+$/.test(String.fromCharCode(key)))||key==0||key==13||isPassKey(key,allowedchars)){return true;}else{return false;}}

function isPassKey(key,allowedchars){if(allowedchars!=null){for(var i=0;i<allowedchars.length;i++){if(allowedchars[i]==String.fromCharCode(key))return true;}}return false;}

function SadeceRakamBlur(e,clear){var nesne=e.target?e.target:e.srcElement;var val=nesne.value;val=val.replace(/^\s+|\s+$/g,"");if(clear)val=val.replace(/\s{2,}/g," ");nesne.value=val;}

var Base64={_keyStr:"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",encode:function(e){var t="";var n,r,i,s,o,u,a;var f=0;e=Base64._utf8_encode(e);while(f<e.length){n=e.charCodeAt(f++);r=e.charCodeAt(f++);i=e.charCodeAt(f++);s=n>>2;o=(n&3)<<4|r>>4;u=(r&15)<<2|i>>6;a=i&63;if(isNaN(r)){u=a=64}else if(isNaN(i)){a=64}t=t+this._keyStr.charAt(s)+this._keyStr.charAt(o)+this._keyStr.charAt(u)+this._keyStr.charAt(a)}return t},decode:function(e){var t="";var n,r,i;var s,o,u,a;var f=0;e=e.replace(/[^A-Za-z0-9\+\/\=]/g,"");while(f<e.length){s=this._keyStr.indexOf(e.charAt(f++));o=this._keyStr.indexOf(e.charAt(f++));u=this._keyStr.indexOf(e.charAt(f++));a=this._keyStr.indexOf(e.charAt(f++));n=s<<2|o>>4;r=(o&15)<<4|u>>2;i=(u&3)<<6|a;t=t+String.fromCharCode(n);if(u!=64){t=t+String.fromCharCode(r)}if(a!=64){t=t+String.fromCharCode(i)}}t=Base64._utf8_decode(t);return t},_utf8_encode:function(e){e=e.replace(/\r\n/g,"\n");var t="";for(var n=0;n<e.length;n++){var r=e.charCodeAt(n);if(r<128){t+=String.fromCharCode(r)}else if(r>127&&r<2048){t+=String.fromCharCode(r>>6|192);t+=String.fromCharCode(r&63|128)}else{t+=String.fromCharCode(r>>12|224);t+=String.fromCharCode(r>>6&63|128);t+=String.fromCharCode(r&63|128)}}return t},_utf8_decode:function(e){var t="";var n=0;var r=c1=c2=0;while(n<e.length){r=e.charCodeAt(n);if(r<128){t+=String.fromCharCode(r);n++}else if(r>191&&r<224){c2=e.charCodeAt(n+1);t+=String.fromCharCode((r&31)<<6|c2&63);n+=2}else{c2=e.charCodeAt(n+1);c3=e.charCodeAt(n+2);t+=String.fromCharCode((r&15)<<12|(c2&63)<<6|c3&63);n+=3}}return t}};

function blackac() { 
	$("#black").show(); 
	$("#macdetay").show();
	//$("body").css('overflow','hidden'); 
}

function kuponTemizledirek() {
	
	var pagead=location.pathname.substring(location.pathname.lastIndexOf("/") + 1);
	//alert(pagead)
	/*if(pagead!='kupon' && pagead!='basketbol' && pagead!='home' && pagead!='' && pagead!='Bwin' && pagead!='Superbahis' && pagead!='duello'){
		kupontemizle();
	}*/
	kupontemizle();
}

function failcont(msg) {
	/*$("#black").fadeIn();
	$(".failcont").fadeIn();
	$(".failcontt").html(msg);
	$("#failkap").focus();*/
	$("#uyarip").html(msg);
	$( "#uyarip" ).dialog({
	  modal: true,
	  buttons: {
		Kapat: function() {
		  $(this).dialog( "close" );
		}
	  },
	  close : function(){
		 $( "#uyarip" ).html('');
	  }
	});
}

function msg(durum,msg) {
	var setle;
	clearInterval(setle);
	$("#"+durum+"").hide();
	$("#"+durum+"").html(msg);
	$("#"+durum+"").show('pulsate', { times:2 },100);
	var setle = setTimeout(function() { $("#"+durum+"").hide(); },2000);
}

function mdf(id,tablo) {
	$("#macd").show();
	loadgir("#macd");
	$.get(baseurl+'home/tumoran'+tablo+'/'+id,function(data) { 		
		$("#macd").html(data);
	});	
}

function macdkapat() {
	$("#macd").slideUp(function() {
		$("#macd").html('');
	});
}

function kupicrenk(th) {
	$(".qbutton 2").removeClass('selected');
	//alert(th);
	$('#'+th).addClass('selected');
}

function kupon(val) {
	
	var decodesi = Base64.decode(val);
	var decode = decodesi.split('|');
    var th=decode[0]+'-'+decode[3]+'-'+decode[2];
	if(decode[4]!='-'){
	var KupondaVarmi = 0;
	$(".event_head").each(function (i) {
		
		var s=$(this).attr('id');
		var idal=s.split('-');		
		var esitle = idal[0]+'-'+idal[1]+'-'+idal[2];
		
		if ($('#'+th).length > 0 && th==esitle){
			//alert(th);
			KupondaVarmi = 1;
			kuponsil(idal[3]);			
        }	
    });
	
	if (KupondaVarmi == 0) {
		$.post(baseurl+'kupon/kuponekle',{val:val},function(data) {  
		if(data=="10") {
			alert('Duellosunu ya da gerçeğini oynadığınız bir maçın içindeki takımları tek kuponda oynayamazsınız.');
		}else if(data=="201") { 
			kuponsay(); 
		} else if(data=="200") { 
			kuponsay(); 
		}else if(data=="5") { 
			msg('faildurum','Maksimum kupon satırına ulaştınız.'); 
		}else if(data=="1") { 
			failcont('Veri Kaynağında sorun oluştu. Lütfen kuponunuzu kontrol ediniz.'); 
		}else if(data=="4") { 
			failcont('Sistem Şuanda Bahislere Kapalıdır.'); 
		}
		});
	}
	}
}

function kuponsay() {
	$.post(baseurl+'kupon/kuponsay/',function(data) {$("#kupjs").html(data);});	
}

function loadgir(div) { 
	$(div).show(); $(div).html('<div style="text-align: center"><img src="/img/712.GIF"></div>'); 
	
}

function kuponsil(id) {
	//loadgir("kuponalan");
	$.post(baseurl+'kupon/kuponsil/',{id:id},function(data) { kuponsay(); });	
}

function kuponsilic(id) {
	//loadgir("kuponalan");
	$.post(baseurl+'kupon/kuponsil/',{id:id},function(data) { kuponguncelle();kuponsay(); });	
}

function kuponguncelle(val) {
	
	if(val==1) { loadgir("#kuponalan");}
	var rand = Math.random();
	var kuponyatan = $("#kuponyatan").val();
	var kuponisim = $("#kuponisim").val();
	var req = $.ajax({
		type:'post',
		url: baseurl+'kupon/kuponguncelle',
		data:{alowa:1,kuponyatan:kuponyatan,kuponisim:kuponisim},
		error: function(data){
			kuponguncelle(val);
		},
		success: function(data){
			$("#kuponalan").html(data);
		}
	});	
}

function limitupdate() {
	var rand = Math.random();
	$.get(baseurl+'kupon/guncelbakiye',function(data) { 
		$("#bakiyem").html(data).show('pulsate', { times:5 },200); 
	});
}

function divtogle(ilk,iki){
	jQuery(ilk).slideToggle('slow');jQuery(iki).toggle();
}

function kuponyazdir(id) {
	
	window.open(baseurl+'kuponlar/kuponyazdir/?kupid='+id, '', 'toolbar=no,location=no,directories=no,menubar=no,scrollbars=yes,width=670,height=500,left=300,top=50');
	
}

function kupontemizle() {
	$.get(baseurl+'kupon/kupontemizle',function() { 
		kuponguncelle(1);kuponsay();
	});	
}


function addZero(i) {
    if (i < 10) {
        i = "0" + i;
    }
    return i;
}

function saatKac(){
	  var d = new Date(); 
	  var hour = addZero(d.getHours()); 
	  var minute = addZero(d.getMinutes()); 
	  var second = addZero(d.getSeconds()); 
	  return document.getElementById('timesbu').innerHTML = second;
}

function go(yer){
	window.location.href=baseurl+yer;
}

function goBack() {
    window.history.back();
}

$(document).ready(function(e) {	
	
	jQuery(function($){
		$.datepicker.regional['tr'] = {
			closeText: 'kapat',
			prevText: ' Önceki Ay ',
			nextText: ' Sonraki Ay ',
			currentText: 'bugün',
			monthNames: ['Ocak','Şubat','Mart','Nisan','Mayıs','Haziran',
			'Temmuz','Ağustos','Eylül','Ekim','Kasım','Aralık'],
			monthNamesShort: ['Ocak','Şubat','Mart','Nisan','Mayıs','Haziran',
			'Temmuz','Ağustos','Eylül','Ekim','Kasım','Aralık'],
			dayNames: ['Pazar','Pazartesi','Salı','Çarşamba','Perşembe','Cuma','Cumartesi'],
			dayNamesShort: ['Pz','Pt','Sa','Ça','Pe','Cu','Ct'],
			dayNamesMin: ['Pz','Pt','Sa','Ça','Pe','Cu','Ct'],
			weekHeader: 'Hf',
			dateFormat: 'dd-mm-yy',
			firstDay: 1,
			isRTL: false,
			showMonthAfterYear: false,
			yearSuffix: ''};
		$.datepicker.setDefaults($.datepicker.regional['tr']);
	});
	
});