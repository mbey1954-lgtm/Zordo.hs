$(document).ready(function(){

    // Ruler Slide
    // ----------------------------------------------------------------------- //
  
    //$(".nav").navgoco({accordion: true});
    $(".type").on("click", function(e){  
        e.preventDefault();
        var selector = $(this).data("toggle");
        $(".sub-content").hide();
        $(selector).show();
        $(this).toggleClass('active');
    });
    
    $(".country").on("click", function(e){  
        e.preventDefault();
        var selector = $(this).data("toggle");
        $(".sub-contents").hide();
        $(selector).show();
        $(this).toggleClass('selected');
    });

	// Go Top Button
    // ----------------------------------------------------------------------- //
	$('.go_top').click(function(){
		$('body,html').animate({scrollTop:0},800);
	});
	
    $('.go_top_gray').click(function(){
        $('body,html').animate({scrollTop:0},800);
    });

	
    // Fixed Header
    // ----------------------------------------------------------------------- //		
//	$('.small-header').hide();	
	
	$(window).scroll(function() {
		if($(this).scrollTop() > 50) {
			$('.small-header').fadeIn();
		} else {
			$('.small-header').fadeOut();
		}
	});
	

 //   $('.dark-small-header').hide();  
    
    $(window).scroll(function() {
        if($(this).scrollTop() > 50) {
            $('.dark-small-header').fadeIn();
        } else {
            $('.dark-small-header').fadeOut();
        }
    });

	
    // Language
    // ----------------------------------------------------------------------- //
    $('.lng').click(function(){
        $('.lang ul').toggle();
        $('.lng').toggleClass('active');
    });


    // Ticket System
    // ----------------------------------------------------------------------- //
    $('.system-container ul').hide();
    $('.system-container').click(function(){
        $('.system-container ul').toggle();
    });
	
	$('.istatistik').fancybox({
		autoSize: false,
		'width': 1024,
		'height': 768,
		'transitionIn': 'elastic',
		'transitionOut': 'elastic',
		'scrolling': 'no',				
		helpers: {
			overlay: {
				closeClick: false
			}
		}		
	});

	$('.footinfo').fancybox({
		autoSize: false,
		'width': 830,
		'height': 768,
		'transitionIn': 'elastic',
		'transitionOut': 'elastic',
		'scrolling': 'no',				
		helpers: {
			overlay: {
				closeClick: false
			}
		}		
	});
	$("#kuponyatan").on("keypress", function(a){ var e=a.keyCode?a.keyCode:a.which;"13"==e&&kuponok()});
	$(".arti").mousehold(100,function(a){var e=$(this).attr("id");arti_bana(e)}),$(".eksi").mousehold(100,function(a){var e=$(this).attr("id");eksi_bana(e)}),$("#aynianda").keyup(function(){var a=$("#aynianda").val();if(""==a)var a="0";$(".aynidegis").val(a)});
	
	$('#tarihb').val($("ul.trhac li:nth-child(2)").attr('id'));
	$('#trhilk').text($("ul.trhac li:nth-child(2)").text());
});

jQuery(function(a){a.datepicker.regional.tr={closeText:"kapat",prevText:" Önceki Ay ",nextText:" Sonraki Ay ",currentText:"bugün",monthNames:["Ocak","Şubat","Mart","Nisan","Mayıs","Haziran","Temmuz","Ağustos","Eylül","Ekim","Kasım","Aralık"],monthNamesShort:["Ocak","Şubat","Mart","Nisan","Mayıs","Haziran","Temmuz","Ağustos","Eylül","Ekim","Kasım","Aralık"],dayNames:["Pazar","Pazartesi","Salı","Çarşamba","Perşembe","Cuma","Cumartesi"],dayNamesShort:["Pz","Pt","Sa","Ça","Pe","Cu","Ct"],dayNamesMin:["Pz","Pt","Sa","Ça","Pe","Cu","Ct"],weekHeader:"Hf",dateFormat:"dd-mm-yy",firstDay:1,isRTL:!1,showMonthAfterYear:!1,yearSuffix:""},a.datepicker.setDefaults(a.datepicker.regional.tr)})

function kuponyazdir(a){window.open(baseurl+"kuponlar/kuponyazdir/?kupid="+a,"","toolbar=no,location=no,directories=no,menubar=no,scrollbars=yes,width=670,height=500,left=300,top=50")}

function failcont(a){$("#uyarip").html(a),$("#uyarip").dialog({modal:!0,buttons:{Kapat:function(){$(this).dialog("close")}},close:function(){$("#uyarip").html("")}})}

function limitupdate(){Math.random();$.get(baseurl+"kupon/guncelbakiye",function(a){$("#bakiyem").html(a).show("pulsate",{times:5},200)})}

var Base64={_keyStr:"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",encode:function(a){var e,t,n,o,i,r,u,l="",s=0;for(a=Base64._utf8_encode(a);s<a.length;)e=a.charCodeAt(s++),t=a.charCodeAt(s++),n=a.charCodeAt(s++),o=e>>2,i=(3&e)<<4|t>>4,r=(15&t)<<2|n>>6,u=63&n,isNaN(t)?r=u=64:isNaN(n)&&(u=64),l=l+this._keyStr.charAt(o)+this._keyStr.charAt(i)+this._keyStr.charAt(r)+this._keyStr.charAt(u);return l},decode:function(a){var e,t,n,o,i,r,u,l="",s=0;for(a=a.replace(/[^A-Za-z0-9\+\/\=]/g,"");s<a.length;)o=this._keyStr.indexOf(a.charAt(s++)),i=this._keyStr.indexOf(a.charAt(s++)),r=this._keyStr.indexOf(a.charAt(s++)),u=this._keyStr.indexOf(a.charAt(s++)),e=o<<2|i>>4,t=(15&i)<<4|r>>2,n=(3&r)<<6|u,l+=String.fromCharCode(e),64!=r&&(l+=String.fromCharCode(t)),64!=u&&(l+=String.fromCharCode(n));return l=Base64._utf8_decode(l)},_utf8_encode:function(a){a=a.replace(/\r\n/g,"\n");for(var e="",t=0;t<a.length;t++){var n=a.charCodeAt(t);128>n?e+=String.fromCharCode(n):n>127&&2048>n?(e+=String.fromCharCode(n>>6|192),e+=String.fromCharCode(63&n|128)):(e+=String.fromCharCode(n>>12|224),e+=String.fromCharCode(n>>6&63|128),e+=String.fromCharCode(63&n|128))}return e},_utf8_decode:function(a){for(var e="",t=0,n=c1=c2=0;t<a.length;)n=a.charCodeAt(t),128>n?(e+=String.fromCharCode(n),t++):n>191&&224>n?(c2=a.charCodeAt(t+1),e+=String.fromCharCode((31&n)<<6|63&c2),t+=2):(c2=a.charCodeAt(t+1),c3=a.charCodeAt(t+2),e+=String.fromCharCode((15&n)<<12|(63&c2)<<6|63&c3),t+=3);return e}};

function loadgir(a){$(a).show(),$(a).html('<div class="load"><img src="'+baseurl+'img/712.GIF"></div>')}

function kuponguncelle(a) {
    1 == a && loadgir("#kuponalan");
    var e = (Math.random(), $("#kuponyatan").val()),
        t = $("#kuponisim").val();
    $.ajax({
        type: "post",
        url: baseurl + "kupon/kuponguncelle",
        data: {
            alowa: 1,
            kuponyatan: e,
            kuponisim: t
        },
        error: function(e) {
            kuponguncelle(a)
        },
        success: function(a) {
            $("#kuponalan").html(a)
        }
    });
}

function SadeceRakam(a,e){var t=void 0==a.charCode?a.keyCode:a.charCode;return/^[0-9]+$/.test(String.fromCharCode(t))||0==t||13==t||isPassKey(t,e)?!0:!1}function isPassKey(a,e){if(null!=e)for(var t=0;t<e.length;t++)if(e[t]==String.fromCharCode(a))return!0;return!1}function SadeceRakamBlur(a,e){var t=a.target?a.target:a.srcElement,n=t.value;n=n.replace(/^\s+|\s+$/g,""),e&&(n=n.replace(/\s{2,}/g," ")),t.value=n}

function msg(a,e){var t;clearInterval(t),$("#"+a).hide(),$("#"+a).html(e),$("#"+a).show("pulsate",{times:2},100);var t=setTimeout(function(){$("#"+a).hide()},2e3)}

function blackkapat(){$("#macdetay").empty(),$(".failcont").hide(),$("#black").hide()}

function tum_artila(){var a=$("input[type=text]");for(i=0;i<a.length;i++){var e=$("input[id=oranes_"+i+"]").val(),t=parseFloat(Math.round(100*e)/100+.05).toFixed(2);$("input[id=oranes_"+i+"]").val(t)}}function tum_eksile(){var a=$("input[type=text]");for(i=0;i<a.length;i++){var e=$("input[id=oranes_"+i+"]").val(),t=parseFloat(Math.round(100*e)/100-.05).toFixed(2);$("input[id=oranes_"+i+"]").val(t)}}function arti_bana(a){var e=$("input[id=oranes_"+a+"]").val(),t=parseFloat(Math.round(100*e)/100+.05).toFixed(2);$("input[id=oranes_"+a+"]").val(t)}function eksi_bana(a){var e=$("input[id=oranes_"+a+"]").val(),t=parseFloat(Math.round(100*e)/100-.05).toFixed(2);$("input[id=oranes_"+a+"]").val(t)}

function kupon(a){var e=(Math.random(),Base64.decode(a)),t=e.split("|"),n=t[0]+"-"+t[3]+"-"+t[2];if("-"!=t[4]){var o=0;$(".event_head").each(function(a){var e=$(this).attr("id"),t=e.split("-"),i=t[0]+"-"+t[1]+"-"+t[2];$("#"+n).length>0&&n==i&&(o=1,kuponsil(t[3]))}),0==o&&$.post(baseurl+"kupon/kuponekle",{val:a},function(a){"10"==a?alert("Duellosunu ya da gerçeğini oynadığınız bir maçın içindeki takımları tek kuponda oynayamazsınız."):"201"==a?kuponguncelle(1):"200"==a?kuponguncelle(1):"5"==a?msg("faildurum","Maksimum kupon satırına ulaştınız."):"1"==a?failcont("Kuponunuzda başlamış ya da oynanamaz maçlar var. Lütfen kuponunuzu kontrol ediniz."):"4"==a&&failcont("Sistem Şuanda Bahislere Kapalıdır.")})}}

function bulsathac(a){if(a==1){$('.saatac').hide();$('.trhac').hide();}else{$('.saatac').toggle();$('.trhac').hide();}}
function bultrhac(a){if(a==1){$('.trhac').hide();$('.saatac').hide();}else{$('.trhac').toggle();$('.saatac').hide();}}

function kupontemizle(bak){
	$.get(baseurl+"kupon/kupontemizle",function(){
		if(!bak)kuponguncelle(1);
		$('.ratio-box').removeClass('active');
	});
}

function kuponsil(a){loadgir("#kuponalan"),$.post(baseurl+"kupon/kuponsil/",{id:a},function(a){kuponguncelle(1)});}

function mdf(gelenmacid,e){
	
	if(document.getElementById('betdetail_'+gelenmacid).style.display=='block'){
		$("#tumac"+gelenmacid).removeClass('extra-but-slcted');
		document.getElementById('betdetail_'+gelenmacid).style.display='none';
	}else{
		document.getElementById('betdetail_'+gelenmacid).style.display='block';
		$("#tumac"+gelenmacid).addClass('extra-but-slcted');
		$.ajax({
			type:'POST',
			url:baseurl+'home/tumoran'+e+'/'+gelenmacid,
			complete:function(jqXHR){
				document.getElementById('betdetail_'+gelenmacid).innerHTML=jqXHR.responseText;
			}
		});
	}
}
function mdf1(gelenmacid,e){
	
	if(document.getElementById('betdetail_'+gelenmacid).style.display=='block'){
		$("#tumac"+gelenmacid).removeClass('extra-but-slcted');
		document.getElementById('betdetail_'+gelenmacid).style.display='none';
	}else{
		document.getElementById('betdetail_'+gelenmacid).style.display='block';
		$("#tumac"+gelenmacid).addClass('extra-but-slcted');
		$.ajax({
			type:'POST',
			url:baseurl+'home/tumoranson/'+gelenmacid,
			data:{t:e},
			complete:function(jqXHR){
				document.getElementById('betdetail_'+gelenmacid).innerHTML=jqXHR.responseText;
			}
		});
	}
}
function kuponTemizledirek(){var a=location.pathname.substring(location.pathname.lastIndexOf("/")+1);"iddaa_bulten"!=a&&"basketbol"!=a&&"home"!=a&&""!=a&&"canlibahis"!=a&&"duello"!=a&&"canlibahisb"!=a&&"buzhokeyi"!=a&&"tenis"!=a&&"hentbol"!=a&&kupontemizle(1)}