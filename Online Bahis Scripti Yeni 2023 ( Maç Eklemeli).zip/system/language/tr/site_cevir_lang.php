<?php
$lang['tenis']			= "Tenis";
$lang['hentbol']		= "Hentbol";
$lang['hokey']			= "Buz Hokeyi";
$lang['altust']			= "Alt/Üst";
$lang['2.settahmin']	= "2.Set Tahmin";
$lang['1.settahmin']	= "1.Set Tahmin";
$lang['1.yariustalt']	= "1.Yarı Üst/Alt";
$lang['2.yariustalt']	= "2.Yarı Üst/Alt";
$lang['1.yaritahmin']	= "1.Yarı Tahmin";
$lang['tekcift']		= "Tek/Çift";
$lang['sanalf']			= "Sanal Futbol";
$lang['sanalb']			= "Sanal Basketbol";
$lang['hesayar']		= "Hesap Ayarlarım";
$lang['sehir']			= "Şehir";
$lang['adres']			= "Adres";
$lang['tc']				= "T.C";
$lang['cins']			= "Cinsiyet";
$lang['ad']				= "Adınız";
$lang['dogum']			= "Dogum Günü";
$lang['pkod']			= "Posta Kodu";
$lang['ulke']			= "Ülke";
$lang['para']			= "Para";
$lang['uyeolmadanolmaz']= "Lütfen Üye Girişi Yapınız.";
$lang['hakk']			= "Hakkımızda";
$lang['sifrhtrl']		= "Şifre Hatırlatma Formu";
$lang['gizlilik']		= "Gizlilik Politikası";
$lang['bnkhesap']		= "Banka Hesapları";
$lang['kytol']			= "Kayıt Ol";
$lang['iban']			= "Iban No";


$lang['home']			= "Spor Bahisleri";
$lang['futbol']			= "Futbol";
$lang['basket']			= "Basketbol";
$lang['duello']			= "Duello";
$lang['canli']			= "Canlı Bahisler";
$lang['cfut']			= "Canlı Futbol";
$lang['cbasket']		= "Canlı Basketbol";
$lang['kpt']			= "Kapat";
$lang['print']			= "Yazdır";
$lang['saat']			= "saat";
$lang['saatall']		= "tüm saatler";
$lang['tarihall']		= "tüm tarihler";
$lang['soltit']			= "Ayarlar";
$lang['kpnlar']			= "Kuponlar";
$lang['hsp']			= "Menü";
$lang['trns']			= "Hesaplar";
$lang['cik']			= "Çıkış";
$lang['ynsifre']		= "Yeni Şifrenizi Yazınız.";
$lang['ynsifre1']		= "Şifrenizi Tekrar Yazınız.";

$lang['pyatiracik']		= "<p>İşlemleriniz <b>10:00 ile 22:00</b> saatleri içinde <b>en geç 1 saat</b> içinde gerçekleşir. Bu işlem için herhangi bir <b>ücret alınmaz</b>. Bu işlemde <b>EN AZ TUTAR 100</b> ve katları olarak kabul edilir.</p>";
$lang['pyatir']			= "Para Yatırma";
$lang['pcek']			= "Para Çekme";
$lang['bacik']			= "Bahis Açık";
$lang['kaz']			= "Kazandı";
$lang['kay']			= "Kaybetti";
$lang['ipt']			= "İptal";
$lang['ert']			= "Ertelendi";

$lang['tumsil']			= "Tümünü sil";
$lang['secin']			= "Seçiniz..";
$lang['bekle']			= "Lütfen Bekleyiniz";
$lang['tpl']			= "Toplam";
$lang['ytrlan']			= "Yatırılan";
$lang['kpno']			= "Kupon No";
$lang['kpshp']			= "Kupon Sahibi";
$lang['bhsadet']		= "Bahis adedi";
$lang['islm']			= "İşlem";
$lang['tip']			= "Tip";
$lang['ksatir']			= "Kupon Satır";
$lang['hpsi']			= "Hepsi";
$lang['giren']			= "Giren";
$lang['cikan']			= "Çıkan";
$lang['gtr']			= "Getir";
$lang['odrm']			= "Önceki Durum";
$lang['drm']			= "Durum";
$lang['olasi']			= "Olası Kazanç";
$lang['netkaz']			= "Net Kazanç";
$lang['bns']			= "Bonus";
$lang['toran']			= "Toplam Oran";
$lang['mac']			= "Maç";
$lang['trh']			= "Tarih";
$lang['sncbekle']		= "Sonuç bekleniyor";
$lang['dvre']			= "Devre";
$lang['drkl']			= "Duraklama";
$lang['cyrk']			= "%s Çeyrek";
$lang['devam']			= "Devam Ediyor";

$lang['sonerdi']		= "Sona Erdi";
$lang['baslamadi']		= "Başlamadı";
$lang['snclandi']		= "Sonuçlandı";

$lang['kupdegistirconfirm']		= "Kuponun durumunu değiştirmek istediğinizden emin misiniz?";

$lang['zmn']			= "Zaman";
$lang['hsphrkt']		= "Hesap Hareketleri";
$lang['ttr']			= "Tutar";
$lang['ottr']			= "Önceki Tutar";
$lang['sttr']			= "Sonraki Tutar";
$lang['isyapan']		= "İşlemi Yapan";
$lang['acikla']			= "Açıklama";
$lang['spr']			= "Spor Türü";
$lang['ev']				= "Ev Sahibi";
$lang['dep']			= "Deplasman";
$lang['thm']			= "Tahmin";
$lang['trch']			= "Tercih";
$lang['oran']			= "Oran";
$lang['iy']				= "İlk Yarı";
$lang['ms']				= "Maç Sonucu";

$lang['kupdetaylink']	= "Kupon Detayı için tıklayınız.";
$lang['kupdetay']		= "Kupon Detayı";
$lang['kupfavipt']		= "Bu Kuponu Takipten Kaldır";
$lang['kupfav']			= "Bu Kuponu Takip Et";

$lang['bykom']			= "Bayi Komisyonu";
$lang['bykomnot']		= "Not:(Bayi Müşterinin Tutan Kuponundan Keseceği Komsiyon Tutarı)";
$lang['kom']			= "Komisyon";
$lang['komsuz']			= "Komisyonsuz";
$lang['ciro']			= "Cirodan";
$lang['srk_kar']		= "Şirket Karından";

$lang['lmt']			= "Limitler";
$lang['byler']			= "Bayiler";
$lang['webler']			= "Üye";
$lang['weblmt']			= "Üye Limitleri";
$lang['weblmt2']		= "Üye Limiti";
$lang['weblmt1']		= "Üye Açabilirmi?";
$lang['siskapat']		= "Sistemi Kapat";
$lang['grsysk']			= "Girişi Yasakla";
$lang['bhsysk']			= "Bahislere Kapat";
$lang['tumscmipt']		= "Tüm Seçimleri İptal Et";
$lang['ckelime']		= "Kelimelerin geçtiği maçlar gizlensin.<br>(Virgül ile ayırınız. Örn: u17,u19) :";
$lang['evt']			= "Evet";
$lang['hyr']			= "Hayır";
$lang['oynbhs']			= "Oynanabilir Bahisler";
$lang['admler']			= "Adminler";
$lang['suadmler']		= "Süper Adminler";

$lang['bos']			= "Herhangi bir sonuç bulunamadı";
$lang['bosbhs']			= "Seçimlerinize uygun müsabaka bulunamadı";
$lang['cbos']			= "Şu anda müsabakanın bilgilerine ulaşılamıyor.";
$lang['byyok']			= "Böyle bir kullanıcı bulunamadı.";
$lang['kupedituyari']	= "böyle bir kupon yok..lütfen kontrol ediniz...";
$lang['hataolustu']		= "bir hata oluştu yeniden deneyiniz.";
$lang['bhsysk']			= "Sistem Şuanda Bahislere Kapalıdır.";

///canlı
$lang['ksure']			= "Kalan süre";
$lang['sgol']			= "Sonraki gol";
$lang['cs']				= "Çifte Şans";
$lang['ua']				= "Alt/Üst";
$lang['ust']			= "Üst";
$lang['alt']			= "Alt";
$lang['hdk']			= "Handikap";
$lang['krn']			= "Korner";
$lang['krk']			= "Kırmızı kart";
$lang['srk']			= "Sarı kart";
$lang['tpskor']			= "Toplam Skor";
$lang['kc1']			= "Kupon kontrol ediliyor";
$lang['kc2']			= "Kuponunuzda canlı bahis olduğu için kontrol edilmektedir.";

///kupon
$lang['kbos']			= "Bahisleri seçmek için ilgili oran üstüne tıklayınız";
$lang['kbaslik']		= "Bahis Kuponu";
$lang['kmiktar']		= "Bahis Miktarı";
$lang['kpok']			= "Kupon oluştur";
$lang['orsure']			= "Oran süresi doldu.";
$lang['bubasladi']		= "Bu maç başladı";
$lang['buaski']			= "Bu maç/oran askıda.";
$lang['bumcaski']		= "Bu maç şu an askıda. Bahis yapılamaz.";
$lang['mbshta']			= "Minimum bahis sayısına ulaşmadınız. %s maç daha ekleyin.";
$lang['minmac']			= "Minimum Maç sayısına ulaşmadınız. %s maç daha ekleyin.";

$lang['enaz']			= 'En az %s oranda kupon yapılabilir.';
$lang['kombinehta']		= "Canlı oyunlarla normal oyunlar kombine edilemezler. Lütfen seçimlerinizi gözden geçiriniz.";
$lang['ayncnlysk']		= "Aynı Kupon İçerisine İki Farklı Canlı Bahisten Oyun Yapamazsınız.";
$lang['tekmac']			= "Tek maç maksimum tutarı";
$lang['coklu']			= "Çoklu maçta en fazla yatırılacak tutarı";
$lang['ctekmac']		= "Canlı Tek maç maksimum tutarı";
$lang['maxorayar']		= "Maksimum oran sınırına bağlı olarak oran ayarlandı";
$lang['maxode']			= "Maksimum ödeme tutarı";
$lang['min_oran']		= "Minimum Oran";
$lang['maxoran']		= "Maksimum Oran";
$lang['yatkont']		= "Yatırılan tutarı kontrol ediniz.";
$lang['supolmaz']		= "SuperAdmin ve Admin hesapları kupon yatıramaz. Kendinize bir bayi hesabı oluşturabilirsiniz.";
$lang['bakiolmaz']		= "Bakiyeniz bu işlem için yeterli değildir.";
$lang['minbhs']			= "Minimum bahis yapma tutarı";
$lang['maxkupon']		= "Maksimum Kupon Tutar";
$lang['smbs']			= "Sabit MBS";
$lang['gcrsiz']			= "Geçersiz";
$lang['cytrmsure']		= "Canlı Yatırma Süresi";
$lang['ciyoy']			= "Canlı İlk Yarı Son Bahis";
$lang['cmsoy']			= "Canlı İkinci Yarı Son Bahis";
$lang['yzcsec']			= "Yazıcı Seçimi";
$lang['nrm']			= "Normal";
$lang['term']			= "Termal";
$lang['bnsytk']			= "Bonus Yetki";
$lang['cmcbklsure']		= "Canlı Maçın Kuponda Bekleme Süresi";
$lang['oynanamaz']		= "Kuponunuzda başlamış ya da oynanamaz maçlar var.";
$lang['minorhata']		= 'Minimum %s oranda kupon yapabilirsiniz.';
$lang['kupguncelyat']	= 'Kuponunuz En güncel Oranla Yatırılacaktır.Lütfen Yatırdıktan Sonra Kuponunuzu Kontrol ediniz...';
$lang['cengelle']		= 'Canlı Futbol Maçları Engelle';
$lang['cengelleb']		= 'Canlı Basketbol Maçlarını Engelle ';
$lang['macara']			= 'Maç arama';
$lang['aynikuponmax']	= 'Aynı Kupon Maksimum Tutar';
$lang['minmac']			= 'Minumum Maç Sayısı';
$lang['maxmac']			= 'Maksimum Maç Sayısı';
$lang['kpnkomb']		= 'Kupon Kombine';
$lang['kpnkomb1']		= '(normal maç ile canlı maç aynı kuponda kombine edilebilirmi?)';
$lang['canli_koruma']	= 'Canlı Maksimum Oran';
$lang['aynikupon']		= 'Aynı kupondan maksimum oynanabilir limite ulaştınız';
$lang['kyaz']			= 'Kupon Yatırıldı. Yazdırılsın mı?';
$lang['ktamam']			= 'Kuponunuz Yatırıldı.! Bol Şanslar.!';

$lang['admedit']			= '%s adlı Admin Düzenleme Formu';
$lang['byedit']				= '%s adlı Bayi Düzenleme Formu';
$lang['gizli']				= 'Gizli';
$lang['girbilgi']			= 'Giriş Bilgileri';
$lang['siteytk']			= 'Site Yetkisi';
$lang['sitesec']			= 'Lütfen Site seçiniz.';
$lang['usrknt']				= 'Geçerli bir kullanıcı adı giriniz';
$lang['sfrknt']				= 'Geçerli bir şifre giriniz';
$lang['kira']				= 'Lütfen Kira Süresini giriniz.';
$lang['kuptsure']			= 'Kupon İptal Süresi';
$lang['kirasure']			= 'Hesap Süresi';
$lang['krsr']				= 'Süreli';
$lang['krsr1']				= 'Süresiz';
$lang['dk']					= 'dakika';
$lang['kupon']				= 'kupon';
$lang['kuponbsl']			= 'Maç başlamış kuponda ve canlı bahislerde iptal yapılamaz';
$lang['bsltrh']				= 'Başlangıç Tarihi';
$lang['btstrh']				= 'Bitiş Tarihi';
$lang['not']				= 'Not';
$lang['email']				= 'E-Mail Adresi';
$lang['emailyazi']			= 'Not: (email adresinizi yazarsanız bu bayinin kuponları email adresinize gönderilecektir.)';
$lang['komayr']				= 'Komisyon Ayarları';
$lang['komskl']				= 'Çalışma Şekli';
$lang['ckomskl']			= 'Canlı Çalışma Şekli';

$lang['emalkntr']			= 'E-Mail Adresinizi Yalnış yazdınız. Lütfen kontrol ediniz.';
$lang['altsinir1']			= 'Alt Kullanıcı Limiti';
$lang['altsinir']			= 'Kaç tane alt bayi oluşturabilir?';
$lang['altsinirw']			= 'Kaç tane Üye oluşturabilir?';
$lang['silme_yetki']		= 'Bayi Silme Yetkisi';
$lang['yapar']				= 'Yapabilir';
$lang['yapamaz']			= 'Yapamaz';
$lang['yetkili']			= 'Yetkili';
$lang['yetkisiz']			= 'Yetki Verme';
$lang['oranduzenleme']		= 'Oran Düzenleme Yetkisi';
$lang['kupon_degistirme']	= 'Kupon Değiştirme Yetkisi';
$lang['iptal_yetki']		= 'İptal Yetkisi';
$lang['yetbaslik']			= 'Yetkileri / Yapabilecekleri';

$lang['tel']			= 'Telefon';
$lang['firma']			= 'Firma Adı';
$lang['sifre']			= 'Şifre';
$lang['user']			= 'Kullanıcı Adı';
$lang['bakiye']			= 'Bakiye';
$lang['htip']			= 'Hesap Tipi';
$lang['altbayi']		= 'Alt Bayileri';
$lang['oluszaman']		= 'Oluşturma';
$lang['gezsyf']			= 'Gezdiği Sayfa';
$lang['tryc']			= 'Tarayıcı';
$lang['songor']			= 'Son Görülme';
$lang['degis']			= 'Değiştir';
$lang['bkislm']			= 'Bakiye İşlemleri';
$lang['gecis']			= 'Geçiş Yap';
$lang['gstr']			= 'Göster';
$lang['drdr']			= 'Durdur';
$lang['bslt']			= 'Başlat';
$lang['ytkyok']			= 'Yetkiniz dışında';
$lang['ekle']			= 'Ekle';
$lang['ckr']			= 'Çıkar';
$lang['edit']			= 'Düzenle';
$lang['sil']			= 'Sil';
$lang['aktf']			= 'Aktif';
$lang['psf']			= 'Pasif';
$lang['ad']				= 'Adınız';
$lang['soyad']			= 'Soyadız';
$lang['bnk']			= 'Banka adı';
$lang['sube']			= 'Şube kodu';
$lang['hspno']			= 'Hesap Numarası';
$lang['gndr']			= 'Gönder';
$lang['tcsi']			= 'T.C. Kimlik Numaranız';
$lang['atcsi']			= 'Alıcının T.C. Kimlik Numarası';
$lang['kyt']			= 'Kaydet';
$lang['bnkhav']			= 'Banka Havalesi';
$lang['hicbir']			= 'Hiç bir zaman';
$lang['tamsil']			= 'Tamamen Sil';
$lang['ggetir']			= 'Geri Getir';
$lang['ismedit']		= 'İsmi Değiştir';
$lang['ynisimkyt']		= 'yeni ismi kaydetmek için enter tuşuna basınız';
$lang['baysilconf']		= '%s adlı kullanıcıyı ve ona bağlı alt kullanıcılar silinecektir.\nSilmek istediğinizden emin misiniz?';
$lang['baygetirconf']	= '%s adlı kullanıcı ve ona bağlı alt kullanıcılar geri getirilecektir. Emin misiniz?';
$lang['uservar']		= 'Bu kullanıcı adı önceden alınmıştır. Lütfen başka bir kullanıcı adı yazın';
$lang['userokdevam']	= 'Kullanıcı adı degistirildi. Geri getirme işlemine devam ediniz.';
$lang['sprvar']			= '%s adlı süperadmin adı şuan kullanımda.\nKullanıcı adı değişikliği yapınız..\n';
$lang['acmahak']		= 'Size tanımlanan maksimum kullanıcı limitine ulaştınız. (En fazla %s kullanıcı).\n';
$lang['admvar']			= '%s adlı admin adı şuan kullanımda.\nKullanıcı adı değişikliği yapınız.\n';
$lang['byvar']			= '%s adlı bayi adı şuan kullanımda.\nKullanıcı adı değişikliği yapınız.\n';
$lang['byvar1']			= '%s adlı kullanıcı adını başka bir bayi kullanıyor.\nKullanıcı adı değişikliğini ancak üst yöneticisi yapabilir.\n';
$lang['byonceust']		= 'bu bayiyi geri getirmek için önce üst yöneticisini geri getirmelisiniz.';

$lang['bins']			= 'Yeni Bayi Kayıt';
$lang['adins']			= 'Yeni Admin Kayıt';
$lang['webins']			= 'Üye Kayıt';
$lang['rpr']			= 'Raporlar';
$lang['grpr']			= 'Günlük Raporlar';
$lang['dialtit']		= 'Uyarı Mesajı';
$lang['msjktu']			= 'Mesaj Kutusu';
$lang['msjdel']			= 'Mesaj Silindi.';
$lang['msjsend']		= 'Mesajınız Gönderildi.';
$lang['nobos']			= 'boş alan bırakmayınız!';
$lang['newmsj']			= 'Yeni Mesaj Yaz';
$lang['newmsj1']		= 'Mesajınızı buraya yazıp , Gönder tuşuna basınız.';
$lang['bhskrl']			= 'Bahis Kuralları';
$lang['mcist']			= 'Maç İstatistikleri';
$lang['tkmist']			= 'Takım İstatistikleri';
$lang['sfredit']		= 'Şifre Değişikliği';
$lang['foranduz']		= 'Futbol Oran Düzenleme';
$lang['boranduz']		= 'Basket Oran Düzenleme';
$lang['duyru']			= 'Duyurular';
$lang['duyrunew']		= 'Yeni Duyuru Kaydı';
$lang['duyrudel']		= 'Kayıt Silinecektir. Onaylıyormusunuz?';
$lang['snclar']			= 'Sonuçlar';
$lang['istsnc']			= 'İstatistik & Sonuçlar';
$lang['tkmadi']			= 'Takım Adı';
$lang['msnclar']		= 'Sonuçlar';
$lang['iptedn']			= 'İptal Eden';
$lang['ipttalp']		= 'İptal Talepleri';
$lang['iptkupon']		= 'İptal Edilmiş Kupon Listesi';
$lang['iptkp']			= 'İptal Edilen Kuponlar';
$lang['sistd']			= 'Sistemdekiler';
$lang['sistdonl']		= 'Sistemdeki Online Bayileriniz (%s)';
$lang['gecistxt']		= 'Şu anda (%s) kullanıcısına geçiş yaptınız';
$lang['gecisgeri']		= 'GERİ DÖN';
$lang['sbygetir']		= 'Silinen Bayi Geri Getir';
$lang['gnlayr']			= 'Genel Ayarlar';

$lang['ynmsj']			= 'Yeni Mesajınız Var !..';
$lang['msjtxt']			= 'Mesaj';
$lang['msjcvp']			= 'Cevap yaz';
$lang['yniptmsj']		= 'Kupon İptal Talebi var !..';
$lang['sfredithata']	= 'bir güvenlik hatası oluştu.<br>yeniden deneyebilir veya sistem yöneticinize durumu bildirebilirsiniz.';
$lang['tekli']			= 'Tekli';
$lang['kombine']		= 'Kombine';
$lang['ikili']			= 'İkili';
$lang['3+']				= '3 Maç ve Üzeri';

$lang['kupiptlshp']		= 'Bu kuponu iptal etmek için gereken yetkiye sahip değilsiniz.';
$lang['kupiptlshp1']	= 'Kupon iptal etme süresini veya limitlerinizi aştınız.';
$lang['kupiptcnf']		= 'Kuponu iptal etmek istediğinizden emin misiniz?';
$lang['kupiptbld']		= 'Kupon İptal Bildirimi';
$lang['kupod']			= 'Kupon ödendi olarak işaretlensin mi?';
$lang['tlpgndr']		= 'Talebi Gönder';
$lang['tlpgndr1']		= 'Bu kupona ait talebinizi daha önce bildirdiniz.';
$lang['tlpok']			= 'Talebiniz Alındı.';
$lang['iptonce']		= 'Bu kuponu daha önceden iptal edilmiş.';

$lang['mcbul']		= 'Değiştirmek istediğiniz maçı bulun';
$lang['surask']		= 'Sürekli Askı';
$lang['cduz']		= 'Canlı maç düzenleme';
$lang['ligsecin']	= 'Düzenlenecek Lig';
$lang['macgstr']	= 'Maç Gösterimi';
$lang['liggstr']	= 'Lig Gösterimi';
$lang['liggiz']		= 'Bu Lig , üst yöneticiniz tarafından gizlendiği için işlem yapamazsınız.';
$lang['macgiz']		= 'Bu Maç , üst yöneticiniz tarafından gizlendiği için işlem yapamazsınız.';
$lang['tummac']		= 'Tüm maçlar için sabit düzenleme';
$lang['tumlg']		= 'Tüm ligler için sabit düzenleme';
$lang['llg']		= 'Belli bir lig için düzenleme';
$lang['tkmac']		= 'Tek bir maç için düzenleme';
$lang['aynian']		= 'Aynı anda değiştir';
$lang['tombala']	= 'Tombala';
$lang['rulet']		= 'Rulet';
$lang['slot1']		= 'Slot';
$lang['poker']		= 'Poker';
$lang['orduz']		= 'Oran Düzenlemesi';
$lang['duzsil']		= 'Düzenlemeleri Sil';
$lang['duzsilcnf']	= 'Tüm düzenlemeler silinecektir. Emin minisiz?';
$lang['tumart']		= 'Tümünü +0.05 Arttır';
$lang['tumeks']		= 'Tümünü -0.05 Düşür';
$lang['hizisl']		= 'Hızlı işlem için basılı tutun';
$lang['duztxt']		= '** Puan bazında yükseltme yapmak için 0.50 ya da 1.50 (nokta koyarak) yükseltme yapınız.<br>** Yüzde bazında yükseltme yapmak için 10, 15 (nokta koymadan) yükseltme yapınız<br>** Aynı şekilde oranları düşürmek için Puan bazında nokta koyarak, Yüzde bazında noktasız numaralandırma kullanınız.';

$lang['1-x']	= "1-X";
$lang['2-x']	= "2-X";
$lang["1-2"]	= "1-2";
 
///bunları çevir
$lang['gecyok']		= 'Bu kullanıcıya geçiş yapma hakkınız yoktur.';
$lang['tekle']		= 'eklenecek tutar';
$lang['tcikar']		= 'çıkarılacak tutar';
$lang['bislendi']		= 'Bakiye işlendi';
$lang['ttrgir']		= 'Tutar Giriniz';
$lang['dtyetrsz']		= 'Düşülecek Tutar Yetersiz';
$lang['zmnaralik']		= 'zaman aralıklarını : işareti ile ayırınız.';
$lang['stkpa']		= 'site kapatma seçeneğini seçiniz';
$lang['wbedit']		= '%s adlı Üye Düzenleme Formu';

 $lang['evet']			= "Evet";
 $lang['hayir']			= "Hayır";
 
 $lang['1alt2.5']		= "1 Alt 2.5";
 $lang['xalt2.5']		= "X Alt 2.5";
 $lang['2alt2.5']		= "2 Alt 2.5";
 
 $lang['1ust2.5']		= "1 Üst 2.5";
 $lang['xust2.5']		= "X Üst 2.5";
 $lang['2ust2.5']		= "2 Üst 2.5";
 $lang['1yener']		= "1 Yener";
 $lang['2yener']		= "2 Yener";
 $lang['golx']		= "Gol X";
 
 $lang["macsonucu"]	= "Maç Sonucu";
 $lang["evsahibi"]	= "Ev Sahibi";
 $lang["beraberlik"]	= "Beraberlik";
 $lang["deplasman"]	= "Deplasman";
 $lang["toplamgolaltust"]	= "Toplam Gol Alt/Üst";
 
 $lang["ilkyarisonucu"]	= "İlk Yarı Sonucu";
 $lang["karsilikligol"]	= "Karşılıklı Gol";
 $lang["var"]	= "Var";
 $lang["yok"]	= "Yok";
 $lang["ilkyaritoplamgolaltust"]	= "İlk Yarı Toplam Gol Alt/Üst";
 
 $lang["ilkyariberaberlikteiade"]	= "İlk Yarı Beraberlikte İade";
 $lang["handikapbahisleri"]	= "Handikap Bahisleri";
 $lang["evsahibievsahibi+1"]	= "Ev Sahibi (Ev Sahibi +1)";
 $lang["beraberlikevsahibi+1"]	= "Beraberlik (Ev Sahibi +1)";
 $lang["deplasmandeplasman-1"]	= "Deplasman (Deplasman -1)";
 $lang["evsahibievsahibi-1"]	= "Ev Sahibi (Ev Sahibi -1)";
 $lang["beraberlikevsahibi-1"]	= "Beraberlik (Ev Sahibi -1)";
 $lang["deplasmandeplasman+1"]	= "Deplasman (Deplasman +1)";
 $lang["ilkyarikarsilikligol"]	= "İlk Yarı Karşılıklı Gol";
 
 $lang["ciftesans"]	= "Çifte Şans";

 $lang["ilkyaritoplamgoltekcift"]	= "İlk Yarı Toplam Gol Tek/Çift";
 $lang["tek"]	= "Tek";
 $lang["cift"]	= "Çift";
 $lang["macsonucuvetoplamgol"]	= "Maç Sonucu ve Toplam Gol";
 $lang["12.5alt"]	= "1 2.5 Alt";
 $lang["x2.5alt"]	= "X 2.5 Alt";
 $lang["22.5alt"]	= "2 2.5 Alt";
 
 $lang["12.5ust"]	= "1 2.5 Üst";
 $lang["x2.5ust"]	= "X 2.5 Üst";
 $lang["22.5ust"]	= "2 2.5 Üst";
 $lang["evsahibive2.5alti"]	= "Ev Sahibi ve 2.5 Altı";
 $lang["beraberlikve2.5alti"]	= "Beraberlik ve 2.5 Altı";
 $lang["deplasmanve2.5alti"]	= "Deplasman ve 2.5 Altı";
 $lang["evsahibive2.5ustu"]	= "Ev Sahibi ve 2.5 Üstü";
 $lang["beraberlikve2.5ustu"]	= "Beraberlik ve 2.5 Üstü";
 $lang["deplasmanve2.5ustu"]	= "Deplasman ve 2.5 Üstü";
 $lang["beraberlikteiade"]	= "Beraberlikte İade";
 $lang["mactakinetgolsayisi"]	= "Maçtaki Net Gol Sayısı";
 $lang["1gol"]	= "1 Gol";
 $lang["2gol"]	= "2 Gol";
 $lang["3gol"]	= "3 Gol";
 $lang["4gol"]	= "4 Gol";
 $lang["5gol"]	= "5 Gol";
 $lang["6golveuzeri"]	= "6 Gol ve Üzeri";
 $lang["mactakitoplamgoller"]	= "Maçtaki Toplam Goller";
 $lang["0-1gol"]	= "0-1 Gol";
 $lang["2-3gol"]	= "2-3 Gol";
 $lang["4-5gol"]	= "4-5 Gol";
 $lang["6golveuzeri"]	= "6 Gol ve Üzeri";
 $lang["hangiyaridahacokgololur"]	= "Hangi Yarı Daha Çok Gol Olur";
 $lang["ilkyari"]	= "İlk Yarı";
 $lang["esit"]	= "Eşit";
 $lang["ikinciyari"]	= "İkinci Yarı";
 $lang["evsahibigolyemez"]	= "Ev Sahibi Gol Yemez";
 $lang["golyemez"]	= "Gol Yemez";
 $lang["golyer"]	= "Gol Yer";
 $lang["deplasmangolyemez"]	= "Deplasman Gol Yemez";

 $lang["toplamgoltekcift"]	= "Toplam Gol Tek/Çift";
 
 $lang["ikinciyaritoplamgolaltust"]	= "İkinci Yarı Toplam Gol Alt/Üst";
 
 $lang["ilkyarimacsonucu"]	= "İlk Yarı / Maç Sonucu";
 
 $lang["ilkyariciftesans"]	= "İlk Yarı Çifte Şans";
 
 $lang["macskoru"]	= "Maç Skoru";
 
 $lang["ilkyarievsahibialtust0.5"]	= "İlk Yarı Ev Sahibi Alt/Üst 0.5";
 
 $lang["ilkyarideplasmanaltust0.5"]	= "İlk Yarı Deplasman Alt/Üst 0.5";
 
 $lang["evsahibialtust1.5"]	= "Ev Sahibi Alt/Üst 1.5";

 $lang["deplasmanaltust1.5"]	= "Deplasman Alt/Üst 1.5";
 
 $lang["evsahibiherikiyaridagolatarmi?"]	= "Ev Sahibi Her Iki Yarida Gol Atar Mi?";
 
 $lang["deplasmanherikiyaridagolatarmi?"]	= "Deplasman Her Iki Yarida Gol Atar Mi?";

 $lang["ilkyaritoplamgol"]	= "İlk Yarı Toplam Gol";
 $lang["gololmaz"]	= "Gol Olmaz";
 
 $lang["2veyafazla"]	= "2 veya Fazla";
 $lang["ikinciyaritoplamgol"]	= "İkinci Yarı Toplam Gol";
 
 $lang["ikinciyarisonucu"]	= "İkinci Yarı Sonucu";

 $lang["herikidevredede1.5altolur"]	= "Her İki Devrede de 1.5 Alt Olur";

 $lang["herikidevredede1.5ustolur"]	= "Her İki Devrede de 1.5 Ust Olur";
 
 $lang["macbahsi"]	= "Maç Bahsi";

 $lang["ilkyaribahsi"]	= "İlk Yarı Bahsi";
 
 $lang["handikapbahsi"]	= "Handikap Bahsi";
 
 $lang["toplamsayialtustuzt.dahil"]	= "Toplam Sayi Alt/Üst (Uzt. Dahil)";
 $lang["alt"]	= "Alt";
 $lang["ust"]	= "Üst";
 $lang["toplamsayitekcift"]	= "Toplam Sayı Tek / Çift";
 
 $lang["ilkyarimacsonucu"]	= "İlk Yarı / Maç Sonucu";
 
 
 $lang["macsonucualtust"]	= "Maç Sonucu Alt/Üst";
 $lang["alt0.5"]	= "Alt 0.5";
 $lang["ust0.5"]	= "Üst 0.5";
 $lang["alt1.5"]	= "Alt 1.5";
 $lang["ust1.5"]	= "Üst 1.5";
 $lang["alt2.5"]	= "Alt 2.5";
 $lang["ust2.5"]	= "Üst 2.5";
 $lang["alt3.5"]	= "Alt 3.5";
 $lang["ust3.5"]	= "Üst 3.5";
 $lang["alt4.5"]	= "Alt 4.5";
 $lang["ust4.5"]	= "Üst 4.5";
 $lang["alt5.5"]	= "Alt 5.5";
 $lang["ust5.5"]	= "Üst 5.5";
 $lang["alt6.5"]	= "Alt 6.5";
 $lang["ust6.5"]	= "Üst 6.5";
 
 $lang["ilkyaritoplamgoltekcift"]	= "İlk Yarı Toplam Gol Tek/Çift";
 
 $lang["toplamgoltekcift"]	= "Toplam Gol Tek/Çift";
 
 $lang["evsahibiyadaberaberlik"]	= "Ev Sahibi ya da Beraberlik";
 $lang["evsahibiyadadeplasman"]	= "Ev Sahibi ya da Deplasman";
 $lang["deplasmanyadaberaberlik"]	= "Deplasman ya da Beraberlik";
 $lang["beraberlikteiade"]	= "Beraberlikte İade";
 
 $lang["deplasmanikiyaridadagolatar"]	= "Deplasman İki Yarıda da Gol Atar";
 
 $lang["2.yaritoplamgol"]	= "2.Yarı Toplam gol";
 $lang["0gol"]	= "0 gol";
 
 $lang["golhandikap"]	= "Gol Handikap";
 $lang["evsahibi+1"]	= "Ev Sahibi +1";
 $lang["beraberlik+1"]	= "Beraberlik +1";
 $lang["deplasman+1"]	= "Deplasman +1";
 $lang["evsahibi-1"]	= "Ev Sahibi -1";
 $lang["beraberlik-1"]	= "Beraberlik -1";
 $lang["deplasman-1"]	= "Deplasman -1";
 $lang["evsahibi+2"]	= "Ev Sahibi +2";
 $lang["beraberlik+2"]	= "Beraberlik +2";
 $lang["deplasman+2"]	= "Deplasman +2";
 $lang["evsahibi-2"]	= "Ev Sahibi -2";
 $lang["beraberlik-2"]	= "Beraberlik -2";
 $lang["deplasman-2"]	= "Deplasman -2";
 $lang["evsahibi0:1"]	= "Ev Sahibi (0:1)";
 $lang["beraberlik0:1"]	= "Beraberlik (0:1)";
 $lang["deplasman0:1"]	= "Deplasman (0:1)";
 $lang["evsahibi0:2"]	= "Ev Sahibi (0:2)";
 $lang["beraberlik0:2"]	= "Beraberlik (0:2)";
 $lang["deplasman0:2"]	= "Deplasman (0:2)";
 $lang["evsahibi1:0"]	= "Ev Sahibi (1:0)";
 $lang["beraberlik1:0"]	= "Beraberlik (1:0)";
 $lang["deplasman1:0"]	= "Deplasman (1:0)";
 $lang["hangiyaridahacokgololur"]	= "Hangi Yarı Daha Çok Gol Olur";
 $lang["ilkyari"]	= "İlk Yarı";
 $lang["esit"]	= "Eşit";
 $lang["ikinciyari"]	= "İkinci Yarı";
 $lang["macsonucuvetoplamgoller"]	= "Maç Sonucu ve Toplam Goller";
 $lang["evsahibialt2.5"]	= "Ev Sahibi Alt 2.5";
 $lang["beraberlikalt2.5"]	= "Beraberlik Alt 2.5";
 $lang["deplasmanalt2.5"]	= "Deplasman Alt 2.5";
 $lang["evsahibiust2.5"]	= "Ev Sahibi Üst 2.5";
 $lang["beraberlikust2.5"]	= "Beraberlik Üst 2.5";
 $lang["deplasmanust2.5"]	= "Deplasman Üst 2.5";
 
 $lang["toplamgolsayisi"]	= "Toplam Gol Sayısı";
 
 $lang["tam1gol"]	= "Tam 1 gol";
 $lang["tam2gol"]	= "Tam 2 gol";
 $lang["tam3gol"]	= "Tam 3 gol";
 $lang["tam4gol"]	= "Tam 4 gol";
 $lang["tam5gol"]	= "Tam 5 gol";
 $lang["tam6gol"]	= "Tam 6 gol";
 $lang["tam7gol"]	= "Tam 7 gol";
 $lang["8+"]	= "8+";
 $lang["gollerevsahibi"]	= "Goller Ev Sahibi";
 
 
 $lang["3+"]	= "3+";
 $lang["gollerdeplasman"]	= "Goller Deplasman";
 
 $lang["deplasmanilkyaritoplamgol"]	= "Deplasman İlk Yarı Toplam Gol";
 
 $lang["ilkyaritoplamgolaltust"]	= "İlk Yarı Toplam Gol Alt/Üst";
 
 $lang["evsahibiilkyaritoplamgol"]	= "Ev sahibi İlk Yarı Toplam Gol";
 
 $lang["msveikitakimdagolatar"]	= "MS ve İki Takım da Gol Atar";
 $lang["1yenergololur"]	= "1 Yener Gol Olur";
 $lang["2yenergololur"]	= "2 Yener Gol Olur";
 $lang["1yenergolyemez"]	= "1 Yener Gol Yemez";
 $lang["2yenergolyemez"]	= "2 Yener Gol Yemez";
 
 $lang["gololurberaberebiter"]	= "Gol Olur Berabere Biter";
 $lang["ikinciyaritoplamgolaltust"]	= "İkinci Yarı Toplam Gol Alt/Üst";
 
 $lang["siradakigol"]	= "Sıradaki Gol";
 $lang["1evsahibi"]	= "(1) Ev Sahibi";
 $lang["1gololmayacak"]	= "(1) Gol Olmayacak";
 $lang["1deplasman"]	= "(1) Deplasman";
 $lang["2evsahibi"]	= "(2) Ev Sahibi";
 $lang["2gololmayacak"]	= "(2) Gol Olmayacak";
 $lang["2deplasman"]	= "(2) Deplasman";
 $lang["3evsahibi"]	= "(3) Ev Sahibi";
 $lang["3gololmayacak"]	= "(3) Gol Olmayacak";
 $lang["3deplasman"]	= "(3) Deplasman";
 $lang["4evsahibi"]	= "(4) Ev Sahibi";
 $lang["4gololmayacak"]	= "(4) Gol Olmayacak";
 $lang["4deplasman"]	= "(4) Deplasman";
 $lang["5evsahibi"]	= "(5) Ev Sahibi";
 $lang["5gololmayacak"]	= "(5) Gol Olmayacak";
 $lang["5deplasman"]	= "(5) Deplasman";
 $lang["6evsahibi"]	= "(6) Ev Sahibi";
 $lang["6gololmayacak"]	= "(6) Gol Olmayacak";
 $lang["6deplasman"]	= "(6) Deplasman";
 $lang["7evsahibi"]	= "(7) Ev Sahibi";
 $lang["7gololmayacak"]	= "(7) Gol Olmayacak";
 $lang["7deplasman"]	= "(7) Deplasman";
 $lang["8evsahibi"]	= "(8) Ev Sahibi";
 $lang["8gololmayacak"]	= "(8) Gol Olmayacak";
 $lang["8deplasman"]	= "(8) Deplasman";
 $lang["karsilikligol"]	= "Karşılıklı Gol";
 
 $lang["evsahibiikiyaridadagolatar"]	= "Ev Sahibi İki Yarıda da Gol Atar";

 $lang["evsahibiilkyarialtust"]	= "Ev Sahibi İlk Yarı Alt/Üst";
 
 $lang["deplasmanilkyarialtust"]	= "Deplasman İlk Yarı Alt/Üst";
 
 $lang["evsahibimacsonucualtust"]	= "Ev Sahibi Maç Sonucu Alt/Üst";
 
 $lang["deplasmanmacsonucualtust"]	= "Deplasman Maç Sonucu Alt/Üst";

 $lang["herikiyaridadagololur"]	= "Her İki Yarıda da Gol Olur";
 $lang["olur"]	= "Olur";
 $lang["olmaz"]	= "Olmaz";
 $lang["evsahibigolyemedenkazanir"]	= "Ev Sahibi Gol Yemeden Kazanır";

 $lang["deplasmangolyemedenkazanir"]	= "Deplasman Gol Yemeden Kazanır";

 $lang["evsahibiyadaberaberlik"]	= "Ev Sahibi ya da Beraberlik";
 $lang["evsahibiyadadeplasman"]	= "Ev Sahibi ya da Deplasman";
 $lang["deplasmanyadaberaberlik"]	= "Deplasman ya da Beraberlik";
 $lang["ikinciyarisonucu"]	= "İkinci Yarı Sonucu";
 
 $lang["ikinciyariciftesans"]	= "İkinci Yarı Çifte Şans";
 $lang["evsahibiyadaberaberlik"]	= "Ev Sahibi ya da Beraberlik";
 $lang["evsahibiyadadeplasman"]	= "Ev Sahibi ya da Deplasman";
 $lang["deplasmanyadaberaberlik"]	= "Deplasman ya da Beraberlik";
 $lang["ikinciyaritoplamgoltekcift"]	= "İkinci Yarı Toplam Gol Tek/Çift";

 $lang["kalansure"]	= "Kalan süre";
 
 $lang["herhangibirtakim1golfarklakazanirmi?"]	= "Herhangi bir takım 1 gol farkla kazanır mı?";
 
 $lang["herhangibirtakim2golfarklakazanirmi?"]	= "Herhangi bir takım 2 gol farkla kazanır mı?";
 
 $lang["herhangibirtakim3golfarklakazanirmi?"]	= "Herhangi bir takım 3 gol farkla kazanır mı?";
 
 $lang["herhangibirtakim4golfarklakazanirmi?"]	= "Herhangi bir takım 4 gol farkla kazanır mı?";
 
 $lang["ilkyarisiradakigol"]	= "İlk Yarı Sıradaki Gol";
 
 $lang["ilkyarikalansure"]	= "İlk Yarı Kalan süre";
 
 $lang["macsonucunormalsure"]	= "Maç Sonucu (normal süre)";
 
 $lang["toplamskor"]	= "Toplam Skor";
 $lang["toplamskortekcift"]	= "Toplam Skor Tek/Çift";
 $lang["1.ceyrektoplamsayitekcift"]	= "1. Çeyrek Toplam Sayı Tek/Çift";
 $lang["2.ceyrektoplamsayitekcift"]	= "2. Çeyrek Toplam Sayı Tek/Çift";
 $lang["3.ceyrektoplamsayitekcift"]	= "3. Çeyrek Toplam Sayı Tek/Çift";
 $lang["4.ceyrektoplamsayitekcift"]	= "4. Çeyrek Toplam Sayı Tek/Çift";
 $lang["ilkyaritoplamskortekcift"]	= "İlk Yarı Toplam Skor Tek/Çift";
 $lang["2.yaritoplamskortekcift"]	= "2. Yarı Toplam Skor Tek/Çift";
 $lang["handikap"]	= "Handikap";
 $lang["1.ceyrektoplampuanaltust"]	= "1. Çeyrek Toplam Puan Alt/Üst";
 $lang["2.ceyrektoplampuanaltust"]	= "2. Çeyrek Toplam Puan Alt/Üst";
 $lang["3.ceyrektoplampuanaltust"]	= "3. Çeyrek Toplam Puan Alt/Üst";
 $lang["4.ceyrektoplampuanaltust"]	= "4. Çeyrek Toplam Puan Alt/Üst";
 $lang["2.yariyikimkazanir?"]	= "2. yarıyı kim kazanır?";
 $lang["3.ceyreksonucu"]	= "3. Çeyrek Sonucu";
 $lang["1.yariyikimkazanir?"]	= "1. yarıyı kim kazanır?";
 $lang["2.ceyreksonucu"]	= "2. Çeyrek Sonucu";
 $lang["4.ceyreksonucu"]	= "4. Çeyrek Sonucu";
 
 $lang["tenfazla"]	= "%s ten fazla";
 $lang["tenaz"]	= "%s ten az";
 
 $lang["denfazla"]	= "%s den fazla";
 $lang["denaz"]	= "%s den az";
 $lang["danfazla"]	= "%s dan fazla";
 $lang["danaz"]	= "%s dan az";
 
 $lang["deplasman11"]	= "Deplasman %s";
 $lang["evsahibi11"]	= "Ev Sahibi %s";
 
 ///yeniii
 
 $lang["dstk"]	= "Destek";
 $lang["odm"]	= "Ödeme Yöntemleri";
 $lang["yrd"]	= "Yardım (S.S.S)";
 $lang["szlk"]	= "Bahis Sözlüğü";
 $lang["mushiz"]	= "Müşteri Hizmetleri";
 $lang["nsl"]	= "Nasıl oynanır?";
 $lang["nsl1"]	= "Canlı yayında krupiyerlerimiz kartları dağıtmadan önce tahminlerinizi alır. İlk kartı size verir. İlk kart size geldikten sonra tekrar bir tahminde bulunabilirsiniz. Oyunun sonunda doğru tahminleriniz size para kazandırır, yanlış tahminleriniz para kaybettirir. Her parti ortalama 1 dakika kadar sürer.";
 $lang["nsl2"]	= "ÖNEMLİ:: !! Kupon yaptıktan sonra kuponun hesaplanmasını beklemeden sayfayı kapatmayınız veya yenilemeyiniz.!!!";
 $lang["cnl"]	= "Canlı Yayın";
 $lang["kasakazanir"]	= "Kasa Kazanır";
 $lang["benkazanirim"]	= "Ben Kazanırım";
 $lang["beraberlikolur"]	= "Beraberlik Olur";
 $lang["bhskpn"]	= "Bahisler Kapandı..";
 $lang["son10"]	= "Son (10) Kuponunuz";
 $lang["kuptmm"]	= "KUPONUNUZ HESAPLANDI...";
 $lang["hspbkle"]	= "!! LÜTFEN KUPONUNUZ HESAPLANINCAYA KADAR BEKLEYİNİZ VE SAYFAYI YENİLEMEYİNİZ !!";
 $lang["dusbky"]	= "Düşülecek Bakiye";
 $lang["tekprt"]	= "Tek partide ancak 1 tarafa oynayabilirsiniz.";
 $lang["hatamanyap"]	= "Bir Sorun Oluştu. Kupon Hesaplanamadı. Manuel Hesaplatınız.";
 $lang["kpnyok"]	= "Hesaplanacak Kupon Bulunamadı!";
 $lang["slot"]	= "Slot Oyun";
 $lang["tlpfrm"]	= "ÜYELİK TALEP FORMU!";
 $lang["zrnlu"]	= "Zorunlu Alanlar";
$lang["uytlpgndr"]	= "Üyelik Talep Formunu Gönder";

