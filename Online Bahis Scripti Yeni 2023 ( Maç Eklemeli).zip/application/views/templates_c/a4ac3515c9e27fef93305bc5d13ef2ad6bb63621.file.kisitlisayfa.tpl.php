<?php /* Smarty version Smarty-3.1.8, created on 2018-08-10 12:36:52
         compiled from "application/views/templates/kisitlisayfa.tpl" */ ?>
<?php /*%%SmartyHeaderCode:16524305615b6d5cb42bae49-53811037%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'a4ac3515c9e27fef93305bc5d13ef2ad6bb63621' => 
    array (
      0 => 'application/views/templates/kisitlisayfa.tpl',
      1 => 1495298277,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '16524305615b6d5cb42bae49-53811037',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_5b6d5cb42faa24_12265197',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5b6d5cb42faa24_12265197')) {function content_5b6d5cb42faa24_12265197($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ("header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>


	<div class="coupons" style="width:100%">	
	<div class="coupon-title">
		<div class="account-table-blue"><span>
			<div class="icon"><i class="fa fa-user"></i></div>
			</span>
			<p>Aradığınız sayfa bulunamadı.. !!!</p>
		</div>
		<div style="background:#ccc;font-size:20px;line-height:30px;text-align:left;padding-left:10px">
		Yetkiniz olmayan bir sayfaya ulaşıyorsunuz.<br>Lütfen yetkilendirme için sistem yöneticiniz ile görüşünüz.
		</div>
		
</div>
</div>

<?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>
<?php }} ?>