<?php /* Smarty version Smarty-3.1.8, created on 2018-08-29 19:12:57
         compiled from "application/views/templates/mobil/login.tpl" */ ?>
<?php /*%%SmartyHeaderCode:2605796495b86c609eaf477-49649187%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '8a1c36ce227bd9ee4ba37acb772665a19b3bea22' => 
    array (
      0 => 'application/views/templates/mobil/login.tpl',
      1 => 1495443492,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2605796495b86c609eaf477-49649187',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'yok' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_5b86c609f29cf0_64978657',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5b86c609f29cf0_64978657')) {function content_5b86c609f29cf0_64978657($_smarty_tpl) {?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" manifest="/manifest.mf">
<head>

<script type="text/javascript">
	var baseurl = "<?php echo base_url();?>
mobil/";
</script>
<style>

</style>

<meta name="robots" content="noindex,nofollow" />
<title><?php echo @title;?>
 Mobile</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<meta name="apple-mobile-web-app-capable" content="yes"/>
<meta name="viewport" content="width=device-width, maximum-scale=1, initial-scale=1.0, user-scalable=no"/>
<meta name="mobile-web-app-capable" content="yes"/>
<meta name="apple-mobile-web-app-status-bar-style" content="black"/>
<meta name="format-detection" content="telephone=no"/>
<meta http-equiv="x-ua-compatible" content="IE=8"/>		
<link type="text/css" rel="stylesheet" href="<?php echo base_url();?>
css/mobil/mobile.css"/>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">

<script>

function go(yer){
	window.location.href=baseurl+yer;
}
</script>
<style>

.small_table {
  background: #3d3d3d none repeat scroll 0 0;
  float: left;
  margin-left: 2.5%;
  margin-right: 2.5%;
  width: 100%;
}
.caption {
  align-items: center;
  background: #2e2e2e none repeat scroll 0 0;
  border: 1px solid #000000;
  display: flex;
  flex-direction: row;
  float: left;
  font-weight: bold;
  padding: 14px 10px;
  width: 100%;
}
.login2 form {
  background: #3d3d3d none repeat scroll 0 0;
  float: right;
  height: auto;
  width: 100%;
}
.login2 span {
  align-items: center;
  border-bottom: 1px solid #000;
  border-right: 1px solid #000;
  color: white;
  display: flex;
  flex-direction: row;
  float: left;
  height: 45px;
  padding: 14px 10px;
  width: 30%;
}
.login2 form .ahsana {
  border-bottom: 1px solid #000;
  color: black;
  float: right;
  height: 45px;
  margin: 0 auto;
  text-align: center;
  width: 70%;
}
.login2 input.username, .login2 input.password {
  background: transparent none repeat scroll 0 0;
  color: white;
  float: left;
  font: 80% "Roboto",sans-serif;
  height: 45px;
  width: 100%;
}
.login2 input {
  color: black;
  display: block;
  height: 45px;
  margin: 0 auto;
  text-align: center;
  width: auto;
}
label {
  color: #b4201b;
  float: left;
  font-weight: bold;
  padding: 0 8px;
  text-shadow: 2px 1px 0 rgba(0, 0, 0, 0.4);
  width: 100%;
}
fieldset, button, input {
  border: 0 none;
}
.login2 li {
  align-items: center;
  background: #ffffff none repeat scroll 0 0;
  display: flex;
  flex-direction: row;
  float: left;
  width: 100%;
}
.clear {
  float: left;
  height: 50px;
  margin-top: 7px;
  text-align: center;
  width: 100%;
}
* {
  box-sizing: border-box;
  list-style-type: none;
  margin: 0;
  padding: 0;
}
.login2 input.submit {
  background: #b4201b none repeat scroll 0 0;
  border: 1px solid #000;
  color: black;
  font: bold 80% "Roboto",sans-serif;
  height: 35px;
  margin-top: 4px;
  width: 100px;
}.footer {
  align-items: center;
  bottom: 0;
  box-shadow: 0 0 7px 3px rgba(0, 0, 0, 0.8);
  box-sizing: border-box;
  display: flex;
  flex-direction: row;
  height: 47px;
  justify-content: center;
  position: fixed;
  text-align: center;
  width: 100%;
}.footer .tabicon {
  width: 312px;
}.footer .tabicon li {
  color: black;
  float: left;
  margin: 3px 0 0;
  text-align: center;
  width: 78px;
}.footer .tabicon li a.active {
  color: #b4201b;
}.footer .tabicon li a {
  color: white;
  text-shadow: 0 0 2px #000;
}a {
  text-decoration: none;
}.footer .tabicon li .fa {
  font-size: 27px;
  margin-bottom: 5px;
  position: relative;
  text-align: center;
  width: 100%;
}.footer .tabicon li p {
  color: white;
  font-size: 12px;
  font-weight: normal;
  width: auto;
}ul {
  margin-top: 0px;
}.footer .tabicon li a.active {
  color: #b4201b;
}
</style>
	
</head>

<div style="left: 0px; right: 0px; z-index: 100; position: fixed; top: 0px;" class="appheader">

<div><div class="header"><div  class="icon noselect "></div><div class="text title noselect">Giriş Formu</div><div  style="padding-left:20px" class="icon logo noselect"></div></div></div></div>
<div class="clear"> </div>
<div class="small_table">
            <div class="caption">
                <div class="icon-left-x"><i class="fa fa-user fa-lg"></i></div>
                <label>Oturum</label>
            </div>
            <ul class="login2">
                <form id="form1" class="form" name="form1" method="post" action="<?php echo base_url();?>
mobil/login/giris">
                    <span>Kullanıcı Adı</span>
                    <div class="ahsana">
                        <input class="username" required="" type="text" name="username" placeholder="Kullanıcı adı">
                    </div>
                    <span>Şifre</span>
                    <div class="ahsana">
                        <input class="password" name="password" placeholder="Parola" required="" type="password">
                    </div>
                    <div class="ahsana">
                        <input class="submit" value="Giriş" type="submit">
                    </div>
                    <span></span>
					<input type="hidden" name="yer" value="<?php echo $_GET['direct'];?>
">
					<div style="padding-left:5px;color:red"><?php if ($_smarty_tpl->tpl_vars['yok']->value){?><?php echo $_smarty_tpl->tpl_vars['yok']->value;?>
<?php }?></div>
                </form>
                <li></li>
            </ul>
        </div>
<div class="clear"> </div>
<?php echo $_smarty_tpl->getSubTemplate ("mobil/footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>
<?php }} ?>