<?php /* Smarty version Smarty-3.1.8, created on 2022-09-28 02:48:55
         compiled from "application/views/templates/para_cekme.tpl" */ ?>
<?php /*%%SmartyHeaderCode:203461462863338be74f2d04-67738300%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'bb29d5b5a8df6d872a6f41e5af42d42cc8354c5a' => 
    array (
      0 => 'application/views/templates/para_cekme.tpl',
      1 => 1495629630,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '203461462863338be74f2d04-67738300',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_63338be752fb54_79393800',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_63338be752fb54_79393800')) {function content_63338be752fb54_79393800($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ("header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>


<script>
function kayit(){
	
	$.ajax({type:'POST',url:baseurl+'ayar/pcetir',data:$("form#pacek").serialize(),
	success:function(snc){
		failcont(snc);
	}	
	});
	$("form#pacek").find('input, select').val('').removeAttr('selected');
	return false;
}

</script>


<div class="menu">	
<div class="user-menu-container">
<div class="user-menu-title"><?php echo lang('trns');?>
</div>
	<?php echo $_smarty_tpl->getSubTemplate ("transfer_left.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

	
</div>
</div>
	<div class="coupons">	
	<div class="coupon-title">
		<div class="account-table-blue"><span>
			<div class="icon"><i class="fa fa-user"></i></div>
			</span>
			<p><?php echo lang('pcek');?>
</p>
		</div>
		
		<div class="para-yatirma-container">
                        <section>
                            <h3 class="eft"><?php echo lang('bnkhav');?>
</h3>
                            <?php echo lang('pyatiracik');?>

                            <a class="button mobile-form-trigger" onclick="$('.mobile-form').toggle();" style="padding:0;"><?php echo lang('pcek');?>
</a> </section>
                        <div class="mobile-form ng-scope" style="display:none">
                            <form id="pacek" method="post" onsubmit="return kayit();">
                                <div class="first">
                                    <fieldset>
                                        <label>Ad Soyad :</label>
                                        <input name="isim" maxlength="25" required="required" value="<?php echo @ad;?>
" type="text">
                                      
                                    </fieldset>
                                    <fieldset>
                                        <label><?php echo lang('tcsi');?>
 :</label>
                                        <input name="tc" maxlength="11" required="required" type="text">                                     
                                    </fieldset>
                                    <fieldset>
                                        <label><?php echo lang('iban');?>
 :</label>
                                        <input name="iban" required="required" type="text">
                                        
                                    </fieldset>
                                </div>
                                <div class="second">
                                    <fieldset>
                                        <label><?php echo lang('bnk');?>
 :</label>
                                        <input name="banka" type="text" required="required">
                                        
                                    </fieldset>
                                    <fieldset>
                                        <label><?php echo lang('sube');?>
 :</label>
                                        <input name="sube" required="required" type="text">
                                        
                                    </fieldset>
                                    <fieldset>
                                        <label><?php echo lang('hspno');?>
 :</label>
                                        <input name="hesap" maxlength="15" required="required" type="text">
                                        
                                    </fieldset>
                                </div>
                                <div class="third">
                                    <fieldset>
                                        <label><?php echo lang('ttr');?>
 :</label>
                                        <input name="tutar" maxlength="10" required="required" type="text">
                                        
                                    </fieldset>
                                    <div class="result">
                                        <button type="submit"><?php echo lang('gndr');?>
</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
</div>
</div>

<?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>
<?php }} ?>