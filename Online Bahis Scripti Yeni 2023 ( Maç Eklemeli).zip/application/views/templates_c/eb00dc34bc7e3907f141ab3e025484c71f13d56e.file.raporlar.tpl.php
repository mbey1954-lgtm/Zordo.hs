<?php /* Smarty version Smarty-3.1.8, created on 2019-01-28 22:03:06
         compiled from "application/views/templates/raporlar.tpl" */ ?>
<?php /*%%SmartyHeaderCode:8789699875c4f51ea9e4c36-79224315%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'eb00dc34bc7e3907f141ab3e025484c71f13d56e' => 
    array (
      0 => 'application/views/templates/raporlar.tpl',
      1 => 1495298306,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '8789699875c4f51ea9e4c36-79224315',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'bayilist' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_5c4f51eaa4fb64_05413700',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5c4f51eaa4fb64_05413700')) {function content_5c4f51eaa4fb64_05413700($_smarty_tpl) {?><?php if (!is_callable('smarty_modifier_date_format')) include '/home/beyplaying/public_html/system/libs/smarty/libs/plugins/modifier.date_format.php';
?><?php echo $_smarty_tpl->getSubTemplate ("header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<?php echo $_smarty_tpl->getSubTemplate ("left.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>



<script>
function asdes(order,as) {
	$("#order").val(order);	
	$("#ascdesc").val(as);
	$("#suanval").val(1);
	kouponcall();
}


function kouponcall() {
	
	loadgir("#kupons");
	var tarih1 = $("#tarih1").val();
	var tarih2 = $("#tarih2").val();
	var satir = $("#k_satir").val();
	var tip = $("#k_tip").val();	
	var userid = $("#k_user").val();
	$.post(baseurl+'raporlar/data',{userid:userid,tarih1:tarih1,tarih2:tarih2,satir:satir,tip:tip},function(data) { 
		$("#kupons").html(data.govde); 
		$("#ustgenel").html(data.msg);
	},'json');
}

$(document).ready(function(e) {
	kouponcall();	
});

</script>

<div class="coupons">	
	<div class="coupon-title">
		<div class="account-table-blue"><span>
			<div class="icon"><i class="fa fa-user"></i></div>
			</span>
			<p><?php echo lang('rpr');?>
</p>
		</div>
		<div class="account-table-gray">		
			<form >
			<?php if ($_smarty_tpl->tpl_vars['bayilist']->value){?>					
			<label><?php echo lang('byler');?>
 :</label>
			<div class="selectbox">
			<select id="k_user">
			<option value=""></option>
			<?php echo $_smarty_tpl->tpl_vars['bayilist']->value;?>

			</select>
			</div>
			<?php }?>
			<label><?php echo lang('trh');?>
 :</label>
			<input type="text" id="tarih1" value="<?php echo smarty_modifier_date_format(time(),'%d-%m-%Y');?>
" readonly>
			<input type="text" class="inputbet" id="tarih2" value="<?php echo smarty_modifier_date_format(time(),'%d-%m-%Y');?>
" readonly>
			<label><?php echo lang('tip');?>
 :</label>
			<div class="selectbox">
			<select id="k_tip">
				<option value=""><?php echo lang('hpsi');?>
</option>
				<option value="1"><?php echo lang('nrm');?>
</option>
				<option value="2"><?php echo lang('canli');?>
</option>
			</select>	
			</div>
			<label><?php echo lang('ksatir');?>
 :</label>
			<div class="selectbox">
			<select id="k_satir">
				<option value=""><?php echo lang('hpsi');?>
</option>
				<option value="1"><?php echo lang('Tekli');?>
</option>
				<option value="kombine"><?php echo lang('kombine');?>
</option>
				<option value="2"><?php echo lang('ikili');?>
</option>
				<option value="3"><?php echo lang('3+');?>
</option>
			</select>	
			</div>
			<button type="button" id="sorgu" onclick="kouponcall(1);"><?php echo lang('gtr');?>
</button>
			</form>			
		</div>
	</div>
	
	<div id="kupons" class="coupon-content"></div>
	<div id="ustgenel"></div>
	
</div>
<?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>
<?php }} ?>