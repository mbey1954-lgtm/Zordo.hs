<?php /* Smarty version Smarty-3.1.8, created on 2018-08-10 15:27:40
         compiled from "application/views/templates/casino.tpl" */ ?>
<?php /*%%SmartyHeaderCode:13914565765b6d84bc2aceb6-31631921%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '09d73db60c4ae0ad274e1ebcd150b37f5ecb2dcf' => 
    array (
      0 => 'application/views/templates/casino.tpl',
      1 => 1495553554,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '13914565765b6d84bc2aceb6-31631921',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_5b6d84bc2ef288_16627352',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5b6d84bc2ef288_16627352')) {function content_5b6d84bc2ef288_16627352($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ("header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<div class="coupons">	
	<div class="coupon-title">
		<div class="account-table-blue"><span>
			<div class="icon"><i class="fa fa-user"></i></div>
			</span>
			<p>Canlı Casino Slot Oyunu</p>
			</div>
		
		<iframe name="my-iframe" src="http://casinomass.com/data/demos/desktop/flaming-hot-egt.html" scrolling="no"  style="width:100%;height:700px" frameBorder="0"></iframe>
</div>
</div>
<?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>
<?php }} ?>