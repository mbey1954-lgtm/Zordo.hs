<?php /* Smarty version Smarty-3.1.8, created on 2018-09-23 05:44:48
         compiled from "application/views/templates/mobil/yardim.tpl" */ ?>
<?php /*%%SmartyHeaderCode:12843489035ba6fe20b23ef0-97676810%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '3a3487d5d58e46de1e3185fb7e7eac293171d5dd' => 
    array (
      0 => 'application/views/templates/mobil/yardim.tpl',
      1 => 1495377630,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '12843489035ba6fe20b23ef0-97676810',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_5ba6fe20b94a84_09267169',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5ba6fe20b94a84_09267169')) {function content_5ba6fe20b94a84_09267169($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ("mobil/header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<?php echo $_smarty_tpl->getSubTemplate ("mobil/header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>


<style>
.support-text {
  color: gray;
  float: left;
  padding: 10px;
  width: 100%;
}#myDiv1, #myDiv2, #myDiv3, #myDiv4, #myDiv5, #myDiv6, #myDiv7, #myDiv8, #myDiv9, #myDiv10, #myDiv11, #myDiv12, #myDiv13, #myDiv14, #myDiv15, #myDiv16, #myDiv17, #myDiv18, #myDiv19, #myDiv20, #myDiv21, #myDiv22, #myDiv23, #myDiv24, #myDiv25, #myDiv26, #myDiv27, #myDiv28, #myDiv29, #myDiv30, #myDiv31, #myDiv32, #myDiv33, #myDiv34 {
  height: 50px;
  margin-bottom: 0;
  width: 100%;
}.support-text h1, .bonus-text h1 {
  color: #de7b24;
  font-size: 17px;
}.support-text ol, .bonus-text ol {
  padding: 20px;
}.support-text ol li, .bonus-text ol li {
  list-style-type: decimal;
  margin-left: 20px;
  padding: 5px;
}.new-content p, .support-text p {
  color: black;
  line-height: 20px;
  margin-bottom: 10px;
  margin-top: 10px;
}#text1, #text2, #text3, #text4, #text5, #text6, #text7, #text8, #text9, #text10, #text11, #text12, #text13, #text14, #text15, #text16, #text17, #text18, #text19, #text20, #text21, #text22, #text23, #text24, #text25, #text26, #text27, #text28, #text29, #text30, #text31, #text32, #text33, #text34 {
  color: gray;
}#text1 a, #text2 a, #text3 a, #text4 a, #text5 a, #text6 a, #text7 a, #text8 a, #text9 a, #text10 a, #text11 a, #text12 a, #text13 a, #text14 a, #text15 a, #text16 a, #text17 a, #text18 a {
  color: gray;
  cursor: pointer;
  font-size: 13px;
  line-height: 20px;
  margin-left: 7px;
}
</style>
<script type="text/javascript">
	 $(window).load(function() {  $("#text1").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv1").offset().top  }, 1000);  });     $("#text2").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv2").offset().top  }, 1000);  });     $("#text3").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv3").offset().top  }, 1000);  });     $("#text4").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv4").offset().top  }, 1000);  });     $("#text5").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv5").offset().top  }, 1000);  });     $("#text6").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv6").offset().top  }, 1000);  });     $("#text7").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv7").offset().top  }, 1000);  });     $("#text8").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv8").offset().top  }, 1000);  });     $("#text9").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv9").offset().top  }, 1000);  });     $("#text10").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv10").offset().top  }, 1000);  });     $("#text11").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv11").offset().top  }, 1000);  });     $("#text12").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv12").offset().top  }, 1000);  });     $("#text13").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv13").offset().top  }, 1000);  });     $("#text14").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv14").offset().top  }, 1000);  });     $("#text15").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv15").offset().top  }, 1000);  });     $("#text16").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv16").offset().top  }, 1000);  });     $("#text17").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv17").offset().top  }, 1000);  });     $("#text18").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv18").offset().top  }, 1000);  });     $("#text19").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv19").offset().top  }, 1000);  });     $("#text20").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv20").offset().top  }, 1000);  });     $("#text21").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv21").offset().top  }, 1000);  });     $("#text22").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv22").offset().top  }, 1000);  });     $("#text23").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv23").offset().top  }, 1000);  });     $("#text24").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv24").offset().top  }, 1000);  });     $("#text25").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv25").offset().top  }, 1000);  });     $("#text26").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv26").offset().top  }, 1000);  });     $("#text27").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv27").offset().top  }, 1000);  });     $("#text28").click(function() {  $('html, body').animate({   scrollTop: $("#myDiv28").offset().top  }, 1000);  });        $("#text29").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv29").offset().top  }, 1000);  });     $("#text30").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv30").offset().top  }, 1000);  });     $("#text31").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv31").offset().top  }, 1000);  });     $("#text32").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv32").offset().top  }, 1000);  });     $("#text33").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv33").offset().top  }, 1000);  }); $('.go_top2').click(function(){ $('body,html').animate({scrollTop:0},800); });   });
    </script> 

<div style="left: 0px; right: 0px; z-index: 100; position: fixed; top: 0px;" class="appheader">
<?php echo mobilhead();?>

<div><div class="header"><div onclick="goBack();" class="icon back noselect "></div><div class="text title noselect">Yardım</div><div onclick="go('index')" style="padding-left:20px" class="icon logo noselect"></div></div></div></div>

<div class="page slide top in" id="page1"><div class="scroll_container" style=""><div class="scroll_wrapper" style="padding-top: 85px; padding-bottom: 44px;"><div class="appcontent"><div>  </div>

<div id="ticket_bodys">
<div class="edtitle " style="border: 1px solid #000"><div class="text">

<div style="font-size:20px;line-height:30px;text-align:left;padding-left:10px">
<div class="support-text">
                    <div id="text1"><i class="fa fa-angle-double-right"></i><a>1- Parolamı unuttum. Nasıl yeni bir parola alırım?</a></div>
                    <div id="text2"><i class="fa fa-angle-double-right"></i><a>2- <?php echo @title;?>
 şu anda hangi bonusları öneriyor?</a></div>
                    <div id="text3"><i class="fa fa-angle-double-right"></i><a>3- Bahis hesabıma para yatırmak istiyorum. Hangi depozito yatırma yöntemleri bulunuyor?</a></div>
                    <div id="text4"><i class="fa fa-angle-double-right"></i><a>4- Bahis hesabıma para yatırmak istiyorum. Bunun karşılığında bir ücret alınıyor mu?</a></div>
                    <div id="text5"><i class="fa fa-angle-double-right"></i><a>5- Banka havalesi yoluyla bahis hesabıma depozito yatırmak istiyorum. Bu işlemi nasıl yapabilirim ve ilgili tutar ne zaman hesabıma geçer?</a></div>
                    <div id="text6"><i class="fa fa-angle-double-right"></i><a>6- Kazandım! Paramı nasıl çekebilirim?</a></div>
                    <div id="text7"><i class="fa fa-angle-double-right"></i><a>7- Paramın banka havalesiyle bana yollanmasını istiyorum. Bu işlem kaç gün sürer?</a></div>
                    <div id="text8"><i class="fa fa-angle-double-right"></i><a>8- Bir veya daha fazla bahis kazandım! Kazançlarım hesabıma ne zaman geçecek?</a></div>
                    <div id="text9"><i class="fa fa-angle-double-right"></i><a>9- Kazanabileceğim maksimum para tutarı nedir?</a></div>
                    <div id="text10"><i class="fa fa-angle-double-right"></i><a>10- Bir bahis yapmak istiyorum. Minimum bahis tutarı nedir?</a></div>
                    <div id="text11"><i class="fa fa-angle-double-right"></i><a>11- Tek bir bahis kuponunda yapabileceğim en fazla bahis sayısı nedir?</a></div>
                    <div id="text12"><i class="fa fa-angle-double-right"></i><a>12- Bahis başvurusu nedir?</a></div>
                    <div id="text13"><i class="fa fa-angle-double-right"></i><a>13- Bahis talebi nedir?</a></div>
                    <div id="text14"><i class="fa fa-angle-double-right"></i><a>14- Nasıl bir parola talebinde bulunurum? Burada neyi göz önünde bulundurmam gerekiyor?</a></div>
                    <div id="text15"><i class="fa fa-angle-double-right"></i><a>15- Bir bahis için başvuru yollarsam ne olur?</a></div>
                    <div id="text16"><i class="fa fa-angle-double-right"></i><a>16- "Bahis limitleri için" uyarı mesaj aldım. Bu ne anlama geliyor?</a></div>
                    <div id="text17"><i class="fa fa-angle-double-right"></i><a>17- <?php echo @title;?>
'in bahis programında bulamadığım bir müsabaka, sonuç veya spora bahis yapmak istiyorum. Bu mümkün mü?</a></div>
                </div><div class="support-text">
                    <div id="myDiv1"></div>
                    <h1>1. Parolamı unuttum. Nasıl yeni bir parola alırım?</h1>
                    <p>Kullanıcı adı ve parola girişi alanlarının hemen üstündeki "Şifrenizi mi unuttunuz ?" öğesine tıklayın.
                        Kimlik doğrulama maksadıyla yeni bir parola atanmasını istemeden önce açılan sayfada kullanıcı adınızı ve doğum tarihinizi girmelisiniz.
                        Yeni parolanızı girerken büyük ve küçük harf yazımına dikkat edin.</p>
                    <a class="go_top2"><i class="fa fa-angle-double-up"></i>Yukarı / Başa Dön</a>
                    <div id="myDiv2"></div>
                    <h1>2. <?php echo @title;?>
 şu anda hangi bonusları öneriyor?</h1>
                    <p>Yardım kısmından "Bonus"a tıklayın.
                        Açılan sayfada sunulan tüm bonusların yanı sıra, geçerli bonus koşullarını bulacaksınız.</p>
                    <a class="go_top2"><i class="fa fa-angle-double-up"></i>Yukarı / Başa Dön</a>
                    <div id="myDiv3"></div>
                    <h1>3. Bahis hesabıma para yatırmak istiyorum. Hangi depozito yatırma yöntemleri bulunuyor?</h1>
                    <p>Alt metne kadar ekranı kaydırıp "Ödeme Yöntemlerine"ne tıklayın.
                        Açılan sayfada <?php echo @title;?>
'in kabul ettiği tüm ödeme yöntemlerinin yanı sıra geçerli ödeme koşullarını bulacaksınız.</p>
                    <a class="go_top2"><i class="fa fa-angle-double-up"></i>Yukarı / Başa Dön</a>
                    <div id="myDiv4"></div>
                    <h1>4. Bahis hesabıma para yatırmak istiyorum. Bunun karşılığında bir ücret alınıyor mu?</h1>
                    <p>Destek kısmından "Ödeme Yöntemlerine"ne tıklayın.
                        Açılan sayfada <?php echo @title;?>
'in kabul ettiği tüm ödeme yöntemlerinin yanı sıra <?php echo @title;?>
 tarafından alınan işlem ücretlerini bulacaksınız.
                        Lütfen ödeme sağlayıcınızın belirli koşullar altında sizden işlem ücreti alabileceğini unutmayın. Bu işlem ücretleri 
                        firmalar arasında farklılık gösterdiğinden lütfen kullandığınız sağlayıcıdan bu bilgiyi talep edin.</p>
                    <a class="go_top2"><i class="fa fa-angle-double-up"></i>Yukarı / Başa Dön</a>
                    <div id="myDiv5"></div>
                    <h1>5. Banka havalesi yoluyla bahis hesabıma depozito yatırmak istiyorum. Bu işlemi nasıl yapabilirim ve ilgili tutar ne zaman hesabıma geçer?</h1>
                    <p>Detek kısmından "Ödeme Yöntemlerine"ne tıklayın.
                        Açılan sayfa "Banka Havalesi" seçeneğini seçin.
                        "Şimdi Öde"ye tıkladıktan sonra ekrandaki adımları takip edin.
                        Lütfen havale işlemlerinin üç ila yedi iş günü sürebileceğini unutmayın.
                        Depozito hesabınıza geçer geçmez muhasebe departmanımızdan bir e-posta alacaksınız..</p>
                    <a class="go_top2"><i class="fa fa-angle-double-up"></i>Yukarı / Başa Dön</a>
                    <div id="myDiv6"></div>
                    <h1>6. Kazandım! Paramı nasıl çekebilirim?</h1>
                    <p>Alt metne kadar ekranı kaydırıp "Ödeme Yöntemlerine"ne tıklayın.
                        Açılan sayfada <?php echo @title;?>
'in kabul ettiği tüm ödeme ve para çekimi yöntemlerinin yanı sıra geçerli ödeme koşullarını bulacaksınız.
                        Dilediğiniz para çekme yöntemini seçin.
                        "Şimdi Çek"e tıkladıktan sonra ekrandaki adımları takip edin.
                        <?php echo @title;?>
 ödeme işlemini tamamladığı anda muhasebe departmanımızdan bir e-posta alacaksınız.</p>
                    <a class="go_top2"><i class="fa fa-angle-double-up"></i>Yukarı / Başa Dön</a>
                    <div id="myDiv7"></div>
                    <h1>7. Paramın banka havalesiyle bana yollanmasını istiyorum. Bu işlem kaç gün sürer?</h1>
                    <p>Havale işlemleri Türkiye içinde bir ile üç gün iş günü sürebilir.
                        Havale işlemleri Avrupa Birliği içinde üç ila yedi iş günü sürebilir.
                        Avrupa Birliği dışındaki ülkelere yapılan havale işlemleri çok daha uzun sürebilir.
                        <?php echo @title;?>
 banka havalelerinin kaç günde tamamlanacağı konusunda hiçbir etkiye sahip değildir.</p>
                    <a class="go_top2"><i class="fa fa-angle-double-up"></i>Yukarı / Başa Dön</a>
                    <div id="myDiv8"></div>
                    <h1>8. Bir veya daha fazla bahis kazandım! Kazançlarım hesabıma ne zaman geçecek?</h1>
                    <p>Bahis kuponlarını en hızlı biçimde işlemek için elimizden geleni yaparız. Ne var ki, ilgili spor etkinliğinin resmi sonuçları elimize ulaşana dek kuponlar tam olarak değerlendirilemez.
                        Değerlendirme süresi spordan spora değişebilir.</p>
                    <a class="go_top2"><i class="fa fa-angle-double-up"></i>Yukarı / Başa Dön</a>
                    <div id="myDiv9"></div>
                    <h1>9. Kazanabileceğim maksimum para tutarı nedir?</h1>
                    <p>Kazancınız değişkenlik gösterebilmektedir.
                        Spor bahisleri - Slot - Casino - Tombala alanlarında kazançlar birbirinden farklıdır.
                        Maksimum kazanabileceğiniz para tüm oyun alanlarında belirtilmiştir.</p>
                    <a class="go_top2"><i class="fa fa-angle-double-up"></i>Yukarı / Başa Dön</a>
                    <div id="myDiv10"></div>
                    <h1>10. Bir bahis yapmak istiyorum. Minimum bahis tutarı nedir?</h1>
                    <p>Tekli bahislerde bahis başına minimum bahis tutarı 1.00 TL.'dur.
                        Sistem ve çoklu bahislerde kombinasyon başına minimum bahis tutarı 0.10 TL.'dir.</p>
                    <a class="go_top2"><i class="fa fa-angle-double-up"></i>Yukarı / Başa Dön</a>
                    <div id="myDiv11"></div>
                    <h1>11. Tek bir bahis kuponunda yapabileceğim en fazla bahis sayısı nedir?</h1>
                    <p>Tek bir bahis kuponunda en fazla 20 etkinliğie bahis yapabilirsiniz.</p>
                    <a class="go_top2"><i class="fa fa-angle-double-up"></i>Yukarı / Başa Dön</a>
                    <div id="myDiv12"></div>
                    <h1>12. Bahis başvurusu nedir?</h1>
                    <p>Belirlenen limitler doğrultusunda otomatik sistemimiz aracılığıyla kabul edilmeyen bir 
                        bahis için manüel olarak başvurma olanağını size sunmaktayız. Bahis kayıt ekibimiz, başvurunuzu kontrol eder 
                        ve bahsin kabul edilip edilmeyeceğine karar verir.</p>
                    <p>ÖNEMLİ: Bahis kayıt ekibimiz tarafından onaylanan bahis başvurusu derhal bağlayıcı bahis olarak kapatılır ve yatırılan tutar bahis hesabından düşürülür. Bu durumda, yapılan başvuru için bahis hesabınızda yeteri kadar bakiye mevcut olduğundan emin olmanız gerekmektedir. Seçilen bahis tutarını karşılayacak bakiye mevcut değilse, başvuru başka herhangi bir bilgiye ihtiyaç duyulmaksızın reddedilir.</p>
                    <p>LÜTFEN GÖZ ÖNÜNDE BULUNDURUNUZ: Bahis başvurusunu 08.00 ve 00.00 saatleri arasında gerçekleştirebilirsiniz.</p>
                    <a class="go_top2"><i class="fa fa-angle-double-up"></i>Yukarı / Başa Dön</a>
                    <div id="myDiv13"></div>
                    <h1>13. Bahis talebi nedir?</h1>
                    <p>Bir bahis talebi yaparak sınırlar nedeniyle otomatik sistemimizin reddettiği bir bahse manuel başvurabilirsiniz. Talep daha sonra bahsin kabul edilip edilemeyeceğine karar veren bahis alımı ekibimiz tarafından manuel olarak kontrol edilir.
                        Not: Bahis alım ekibimiz tarafından onaylanan bir bahis talebi anında geçerli bir bahis sayılır ve bahis tutarı bahis hesabınızdan düşülür. Bu nedenle gönderilen bahis talebi için bahis hesabınızda yeterli kredi olduğundan emin olmanız gereklidir. Geçerli bakiyeniz istenen bahis tutarını karşılamaya yetmiyorsa bahis talebiniz reddedilecektir.
                        Lütfen bahis taleplerinin yalnızca 08:00 ve 00:00 arasında gönderilebileceğini unutmayın.</p>
                    <a class="go_top2"><i class="fa fa-angle-double-up"></i>Yukarı / Başa Dön</a>
                    <div id="myDiv14"></div>
                    <h1>14. Nasıl bir parola talebinde bulunurum? Burada neyi göz önünde bulundurmam gerekiyor?</h1>
                    <p>Bir bahis koyarak veya bahis tutarını arttırarak bir sınıra ulaştığınızda bahis kuponunda görüntülenen bir mesajla bilgi sahibi olacaksınız. Tüm ödeme yöntemlerinin mümkün olmadığı hallerde aşağıdakileri deneyebilirsiniz.
                        Bahis miktarını ayarlayın: Bahsiniz için maksimum olası bahis tutarı görüntülenir ve bunu bahis tutarı olarak kabul etmeyi seçebilirsiniz. Daha sonra düşürülen bahis tutarıyla bahis yapılır.
                        Bir bahse başvurun. Bahis alım ekibimize başvurarak dilediğiniz bahis tutarıyla manuel olarak bir bahse başvurabilirsiniz. Lütfen belirli koşullar altında bahis düşük bir bahis tutarıyla onaylanacaktır. Bahis talebini göndererek bu olası düşürmeyi kabul edersiniz.
                        Kalan tutarlar üzerindeki bahis tutarları ve bahis taleplerini düşürün: Bahsiniz için maksimum olası bahis tutarı görüntülenir ve bunu bahis tutarı olarak kabul etmeyi seçebilirsiniz. İstenen orijinal bahis tutarının farkı için bahis bahis alımı ekibimizle uygulanır. Lütfen belirli koşullar altında bahis düşük bir bahis tutarıyla onaylanacaktır. Bahis talebini göndererek bu olası düşürmeyi kabul edersiniz.
                        Örnek: 600.00 TL'lik bir bahis yapmak istiyorsanız fakat sınıra ulaştınız. 400.00 TL.'lik maksimum izin verilen bahis tutarını yapın ve kalan 200.00 TL. için ekstra bahis isteğinde bulunun. Bahis alımı ekibimiz 200.00 TL.'lik bu bahsin kabul edilip edilmeyeceğine, bahis tutarının düşürülüp düşürülmeyeceğine veya bahsin kesinlikle kabul edilip edilmeyeceğine karar verir.
                        Lütfen bahis taleplerinin yalnızca 08:00 ve 00:00 arasında gönderilebileceğini unutmayın.</p>
                    <a class="go_top2"><i class="fa fa-angle-double-up"></i>Yukarı / Başa Dön</a>
                    <div id="myDiv15"></div>
                    <h1>15. Bir bahis için başvuru yollarsam ne olur?</h1>
                    <p>Bahis talebiniz anında bahis alımı ekibimiz tarafından kontrol edilir. İstek yapılan bir bahsin durumunu dilediğiniz zaman "Kuponlar" sekmesi altında görüntüleyebilirsiniz. Aşağıdaki durumlar olasıdır:
                        İstek bekliyor: Bahis isteğiniz halen kontrol ediliyor. Bahsi iptal edebilirsiniz.
                        Aç: Bahsiniz kontrol edildi ve bahis alımı ekibimiz tarafından kabul edildi. Yukarıdaki durumun yanı sıra, istenen bahis tutarının düşürülme ihtimali de vardır. Bahis kuponu numarasına tıklamak sizi bahis tutarının listelendiği bahis kuponu bilgilerine götürür.
                        Reddedildi: Bahsiniz kontrol edildi ve bahis alımı ekibimiz tarafından kabul edilmedi. Ret nedenini bahis kuponu bilgilerinde görüntüleyebilirsiniz.</p>
                    <a class="go_top2"><i class="fa fa-angle-double-up"></i>Yukarı / Başa Dön</a>
                    <div id="myDiv16"></div>
                    <h1>16. "Bahis limitleri için" uyarı mesaj aldım. Bu ne anlama geliyor?</h1>
                    <p>Risk yönetimi ekibimiz sürekli olarak tüm bahis sınırlarını izler ve onları 
                        ayarlayarak bahis isteklerini işler. Bu işlevler bahis yapılacak oyun ve sonuç, konulmuş 
                        olan bahis tutarları ve benzeri birçok parametreye tabidir. Ne var ki, sürekli değişikliklerden ötürü hiçbir genel ifade yapılamaz.</p>
                    <a class="go_top2"><i class="fa fa-angle-double-up"></i>Yukarı / Başa Dön</a>
                    <div id="myDiv17"></div>
                    <h1>17. <?php echo @title;?>
'in bahis programında bulamadığım bir müsabaka, sonuç veya spora bahis yapmak istiyorum. Bu mümkün mü?</h1>
                    <p>Her hafta en yüksek oranlarla 5.000 bahis etkinliği sunarız. Ayrıca her bahis etkinliği için çok yüksek oranlar sunarız. 
                        Ne var ki, bahis programlarımıza tüm müsabaka ve sporları dahil edemiyoruz. Memnuniyetiniz önceliğimiz olduğundan isteklerinizi 
                        bizim için önemlidir ve sizi dinlemek isteriz. Bu nedenle lütfen "Müteri Hizmetleri"ne tıklayarak bize önerilerinizi gönderin. 
                        Ancak; önerinizin uygulamaya konulacağını garanti edemiyoruz.</p>
                    <a class="go_top2"><i class="fa fa-angle-double-up"></i>Yukarı / Başa Dön</a> </div>
</div>

</div></div>

</div>
<div style="height:20px;">&nbsp;</div></div></div></div></div>

<?php echo $_smarty_tpl->getSubTemplate ("mobil/footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>
<?php }} ?>