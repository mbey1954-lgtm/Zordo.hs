<?php /* Smarty version Smarty-3.1.8, created on 2018-09-08 10:48:16
         compiled from "application/views/templates/sifremi_unuttum.tpl" */ ?>
<?php /*%%SmartyHeaderCode:8127985925b937ec04561a9-24604534%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'd27ea0ddb3fa30243524ca8adbe64c8371edbea1' => 
    array (
      0 => 'application/views/templates/sifremi_unuttum.tpl',
      1 => 1495441947,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '8127985925b937ec04561a9-24604534',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'yok' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_5b937ec04ba676_02825856',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5b937ec04ba676_02825856')) {function content_5b937ec04ba676_02825856($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ("header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<?php echo $_smarty_tpl->getSubTemplate ("left1.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>


<main>
<div class="table-container bulten">

	<div class="coupon-title">
		<div class="account-table-blue"><span>
			<div class="icon"><i class="fa fa-user"></i></div>
			</span>
			<p><?php echo lang('sifrhtrl');?>
</p>
		</div>		
		<div style="background:#ccc">
		<form id="form1" class="form" name="form1" method="post" action="<?php echo base_url();?>
info/sifrehatirlat">
		<div class="" style="margin: 5px"><fieldset><input class="username" required="" type="text" name="email" placeholder="E-Mail Adresiniz" style="background: rgba(0, 0, 0, 0) linear-gradient(to top, #8c1c17 0%, #b4201b 100%) repeat scroll 0 0;
color: #d9d9d9;
display: inline-block;
font-size: 11px;
font-weight: bold;
margin: 2px 0;
opacity: 1;
outline: medium none;
padding: 4px;
width: 217px;"><button type="submit" class="btn" value="Şifremi Unuttum">Şifremi Unuttum</button></fieldset>
<div style="padding-left:5px;color:red"><?php if ($_smarty_tpl->tpl_vars['yok']->value){?><?php echo $_smarty_tpl->tpl_vars['yok']->value;?>
<?php }?></div>
</div></form>
		</div>
		

</div>
</div>
</main>

<?php echo $_smarty_tpl->getSubTemplate ("right.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>
<?php }} ?>