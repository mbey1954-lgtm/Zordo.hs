<?php /* Smarty version Smarty-3.1.8, created on 2022-09-15 19:24:00
         compiled from "application/views/templates/canli.tpl" */ ?>
<?php /*%%SmartyHeaderCode:2236783345b6d5cf9592144-99266526%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '8b640904676e3d22e1c3d6da6cc90c1af8a69800' => 
    array (
      0 => 'application/views/templates/canli.tpl',
      1 => 1663259033,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2236783345b6d5cf9592144-99266526',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_5b6d5cf961af80_12159006',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5b6d5cf961af80_12159006')) {function content_5b6d5cf961af80_12159006($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ("header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>



<script>
var dongu,tbl='';

function liveupd(tip) {
	clearInterval(dongu);
	var evidler=$("#eventler").val();
	var varmi;
	if(evidler){varmi=1;}else{varmi=0;}
	if(tip==1){
		tbl='';
		$('.tipyaz').text("<?php echo lang('canli');?>
 - <?php echo lang('futbol');?>
");
		$('.hngf').addClass('active');
		$('.hngb').removeClass('active');
	}else if(tip==2){
		tbl='b';
		$('.tipyaz').text("<?php echo lang('canli');?>
 - <?php echo lang('basket');?>
");
		$('.hngb').addClass('active');
		$('.hngf').removeClass('active');
	}
	$.post(baseurl+'canlibahis'+tbl+'/livelist/',{eventler:evidler},function(data) {		
		$("#canliust").html(data.ust);
		setTimeout(function(){
			$('.icoran').removeClass('backgroundGreen').removeClass('backgroundRed');
			$('.ratio-box').removeClass('backgroundGreen').removeClass('backgroundRed');
		},2000);
	},'json');
	basla();
}

function orkapat(eventid){
	$('#betdetail_'+eventid).hide();$('#tumac'+eventid).removeClass('extra-but-slcted-orange');
	$("#eventler").val('');
}

function oran_ac(gelenmacid,e){
	clearInterval(dongu);
	$(".orkapatall").not('#betdetail_'+gelenmacid).hide();
	$(".oranstil").removeClass('extra-but-slcted-orange');
	if(document.getElementById('betdetail_'+gelenmacid).style.display=='block'){
		$("#tumac"+gelenmacid).removeClass('extra-but-slcted-orange');
		$("#eventler").val('');
		document.getElementById('betdetail_'+gelenmacid).style.display='none';
	}else{
		loadgir('#betdetail_'+gelenmacid);
		document.getElementById('betdetail_'+gelenmacid).style.display='block';
		$("#eventler").val(gelenmacid);
		$("#tumac"+gelenmacid).addClass('extra-but-slcted-orange');
		$.ajax({
			type:'POST',
			data:{x:$('#x_'+gelenmacid).val()},
			url:baseurl+'canlibahis'+tbl+'/liveodds/'+gelenmacid+'/0',
			complete:function(jqXHR){
				document.getElementById('betdetail_'+gelenmacid).innerHTML=jqXHR.responseText;
			}
		});
	}
	basla();
}

function canliekle(varo) {

	$.post(baseurl+'kupon/liveadd/',{warrior:varo},function(data) { 
		if(data=="6") { failcont("<?php echo lang('orsure');?>
"); } else
		if(data=="5") { failcont("<?php echo lang('ayncnlysk');?>
");} else
		if(data=="4") { failcont("<?php echo lang('bhsysk');?>
");} else
		if(data=="1") { kuponguncelle(); }
	});
}
function canliekleb(varo) {

	$.post(baseurl+'kupon/liveaddb/',{warrior:varo},function(data) { 
		if(data=="5") { failcont("<?php echo lang('ayncnlysk');?>
");} else
		if(data=="4") { failcont("<?php echo lang('bhsysk');?>
");} else
		if(data=="1") { kuponguncelle(); }
	});
}
function loadgelecek(){
	
	$.post(baseurl+'canlibahis/livegelecek',function(data) {		
		$("#gelecek").html(data);	
	});	
}

function tvac(veri) {
	
	$("#tvdiv").html(''); 
	$("#tvdiv").html('<iframe id="video-player" style="border:1px #ccc solid;" src="'+veri+'" scrolling="no" frameborder="1" marginheight="0px" marginwidth="0px" height="360px" width="678px"></iframe>'); 
	$( "#tvdiv" ).dialog({
		modal: false,
		position:['top',30],
		width: 683,
		height: 400,
		close : function(){
		 $( "#tvdiv" ).html('');
		}
	});
}

liveupd();
kuponguncelle();
/*loadgelecek();*/

jQuery(function() {
	$("#eventler").val('');
	loadgir("#canliust");
	$("#videoac").live( "click", function(event) {	
		event.stopImmediatePropagation();
		var anurl = $(this).attr('rel');
		tvac(anurl);
		
	});
	
});

function basla(){
	dongu=setInterval(function(){ 
		liveupd();
	}, 10000);
}
basla();

</script>

<div id="tvdiv" title="Canlı Anlatım" style="display:none"></div>
<div class="live-container">
<div class="live-table-container">
	<div class="tabs">
		<input type="hidden" id="eventler">
		<ul>
			<li onclick="liveupd(1)" class="hngf active"><div class="icon icon-1" style="margin: -2px 2px 0 0"></div> <?php echo lang('futbol');?>
</li>
			<?php if (@canlibahisb=='1'&&@canliyasakb=='0'){?>
			<li onclick="liveupd(2)" class="hngb"><div class="icon icon-2" style="margin: -2px 2px 0 0"></div> <?php echo lang('basket');?>
</li>
			<?php }?>
		</ul>
	</div>
	<div class="tab_container">
		<div class="tab_content">
			<div class="live-title">
				<div class="icon icon-1"></div>
				<section class="tipyaz"><?php echo lang('canli');?>
 - <?php echo lang('futbol');?>
</section>
			</div>
			<div id="canliust"></div>
		</div>	
	</div>	
</div>	
</div>

<?php echo $_smarty_tpl->getSubTemplate ("right.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>
<?php }} ?>