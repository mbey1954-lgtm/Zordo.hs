<?php /* Smarty version Smarty-3.1.8, created on 2018-08-10 12:36:51
         compiled from "application/views/templates/ana.tpl" */ ?>
<?php /*%%SmartyHeaderCode:19782763905b6d5cb356dc94-46124449%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '92880a04654fb1ad931eb516fc05ea83638146b9' => 
    array (
      0 => 'application/views/templates/ana.tpl',
      1 => 1495549354,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '19782763905b6d5cb356dc94-46124449',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_5b6d5cb35e1628_47322576',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5b6d5cb35e1628_47322576')) {function content_5b6d5cb35e1628_47322576($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ("header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<?php echo $_smarty_tpl->getSubTemplate ("left1.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<link rel="stylesheet" href="<?php echo base_url();?>
css/slider.css">
<script type="text/javascript" src="<?php echo base_url();?>
js/jquery.nivo.slider.pack.js"></script>

<script>

function ligler() {
	$.post(baseurl+'home/ligler/1',function(data) {	
		if(data.f){$('#ligler').show();}
		$("#ligler").html(data.f);
	}, "json");
	$('html, body').animate({ scrollTop: $("body").offset().top }, 500);
}
function PuanDurumu(id,id1) {	

	$.get(baseurl+'home/puandurumu/'+id+'/'+id1,function(data) {	
		$( ".puan" ).dialog({
		  modal: true,
		  width: 680,
		  position:['top',30],
		  close : function(){
			 $( ".puan" ).html('');
		  }
		});
		$(".puan").html(data);
	});
}	
function loadbulten(ligid){

	var takim = $("#takimara").val(); var kod = $("#mac_kodu").val(); var tarih = $("#tarihb").val();
	var saat = $("#saat").val(); 
	loadgir(".bulten");
	
	$.post(baseurl+'home/bulten/',{duelmi:0,ligid:ligid,takim:takim,tarih:tarih,kod:kod,saat:saat},function(data) {
		
		var arayi = {};
		var byaz ='';
		
		if(data.yok){
			byaz +="<div class='bos'><?php echo lang('bosbhs');?>
</div>";
			kuponguncelle(1);
		}else{
		
		$.each(data,function(lig,d1){
				var ayr=lig.split('|');
				/*if(ayr[2]!=0){
					var parca=ayr[2].split("-");
					var puan='<a href="javascript:PuanDurumu('+parca[0]+','+parca[1]+');void(0);" title="Puan Durumu"><img width="20" height="20" style="margin-right: 5px; width: 20px; height: 20px; border: 0px none; float: right; margin-top: 3px;" src="/images/results.png"></a>';
				}else{
					var puan ='';
				}*/
				byaz +='<div><div><div class="general-table-title-blue"><div class="icon icon-1"></div><p>'+ayr[0]+'</p></div> <div class="general-subtitle-gray"><ul><li><span class="icon-time"></span></li><li><i class="fa fa-flag"></i></li><li></li><li> <strong ><?php echo lang("thm");?>
</strong> <span>1</span> <span>X</span> <span>2</span> </li><li> <strong ><?php echo lang("ua");?>
</strong> <span ><?php echo lang("alt");?>
</span> <span ><?php echo lang("ust");?>
</span> </li><li><span class="icon-mini-statistic"></span></li><li>+</li></ul></div></div>';
				
				$.each(d1,function(v,d2){
					if(d2.mac_kodu){var kyaz=d2.mac_kodu;}else{var kyaz='<font color="#fff">-</font>';}	
					if(v % 2 == 0){var even='even';}else{var even='';}
					byaz +='<ul class="match-list-default zebra">  <li>'+d2.gun+' '+d2.st+'</li><li>'+d2.mac_kodu+'</li><li><em class="xcard"></em> <span class="t1">'+d2.ev_takim+'</span> <span class="score">-:-</span><em class="xcard"></em> <span class="t2">'+d2.konuk_takim+'</span> </li>  <li><a class="ratio-box" class="qbut all'+d2.id+'-'+d2.tipi+'" onclick="kupon(\''+d2.evk+'\');" id="'+d2.id+'-1-'+d2.tipi+'" href="javascript:;"><span>'+d2.ev+'</span></a> <a class="ratio-box" class="qbut all'+d2.id+'-'+d2.tipi+'" onclick="kupon(\''+d2.bk+'\');" id="'+d2.id+'-2-'+d2.tipi+'" href="javascript:;"><span>'+d2.brb+'</span></a> <a class="ratio-box" class="qbut all'+d2.id+'-'+d2.tipi+'" onclick="kupon(\''+d2.kk+'\');" id="'+d2.id+'-3-'+d2.tipi+'" href="javascript:;"><span>'+d2.knk+'</span></a> </li> <li><a class="ratio-box" class="qbut all'+d2.id+'-'+d2.tipi+'" onclick="kupon(\''+d2.a25k+'\');" id="'+d2.id+'-6-'+d2.tipi+'" href="javascript:;"><span>'+d2.a25+'</span></a> <a class="ratio-box" class="qbut all'+d2.id+'-'+d2.tipi+'" onclick="kupon(\''+d2.u25k+'\');" id="'+d2.id+'-7-'+d2.tipi+'" href="javascript:;"><span>'+d2.u25+'</span></a> </li><li>';    
					if(d2.iddaa_kodu){
					/*byaz +='<a class="istatistik fancybox.iframe" href="https://tuttur.mackolik.com/Advanced/Football/Comparison/Default.aspx?iddaaId='+d2.iddaa_kodu+'"><span class="icon-istatistik"><i class="fa fa-signal"></i></span></a>';*/
					}
					byaz +='</li><li class="extra-but" onclick="mdf(\''+d2.id+'\',\'\');" id="tumac'+d2.id+'"><span>+'+d2.orsayi+'</span></li></ul><div id="betdetail_'+d2.id+'" style="display: none;"></div>';
				});
				byaz+='</div>';
			});
			ligler();
			kuponguncelle(1);
		}
		$(".bulten").html(byaz);
	}, "json");	
}	


$(document).ready(function(e) {
	
	loadbulten();
	
	$('#flig').live( "click", function() {
		$('#ligler').slideToggle('slow');             
	});
		
	$('#takimara').live( "keyup", function() {
		var mackodu = $("#takimara").val();
		if(mackodu.length>2) { 
			loadbulten();
		}else if(mackodu.length<1) { 
			loadbulten(); 		
		}
	});


	$('#mac_kodu').live( "keyup", function() {
		var mackodu = $("#mac_kodu").val();
		if(mackodu.length>2) { 
			loadbulten();
		}else if(mackodu.length<1) { 
			loadbulten(); 		
		}
	});
	$('#main_slider').nivoSlider({
		effect: 'slideInLeft',			
		animSpeed:700,
		pauseTime:5000,
		startSlide:0,
		slices:10,
		directionNav:false,
		directionNavHide:false,
		controlNav:true,			
		controlNavThumbs:false,			
		keyboardNav:true,			
		pauseOnHover:true,			
		captionOpacity:0.8,			
	}); 
});
	
</script>


<main>
 <div id="slide-main">
	  <div id="slider-wrapper">
		<div class="slider mainback"> <img src="<?php if (@tema==1){?>/images/mainfront1.png<?php }else{ ?>/images/mainfront.png<?php }?>" alt="" title=""/></div>
		<div id="main_slider" class="nivoSlider"> 
		<img src="/images/mainslider01.jpg" title="#caption1" alt="" />
		<img src="/images/mainslider03.jpg" title="#caption2" alt="" />
		<img src="/images/mainslider02.jpg" title="#caption3" alt="" /> </div>
	  </div>
	  <div id="caption1" class="nivo-html-caption">
		<div class="nivo-title">
		  <label>Canlı Sporlar</label>
		  <p>Yüksek oranlarla oynayarak kuponunu<br>
			oluştur ve kazanmaya başla.Çeşitli<br>
			sporlada kazanma şansını arttır.</p>
		  <a class="actionbutton" href="<?php echo base_url();?>
canlibahis">Bahis Yap!</a> </div>
	  </div>
	  <div id="caption2" class="nivo-html-caption">
		<div class="nivo-title">
		  <label>Canlı Tombala</label>
		  <p>Canlı Tombala heyecanını canlı odalarda<br>
			yaşa.Tombala Kartlarında  sanşını dene.</p>
		  <a class="actionbutton" href="<?php echo base_url();?>
ayar/tombala">Hemen Oyna!</a> </div>
	  </div>
	  <div id="caption3" class="nivo-html-caption">
		<div class="nivo-title">
		  <label>Canlı Poker</label>
		  <p>Canlı Poker heyecanını canlı masalarda<br>
			yaşa.Poker oyunların da sanşını dene.</p>
		  <a class="actionbutton" href="<?php echo base_url();?>
ayar/poker">Hemen Oyna!</a> </div>
	  </div>
  </div>
<div class="table-container bulten"></div>
</main>

<?php echo $_smarty_tpl->getSubTemplate ("right.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>
<?php }} ?>