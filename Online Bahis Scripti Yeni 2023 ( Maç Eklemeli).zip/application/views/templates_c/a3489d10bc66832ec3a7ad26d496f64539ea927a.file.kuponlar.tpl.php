<?php /* Smarty version Smarty-3.1.8, created on 2018-09-14 23:47:17
         compiled from "application/views/templates/kuponlar.tpl" */ ?>
<?php /*%%SmartyHeaderCode:12299584125b9c1e558c0ed4-46055289%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'a3489d10bc66832ec3a7ad26d496f64539ea927a' => 
    array (
      0 => 'application/views/templates/kuponlar.tpl',
      1 => 1495298281,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '12299584125b9c1e558c0ed4-46055289',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'bayilist' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_5b9c1e55988d78_54313883',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5b9c1e55988d78_54313883')) {function content_5b9c1e55988d78_54313883($_smarty_tpl) {?><?php if (!is_callable('smarty_modifier_date_format')) include '/home/beyplaying/public_html/system/libs/smarty/libs/plugins/modifier.date_format.php';
?><?php echo $_smarty_tpl->getSubTemplate ("header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>




<script>
function asdes(order,as) {
	$("#order").val(order);	
	$("#ascdesc").val(as);
	$("#suanval").val(1);
	kouponcall(1);
}
function AddFav(ticketid,fav) {
	loadgir("#kupons");
	param="ticketID="+ticketid;
	param+="&fav="+fav;
	$.ajax({
		type:'POST',
		url:baseurl+'kuponlar/kuponfavori',
		data:param,
		complete:function(jqXHR){			
			kouponcall(0);
		}
	});
}
function kupon_iptal(id) {

	if(confirm(id+" <?php echo lang('kupiptcnf');?>
")) {

	$.post(baseurl+'kuponlar/kuponiptal',{id:id},function(data) { 
	if(data=="1") { failcont("<?php echo lang('kupiptlshp');?>
"); } else
	if(data=="2") { failcont("<?php echo lang('iptonce');?>
"); } else
	if(data=="3") { failcont("<?php echo lang('kupiptlshp1');?>
"); } else {
		kouponcall(5);
	}
	});
	}
}

function kupon_iptal_bildir(id) {
	
	var iptmsg = $("#iptmsg").val();
	$.post(baseurl+'kuponlar/kuponiptalbildirim',{id:id,iptmsg:iptmsg},function(data) {
		if(data=="1") { 
			failcont("<?php echo lang('tlpgndr1');?>
");
			$("#iptmsg").val('');
			$( ".kupon_iptal" ).dialog( "close" );
		} else{
			failcont("<?php echo lang('tlpok');?>
");
			$("#iptmsg").val('');
			$( ".kupon_iptal" ).dialog( "close" );
		}
	});
}

function kupon_iptal_bildir_div(id) {

	$( ".kupon_iptal" ).dialog({
	  modal: true,
	  title:id+" <?php echo lang('kupiptbld');?>
",
	  buttons: {
		"<?php echo lang('tlpgndr');?>
": function() {
		  kupon_iptal_bildir(id);
		}
	  }
	});
}

function kupon_odendi(id) {

	if(confirm(id+" <?php echo lang('kupod');?>
")) {
		$.post(baseurl+'kuponlar/kuponodendi',{id:id},function(data) { 
		if(data=="401") { failcont("<?php echo lang('kupiptlshp');?>
"); } else
		if(data=="404") { failcont("<?php echo lang('kupiptlshp1');?>
"); } else {
			kouponcall(5);
		}
		});
	}
}

function kouponcall(val) {
	
	if(val){loadgir("#kupons");}
	
	var kupon_no = $("#k_kuponno").val();
	var kuponsahip = $("#k_kuponsahip").val();
	var tarih1 = $("#tarih1").val();
	var tarih2 = $("#tarih2").val();
	var satir = $("#k_satir").val();
	var durum = $("#k_durum").val();
	var tip = $("#k_tip").val();
	var domain = $("#domain").val();
	
	var rand = Math.random();
	var order = $("#order").val();
	var asde = $("#ascdesc").val();
	var paging = $("#suanval").val();
	var userid = $("#k_user").val();
	$.post(baseurl+'kuponlar/data',{userid:userid,pi:paging,kuponsahip:kuponsahip,kupon_no:kupon_no,tarih1:tarih1,tarih2:tarih2,satir:satir,durum:durum,domain:domain,tip:tip,order:order,ascdesc:asde},function(data) { 
		$("#kupons").html(data); 
	});
}

function kupond(id,ac) {	

	$("#gordum_"+id+"").show();
	loadgir("#kupdetail_"+id);
	if(document.getElementById('yapma_'+id).style.display=='table-row' && !ac){		
		document.getElementById('yapma_'+id).style.display='none';
	}else{
		document.getElementById('yapma_'+id).style.display='table-row';		
		$.ajax({
			type:'POST',
			data:{id:id},
			url:baseurl+'kuponlar/kupond',
			complete:function(jqXHR){
				document.getElementById('kupdetail_'+id).innerHTML=jqXHR.responseText;
			}
		});
	}
}

$(document).ready(function(e) {
	kouponcall(1);
	
	$('#k_kuponno').keypress(function(event){
		var keycode = (event.keyCode ? event.keyCode : event.which);
		if(keycode == '13'){ kouponcall(1); }
	});
	
	setInterval(function() { 
		kouponcall(0);
	},60000);
});

$(window).scroll(function(){
	if($(window).scrollTop() + $(window).height() >= $(document).height()) {
		var kontrol = $("#footcontrol").val();
		if(kontrol=="1") {
			var suan = parseInt($("#suanval").val())+1;
			$("#suanval").val(suan);
			kouponcall(0);
		}
	}
});
</script>


	<div class="coupons kupbura" style="width:100%">
	
		<div class="coupon-title">
			<div class="account-table-blue"><span>
				<div class="icon"><i class="fa  fa-clone"></i></div>
				</span>
				<p><?php echo lang('kpnlar');?>
</p>
			</div>
			<div class="account-table-gray">
				<form method="post" >
					<label><?php echo lang('kpno');?>
</label>
					<input type="text" id="k_kuponno" size="7" >
					<?php if ($_smarty_tpl->tpl_vars['bayilist']->value){?>					
					<label><?php echo lang('byler');?>
 :</label>
					<div class="selectbox">
					<select id="k_user">
					<option value=""></option>
					<?php echo $_smarty_tpl->tpl_vars['bayilist']->value;?>

					</select>
					</div>
					<?php }?>
					<label><?php echo lang('trh');?>
 :</label>
					<input type="text" id="tarih1" value="<?php echo smarty_modifier_date_format(time(),'%d-%m-%Y');?>
" readonly>
					<input type="text" class="inputbet" id="tarih2" value="<?php echo smarty_modifier_date_format(time(),'%d-%m-%Y');?>
" readonly>
					<label><?php echo lang('drm');?>
 :</label>
					<div class="selectbox">
						<select id="k_durum">
							<option value=""><?php echo lang('hpsi');?>
</option>
							<option value="2"><?php echo lang('kaz');?>
</option>
							<option value="3"><?php echo lang('kay');?>
</option>
							<option value="1"><?php echo lang('bacik');?>
</option>
							<option value="4"><?php echo lang('ipt');?>
</option>
							<option value="5"><?php echo lang('ert');?>
</option>
						</select>
					</div>
					<label>Program :</label>
					<div class="selectbox">
						<select id="k_tip">
							<option value=""><?php echo lang('hpsi');?>
</option>
							<option value="1"><?php echo lang('futbol');?>
</option>
							<option value="2"><?php echo lang('basket');?>
</option>
							<option value="3"><?php echo lang('duello');?>
</option>
							<option value="4"><?php echo lang('canli');?>
</option>
							<option value="5"><?php echo lang('sanalf');?>
</option>
							<option value="6"><?php echo lang('sanalb');?>
</option>
							<option value="7"><?php echo lang('slot');?>
</option>
							<option value="8"><?php echo lang('tenis');?>
</option>
							<option value="9"><?php echo lang('hentbol');?>
</option>
							<option value="10"><?php echo lang('hokey');?>
</option>
						</select>
					</div>
					<label><?php echo lang('ksatir');?>
 :</label>
					<div class="selectbox">
						<select id="k_satir" >
							<option value=""><?php echo lang('hpsi');?>
</option>
							<option value="1"><?php echo lang('tekli');?>
</option>
							<option value="kombine"><?php echo lang('kombine');?>
</option>
							<option value="2"><?php echo lang('ikili');?>
</option>
							<option value="3"><?php echo lang('3+');?>
</option>
						</select>
					</div>
					<?php if (@yetki==1){?>
					<label>Site :</label>
					<div class="selectbox">
						<select id="domain" >
							<?php echo domainver(2);?>

						</select>
					</div>
					<?php }?>
					<button type="button" id="sorgu" onclick="$('#suanval').val(1);kouponcall(1);"><?php echo lang('gtr');?>
</button>
				<input type="hidden" id="order" value="a.id">
				<input type="hidden" id="ascdesc" value="desc">
				<input type="hidden" id="suanval" value="1">
				</form>
			</div>
		</div>
		
		<div id="kupons" class="coupon-content" style="font-size: 14px;font-weight: bold"></div>
		
</div>

<?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>
<?php }} ?>