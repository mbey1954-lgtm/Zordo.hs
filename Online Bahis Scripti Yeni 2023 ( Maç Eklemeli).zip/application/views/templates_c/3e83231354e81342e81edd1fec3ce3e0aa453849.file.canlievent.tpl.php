<?php /* Smarty version Smarty-3.1.8, created on 2022-09-15 23:53:50
         compiled from "application/views/templates/mobil/canlievent.tpl" */ ?>
<?php /*%%SmartyHeaderCode:880214480632390de18e366-93000017%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '3e83231354e81342e81edd1fec3ce3e0aa453849' => 
    array (
      0 => 'application/views/templates/mobil/canlievent.tpl',
      1 => 1495298414,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '880214480632390de18e366-93000017',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'event' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_632390de1ce1a9_70196229',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_632390de1ce1a9_70196229')) {function content_632390de1ce1a9_70196229($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ("mobil/header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>


<script>
var event='<?php echo $_smarty_tpl->tpl_vars['event']->value;?>
';

function liveupd(vals) {
	
	if(vals){loadgir("#odds");}
	
	$.post(baseurl+'canlibahis/liveodds/',{event:event},function(data) {		
		if(data.ust=='yok'){
			$("#canliust").html('<div class="bonusSloganBox"> <span>Şu anda müsabakanın bilgilerine ulaşılamıyor.</span><br><span>Lütfen başka bir müsabaka seçiniz.</span> </div><button onclick="go(\'\')" class="bigbutton"><div class="text">Geri</div></button>');
			$("#odds").html('');	
			clearInterval(dongu);
		}else{
			$("#canliust").html(data.ust);		
			$("#odds").html(data.odds);			
		}		
	},'json');
}

function canliekle(varo) {

	$.post(baseurl+'kupon/liveadd/',{warrior:varo},function(data) { 
		if(data=="2") { msg('faildurum','Bu maç şu an askıda. Bahis yapılamaz.'); } else
		if(data=="6") { msg('faildurum','Oran süresi doldu.'); } else
		if(data=="3") { failcont('Veri Kaynağında sorun oluştu. Lütfen kuponunuzu kontrol ediniz.');} else
		if(data=="5") { failcont('Aynı Kupon İçerisine İki Farklı Canlı Bahisten Oyun Yapamazsınız.');} else
		if(data=="4") { failcont('Sistem Şuanda Bahislere Kapalıdır.');} else
		if(data=="1") { kuponsay(); }
	});
}


liveupd(1);
kuponsay();

var dongu=setInterval(function(){ 
	liveupd();			
}, 5000);
</script>



<div style="left: 0px; right: 0px; z-index: 100; position: fixed; top: 0px;" class="appheader">
<?php echo mobilhead();?>

<div>  <div class="header"><div onclick="goBack();" class="icon back noselect "></div><div class="text title noselect">Canlı Bahis</div><div onclick="go('home')" style="padding-left:20px" class="icon logo noselect"></div></div></div></div>

<div class="page slide top in" id="page1">
<div class="scroll_container" style="">
<div class="scroll_wrapper" style="padding-top: 85px; padding-bottom: 44px;">
<div class="appcontent">
<div>  </div>

<div id="canliust"></div>
<div id="odds"></div>

<div style="height:20px;">&nbsp;</div>

</div></div></div></div>

<?php echo $_smarty_tpl->getSubTemplate ("mobil/footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>
<?php }} ?>