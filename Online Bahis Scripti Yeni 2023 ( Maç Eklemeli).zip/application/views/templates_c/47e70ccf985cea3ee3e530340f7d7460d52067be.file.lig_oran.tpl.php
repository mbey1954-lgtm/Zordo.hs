<?php /* Smarty version Smarty-3.1.8, created on 2018-11-07 22:00:32
         compiled from "application/views/templates/lig_oran.tpl" */ ?>
<?php /*%%SmartyHeaderCode:9682880305be336505be2e4-09162162%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '47e70ccf985cea3ee3e530340f7d7460d52067be' => 
    array (
      0 => 'application/views/templates/lig_oran.tpl',
      1 => 1495298285,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '9682880305be336505be2e4-09162162',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'liglist' => 0,
    'l' => 0,
    'ligrow' => 0,
    'lgdegisik' => 0,
    'lgd' => 0,
    'lmbs' => 0,
    'orantip' => 0,
    'tip' => 0,
    'oran' => 0,
    'd' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_5be336506b5e44_66174979',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5be336506b5e44_66174979')) {function content_5be336506b5e44_66174979($_smarty_tpl) {?><hr>
		<form method="post" action="<?php echo base_url();?>
oranmerkezi/lig">
		
		<table style="margin-left:10px;width: 80%;color:<?php if (@tema==1){?>#000<?php }else{ ?>#fff<?php }?>;margin-bottom:20px;margin-top:20px">
		<tr>
		<td width="117"><?php echo lang('ligsecin');?>
</td>
		<td>
		<select onChange="self.location.href='?secim=2&lig='+this.value+'';" name="duzenleme" data-placeholder="Lig Seçin" class="chosen">
			<option value=""><?php echo lang('secin');?>
</option>
			<?php  $_smarty_tpl->tpl_vars['l'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['l']->_loop = false;
 $_smarty_tpl->tpl_vars['isim'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['liglist']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['l']->key => $_smarty_tpl->tpl_vars['l']->value){
$_smarty_tpl->tpl_vars['l']->_loop = true;
 $_smarty_tpl->tpl_vars['isim']->value = $_smarty_tpl->tpl_vars['l']->key;
?>
				<option value="<?php echo $_smarty_tpl->tpl_vars['l']->value->id;?>
" <?php if ($_GET['lig']==$_smarty_tpl->tpl_vars['l']->value->id){?>selected<?php }?> ><?php echo $_smarty_tpl->tpl_vars['l']->value->lig_adi;?>
</option>			
			<?php } ?>
			</optgroup>
		</select>			
		</td>		
		</tr>		
		</table>
		
		<?php if ($_GET['lig']!=''){?>
		
		<table style="margin:10px 0px 20px 10px;width:90%;color:<?php if (@tema==1){?>#000<?php }else{ ?>#fff<?php }?>;" id="table_step">
		<tr>
			<td colspan="2"><div class="duzenlemebaslik"><?php echo $_smarty_tpl->tpl_vars['ligrow']->value->lig_adi;?>
</div></td>				
		</tr>
		</table>
		<?php if ($_smarty_tpl->tpl_vars['ligrow']->value->gizli&&sesionlar('id')!=1){?>
			<div class="formbaslik"><?php echo lang('liggiz');?>
</div>		
		<?php }else{ ?>
		<div class="formbaslik"><?php echo lang('gnlayr');?>

		<?php if ($_smarty_tpl->tpl_vars['lgdegisik']->value==1){?>
		<a href="<?php echo base_url();?>
oranmerkezi/allsil/2/<?php echo $_GET['lig'];?>
" onClick='return confirm("<?php echo lang('duzsilcnf');?>
");' class="d3">(<?php echo lang('duzsil');?>
)</a>
		<?php }?>
		</div>
		
		<table style="margin:10px 0px 20px 10px;width:50%;color:<?php if (@tema==1){?>#000<?php }else{ ?>#fff<?php }?>;" id="table_step">
		
		<tr>
			<td colspan="2">
				<span style="float: left; margin-right: 17px;"><?php echo lang('liggstr');?>
</span>			
				<?php ob_start();?><?php echo lig_gizlidurum(sesionlar('id'),$_GET['lig'],'gizlilig','oranver');?>
<?php $_tmp1=ob_get_clean();?><?php $_smarty_tpl->tpl_vars['lgd'] = new Smarty_variable($_tmp1, null, 0);?>
				<select name="lig_goster" class="chosen-select-no-single" style="width:100px;float:left" >
					<option value="0" <?php if ($_smarty_tpl->tpl_vars['lgd']->value=='0'){?>selected<?php }?>><?php echo lang('gstr');?>
</option>			
					<option value="1" <?php if ($_smarty_tpl->tpl_vars['lgd']->value=='1'){?>selected<?php }?>><?php echo lang('gizli');?>
</option>			
				</select>
			</td>				
		</tr>
		
		<tr>
			<td ><span style="float: left; margin-right: 34px;"><?php echo lang('smbs');?>
</span> 
			<?php ob_start();?><?php echo sabitmbs(sesionlar('id'),$_GET['lig'],'mbslig','oranver');?>
<?php $_tmp2=ob_get_clean();?><?php $_smarty_tpl->tpl_vars['lmbs'] = new Smarty_variable($_tmp2, null, 0);?>
			<input type="text" name="sabitmbs" class="inputbet" style="width:90px;" value="<?php echo $_smarty_tpl->tpl_vars['lmbs']->value;?>
" maxlength="1">
			</td>

			<td><?php echo lang('aynian');?>
 
			<input type="text" style="width:50px" id="aynianda" class="inputbet" maxlength="5">
			</td>	
		</tr>
		
		</table>
		
		<div class="formbaslik"><?php echo lang('orduz');?>
</div>
		
		<div class="tumulink" style="margin-top: -30px">
		<a class="d2" onclick="tum_artila();" href="javascript:;" style="margin-right: 10px"><?php echo lang('tumart');?>
</a>
		<a class="d3" onclick="tum_eksile();" href="javascript:;" style="margin-right: 10px"><?php echo lang('tumeks');?>
</a>
		<input type="submit" value="<?php echo lang('kyt');?>
" class="button">
		</div>
		
		<?php  $_smarty_tpl->tpl_vars['oran'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['oran']->_loop = false;
 $_smarty_tpl->tpl_vars['tip'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['orantip']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['oran']->key => $_smarty_tpl->tpl_vars['oran']->value){
$_smarty_tpl->tpl_vars['oran']->_loop = true;
 $_smarty_tpl->tpl_vars['tip']->value = $_smarty_tpl->tpl_vars['oran']->key;
?>
			<div class="odorantip"><?php echo $_smarty_tpl->tpl_vars['tip']->value;?>
</div>
			<div class="duzentable">
				<ul class="head">
				<li><?php echo lang('gstr');?>
</li>
				<li><?php echo lang('thm');?>
</li>
				<li><?php echo lang('oran');?>
</li>
				</ul>
			<?php  $_smarty_tpl->tpl_vars['d'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['d']->_loop = false;
 $_smarty_tpl->tpl_vars['i'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['oran']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['d']->key => $_smarty_tpl->tpl_vars['d']->value){
$_smarty_tpl->tpl_vars['d']->_loop = true;
 $_smarty_tpl->tpl_vars['i']->value = $_smarty_tpl->tpl_vars['d']->key;
?>
				<ul>
				<li style="width:50px;"><input type="checkbox" name="oranvals_<?php echo $_smarty_tpl->tpl_vars['d']->value->id;?>
" value="<?php echo $_smarty_tpl->tpl_vars['d']->value->id;?>
" <?php ob_start();?><?php echo $_smarty_tpl->tpl_vars['d']->value->id;?>
<?php $_tmp3=ob_get_clean();?><?php ob_start();?><?php echo $_GET['lig'];?>
<?php $_tmp4=ob_get_clean();?><?php echo oranmerkez_gizlitip($_tmp3,sesionlar('id'),$_tmp4,'gizlioran','oranver');?>
></li>
				<li style="width:250px;"><?php echo $_smarty_tpl->tpl_vars['d']->value->oran_val;?>
</li>
				<li>
				<input type="text" size="4" class="inputbet aynidegis" id="oranes_<?php echo $_smarty_tpl->tpl_vars['d']->value->id;?>
" name="oranval_<?php echo $_smarty_tpl->tpl_vars['d']->value->id;?>
" value="<?php ob_start();?><?php echo $_smarty_tpl->tpl_vars['d']->value->id;?>
<?php $_tmp5=ob_get_clean();?><?php ob_start();?><?php echo $_GET['lig'];?>
<?php $_tmp6=ob_get_clean();?><?php echo oranmerkez_oranver($_tmp5,sesionlar('id'),$_tmp6,'futbollig','oranver');?>
" maxlength="6"> 
				<a href="javascript:;" class="d2 arti" id="<?php echo $_smarty_tpl->tpl_vars['d']->value->id;?>
">[+0.05]</a> 
				<a href="javascript:;" id="<?php echo $_smarty_tpl->tpl_vars['d']->value->id;?>
" class="d3 eksi">[-0.05]</a> 
				<span>(<?php echo lang('hizisl');?>
)</span></li>
				</ul>
			<?php } ?>
			</div>
		<?php } ?>
		<input type="hidden" name="kontrol" value="lig">
		<input type="hidden" name="secimi" value="<?php echo $_GET['secim'];?>
">
		<input type="hidden" name="lig" value="<?php echo $_GET['lig'];?>
">
		</form>
		
		<?php }?>
		<?php }?><?php }} ?>