<?php /* Smarty version Smarty-3.1.8, created on 2018-09-05 02:46:12
         compiled from "application/views/templates/basmaca.tpl" */ ?>
<?php /*%%SmartyHeaderCode:5801201145b8f1944dc20a9-71458198%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '7dfef6d2140259ac4d9ef33d74f54cebad619e19' => 
    array (
      0 => 'application/views/templates/basmaca.tpl',
      1 => 1495298251,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '5801201145b8f1944dc20a9-71458198',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'mbl' => 0,
    'snyaz' => 0,
    'kasa' => 0,
    'ben' => 0,
    'berabere' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_5b8f1944e90025_04873883',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5b8f1944e90025_04873883')) {function content_5b8f1944e90025_04873883($_smarty_tpl) {?><link href="<?php echo base_url();?>
css/kimkazanir.css" rel="stylesheet" type="text/css">
<?php echo $_smarty_tpl->getSubTemplate ("header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<?php echo $_smarty_tpl->getSubTemplate ("left.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

	
<?php if ($_smarty_tpl->tpl_vars['mbl']->value==1){?><script>alert('Lütfen Masaüstünden Giriş Yapınız.');window.location.href='/home';</script><?php }?>

<script>
$(function () {
window.onbeforeunload = function(){ return "Yaptığınız Kuponların Hesaplandığına emin misiniz?";}  
});
function olasihesapla(){var a=$("#kimoran").text()*$("#dusulecek").text();$("#olasi").text(a.toFixed(2));var c=$("#dusulecek").text()+","+$("#kimoran").text()+","+a.toFixed(2)+","+$("#odadi").text()+","+$("#oddidsi").text();var b=Base64.encode(c);$("#kimdecode").html(b)}function kuponsifirla(){$("#skup").hide();$("#oddidsi,#kimdecode,#kupustyazi,#dusulecek,#olasi").text("")}function bet_disable(){$(".savas_tahminbox ul li a").removeClass("onselect").addClass("savas_bitti");$("#skup").hide()}function bet_enable(){$(".savas_tahminbox ul li a").removeClass("onselect").removeClass("savas_kzn").removeClass("savas_bitti").removeClass("savas_kyp").addClass("enabled");$(".savas_tahminbox .yazisi").removeClass("savas_kzn").removeClass("savas_kyp")}var gerisayim;clearTimeout(gerisayim);function gerisay(){var a=$("#snsi").text();if(a<1){bet_disable();kuponsifirla();clearTimeout(gerisayim)}else{if(a>0){var b=a-1;$("#snsi").text(b);gerisayim=setTimeout(function(){gerisay()},1000)}}if(b==0){$("#ksur").html("<font ><?php echo lang('bhskpn');?>
</font>");bet_disable();kuponsifirla();clearTimeout(gerisayim)}};
</script>



<script type="text/javascript" src="https://node-amazon.betgames.tv/socket.io/socket.io.js"></script>

<div class="coupons">	
	<div class="coupon-title" style="position: relative;">
		<div class="account-table-blue"><span>
			<div class="icon"><i class="fa fa-user"></i></div>
			</span>
			<p><?php echo lang('slot');?>
</p>
		</div>

<div class="savas_content" >

<div style="height: 360px; margin-top: 100px;">

<div style="position: absolute; z-index: 1; top: 35px; background: <?php if (@tema==1){?>#eee<?php }else{ ?>rgb(48, 48, 48)<?php }?>; left: 0px; width: 100%; height: 100px;"><div class="savas_title" style="padding: 5px"><span><font><?php echo lang('nsl');?>
</font><?php echo lang('nsl1');?>
<?php if (@direk=='0'){?><br><not style="color:red"><?php echo lang('nsl2');?>
</not><?php }?></span></div>	</div>
	

<div class="savas_tv" id="player" style="position: relative;height: 300px;">
<iframe src="https://betgames9.betgames.tv/ext/game/odds/testpartner/8/0/decimal" style="position: absolute; width: 550px; height: 390px; top: -102px;border:none" scrolling="no"></iframe>
</div>

<div class="savas_right">


<div class="savas_bahisler">
	<div id="s_odds">
		<div class="savas_boxtitle"><?php echo lang('slot');?>
 <span id="ksur"><?php echo $_smarty_tpl->tpl_vars['snyaz']->value;?>
</span></div>
		<div id="coefficient_528" class="savas_tahminbox" >
			<ul>
				<li class="nobord">
				<a data-odd-id="528" class="poker_odd enabled"><?php echo $_smarty_tpl->tpl_vars['kasa']->value;?>
</a>
				</li>
				<li class="yazisi"><?php echo lang('kasakazanir');?>
</li>
			</ul>
		</div>		
		<div id="coefficient_529" class="savas_tahminbox" >
			<ul>
				<li class="nobord">
				<a data-odd-id="529" class="poker_odd enabled"><?php echo $_smarty_tpl->tpl_vars['ben']->value;?>
</a>
				</li>
				<li class="yazisi"><?php echo lang('benkazanirim');?>
</li>
			</ul>
		</div>
		<div id="coefficient_530" class="savas_tahminbox" >
			<ul>
				<li class="nobord">
				<a data-odd-id="530" class="poker_odd enabled"><?php echo $_smarty_tpl->tpl_vars['berabere']->value;?>
</a>
				</li>
				<li class="yazisi"><?php echo lang('beraberlikolur');?>
</li>
			</ul>
		</div>		
	</div>
</div>

<div id="skup" style="display: none;">    
	<div class="savas_boxtitle" id="kupustyazi"></div>
        <div class="savas_paralar">
		<ul>
        	<li data-pp="5">5</li>
        	<li class="inper" data-pp="10">10</li>
        	<li data-pp="15">15</li>
        	<li data-pp="20">20</li>
        	<li data-pp="50">50</li>
        	<li data-pp="75">75</li>
        	<li data-pp="100">100</li>
        	<li data-pp="150">150</li>
        	<li data-pp="250">250</li>
        	<li data-pp="500">500</li>
        </ul>
    </div>
    
    <div class="savaskuponalt">
    	<div class="savaskuponalttable">
        <ul>
        	<li class="one"><?php echo lang('bakiye');?>
</li>
            <li id="bakiyeniz"><?php echo nf(@bakiye);?>
</li>
        </ul>
    	<ul>
        	<li class="one"><?php echo lang('dusbky');?>
</li>
            <li id="dusulecek" style="color:#BC2121; font-weight:bold;"></li>
        </ul>
        <ul>
        	<li class="one"><?php echo lang('olasi');?>
</li>
            <li id="olasi" style="color:#0F0; font-weight:bold;"></li>
        </ul>
        </div>
		<div id="kimdecode" style="display:none"></div>
		<div id="oddidsi" style="display:none"></div>
        <div class="savasbutton"><a onclick="savasok();" class="savas_button ro" href="javascript:;"><?php echo lang('kpok');?>
</a></div>
    </div>
</div>

<div class="savas_ok ro"><?php echo lang('ktamam');?>
</div>
<div id="kuphesapok" style="display:none"><?php echo lang('kuptmm');?>
</div>
<div id="kuponbekle" class="savas_boxtitle" style="display:none"><?php echo lang('hspbkle');?>
</div>
<div id="bidahakuponolmaz" class="savas_boxtitle" style="display:none"></div>
</div>
</div>
<!--<audio preload="auto" id="doldur"><source type="audio/mp3" src="doldur.mp3"></source></audio>
<audio preload="auto" id="ates"><source type="audio/mp3" src="ates.mp3"></source></audio>-->
<input type="hidden" value="" id="kimdeger">

<script>
var socket;function lastlist(){$.ajax({url:baseurl+"slot/sonkupon/",type:"POST",success:function(a){$("#lastlist").html(a)}})}$(function(){socket=io.connect("https://node-amazon.betgames.tv");socket.on("connect",function(){socket.on("war_game_info",function(a){var b=JSON.parse(a);update_lottery_times(b);update_card_game_info(b)});socket.emit("subscribe","war_game_info")});$("#s_odds").on("click",".poker_odd.enabled",function(g){g.stopPropagation();g.preventDefault();if($(this).hasClass("savas_bitti")){return}var a=$("#kimdeger").val();if(a){$("#bidahakuponolmaz").show();$("#bidahakuponolmaz").html("<?php echo lang('tekprt');?>
");setTimeout(function(){$("#bidahakuponolmaz").slideUp()},5000);return}$("#skup , .savas_button").show();var d=$(this);$(".poker_odd").removeClass("onselect");d.removeClass("onselect").addClass("onselect");var f=d.attr("data-odd-id");var b=d.text();var c;if(f==528){c="<?php echo lang('kasakazanir');?>
"}else{if(f==529){c="<?php echo lang('benkazanirim');?>
"}else{if(f==530){c="<?php echo lang('beraberlikolur');?>
"}}}$("#oddidsi").html(f);$("#kupustyazi").html('<font id="odadi">'+c+'</font> <span id="kimoran">'+b+"</span>");$("#dusulecek").text($(".savas_paralar ul li.inper").text());olasihesapla();});$(".savas_paralar ul li").on("click",function(){var a=$(this).data("pp");$("#preprice").val(a);$("#dusulecek").text(a);$(".savas_paralar ul li").removeClass("inper");if(a==$("#dusulecek").text()){$(this).addClass("inper")}olasihesapla()});/*vidupd();setInterval(function(){vidupd()},120000);*/lastlist()});var update_lottery_times=function(b){var a=b.seconds_left;if(a>0){$("#ksur").html('<font id="snsi"></font> sn');$("#snsi").text(a);gerisay()}else{$("#ksur").html("<font ><?php echo lang('bhskpn');?>
</font>");bet_disable();kuponsifirla()}};var won_status="<?php echo lang('kaz');?>
";var lost_status="<?php echo lang('kay');?>
";var push_status="?";var update_card_game_info=function(c){bet_enable();var b=0;var d=false;if(c.won_odds!=false&&!d){d=true;setTimeout(function(){c.won_odds=false;update_card_game_info(c)},5000)}var a="";$.each(c.odds,function(f,j){if(j.odd_preset_id==71||typeof j.odd_preset_id==="undefined"){var k=j.odd_id;var h=j.odd_value;var e=j.status;var g=j.is_enabled;if(d){if(c.won_odds!==false&&$.inArray(k,c.won_odds)!==-1){$("#coefficient_"+k+" .poker_odd").attr("data-odd-id",k).removeClass("enabled").addClass("savas_kzn").text(won_status);$("#coefficient_"+k+" .yazisi").addClass("savas_kzn");kuponhesapla(k,2)}else{$("#coefficient_"+k+" .poker_odd").attr("data-odd-id",k).removeClass("enabled").addClass("savas_kyp").text(lost_status);$("#coefficient_"+k+" .yazisi").addClass("savas_kyp");kuponhesapla(k,3)}if($.inArray(k,c.push_odds)!==-1){$("#coefficient_"+k+" .poker_odd").attr("data-odd-id",k).removeClass("enabled").addClass("savas_kyp").text(push_status);$("#coefficient_"+k+" .yazisi").addClass("savas_kyp");kuponhesapla(k,3)}}else{if(g==1){$("#coefficient_"+k+" .poker_odd").removeClass("disabled won lost").attr("data-odd-id",k).text(h)}else{if(e=="won"){$("#coefficient_"+k+" .poker_odd").attr("data-odd-id",k).removeClass("enabled").addClass("savas_kzn").text(won_status);$("#coefficient_"+k+" .yazisi").addClass("savas_kzn");kuponhesapla(k,2)}else{if(e=="lost"){$("#coefficient_"+k+" .poker_odd").attr("data-odd-id",k).removeClass("enabled").addClass("savas_kyp").text(lost_status);$("#coefficient_"+k+" .yazisi").addClass("savas_kyp");kuponhesapla(k,3)}}}}b++}});if(c.seconds_left==0){bet_disable();kuponsifirla();clearTimeout(gerisayim)}};/*function vidupd(){$.ajax({url:baseurl+"slot/data/",type:"POST",data:{a:"vid"},success:function(a){$(".savas_tv").html(a)}})}*/function kuponhesapla(f,d){var c=$("#kimdeger").val();if(c){var e=c.split("yolla");var a=e[0];var b=e[1];if(f==b){$.ajax({url:baseurl+"slot/kupondusur/",type:"POST",data:{durum:d,oyunid:a},success:function(g){if(g==1){lastlist();kuponsifirla();$("#kuphesapok").show();$("#kuponbekle").hide();setTimeout(function(){$("#kuphesapok").slideUp()},5000)}else{if(g==2){alert("<?php echo lang('hatamanyap');?>
")}else{if(g==3){alert("<?php echo lang('kpnyok');?>
")}}}$("#kimdeger").val("")}})}}}function savasok(){$(".savas_button").hide();$(".savas_ok").hide();$("#skup").slideUp();$.ajax({url:baseurl+"slot/kuponok/",type:"POST",data:{val:$("#kimdecode").html()},success:function(a){if(a.search("yolla")>0){limitupdate();lastlist();$("#kuponbekle").show();$("#kimdeger").val(a);$(".blooder").show("pulsate",{times:1},100,function(){$(".blooder").fadeOut(3000)});$(".savas_ok").show("pulsate",{times:5},100);setTimeout(function(){$(".savas_ok").slideUp()},5000)}else{$("#yatsonuc").html(a)}}})};
</script>

<div class="clear"></div>
</div>
<?php if (@direk=='0'){?>
	<div class="savas_kups">
		<div class="savas_boxtitle"><?php echo lang('son10');?>
</div>
        <div id="lastlist" class="coupon-content"></div>
    </div>
<?php }?>
</div>

<div id="yatsonuc"></div>
		

</div>

<?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>
<?php }} ?>