<?php /* Smarty version Smarty-3.1.8, created on 2018-08-11 20:11:22
         compiled from "application/views/templates/mobil/footer.tpl" */ ?>
<?php /*%%SmartyHeaderCode:2780396695b6f18ba81cde4-28292140%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '9096bb1a00096077b225e96152dfc548748cbd5c' => 
    array (
      0 => 'application/views/templates/mobil/footer.tpl',
      1 => 1497384340,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2780396695b6f18ba81cde4-28292140',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_5b6f18ba847924_78175781',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5b6f18ba847924_78175781')) {function content_5b6f18ba847924_78175781($_smarty_tpl) {?>
<script>
function hata(msg,ref) {
	
	$(".hata").show();
	$(".hatabox").show();
	$(".hatakapat").show();
	$(".hatamsg").html(msg);
	if(ref=="2") {
		$(".hatakapat").hide();
	}
}
function hatakapat() {
	$(".hatabox").hide();
	$(".hata").hide();
}
</script>

<style>
* {
  box-sizing: border-box;
  list-style-type: none;
  margin: 0;
  padding: 0;
}
.clear {
  float: left;
  height: 50px;
  margin-top: 7px;
  text-align: center;
  width: 100%;
}.footer {
  align-items: center;
  bottom: 0;
  box-shadow: 0 0 7px 3px rgba(0, 0, 0, 0.8);
  box-sizing: border-box;
  display: flex;
  flex-direction: row;
  height: 47px;
  justify-content: center;
  position: fixed;
  text-align: center;
  width: 100%;
  z-index: 999999;
}.footer .tabicon {
  width: 312px;
}.footer .tabicon li {
  color: black;
  float: left;
  margin: 3px 0 0;
  text-align: center;
  width: 78px;
}.footer .tabicon li a.active {
  color: #b4201b;
}.footer .tabicon li a {
  color: white;
  text-shadow: 0 0 2px #000;
}a {
  text-decoration: none;
}.footer .tabicon li .fa {
  font-size: 27px;
  margin-bottom: 5px;
  position: relative;
  text-align: center;
  width: 100%;
}.footer .tabicon li p {
  color: white;
  font-size: 12px;
  font-weight: normal;
  width: auto;
}ul {
  margin-top: 0px;
}.footer .tabicon li a.active {
  color: #b4201b;
}
</style>

<?php if (@tema=='1'){?>
<link rel="stylesheet" href="<?php echo base_url();?>
css/mobil/tema.css">
<?php }?>
<div class="hata">
<div class="hatabox">
<div class="hatabaslik">Bilgi</div>
<div class="hatamsg"></div>
<div class="hatakapat"><input onClick="hatakapat();" type="button" class="button yatirbutton" value="Tamam"></div>
</div>
</div>

<div class="clear"> </div>

<div class="footer blue">
  <ul class="tabicon">
    
	  <li><a onclick="go('index')" class="<?php if ((curpagename(2)=='index'||curpagename(1)=='')){?>active<?php }?>"><i class="fa fa-home "></i>
      <p>Anasayfa</p>
      </a></li>
    <li><a onclick="go('canlibahis')" class="<?php if (curpagename(2)=='canlibahis'){?>active<?php }?>"><i class="fa fa-caret-square-o-right"></i>
      <p>Canlı</p>
      </a></li>
    <?php if (@direk=='0'){?>
		<li><a onclick="go('kuponlar')" class="<?php if (curpagename(2)=='kuponlar'){?>active<?php }?>"><i class="fa  fa-user "></i><p>Kuponlar</p>
		</a></li>
	<?php }else{ ?>
		<li><a onclick="go('login/home/?direct=mobil')"><i class="fa  fa-user "></i><p>Oturum</p>
		</a></li>
    <?php }?>
    <li><a onclick="go('kupon')" class="<?php if (curpagename(2)=='kupon'){?>active<?php }?>"><i class="fa  fa-list-ul "></i>
      <p>Bahis Kuponu</p><div class="editorCount count kuponsayi" ></div>
      </a>
    </li>
 </ul>
</div>

<div id="kupjs"></div>
<?php }} ?>