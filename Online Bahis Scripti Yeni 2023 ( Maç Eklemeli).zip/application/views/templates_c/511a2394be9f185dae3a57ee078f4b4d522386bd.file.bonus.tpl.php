<?php /* Smarty version Smarty-3.1.8, created on 2022-10-19 01:38:40
         compiled from "application/views/templates/bonus.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1725614958634f2af0bc0e20-82068601%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '511a2394be9f185dae3a57ee078f4b4d522386bd' => 
    array (
      0 => 'application/views/templates/bonus.tpl',
      1 => 1495450557,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1725614958634f2af0bc0e20-82068601',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'liste' => 0,
    'row' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_634f2af0c071a1_77947163',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_634f2af0c071a1_77947163')) {function content_634f2af0c071a1_77947163($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ("header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<?php echo $_smarty_tpl->getSubTemplate ("left.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>



<script>
function silyetki(id) {
	if(confirm('Bonus Kaydı Silinecektir. Onaylıyormusunuz?')) {
		self.location.href=baseurl+'ayar/bonusdata/?sil='+id;			
	}
}
</script>


<div class="coupons">	
	<div class="coupon-title">
		<div class="account-table-blue"><span>
			<div class="icon"><i class="fa fa-user"></i></div>
			</span>
			<p>Bonus Düzenle</p>
		</div>
		
		<form method="post" action="<?php echo base_url();?>
ayar/bonusdata">
		<table style="width:100%" class="tftable" cellspacing="0" cellpadding="0">
		<thead><tr >
		<th class="t">Maç Sayısı</td>
		<th class="t">Bonus</td>
		<th class="t">Sil</td>
		</tr></thead><tbody>
		<?php  $_smarty_tpl->tpl_vars['row'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['row']->_loop = false;
 $_smarty_tpl->tpl_vars['mac'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['liste']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['row']->key => $_smarty_tpl->tpl_vars['row']->value){
$_smarty_tpl->tpl_vars['row']->_loop = true;
 $_smarty_tpl->tpl_vars['mac']->value = $_smarty_tpl->tpl_vars['row']->key;
?>
		
		<tr >
		<td width="80">
		<input name="minm_<?php echo $_smarty_tpl->tpl_vars['row']->value->id;?>
" type="text" class="inputbet" size="4" value="<?php echo $_smarty_tpl->tpl_vars['row']->value->minm;?>
" maxlength="3"> ile 
		<input name="maxm_<?php echo $_smarty_tpl->tpl_vars['row']->value->id;?>
" type="text" class="inputbet" size="4" value="<?php echo $_smarty_tpl->tpl_vars['row']->value->maxm;?>
" maxlength="3"> maç arası 
		</td>
		<td width="80">% <input name="bonus_<?php echo $_smarty_tpl->tpl_vars['row']->value->id;?>
" type="text" class="inputbet" size="4" value="<?php echo $_smarty_tpl->tpl_vars['row']->value->bonus;?>
" maxlength="3"> bonus</td>
		<td width="80"><a href="javascript:;" class="d3" onclick="silyetki(<?php echo $_smarty_tpl->tpl_vars['row']->value->id;?>
)">Sil</a></td>
		</tr>		
		<?php } ?>
		<tr >
		<td colspan="5" >
		<input name="edit" type="hidden" value="1">
		<input type="submit" class="button" value="Düzenlemeyi Bitir" id="kaydet"></td>
		</tr></tbody>
		</table>
		</form>
		
		<div class="formbaslik">Yeni Bonus Kaydı</div>
		
		<form method="post" action="<?php echo base_url();?>
ayar/bonusdata">

		<table class="tftable" style="width:100%" cellspacing="0" cellpadding="0">
		<tr class="bas">
		<th class="t">Maç Sayısı</td>
		<th class="t">Bonus</td>
		</tr>
		<tr >
		<td width="80"><input name="minm" type="text" class="inputbet" size="4" maxlength="3"> ile 
		<input name="maxm" type="text" class="inputbet" size="4" maxlength="3"> maç arası 
		</td>
		<td width="80">% <input name="bonusy" type="text" class="inputbet" size="4" maxlength="3"> bonus</td>
		</tr>
		<tr >
		<td colspan="4" >
		<input name="insert" type="hidden" value="1">
		<input type="submit" class="button" value="Yeni Bonusu Kaydet" id="kaydet"></td>
		</tr>
		</table>
		</form>

</div>
</div>

<?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>
<?php }} ?>