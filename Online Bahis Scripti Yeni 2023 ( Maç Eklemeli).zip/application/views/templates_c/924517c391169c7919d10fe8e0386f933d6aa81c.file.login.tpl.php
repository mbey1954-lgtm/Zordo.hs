<?php /* Smarty version Smarty-3.1.8, created on 2022-10-20 23:40:05
         compiled from "application/views/templates/login.tpl" */ ?>
<?php /*%%SmartyHeaderCode:20436596605b85c14cc1e796-26905214%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '924517c391169c7919d10fe8e0386f933d6aa81c' => 
    array (
      0 => 'application/views/templates/login.tpl',
      1 => 1666291261,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '20436596605b85c14cc1e796-26905214',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_5b85c14cd50153_28920847',
  'variables' => 
  array (
    'yok' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5b85c14cd50153_28920847')) {function content_5b85c14cd50153_28920847($_smarty_tpl) {?><!doctype html>
<html>
<head>
<meta charset="utf-8">
<title><?php echo @title;?>
</title>
<link rel="stylesheet" href="<?php echo base_url();?>
css/reset.css">
<script type="text/javascript" src="<?php echo base_url();?>
js/jquery.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>
js/main.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>
js/fancy.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>
js/jquery-ui-1.8.21.custom.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>
js/mousehold.js"></script>
<link rel="stylesheet" href="<?php echo base_url();?>
css/base.css">
<link rel="stylesheet" href="<?php echo base_url();?>
css/ie.css">
<link rel="stylesheet" href="<?php echo base_url();?>
css/font-awesome.css">
<link rel="stylesheet" href="<?php echo base_url();?>
css/jquery-ui.css">
<link rel="stylesheet" href="<?php echo base_url();?>
css/icomoon.css">
<link rel="stylesheet" href="<?php echo base_url();?>
css/fancy.css">
<link rel="stylesheet" href="<?php echo base_url();?>
csslogin/login.css">
<link rel="stylesheet" href="<?php echo base_url();?>
csslogin/loginboots.css">
<?php if ($_smarty_tpl->tpl_vars['yok']->value){?>
<script>alert('<?php echo $_smarty_tpl->tpl_vars['yok']->value;?>
');</script>
<?php }?>

<script>var baseurl = "{base_url()}";

$(function() {
	$(".ui-widget-overlay").live( "click", function() {	
		$(".ui-icon.ui-icon-closethick").trigger("click");
	});
	$('#main_slider').nivoSlider({	
	effect: 'slideInLeft',	animSpeed:700,	pauseTime:5000,	startSlide:0,	slices:10,	directionNav:false,	directionNavHide:false,	controlNav:true,	controlNavThumbs:false,	keyboardNav:true,	pauseOnHover:true,	captionOpacity:0.8,	
	});
	$('.slide2').nivoSlider({	
	effect: 'slideInLeft',	animSpeed:700,	pauseTime:5000,	startSlide:0,	slices:10,	directionNav:false,	directionNavHide:false,	controlNav:true,	controlNavThumbs:false,	keyboardNav:true,	pauseOnHover:true,	captionOpacity:0.8,	
	});	
});	

function dil_cevir(lang){	
$.post(baseurl+"login/lang/", { dil: lang}).done(function(e) {	window.location.reload();	});
}
</script>
<style>
.da-thumbs-promosyonlar .dtp-item a div {
  background: rgba(26, 44, 70, 0.7) none repeat scroll 0 0;
  height: 100%;
  position: absolute;
  width: 100%;
}
.da-thumbs-promosyonlar .dtp-item {
  background: rgba(192, 220, 4, 0.5) none repeat scroll 0 0;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
  float: left;
  margin: 1px;
  padding: 3px;
  position: relative;
  width: 392px;
}.da-thumbs-promosyonlar .dtp-item a {
  overflow: hidden;
}.da-thumbs-promosyonlar .dtp-item a, .da-thumbs-promosyonlar .dtp-item a img {
  display: block;
  position: relative;
}.da-thumbs-promosyonlar .dtp-item a div span {
  border-bottom: 1px solid rgba(255, 255, 255, 0.5);
  border-top: 1px solid rgba(255, 255, 255, 0.5);
  color: rgba(255, 255, 255, 0.9);
  display: block;
  font-weight: normal;
  margin: 40px 20px 20px;
  padding: 10px 0;
  text-shadow: 1px 1px 1px rgba(0, 0, 0, 0.2);
  text-transform: uppercase;
}.da-thumbs-promosyonlar {
  float: left;
  height: auto;
  list-style: outside none none;
  margin: 10px auto;
  padding: 0;
  position: relative;
  width: 100%;
}
</style>

<?php if (detect_mobile()){?>

<style>
header{
	width:1010px;
}
.wp{
	width:1010px !important;
}
.v2_footer{
	width:1010px !important;
}
.col-sm-3 img{
	width:130px !important;
}
.col-sm-2 img{
	width:100px !important;
}
nav ul li a{
	padding:0 5px;
	margin:3px 7px 0 0;
}
#bottom ul{
	padding:0 0 0 50px
}
#slide-main{
	margin-top:20px
}
</style>

<?php }?>
<link rel="stylesheet" href="<?php echo base_url();?>
css/slider.css">
<script type="text/javascript" src="<?php echo base_url();?>
js/jquery.nivo.slider.pack.js"></script>
</head>

<body>

<header class="big_header_blue" >
<div class="wp" > 
<div class="logo">
<a href="<?php echo base_url();?>
"><img src="<?php echo base_url();?>
img/logo.svg" alt=""></a>
</div> 

<nav> <ul> 
<li><a href="<?php echo base_url();?>
kayit " class="active"><?php echo lang('home');?>
</a></li>
<li><a href="<?php echo base_url();?>
kayit " class=""><?php echo lang('canli');?>
</a></li>
<li><a href="<?php echo base_url();?>
kayit " class=""><?php echo lang('slot');?>
</a></li> 
<li><a href="<?php echo base_url();?>
kayit " ><?php echo lang('snclar');?>
</a></li> 
</ul> </nav> 

<div class="user-area"> 
<div class="lang" style="width: 100px;">
        <div class="lng lng_blue">
        
          <div class="flag-icon flag-icon-<?php echo @dil;?>
"></div>
          <p><?php if (@dil=='tr'){?>Türkçe<?php }elseif(@dil=='en'){?>English<?php }elseif(@dil=='de'){?>Deutsch<?php }elseif(@dil=='fr'){?>Francais<?php }?></p>
          <div class="lng_arrow"><i class="fa fa-caret-down"></i></div>
		
        </div>
        <ul>
          <li class="lang_li_blue" onclick="dil_cevir('tr');">
            <div class="flag-icon flag-icon-tr"></div>
            <p>Türkçe</p>
          </li>
          <li class="lang_li_blue" onclick="dil_cevir('en');">
            <div class="flag-icon flag-icon-en"></div>
            <p>English</p>
          </li>
          <li class="lang_li_blue" onclick="dil_cevir('de');">
            <div class="flag-icon flag-icon-de"></div>
            <p>Deutsch</p>
          </li>
          <li class="lang_li_blue" onclick="dil_cevir('fr');">
            <div class="flag-icon flag-icon-fr"></div>
            <p>Francais</p>
          </li>
        </ul>
      </div>
	  
<div class="user-logged" style="margin-top: -12px;"> 

<form id="form1" name="form1" method="post" action="<?php echo base_url();?>
login/giris">	  
	<div class="login" style="z-index: 5;">
		<table border="0" align="right" cellpadding="0" cellspacing="0" width="100%"> 
			<fieldset>
				<input type="text" name="username" placeholder="<?php echo lang('user');?>
" />
				<input type="password" name="password" placeholder="<?php echo lang('sifre');?>
" />
			</fieldset>
			<tr>
				<td><button type="button" class="btn" value="Şifremi Unuttum" onclick="window.location.href='<?php echo base_url();?>
info/sifremi_unuttum'"/>Şifremi Unuttum</button></td>
				<td></td>
				<td><input type="submit" value="Giriş Yap" style="width: 90px; float: right;"/></td>
			</tr>
		</table>
	</div>
</form>
</div> 
</div>

</div>
</header>

<div class="page" >
<div class="wp">
<div class="menu">

<div class="bet-list">
<div class="timeline-container"> 
<div class="title"><?php echo lang('home');?>
</div> </div>

<div id="cssmenu">
<ul>
<li><a href="<?php echo base_url();?>
kayit " class="itemac" id="flig"><div class="icon-1"></div>
	<div class="sports ng-binding"><?php echo lang('home');?>
</div></a></li>	
	
<li><a href="<?php echo base_url();?>
kayit " class="itemac" id="blig"><div class="icon-2"></div>
	<div class="sports ng-binding"><?php echo lang('basket');?>
</div></a></li>
	
<li><a href="<?php echo base_url();?>
kayit " class="itemac" id="flig"><div class="icon-1"></div>
	<div class="sports ng-binding">Canlı Bahis</div></a></li>

<li><a href="<?php echo base_url();?>
kayit " class="itemac" id="flig"><div class="icon-1"></div>
	<div class="sports ng-binding"><?php echo lang('duello');?>
</div></a></li>

<li><a href="<?php echo base_url();?>
kayit " class="itemac" id="flig"><div class="icon-4"></div>
	<div class="sports ng-binding">Hentbol</div></a></li>

<li><a href="<?php echo base_url();?>
kayit " class="itemac" id="flig"><div class="icon-5"></div>
	<div class="sports ng-binding">Tenis</div></a></li>

<li><a href="<?php echo base_url();?>
kayit " class="itemac" id="flig"><div class="icon-1"></div>
	<div class="sports ng-binding">Dart</div></a></li>

<li><a href="<?php echo base_url();?>
kayit " class="itemac" id="flig"><div class="icon-1"></div>
	<div class="sports ng-binding"><?php echo lang('slot');?>
</div></a></li>

<li><a href="<?php echo base_url();?>
kayit " class="itemac" id="flig"><div class="icon-6"></div>
	<div class="sports ng-binding">Voleybol</div></a></li>	

<li><a href="<?php echo base_url();?>
kayit " class="itemac" id="blig"><div class="icon-2"></div>
	<div class="sports ng-binding">Masa Tenisi</div></a></li>
		
<li><a href="<?php echo base_url();?>
kayit " class="itemac"><div class="icon-1"></div>
	<div class="sports ng-binding">Beyzbol</div></a></li>

<li><a href="<?php echo base_url();?>
kayit " class="itemac"><div class="icon-2"></div>
	<div class="sports ng-binding">Bandy</div></a></li>	

	<li><a href="<?php echo base_url();?>
kayit " class="itemac"><div class="icon-1"></div>
	<div class="sports ng-binding">Floorball</div></a></li>
	
<li><a href="<?php echo base_url();?>
kayit " class="itemac"><div class="icon-2"></div>
	<div class="sports ng-binding">Rugby</div></a></li>

	
</ul></div>

<img src="<?php echo base_url();?>
imglogin/left.jpg" width="200px"></img>
</div>



</div>

<main > 

<div id="slide-main" style="margin-top:20px"> 
<div id="slider-wrapper">
<div class="slider mainback">
	<img src="<?php echo base_url();?>
images/mainfront.png" alt="" title=""/></div>
<div id="main_slider" class="nivoSlider"> 
	<img src="<?php echo base_url();?>
imglogin/mainslider01.jpg" title="#caption1" alt="" /> 
	<img src="<?php echo base_url();?>
imglogin/mainslider02.jpg" title="#caption2" alt="" /> 
	<img src="<?php echo base_url();?>
imglogin/mainslider04.jpg" title="#caption3" alt="" /> 	
	</div> </div> 


<div id="caption1" class="nivo-html-caption">
<div class="nivo-title"> 
<label>Canlı Skorlar</label> 
<p>Yüksek oranlarla oynayarak kuponunu<br>oluştur ve kazanmaya başla.Çeşitli<br>sporlada kazanma şansını arttır.</p> 
<a class="actionbutton" href="javascript:;">Bahis Yap!</a> </div> </div> 

<div id="caption2" class="nivo-html-caption">
<div class="nivo-title"> 
<label>Canlı Slot</label> <p>Canlı Slot heyecanını canlı masalarda<br>yaşa.slot oyunlarda sanşını dene.</p> 
<a class="actionbutton" href="javascript:;">Hemen Oyna!</a> </div> </div> 

<div id="caption3" class="nivo-html-caption">
<div class="nivo-title"> 
<label>Futbol Heyecanı</label> 
<p>Yüksek oranlarla oynayarak kuponunu<br>oluştur ve kazanmaya başla.Çeşitli<br>sporlada kazanma şansını arttır.</p> 
<a class="actionbutton" href="javascript:;">Bahis Yap!</a> </div> </div> 

 

</div>

    <!--container start-->
    <div class="table-container">


      <div class="row">
        <div class="col-lg-12 col-sm-12 address">
			<!--<div class="table-container ">
			<div class="general-table-title-blue"><div class="icon" style="font-size:20px !important"><i class="fa fa-user"></i></div><p><?php echo lang('tlpfrm');?>
</p></div>
			</div>-->
			<div id="da-thumbs" class="da-thumbs-promosyonlar">

                <div class="dtp-item">
                    <a href="#">
                        <img class="img-responsive Bonus-Img" src="/images/pr1.png" alt="<?php echo @title;?>
 HOŞ GELDİN BONUSU" >
                        <div><span>Hoş Geldin Bonusu</span></div>
                    </a>
                </div>
                <div class="dtp-item">
                    <a href="#">
                        <img class="img-responsive Bonus-Img" src="/images/pr2.png" alt="<?php echo @title;?>
 HAVALE BONUSU" >
                        <div><span>Havale bonusu</span></div>
                    </a>
                </div>
                <div class="dtp-item">
                    <a href="#">
                        <img class="img-responsive Bonus-Img" src="/images/pr3.png" alt="<?php echo @title;?>
 CEPBANK BONUSU" >
                        <div><span>Cepbank bonusu</span></div>
                    </a>
                </div>
                <div class="dtp-item">
                    <a href="#">
                        <img class="img-responsive Bonus-Img" src="/images/pr4.png" alt="<?php echo @title;?>
 %15 G&#220;NL&#220;K %20 HAFTALIK KAYIP BONUSU" >
                        <div><span>%15 G&#252;nl&#252;k %20 Haftalık Kayıp Bonusu</span></div>
                    </a>
                </div>
                <div class="dtp-item">
                    <a href="#">
                        <img class="img-responsive Bonus-Img" src="/images/pr5.png" alt="<?php echo @title;?>
 ARKADAŞINI GETİR BONUSU" >
                        <div><span>Arkadaşını Getir Bonusu</span></div>
                    </a>
                </div>
                <div class="dtp-item">
                    <a href="#">
                        <img class="img-responsive Bonus-Img" src="/images/pr6.png" alt="<?php echo @title;?>
 KOMBİNE BONUSU" >
                        <div><span>Kombine Bonusu</span></div>
                    </a>
                </div>
                <div class="dtp-item">
                    <a href="#">
                        <img class="img-responsive Bonus-Img" src="/images/pr7.png" alt="<?php echo @title;?>
 DERBİLERE &#214;ZEL %25 KAYIP BONUSU" >
                        <div><span>Derbilere &#246;zel %25 Kayıp bonusu</span></div>
                    </a>
                </div>
                <div class="dtp-item">
                    <a href="#">
                        <img class="img-responsive Bonus-Img" src="/images/pr8.png" alt="<?php echo @title;?>
 DOĞUM G&#220;N&#220; BONUSU" >
                        <div><span>Doğum G&#252;n&#252; Bonusu</span></div>
                    </a>
                </div>

        </div>
        </div>
      </div>
	
	<div class="topfoot" style="height:0px">
<div class=" payment">
<div class="col-md-3 col-sm-3">
<img src="<?php echo base_url();?>
imglogin/payment/pp.png" style="margin: 15px 0px;" width="200px"></img></div>
<div class="col-md-7 col-sm-7">
	<img src="<?php echo base_url();?>
imglogin/payment/1.png"></img>
	<img src="<?php echo base_url();?>
imglogin/payment/2.png"></img>
	<img src="<?php echo base_url();?>
imglogin/payment/3.png"></img>
	<img src="<?php echo base_url();?>
imglogin/payment/4.png"></img>
	<img src="<?php echo base_url();?>
imglogin/payment/5.png"></img>
	<img src="<?php echo base_url();?>
imglogin/payment/6.png"></img>
	<img src="<?php echo base_url();?>
imglogin/payment/7.png"></img>
	<img src="<?php echo base_url();?>
imglogin/payment/8.png"></img>
	<img src="<?php echo base_url();?>
imglogin/payment/9.png"></img>
	<img src="<?php echo base_url();?>
imglogin/payment/10.png"></img>
	<img src="<?php echo base_url();?>
imglogin/payment/11.png"></img>
	<img src="<?php echo base_url();?>
imglogin/payment/12.png"></img>
</div>
<div class="col-md-2 col-sm-2"><img src="<?php echo base_url();?>
imglogin/payment/secure.png" style="margin: -1px 0px 0px -20px;" width="150px"></img></div>
</div>
	    
</div>

    </div>
    <!--container end-->
<!---REGISTERFORM ------>
</main>

<aside>
<div id="module">
	<div class="sidebar-module"> 
		<div class="module-title"> <p><?php echo lang('dstk');?>
</p> </div> 
		<div class="content"> 
		<ul class="listing-icon"> 
		<li><a href="<?php echo base_url();?>
kayit "><i class="fa fa-angle-double-right"></i><?php echo lang('odm');?>
</a></li>
			<li><a href="<?php echo base_url();?>
kayit "><i class="fa fa-angle-double-right"></i><?php echo lang('yrd');?>
</a></li>
			<li><a href="<?php echo base_url();?>
kayit "><i class="fa fa-angle-double-right"></i><?php echo lang('szlk');?>
</a></li>
			<li><a href="<?php echo base_url();?>
kayit "><i class="fa fa-angle-double-right"></i><?php echo lang('bhskrl');?>
</a></li>
		</ul>
		<div class="button-container"><a href="<?php echo base_url();?>
kayit">Kayıt Ol</a></a></div>
		</div> 
	</div>
	<div class="sidebar-module">
		<img src="<?php echo base_url();?>
imglogin/right.jpg" ></img>
	</div>
</div>
</aside>

</div>
</div>

<footer class="v2_footer" style="position:relative">

<section id="bottom">
		<ul>
			<li>
				<ul>
				<h3>Zirvedekiler</h3>
				<li><a>Champions League</a></li>
				<li><a>1. Bundesliga</a></li>
				<li><a>Premier League</a></li>	
				<li><a>Primera Division</a></li>	
				<li><a>Süper Lig</a></li>	
				<li><a>Serie A</a></li>	
				</ul>			
			</li>
			<li>
				<ul>
				<h3>Ekstralar</h3>
				<li><a><?php echo lang('home');?>
</a></li>
				<li><a><?php echo lang('canli');?>
</a></li>
				<li><a>Canlı Skor</a></li>	
				<li><a><?php echo lang('slot');?>
</a></li>	
				<li><a>İstatistikler</a></li>	
				<li><a>Promosyon</a></li>	
				</ul>			
			</li>
			<li>
				<ul>
				<h3>Bilgi</h3>
				<li><a>Ödeme Yöntemleri</a></li>
				<li><a>Kullanım Şartları</a></li>
				<li><a>Gizlilik Sözleşmesi</a></li>	
				<li><a>Sorumluluk</a></li>
				<li><a>Hükümler ve Koşullar</a></li>	

				</ul>			
			</li>
			<li>
				<ul>
				<h3>Superbetwin1</h3>
				<li><a>Hakkımızda</a></li>
				<li><a>İletişim</a></li>
				<li><a>Üyelik Formu</a></li>
				<li><a><?php echo lang('yrd');?>
</a></li>	
				</ul>			
			</li>		

<li style="width:100px">
	<ul>
		<li></li>
		<li></li>
		<li><img src="<?php echo base_url();?>
imglogin/18.png" width="120px"></li>
	</ul>
</li>			

		</ul>
	</section>
<div class="bottomfooter">
	<div class="container">
		<div class="col-sm-5 col-md-5">
			<p style="color:white;font-size:16px;font-weight:700;font-style:italic">Eurobet<span style="color:#ff3333;">Full</span>.com</p>
		</div>
		<div class="col-sm-7 col-md-7">
			<p style="color:white;font-size:12px;font-weight:700;">2017 <span style="color:#ff3333;font-size:13px">©</span> All Rights Reserved.</p>
		</div>
	</div>
</div>

</footer>

<script type="text/javascript">
(function(n,t){"use strict";n.HoverDir=function(t,i){this.$el=n(i),this._init(t)},n.HoverDir.defaults={speed:300,easing:"ease",hoverDelay:0,inverse:!1},n.HoverDir.prototype={_init:function(t){this.options=n.extend(!0,{},n.HoverDir.defaults,t),this.transitionProp="all "+this.options.speed+"ms "+this.options.easing,this.support=Modernizr.csstransitions,this._loadEvents()},_loadEvents:function(){var t=this;this.$el.on("mouseenter.hoverdir, mouseleave.hoverdir",function(i){var f=n(this),r=f.find("div"),e=t._getDir(f,{x:i.pageX,y:i.pageY}),u=t._getStyle(e);i.type==="mouseenter"?(r.hide().css(u.from),clearTimeout(t.tmhover),t.tmhover=setTimeout(function(){r.show(0,function(){var i=n(this);t.support&&i.css("transition",t.transitionProp),t._applyAnimation(i,u.to,t.options.speed)})},t.options.hoverDelay)):(t.support&&r.css("transition",t.transitionProp),clearTimeout(t.tmhover),t._applyAnimation(r,u.from,t.options.speed))})},_getDir:function(n,t){var i=n.width(),r=n.height(),u=(t.x-n.offset().left-i/2)*(i>r?r/i:1),f=(t.y-n.offset().top-r/2)*(r>i?i/r:1);return Math.round((Math.atan2(f,u)*(180/Math.PI)+180)/90+3)%4},_getStyle:function(n){var t,i,r={left:"0px",top:"-100%"},u={left:"0px",top:"100%"},f={left:"-100%",top:"0px"},e={left:"100%",top:"0px"},o={top:"0px"},s={left:"0px"};switch(n){case 0:t=this.options.inverse?u:r,i=o;break;case 1:t=this.options.inverse?f:e,i=s;break;case 2:t=this.options.inverse?r:u,i=o;break;case 3:t=this.options.inverse?e:f,i=s}return{from:t,to:i}},_applyAnimation:function(t,i,r){n.fn.applyStyle=this.support?n.fn.css:n.fn.animate,t.stop().applyStyle(i,n.extend(!0,[],{duration:r+"ms"}))}};var r=function(n){t.console&&t.console.error(n)};n.fn.hoverdir=function(t){var i=n.data(this,"hoverdir"),u;return typeof t=="string"?(u=Array.prototype.slice.call(arguments,1),this.each(function(){if(!i){r("cannot call methods on hoverdir prior to initialization; attempted to call method '"+t+"'");return}if(!n.isFunction(i[t])||t.charAt(0)==="_"){r("no such method '"+t+"' for hoverdir instance");return}i[t].apply(i,u)})):this.each(function(){i?i._init():i=n.data(this,"hoverdir",new n.HoverDir(t,this))}),i}})(jQuery,window);

window.Modernizr=function(n,t,i){function p(n){d.cssText=n}function u(n,t){return typeof n===t}function it(n,t){return!!~(""+n).indexOf(t)}function g(n,t){var u,r;for(u in n)if(r=n[u],!it(r,"-")&&d[r]!==i)return t=="pfx"?r:!0;return!1}function ut(n,t,r){var e,f;for(e in n)if(f=t[n[e]],f!==i)return r===!1?n[e]:u(f,"function")?f.bind(r||t):f;return!1}function b(n,t,i){var r=n.charAt(0).toUpperCase()+n.slice(1),f=(n+" "+y.join(r+" ")+r).split(" ");return u(t,"string")||u(t,"undefined")?g(f,t):(f=(n+" "+w.join(r+" ")+r).split(" "),ut(f,t,i))}var ft="2.6.2",r={},c=!0,l=t.documentElement,rt="modernizr",k=t.createElement(rt),d=k.style,tt,et={}.toString,nt="Webkit Moz O ms",y=nt.split(" "),w=nt.toLowerCase().split(" "),e={},ot={},st={},v=[],a=v.slice,f,h={}.hasOwnProperty,o,s;o=!u(h,"undefined")&&!u(h.call,"undefined")?function(n,t){return h.call(n,t)}:function(n,t){return t in n&&u(n.constructor.prototype[t],"undefined")},Function.prototype.bind||(Function.prototype.bind=function(n){var t=this,i,r;if(typeof t!="function")throw new TypeError;return i=a.call(arguments,1),r=function(){var e,f,u;return this instanceof r?(e=function(){},e.prototype=t.prototype,f=new e,u=t.apply(f,i.concat(a.call(arguments))),Object(u)===u?u:f):t.apply(n,i.concat(a.call(arguments)))},r}),e.csstransitions=function(){return b("transition")};for(s in e)o(e,s)&&(f=s.toLowerCase(),r[f]=e[s](),v.push((r[f]?"":"no-")+f));return r.addTest=function(n,t){if(typeof n=="object")for(var u in n)o(n,u)&&r.addTest(u,n[u]);else{if(n=n.toLowerCase(),r[n]!==i)return r;t=typeof t=="function"?t():t,typeof c!="undefined"&&c&&(l.className+=" "+(t?"":"no-")+n),r[n]=t}return r},p(""),k=tt=null,function(n,t){function p(n,t){var i=n.createElement("p"),r=n.getElementsByTagName("head")[0]||n.documentElement;return i.innerHTML="x<style>"+t+"</style>",r.insertBefore(i.lastChild,r.firstChild)}function l(){var n=r.elements;return typeof n=="string"?n.split(" "):n}function u(n){var t=c[n[h]];return t||(t={},o++,n[h]=o,c[o]=t),t}function s(n,r,f){if(r||(r=t),i)return r.createElement(n);f||(f=u(r));var e;return e=f.cache[n]?f.cache[n].cloneNode():b.test(n)?(f.cache[n]=f.createElem(n)).cloneNode():f.createElem(n),e.canHaveChildren&&!w.test(n)?f.frag.appendChild(e):e}function v(n,r){if(n||(n=t),i)return n.createDocumentFragment();r=r||u(n);for(var e=r.frag.cloneNode(),f=0,o=l(),s=o.length;f<s;f++)e.createElement(o[f]);return e}function y(n,t){t.cache||(t.cache={},t.createElem=n.createElement,t.createFrag=n.createDocumentFragment,t.frag=t.createFrag()),n.createElement=function(i){return r.shivMethods?s(i,n,t):t.createElem(i)},n.createDocumentFragment=Function("h,f","return function(){var n=f.cloneNode(),c=n.createElement;h.shivMethods&&("+l().join().replace(/\w+/g,function(n){return t.createElem(n),t.frag.createElement(n),'c("'+n+'")'})+");return n}")(r,t.frag)}function a(n){n||(n=t);var f=u(n);return r.shivCSS&&!e&&!f.hasCSS&&(f.hasCSS=!!p(n,"article,aside,figcaption,figure,footer,header,hgroup,nav,section{display:block}mark{background:#FF0;color:#000}")),i||y(n,f),n}var f=n.html5||{},w=/^<|^(?:button|map|select|textarea|object|iframe|option|optgroup)$/i,b=/^(?:a|b|code|div|fieldset|h1|h2|h3|h4|h5|h6|i|label|li|ol|p|q|span|strong|style|table|tbody|td|th|tr|ul)$/i,e,h="_html5shiv",o=0,c={},i,r;(function(){try{var n=t.createElement("a");n.innerHTML="<xyz></xyz>",e="hidden"in n,i=n.childNodes.length==1||function(){t.createElement("a");var n=t.createDocumentFragment();return typeof n.cloneNode=="undefined"||typeof n.createDocumentFragment=="undefined"||typeof n.createElement=="undefined"}()}catch(r){e=!0,i=!0}})(),r={elements:f.elements||"abbr article aside audio bdi canvas data datalist details figcaption figure footer header hgroup mark meter nav output progress section summary time video",shivCSS:f.shivCSS!==!1,supportsUnknownElements:i,shivMethods:f.shivMethods!==!1,type:"default",shivDocument:a,createElement:s,createDocumentFragment:v},n.html5=r,a(t)}(this,t),r._version=ft,r._domPrefixes=w,r._cssomPrefixes=y,r.testProp=function(n){return g([n])},r.testAllProps=b,l.className=l.className.replace(/(^|\s)no-js(\s|$)/,"$1$2")+(c?" js "+v.join(" "):""),r}

$(function () {
	$(' #da-thumbs > .dtp-item ').each(function () { $(this).hoverdir(); });
});
</script>

</body></html><?php }} ?>