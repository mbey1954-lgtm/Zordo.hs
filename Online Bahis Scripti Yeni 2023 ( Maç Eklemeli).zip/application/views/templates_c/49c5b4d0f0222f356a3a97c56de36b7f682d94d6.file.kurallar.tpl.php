<?php /* Smarty version Smarty-3.1.8, created on 2018-08-11 18:22:17
         compiled from "application/views/templates/kurallar.tpl" */ ?>
<?php /*%%SmartyHeaderCode:9650556425b6eff296bc3c3-99094565%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '49c5b4d0f0222f356a3a97c56de36b7f682d94d6' => 
    array (
      0 => 'application/views/templates/kurallar.tpl',
      1 => 1495298284,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '9650556425b6eff296bc3c3-99094565',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'liste' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_5b6eff2975c542_65165644',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5b6eff2975c542_65165644')) {function content_5b6eff2975c542_65165644($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ("header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>


<div class="coupons" style="width:100%">	

	<div class="coupon-title">
		<div class="account-table-blue"><span>
			<div class="icon"><i class="fa fa-user"></i></div>
			</span>
			<p><?php echo lang('bhskrl');?>
</p>
		</div>		
		<div style="background:#ccc"><?php echo $_smarty_tpl->tpl_vars['liste']->value;?>
</div>
		
</div>
</div>

<?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>
<?php }} ?>