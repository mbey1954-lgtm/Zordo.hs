<?php /* Smarty version Smarty-3.1.8, created on 2018-08-10 12:36:51
         compiled from "application/views/templates/right.tpl" */ ?>
<?php /*%%SmartyHeaderCode:9340725685b6d5cb3796a23-73729771%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '84de055b27e73af22aa1da9807ca01da9e7d6775' => 
    array (
      0 => 'application/views/templates/right.tpl',
      1 => 1495785019,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '9340725685b6d5cb3796a23-73729771',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_5b6d5cb37fe694_44303291',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5b6d5cb37fe694_44303291')) {function content_5b6d5cb37fe694_44303291($_smarty_tpl) {?><link rel="stylesheet" href="<?php echo base_url();?>
css/slider.css">
<script type="text/javascript" src="<?php echo base_url();?>
js/jquery.nivo.slider.pack.js"></script>

<script>
$(function() {
	$('#main_slider2').nivoSlider({
		effect:'fade',
		pauseTime:5000,
		startSlide:0,
		slices:10,
		directionNav:false,
		directionNavHide:false,
		controlNav:true,			
		controlNavThumbs:false,			
		keyboardNav:true,			
		pauseOnHover:true,			
		captionOpacity:0.8,	
	});
});
</script>


<aside>
<div id="module">	
	<div class="module-title">
        <p><?php echo lang('kbaslik');?>
</p>
    </div>
	<div class="content-2">
		<div class="coupon" >
		
			<div class="blank-coupon"><span class="oddconfirm"><?php echo lang('kbos');?>
</span></div>
			
			<div class="countdown os" style="display:none">
				<span id="count" class="os"><?php echo lang('bekle');?>
<h1><?php echo @title;?>
 </h1></span>
				<input type="hidden" id="countgeri" value="">
				<input type="hidden" id="songeri" value="3">
				<?php echo lang('kc1');?>
<font id="sonbe"><?php echo lang('kc2');?>
</font>
			</div>
			
			<div class="kuponalt" style="display:none">
			<a class="clear" href="#" onClick="kupontemizle(0);"><?php echo lang('tumsil');?>
</a>
			<div id="kuponalan"></div>
			
			<div class="form">
				<fieldset>
					<label><?php echo lang('kmiktar');?>
</label>
						<input type="text" size="6" class="input" value="" autocorrect="off" autocomplete="off" id="kuponyatan" onkeypress="return SadeceRakam(event,['.']);" onblur="SadeceRakamBlur(event,true);" onClick="this.select();">
				</fieldset>
				<fieldset>
					<label><?php echo lang('bhsadet');?>
</label>
					<div id="toplammac" class="kupdiv">0</div>
				</fieldset>
				<fieldset>
					<label><?php echo lang('toran');?>
</label>
					<div id="toplamoran" class="kupdiv">0</div>
				</fieldset>
				<fieldset>
					<label><?php echo lang('olasi');?>
</label>
					<div id="tutarhesap" class="kupdiv">0</div>
				</fieldset>
				<fieldset id="bonsgiz" style="display:none">
					<label><?php echo lang('bns');?>
</label>
					<div id="bonusuhak" class="kupdiv">0</div>
				</fieldset>
				<fieldset>
                    <input class="checkbox" type="checkbox" checked>
                    <label class="changeoran">Oran değişikliklerini kabul ediyorum</label>
                </fieldset>
				<div class="bottom">
					<button onclick="kuponok();" id="yatirson"><?php echo lang('kpok');?>
</button>
				</div>
			</div>
			</div>
		</div>
	</div>
</div>

<div id="sidebarbox">
	<div id="slider2-wrapper">
        
        <div class="mainback"> <img src="/images/aside_banner.jpg" width="100%" height="100%"/><span>Casino</span>
            <p>Gerçek ya da<br>
                Eğlence için<br>
                oynayın !</p>
        </div>
        <div class="baslik">Canlı Casino & Tombala</div>
               
        <div id="main_slider2" class="nivoSlider"> <img src="/images/aside01.jpg"/> <img src="/images/aside02.jpg" /> <img src="/images/aside03.jpg" /> </div>
    </div>
	
	<div class="sidebar-module">
        <div class="module-title">
            <p><?php echo lang('dstk');?>
</p>
        </div>
        <div class="content">
            <ul class="listing-icon">
                <li><a href="<?php echo base_url();?>
info/hakkimizda"><i class="fa fa-angle-double-right"></i><?php echo lang('hakk');?>
</a></li>
                <li><a href="<?php echo base_url();?>
info/gizlilik"><i class="fa fa-angle-double-right"></i><?php echo lang('gizlilik');?>
</a></li>
                <li><a href="<?php echo base_url();?>
info/yardim"><i class="fa fa-angle-double-right"></i><?php echo lang('yrd');?>
</a></li>
                <li><a href="<?php echo base_url();?>
info/sozluk"><i class="fa fa-angle-double-right"></i><?php echo lang('szlk');?>
</a></li>
                <li><a href="<?php echo base_url();?>
info/bahiskurallari"><i class="fa fa-angle-double-right"></i><?php echo lang('bhskrl');?>
</a></li>
                <?php if (@direk=='0'){?>
				<li><a href="<?php if (@direk=='0'){?><?php echo base_url();?>
ayar/sistemdekiler<?php }else{ ?>#<?php }?>"><i class="fa fa-angle-double-right"></i><?php echo lang('sistd');?>
</a></li>
				<?php }?>
            </ul>
			<?php if (@direk=='1'){?>
            <div class="button-container"><a href="<?php if (@direk=='1'){?><?php echo base_url();?>
kayit<?php }else{ ?><?php echo base_url();?>
home<?php }?>">Kayıt Ol</a></div>
			<?php }?>
        </div>
    </div>
	
</div>


</aside><?php }} ?>