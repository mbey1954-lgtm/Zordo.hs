<?php /* Smarty version Smarty-3.1.8, created on 2018-08-10 12:36:58
         compiled from "application/views/templates/poker.tpl" */ ?>
<?php /*%%SmartyHeaderCode:20352734705b6d5cba2487c4-98283217%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'a6a94a6815647e2d38a7e4b465cd32ca2fa4498f' => 
    array (
      0 => 'application/views/templates/poker.tpl',
      1 => 1495553546,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '20352734705b6d5cba2487c4-98283217',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_5b6d5cba27f254_95151280',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5b6d5cba27f254_95151280')) {function content_5b6d5cba27f254_95151280($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ("header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<div class="coupons">	
	<div class="coupon-title">
		<div class="account-table-blue"><span>
			<div class="icon"><i class="fa fa-user"></i></div>
			</span>
			<p>Canlı Poker</p>
			</div>
		
		<iframe name="my-iframe" src="https://href.li/?https://betgames9.betgames.tv/ext/client/index/testpartner/zzg84vmgm4/tr/0/5/default" scrolling="no"  style="width:100%;height:1550px" frameBorder="0"></iframe>
</div>
</div>
<?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>
<?php }} ?>