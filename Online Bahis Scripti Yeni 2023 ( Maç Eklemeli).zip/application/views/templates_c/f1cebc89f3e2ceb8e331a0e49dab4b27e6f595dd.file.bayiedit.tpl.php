<?php /* Smarty version Smarty-3.1.8, created on 2018-08-26 19:58:09
         compiled from "application/views/templates/bayiedit.tpl" */ ?>
<?php /*%%SmartyHeaderCode:6903466895b82dc21c2eb22-45875654%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'f1cebc89f3e2ceb8e331a0e49dab4b27e6f595dd' => 
    array (
      0 => 'application/views/templates/bayiedit.tpl',
      1 => 1495310494,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '6903466895b82dc21c2eb22-45875654',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'yok' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_5b82dc21ca3362_34146774',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5b82dc21ca3362_34146774')) {function content_5b82dc21ca3362_34146774($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ("header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<?php echo $_smarty_tpl->getSubTemplate ("left.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>



<script>
$(function() {

	$("#kaydet").click(function(e) {
		var f = self.document.kform;
		if(f.sifre.value.length<1) { alert("<?php echo lang('sfrknt');?>
"); f.sifre.focus(); }else 
		if($('input[name=kiralikmi]:checked').val()==1 && f.hesapbaslangic.value.length<1) {
			alert("<?php echo lang('kira');?>
");
			f.hesapbaslangic.focus();
		}else {
		f.submit();
		}
    });
	
	$("#kaydets").click(function(e) {
		var f = self.document.kform;
		if($("input[name='domain[]']:checked").length == 0){
			alert("<?php echo lang('sitesec');?>
");return false;
		}else {
		f.submit();
		}
    });
		
});
function ePostaKont(eposta)
{
    var duzenli = new RegExp(/^[a-z]{1}[\d\w\.-]+@[\d\w-]{3,}\.[\w]{2,3}(\.\w{2})?$/);
    
    return duzenli.test(eposta);
}
function ekontrol()
{
    var giris = document.getElementById('email');
    
    if(ePostaKont(giris.value))
        giris.style.backgroundColor = "white";
    else
        giris.style.backgroundColor = "#F0D0D0";
}
function emkontrol()
{
    var giris = document.getElementById('email');
    
    if(!ePostaKont(giris.value)){
		giris.style.backgroundColor = "white";
		giris.value='';
		alert("<?php echo lang('emalkntr');?>
");
	}
}
</script>


<div class="coupons">	
	<div class="coupon-title">
		
		<?php if ($_smarty_tpl->tpl_vars['yok']->value){?>
		<div class="bos">
		<?php echo lang('byyok');?>

		</div>
		<?php }else{ ?>
			<?php if (@yetki=='1'){?>
				<?php echo $_smarty_tpl->getSubTemplate ("superedit.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

			<?php }elseif(@yetki=='3'){?>
				<?php echo $_smarty_tpl->getSubTemplate ("bayieditana.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

			<?php }elseif(@yetki=='2'){?>
				<?php echo $_smarty_tpl->getSubTemplate ("adminedit.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

			<?php }?>
		
		<?php }?>
		
</div>
</div>

<?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>
<?php }} ?>