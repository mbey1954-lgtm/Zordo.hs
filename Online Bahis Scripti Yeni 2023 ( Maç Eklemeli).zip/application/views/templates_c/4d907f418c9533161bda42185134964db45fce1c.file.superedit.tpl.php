<?php /* Smarty version Smarty-3.1.8, created on 2022-10-19 01:32:49
         compiled from "application/views/templates/superedit.tpl" */ ?>
<?php /*%%SmartyHeaderCode:2106755036634f29918b84d5-03225800%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '4d907f418c9533161bda42185134964db45fce1c' => 
    array (
      0 => 'application/views/templates/superedit.tpl',
      1 => 1495298311,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2106755036634f29918b84d5-03225800',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'veri' => 0,
    'ayr' => 0,
    'ayrs' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_634f29918f1c57_07769973',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_634f29918f1c57_07769973')) {function content_634f29918f1c57_07769973($_smarty_tpl) {?><div class="account-table-blue"><span>
	<div class="icon"><i class="fa fa-user"></i></div>
	</span>
	<p> (<?php echo $_smarty_tpl->tpl_vars['veri']->value->username;?>
) adlı Süperadmin Düzenleme Formu</p>
</div>


<form method="post" action="<?php echo base_url();?>
bayikayit/editform" name="kform">
<table style="margin:10px 0px 20px 10px;width:98%;color: <?php if (@tema==1){?>#000<?php }else{ ?>#fff<?php }?>;" id="table_step">
		<tr>
			<td colspan="2"><div class="formbaslik">Giriş Bilgileri</div></td>				
		</tr>
		<tr>
			<td>Kullanıcı Adı</td>				
			<td><input type="text" class="inputbet" readonly value="<?php echo $_smarty_tpl->tpl_vars['veri']->value->username;?>
"></td>				
		</tr>
		<tr>
			<td>Şifre</td>				
			<td><input type="text" class="inputbet" readonly value="*****"> Gizlidir.</td>				
		</tr>
		<tr>
			<td>Firma Adı</td>				
			<td><input type="text" class="inputbet" name="firma" value="<?php echo $_smarty_tpl->tpl_vars['veri']->value->firma;?>
"></td>				
		</tr>
		<tr>
			<td colspan="2" class="trenayar"><div class="formbaslik">Yetkileri / Yapabilecekleri</div></td>				
		</tr>
		<tr  height="40">
			<td>Site Yetkisi</td>				
			<td>
			<?php $_smarty_tpl->tpl_vars['ayrs'] = new Smarty_variable(explode("|",$_smarty_tpl->tpl_vars['ayr']->value->domain), null, 0);?>
			<?php echo domainver(3,'',$_smarty_tpl->tpl_vars['ayrs']->value);?>

			</td>				
		</tr>
		<tr>
			<td>Alt Kullanıcı Limiti</td>				
			<td><input type="text" class="inputbet" name="alt_sinir" value="<?php echo $_smarty_tpl->tpl_vars['ayr']->value->alt_sinir;?>
" size="5" maxlength="2"> Kaç tane admin oluşturabilir?</td>				
		</tr>		
		<tr>
			<td colspan="2" class="trenayar"><input type="button" class="button" value="Kaydet" id="kaydets"></td>			
		</tr>
	</table>
	<input type="hidden" name="userid" value="<?php echo $_GET['id'];?>
">
</form><?php }} ?>