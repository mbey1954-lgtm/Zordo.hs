<?php /* Smarty version Smarty-3.1.8, created on 2018-08-11 20:11:22
         compiled from "application/views/templates/mobil/index.tpl" */ ?>
<?php /*%%SmartyHeaderCode:15619338035b6f18ba721a59-05139524%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'f922708d9644a8cf131dbffca63dcfc3ff1eb51b' => 
    array (
      0 => 'application/views/templates/mobil/index.tpl',
      1 => 1495632018,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '15619338035b6f18ba721a59-05139524',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'fsay' => 0,
    'ssay' => 0,
    'bsay' => 0,
    'dsay' => 0,
    'dvarmi' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_5b6f18ba7e6d37_85093164',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5b6f18ba7e6d37_85093164')) {function content_5b6f18ba7e6d37_85093164($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ("mobil/header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>


<script>
	kuponsay();
	
	function paschange() {

		var newpass = $("#newpass").val();
		var newpasst = $("#newpasst").val();
		if(newpass != newpasst){alert('şifreler uyuşmuyor.');return false;}
		$.post(baseurl+'home/newpass',{newpass:newpass},function(data) {	
			if(data=="1") { 
				hata('Şifreniz Değişti.');				
				$("#newpass,#newpasst").val('');
				$("#paserror").html('');
				$( "#paschangediv" ).dialog( "close" );
			}else{
				$("#paserror").html('<div class="bos">bir güvenlik hatası oluştu.<br>yeniden deneyebilir veya sistem yöneticinize durumu bildirebilirsiniz.</div>');
			}
		});
	}
$(document).ready(function(e) {
	$('#paschange').live( "click", function() {
		$("#paserror").html('');
		$( "#paschangediv" ).dialog({
		  modal: true,
		  buttons: {
			Kaydet: function() {
			  paschange();
			}
		  }
		});
	});
});
</script>
<style>
body{width:100%}
#siff  a {
    border-top: 1px solid #b2b2b2;
    color: black;
    display: block;
    margin-bottom: -20px;
    margin-left: -7px;
    padding-bottom: 5px;
    padding-left: 7px;
    padding-top: 10px;
}.main {
  float: left;
  height: auto;
  margin-bottom: 20px;
  margin-top: 70px;
  width: 100%;
}.main_banner img {
  width: 100%;
}.small_table {
  background: #3d3d3d none repeat scroll 0 0;
  float: left;
  margin-left: 2.5%;
  margin-right: 2.5%;
  width: 95%;
}label {
  color: #b4201b;
  float: left;
  font-weight: bold;
  padding: 0 8px;
  text-shadow: 2px 1px 0 rgba(0, 0, 0, 0.4);
  width: 100%;
  font-size: 16px;
}.caption {
  align-items: center;
  background: #2e2e2e none repeat scroll 0 0;
  border: 1px solid #000000;
  display: flex;
  flex-direction: row;
  float: left;
  font-weight: bold;
  padding: 14px 10px;
  width: 100%;
}.main_category .mright {
  float: right;
  width: 50%;
}.icon-left-x {
  float: left;
  height: 20px;
  width: 20px;
}.icon-left-x .fa {
  background: rgba(0, 0, 0, 0) linear-gradient(to top, #8c1c17 0%, #b4201b 100%) repeat scroll 0 0;
  border-radius: 3px;
  color: white;
  filter: drop-shadow(1px 1px 1px black);
  float: left;
  font-size: 15px;
  height: 20px;
  line-height: 20px;
  margin: 0;
  width: 20px;
}.fa {
  float: right;
  margin-left: 10px;
  text-align: center;
  width: 15px;
}.main_category li, .panel_language li, .panel_settings li, .coupon_detail li, .panel li, .login li, .change_password li, .credit_transfer li {
  align-items: center;
  background: #3d3d3d none repeat scroll 0 0;
  border-bottom: 1px solid #000;
  border-left: 1px solid #000000;
  border-right: 1px solid #000000;
  color: white;
  display: flex;
  flex-direction: row;
  float: left;
  width: 100%;
}.main_category .mleft {
  border-right: 1px solid #000;
  float: left;
  width: 50%;
}.main_category li a, .sport_category li a, .panel_language li a, .panel_settings li a, .panel li a {
  align-items: center;
  color: white;
  display: flex;
  flex-direction: row;
  float: left;
  padding: 14px 10px;
  width: 100%;
}* {
  box-sizing: border-box;
  list-style-type: none;
  margin: 0;
  padding: 0;
}.right {
  align-items: center;
  display: flex;
  flex-direction: row;
  float: right;
  justify-content: center;
  margin-left: auto;
  text-align: center;
  width: auto;
}.main_banner {
  float: left;
  margin-top: 20px;
  margin-bottom: 20px;
  margin-left: 2.5%;
  margin-right: 2.5%;
  position: relative;
  width: 95%;
}.main_banner .text {
  color: #fff;
  float: left;
  height: auto;
  margin: 2% 0 0 5%;
  position: absolute;
  width: auto;
}.main_banner .text h2 {
  font-size: 4vw;
}.main_banner .text h1 {
  font-size: 2.3vw;
  margin-top: 8%;
  position: relative;
}.clear {
  float: left;
  height: 50px;
  margin-top: 7px;
  text-align: center;
  width: 100%;
}
</style>

<div id="paschangediv" title="Şifre Değiştirme" style="display:none">
	<p>
		
		<input type="text" class="inputbet" name="sifre" id="newpass">
		<br>
		Yeni Şifrenizi Yazınız.
		<br>
		
		<input type="text" class="inputbet" name="sifret" id="newpasst">
		<br>Şifrenizi Tekrar Yazınız.
	</p>
	<p id="paserror"></p>
</div>
<div style="left: 0px; right: 0px; z-index: 100; position: fixed; top: 0px;" class="appheader">
<?php echo mobilhead();?>


     <div><div class="header"><div onclick="goBack();" class="icon backc noselect "></div><div  class="text title noselect">Spor Bahisleri</div><div onclick="go('index')" style="padding-left:20px" class="icon logo noselect"></div></div></div>
</div>

<div style="margin-top: 120px;">
	<div class="small_table">
		<div class="caption">
			<div class="icon-left-x"><i class="fa fa-btc fa-lg"></i></div>
			    <label>Bahis</label>
		</div>
		<ul class="main_category">
			<li>
				<?php if (@futbol=='1'){?>
				<div class="mleft "><a title="#" onclick="go('home')"><span>Futbol</span>
					<div class="right">(<?php echo $_smarty_tpl->tpl_vars['fsay']->value;?>
)</div>
					</a></div>
				<?php }?>
				<?php if (@canlibahis=='1'){?>
				<div class="mright "><a title="#" onclick="go('canlibahis')"><span>Canlı Bahisleri</span>
					<div class="right">(<?php echo $_smarty_tpl->tpl_vars['ssay']->value;?>
)</div>
					</a></div>
				<?php }?>
			</li>
			<li>
				<?php if (@basketbol=='1'&&@baskapat=='0'){?>
				<div class="mleft "><a title="#" onclick="go('home/basketbol')"><span>Basketbol </span>
					<div class="right">(<?php echo $_smarty_tpl->tpl_vars['bsay']->value;?>
)</div>
					</a></div>
				<?php }?>
				<?php if (@duello=='1'&&@dukapat=='0'){?>
				<div class="mright "><a title="#" onclick="go('home/duello')"><span>Duello </span>
					<div class="right">(<?php echo $_smarty_tpl->tpl_vars['dsay']->value;?>
)</div>
					</a></div>
				<?php }?>
			</li>
		</ul>
	</div>
</div>

<div class="main_banner">
	    
	<div class="text">
	<h2>LIVE CASINO</h2>
	<h1>Blackjack<br>
	Roulette<br>
	Baccarat<br>
	Craps</h1>
	</div>
	<img src="/imglogin/mainslider02.jpg">
</div>

<?php if (@direk=='1'){?>
<div class="small_table" style="margin-top: 30px;">
	<div class="caption">
		<div class="icon-left-x"><i class="fa fa-info-circle fa-lg"></i></div>
		<label>Info</label>
	</div>
	<ul class="main_category">
		<li>
			<div class="mleft"><a title="#" href="<?php echo base_url();?>
mobil/info/sifremi_unuttum"><span>Şifremi Unuttum</span>
				<div class="right"><i class="fa fa-caret-right fa-lg"></i></div>
				</a></div>
			<div class="mright"><a title="#" href="<?php echo base_url();?>
mobil/info/hakkimizda"><span><?php echo lang('hakk');?>
</span>
				<div class="right"><i class="fa fa-caret-right fa-lg"></i></div>
				</a></div>
			
		</li>
		<li>
			<div class="mleft"><a title="#" href="<?php echo base_url();?>
mobil/info/yardim"><span><?php echo lang('yrd');?>
</span>
				<div class="right"><i class="fa fa-caret-right fa-lg"></i></div>
				</a></div>
			<div class="mright"><a title="#" href="<?php echo base_url();?>
mobil/info/gizlilik"><span><?php echo lang('gizlilik');?>
</span>
				<div class="right"><i class="fa fa-caret-right fa-lg"></i></div>
				</a></div>
		</li><li>
			<div class="mleft"><a title="Masaüstü" href="<?php echo base_url();?>
home/?masaustu=1"><span>Masaüstü</span>
				<div class="right"><i class="fa fa-caret-right fa-lg"></i></div>
				</a></div>
			<div class="mright"><a title="<?php echo base_url();?>
mobil/info/sozluk" href="#"><span><?php echo lang('szlk');?>
</span>
				<div class="right"><i class="fa fa-caret-right fa-lg"></i></div>
				</a></div>
		</li>
	</ul>
</div>
<?php }else{ ?>
<div class="small_table" style="">
	<div class="caption">
		<div class="icon-left-x"><i class="fa fa-info-circle fa-lg"></i></div>
		<label>Info</label>
	</div>
	<ul class="main_category">
		<li>
			<div class="mleft"><a title="#" href="<?php echo base_url();?>
home/?masaustu=1"><span>Masaüstü</span>
				<div class="right"><i class="fa fa-caret-right fa-lg"></i></div>
				</a></div>
			<div class="mright"><a title="#" href="#"><span id="paschange">Şifre Değiştir</span>
				<div class="right"><i class="fa fa-caret-right fa-lg"></i></div>
				</a></div>
		</li>
		<li>
			<div class="mleft"><a title="#" href="#" onclick="go('raporlar')"><span><?php echo lang('rpr');?>
</span>
				<div class="right"><i class="fa fa-caret-right fa-lg"></i></div>
				</a></div>
			<div class="mright"><a title="" href="<?php echo base_url();?>
mobil/info/sozluk"><span>Bahis Sözlüğü</span>
				<div class="right"><i class="fa fa-caret-right fa-lg"></i></div>
				</a></div>
		</li>
		<?php if (@yetki=='4'){?>
		<li>
			<div class="mleft"><a title="#" href="<?php echo base_url();?>
mobil/info/banka_hesap"><span><?php echo lang('bnkhesap');?>
</span>
				<div class="right"><i class="fa fa-caret-right fa-lg"></i></div>
				</a></div>
			
		</li>
		<?php }?>
	</ul>
</div>
<?php }?>
<?php $_smarty_tpl->tpl_vars['dvarmi'] = new Smarty_variable(duyurular(), null, 0);?>
<?php if ($_smarty_tpl->tpl_vars['dvarmi']->value){?>
<div style="padding-bottom:0px;margin-top:5px;margin-bottom:5px;margin-right:5px;background:#2A7394; height: 37px; font-size:24px; color:#FFF; font-weight:bold; text-align:center;" id="siff">
<marquee onmouseover="this.setAttribute('scrollamount', 0, 0);" onmouseout="this.setAttribute('scrollamount', 6, 0);" scrollamount="6" style="float: left; width: 90%;padding-top: 2px;font-size:14px;">
<ul style="list-style:none;margin-top: 6px;float: left;"><?php echo $_smarty_tpl->tpl_vars['dvarmi']->value;?>
</ul></marquee>
</div>
<?php }?>

<div class="clear"> </div>
<?php echo $_smarty_tpl->getSubTemplate ("mobil/footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>
<?php }} ?>