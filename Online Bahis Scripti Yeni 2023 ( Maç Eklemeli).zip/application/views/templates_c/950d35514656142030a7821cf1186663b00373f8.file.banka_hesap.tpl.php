<?php /* Smarty version Smarty-3.1.8, created on 2019-01-03 11:37:50
         compiled from "application/views/templates/banka_hesap.tpl" */ ?>
<?php /*%%SmartyHeaderCode:19102461475c2dc9de91dfb5-32523588%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '950d35514656142030a7821cf1186663b00373f8' => 
    array (
      0 => 'application/views/templates/banka_hesap.tpl',
      1 => 1495655694,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '19102461475c2dc9de91dfb5-32523588',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'liste' => 0,
    'keyi' => 0,
    'row' => 0,
    'keyibu' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_5c2dc9de9931a3_66199536',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5c2dc9de9931a3_66199536')) {function content_5c2dc9de9931a3_66199536($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ("header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>



<style>
.mb_bank_account {
display: none;
}
</style>
<script>
function kayit(k){
	
	$.ajax({type:'POST',url:baseurl+'ayar/pcetir_yatir',data:$("form#pacek"+k).serialize(),
	success:function(snc){
		failcont(snc);
	}	
	});
	$("form#pacek"+k).find('input, select').not('input[type=hidden]').val('').removeAttr('selected');
	return false;
}

</script>

<div class="menu">	
<div class="user-menu-container">
<div class="user-menu-title"><?php echo lang('trns');?>
</div>
	<?php echo $_smarty_tpl->getSubTemplate ("transfer_left.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

</div>
</div>

<div class="coupons">
	<div class="coupon-title">
		<div class="account-table-blue"><span>
			<div class="icon"><i class="fa fa-user"></i></div>
			</span>
			<p><?php echo lang('bnkhesap');?>
</p>
		</div>		
		<div style="background: #3b3b3b none repeat scroll 0 0;
float: left;
padding: 20px;
width: 100%;border: 1px solid #000;">

		<div class="formbaslik"><b>Güncel</b> Banka Hesap Bilgilerine Buradan Ulaşabilirsiniz</b></div>
		<div style="border: 1px solid #000;
    color: #ccc;"><b><font size="3" color="red"> <div align="center"><p>>>DİKKAT!<<</p></div><p> En düşük Para yatırma limiti 100 TL, En yüksek Para yatırma limiti 10000 TL dir. Lütfen Para yatırma işleminden sonra canlı yardımdan bilgi veriniz.</p></font></b></div>
	
	<div style="width: 200px; margin: 10px 0px; color: rgb(204, 204, 204);" class="formbaslik">Lütfen Banka Seçiniz :</div>
	<select style="width: 200px" id="mb_bank" name="mb_bank">
		<?php  $_smarty_tpl->tpl_vars['row'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['row']->_loop = false;
 $_smarty_tpl->tpl_vars['keyi'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['liste']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['row']->key => $_smarty_tpl->tpl_vars['row']->value){
$_smarty_tpl->tpl_vars['row']->_loop = true;
 $_smarty_tpl->tpl_vars['keyi']->value = $_smarty_tpl->tpl_vars['row']->key;
?>
		<option value="<?php echo $_smarty_tpl->tpl_vars['keyi']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['row']->value->banka;?>
</option>
		<?php } ?>
		</select>
		<?php  $_smarty_tpl->tpl_vars['row'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['row']->_loop = false;
 $_smarty_tpl->tpl_vars['keyibu'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['liste']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['row']->key => $_smarty_tpl->tpl_vars['row']->value){
$_smarty_tpl->tpl_vars['row']->_loop = true;
 $_smarty_tpl->tpl_vars['keyibu']->value = $_smarty_tpl->tpl_vars['row']->key;
?>
		<div class="mb_bank_account" id="mb_bank_account__<?php echo $_smarty_tpl->tpl_vars['keyibu']->value;?>
" style="<?php if ($_smarty_tpl->tpl_vars['keyibu']->value==0){?>display:block;<?php }?>"><div style="text-align: center;"><img height="37" style="border: 1px solid #000;" src="<?php echo base_url();?>
images/bnk/<?php echo $_smarty_tpl->tpl_vars['row']->value->img;?>
.png" width="165"/></div><div class="mb_bank_details"><table class="tftable" style="width: 100%"><tbody><tr><td width="240">Hesap İsmi</td><td width="5">:</td><td><?php echo $_smarty_tpl->tpl_vars['row']->value->isim;?>
</td></tr><tr><td >Şube Kodu</td><td >:</td><td><?php echo $_smarty_tpl->tpl_vars['row']->value->sube;?>
</td></tr><tr><td >Hesap No</td><td >:</td><td><?php echo $_smarty_tpl->tpl_vars['row']->value->hesap;?>
</td></tr><tr><td >IBAN</td><td >:</td><td><?php echo $_smarty_tpl->tpl_vars['row']->value->iban;?>
</td></tr></tbody></table></div>
		<div style=" margin: 10px 0px; color: rgb(204, 204, 204);" class="formbaslik">Ödeme Bildirim Formu</div>
		<form id="pacek<?php echo $_smarty_tpl->tpl_vars['keyibu']->value;?>
" method="post" onsubmit="return kayit(<?php echo $_smarty_tpl->tpl_vars['keyibu']->value;?>
);">
			<input name="banka" type="hidden" value="<?php echo $_smarty_tpl->tpl_vars['row']->value->banka;?>
">
			<input name="sube" type="hidden" value="<?php echo $_smarty_tpl->tpl_vars['row']->value->sube;?>
">
			<input name="iban" type="hidden" value="<?php echo $_smarty_tpl->tpl_vars['row']->value->iban;?>
">
			<input name="hesap" type="hidden" value="<?php echo $_smarty_tpl->tpl_vars['row']->value->hesap;?>
">
			<table id="table_step" style="margin:10px 0px 20px 10px;width:98%;color: #fff;">
				<tbody>
				<tr>
					<td>Ad Soyad :</td>
					<td><input name="isim" maxlength="25" required="required" value="<?php echo @ad;?>
" type="text">
					</td>
				</tr>
				<tr>
					<td><?php echo lang('ttr');?>
 :</td>
					<td><input name="tutar" maxlength="10" required="required" type="text"></td>
				</tr>
				<tr>
					<td>Not :</td>
					<td><input name="not" type="text"></td>
				</tr>
				<tr>
					<td colspan="2"><button class="button" type="submit"><?php echo lang('gndr');?>
</button></td>
				</tr>
			</table>
		</form>
		</div>
		<?php } ?>
		</div>
		

</div>
</div>


<script>
  $('#mb_bank').on('change',function() {
		$('.mb_bank_account').hide();
		$('#mb_bank_account__' + $(this).val()).fadeIn();
	});
</script>



<?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>
<?php }} ?>