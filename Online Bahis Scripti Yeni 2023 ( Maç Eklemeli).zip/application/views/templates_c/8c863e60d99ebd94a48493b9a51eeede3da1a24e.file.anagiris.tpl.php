<?php /* Smarty version Smarty-3.1.8, created on 2022-09-15 19:54:38
         compiled from "application/views/templates/mobil/anagiris.tpl" */ ?>
<?php /*%%SmartyHeaderCode:207284965632358ce7834d7-52286043%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '8c863e60d99ebd94a48493b9a51eeede3da1a24e' => 
    array (
      0 => 'application/views/templates/mobil/anagiris.tpl',
      1 => 1663257884,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '207284965632358ce7834d7-52286043',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_632358ce7bea66_54810940',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_632358ce7bea66_54810940')) {function content_632358ce7bea66_54810940($_smarty_tpl) {?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" manifest="/manifest.mf">
<head>

<script type="text/javascript">
	var baseurl = "<?php echo base_url();?>
mobil/";
</script>

<meta name="robots" content="noindex,nofollow" />
<title><?php echo @title;?>
 Mobile</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<meta name="apple-mobile-web-app-capable" content="yes"/>
<meta name="viewport" content="width=device-width, maximum-scale=1, initial-scale=1.0, user-scalable=no"/><meta name="mobile-web-app-capable" content="yes"/>
<meta name="apple-mobile-web-app-status-bar-style" content="black"/>
<meta name="format-detection" content="telephone=no"/>
<meta http-equiv="x-ua-compatible" content="IE=8"/>		
<link type="text/css" rel="stylesheet" href="<?php echo base_url();?>
css/mobil/mobile.css"/>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">	
</head>

<script>
function gologin(yer){
	window.location.href=baseurl+'login/home/?direct='+yer;
}
function go(yer){
	window.location.href=baseurl+yer;
}
</script>
<style>
body{width:100%}
.wrapperz{
    margin:0px auto;
	padding:0px;
    max-width:600px;
    background: url(/css/mobil/ust.jpg);	
	background-repeat: no-repeat;
    background-size: 100% auto;
    background-position: center top;
    height: 200px;
    
    
}
.create-button {
  background: #b4201b none repeat scroll 0 0;
  border: 1px solid #000000;
  height: 23px;
  margin-bottom: 10px !important;
  text-align: center;
  width: 100%;
  padding:7px 15px;
  color:#fff;
}
.main {
  float: left;
  height: auto;
  margin-bottom: 20px;
  margin-top: 70px;
  width: 100%;
}.main_banner img {
  width: 100%;
}.small_table {
  background: #3d3d3d none repeat scroll 0 0;
  float: left;
  margin-left: 2.5%;
  margin-right: 2.5%;
  width: 95%;
}label {
  color: #b4201b;
  float: left;
  font-weight: bold;
  padding: 0 8px;
  text-shadow: 2px 1px 0 rgba(0, 0, 0, 0.4);
  width: 100%;
  font-size: 16px;
}.caption {
  align-items: center;
  background: #2e2e2e none repeat scroll 0 0;
  border: 1px solid #000000;
  display: flex;
  flex-direction: row;
  float: left;
  font-weight: bold;
  padding: 14px 10px;
  width: 100%;
}.main_category .mright {
  float: right;
  width: 50%;
}.icon-left-x {
  float: left;
  height: 20px;
  width: 20px;
}.icon-left-x .fa {
  background: rgba(0, 0, 0, 0) linear-gradient(to top, #8c1c17 0%, #b4201b 100%) repeat scroll 0 0;
  border-radius: 3px;
  color: white;
  filter: drop-shadow(1px 1px 1px black);
  float: left;
  font-size: 15px;
  height: 20px;
  line-height: 20px;
  margin: 0;
  width: 20px;
}.fa {
  float: right;
  margin-left: 10px;
  text-align: center;
  width: 15px;
}.main_category li, .panel_language li, .panel_settings li, .coupon_detail li, .panel li, .login li, .change_password li, .credit_transfer li {
  align-items: center;
  background: #3d3d3d none repeat scroll 0 0;
  border-bottom: 1px solid #000;
  border-left: 1px solid #000000;
  border-right: 1px solid #000000;
  color: white;
  display: flex;
  flex-direction: row;
  float: left;
  width: 100%;
}.main_category .mleft {
  border-right: 1px solid #000;
  float: left;
  width: 50%;
}.main_category li a, .sport_category li a, .panel_language li a, .panel_settings li a, .panel li a {
  align-items: center;
  color: white;
  display: flex;
  flex-direction: row;
  float: left;
  padding: 14px 10px;
  width: 100%;
}* {
  box-sizing: border-box;
  list-style-type: none;
  margin: 0;
  padding: 0;
}.right {
  align-items: center;
  display: flex;
  flex-direction: row;
  float: right;
  justify-content: center;
  margin-left: auto;
  text-align: center;
  width: auto;
}.main_banner {
  float: left;
  margin-top: 20px;
  margin-bottom: 20px;
  margin-left: 2.5%;
  margin-right: 2.5%;
  position: relative;
  width: 95%;
}.main_banner .text {
  color: #fff;
  float: left;
  height: auto;
  margin: 2% 0 0 5%;
  position: absolute;
  width: auto;
}.main_banner .text h2 {
  font-size: 4vw;
}.main_banner .text h1 {
  font-size: 2.3vw;
  margin-top: 8%;
  position: relative;
}.clear {
  float: left;
  height: 50px;
  margin-top: 7px;
  text-align: center;
  width: 100%;
}.footer {
  align-items: center;
  bottom: 0;
  box-shadow: 0 0 7px 3px rgba(0, 0, 0, 0.8);
  box-sizing: border-box;
  display: flex;
  flex-direction: row;
  height: 47px;
  justify-content: center;
  position: fixed;
  text-align: center;
  width: 100%;
}.footer .tabicon {
  width: 312px;
}.footer .tabicon li {
  color: black;
  float: left;
  margin: 3px 0 0;
  text-align: center;
  width: 78px;
}.footer .tabicon li a.active {
  color: #b4201b;
}.footer .tabicon li a {
  color: white;
  text-shadow: 0 0 2px #000;
}a {
  text-decoration: none;
}.footer .tabicon li .fa {
  font-size: 27px;
  margin-bottom: 5px;
  position: relative;
  text-align: center;
  width: 100%;
}.footer .tabicon li p {
  color: white;
  font-size: 12px;
  font-weight: normal;
  width: auto;
}ul {
  margin-top: 0px;
}.footer .tabicon li a.active {
  color: #b4201b;
}
</style>


<div style="left: 0px; right: 0px; z-index: 100; position: fixed; top: 0px;" class="appheader">

<div><div class="header"><div  class="icon noselect "></div><div class="text title noselect"><img src="/img/logo.svg" height="28" width="100"></div><div  style="padding-left:20px" class="icon logo noselect"></div></div></div></div>


<div style="margin-top: 70px;">
	<div class="small_table">
		<div class="caption">
			<div class="icon-left-x"><i class="fa fa-btc fa-lg"></i></div>
			<label>Bahis</label>
		</div>
		<ul class="main_category">
			<li>
				<div class="mleft "><a title="#" ><span>Futbol</span>
					<div class="right"><i class="fa fa-caret-right fa-lg"></i></div>
					</a></div>
				<div class="mright "><a title="#" ><span>Canlı Bahisleri</span>
					<div class="right"><i class="fa fa-caret-right fa-lg"></i></div>
					</a></div>
			</li>
			<li>
				<div class="mleft "><a title="#" ><span>Basketbol </span>
					<div class="right"><i class="fa fa-caret-right fa-lg"></i></div>
					</a></div>
				<div class="mright "><a title="#" ><span>Duello </span>
					<div class="right"><i class="fa fa-caret-right fa-lg"></i></div>
					</a></div>
			</li>
		</ul>
	</div>
</div>

<div class="main_banner">
	    
	<div class="text">
	<h2>LIVE CASINO</h2>
	<h1>Blackjack<br>
	Roulette<br>
	Baccarat<br>
	Craps</h1>
	</div>
	<img src="/imglogin/mainslider02.jpg">
</div>

<div class="small_table">
	<div class="caption">
		<div class="icon-left-x"><i class="fa fa-star fa-lg"></i></div>
		<label>Casino</label>
	</div>
	<ul class="main_category">
		<li>
			<div class="mleft"><a href="#"><span>Slot</span>
				<div class="right"><i class="fa fa-caret-right fa-lg"></i></div>
				</a></div>
			<div class="mright"><a href="#"><span>Canlı Casino</span>
				<div class="right"><i class="fa fa-caret-right fa-lg"></i></div>
				</a></div>
		</li>
		<li>
			<div class="mleft"><a href="#"><span>Canlı Tombala</span>
				<div class="right"><i class="fa fa-caret-right fa-lg"></i></div>
				</a></div>
			<div class="mright"><a href="#"><span>Diger oyunlar</span>
				<div class="right"><i class="fa fa-caret-right fa-lg"></i></div>
				</a></div>
		</li>
	</ul>
</div>

<div class="small_table" style="margin-top: 30px;">
	<div class="caption">
		<div class="icon-left-x"><i class="fa fa-info-circle fa-lg"></i></div>
		<label>Info</label>
	</div>
	<ul class="main_category">
		<li>
			<div class="mleft"><a title="#" href="<?php echo base_url();?>
mobil/info/hakkimizda"><span>Hakkımızda</span>
				<div class="right"><i class="fa fa-caret-right fa-lg"></i></div>
				</a></div>
			<div class="mright"><a title="#" href="<?php echo base_url();?>
mobil/info/yardim"><span>Yardım (S.S.S)</span>
				<div class="right"><i class="fa fa-caret-right fa-lg"></i></div>
				</a></div>
		</li>
		<li>
			<div class="mleft"><a title="#" href="<?php echo base_url();?>
mobil/info/gizlilik"><span>Gizlilik politikası</span>
				<div class="right"><i class="fa fa-caret-right fa-lg"></i></div>
				</a></div>
			<div class="mright"><a title="#" href="<?php echo base_url();?>
mobil/info/sozluk"><span>Bahis Sözlüğü</span>
				<div class="right"><i class="fa fa-caret-right fa-lg"></i></div>
				</a></div>
		</li>
	</ul>
</div>	
<!--<div style="margin-left:10%;margin-right: 15%;margin-top: 25%">

<div class="create-button" onclick="gologin('mobil');"><span>Mobil</span></div>
<div class="create-button" onclick="gologin('masaustu');"><span>Masaüstü</span></div>

</div>-->

<div class="clear"> </div>
<div class="footer blue">
  <ul class="tabicon">
    <li><a onclick="go('index')" class="active"><i class="fa fa-home fa-lg"></i>
      <p>Anasayfa</p>
      </a></li>
    <li><a ><i class="fa fa-caret-square-o-right fa-lg"></i>
      <p>Canlı</p>
      </a></li>
    
    <li><a onclick="go('login/home/?direct=mobil')"><i class="fa  fa-user fa-lg"></i>
      <p>Oturum</p>
      </a></li>
    
    <li><a href="#"><i class="fa  fa-list-ul fa-lg"></i>
      <p>Bahis Kuponu</p>
      </a>
    </li>
  </ul>
</div><?php }} ?>