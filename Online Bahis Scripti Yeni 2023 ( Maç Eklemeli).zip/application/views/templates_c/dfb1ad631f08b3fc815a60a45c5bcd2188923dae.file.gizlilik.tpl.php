<?php /* Smarty version Smarty-3.1.8, created on 2018-09-23 05:44:36
         compiled from "application/views/templates/mobil/gizlilik.tpl" */ ?>
<?php /*%%SmartyHeaderCode:13715382755ba6fe141e4c72-13800410%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'dfb1ad631f08b3fc815a60a45c5bcd2188923dae' => 
    array (
      0 => 'application/views/templates/mobil/gizlilik.tpl',
      1 => 1495442495,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '13715382755ba6fe141e4c72-13800410',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_5ba6fe1440f2a7_02926810',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5ba6fe1440f2a7_02926810')) {function content_5ba6fe1440f2a7_02926810($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ("mobil/header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<?php echo $_smarty_tpl->getSubTemplate ("mobil/header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>


<style>
.support-text {
  color: gray;
  float: left;
  padding: 10px;
  width: 100%;
}#myDiv1, #myDiv2, #myDiv3, #myDiv4, #myDiv5, #myDiv6, #myDiv7, #myDiv8, #myDiv9, #myDiv10, #myDiv11, #myDiv12, #myDiv13, #myDiv14, #myDiv15, #myDiv16, #myDiv17, #myDiv18, #myDiv19, #myDiv20, #myDiv21, #myDiv22, #myDiv23, #myDiv24, #myDiv25, #myDiv26, #myDiv27, #myDiv28, #myDiv29, #myDiv30, #myDiv31, #myDiv32, #myDiv33, #myDiv34 {
  height: 50px;
  margin-bottom: 0;
  width: 100%;
}.support-text h1, .bonus-text h1 {
  color: #de7b24;
  font-size: 17px;
}.support-text ol, .bonus-text ol {
  padding: 20px;
}.support-text ol li, .bonus-text ol li {
  list-style-type: decimal;
  margin-left: 20px;
  padding: 5px;
}.new-content p, .support-text p {
  color: black;
  line-height: 20px;
  margin-bottom: 10px;
  margin-top: 10px;
}#text1, #text2, #text3, #text4, #text5, #text6, #text7, #text8, #text9, #text10, #text11, #text12, #text13, #text14, #text15, #text16, #text17, #text18, #text19, #text20, #text21, #text22, #text23, #text24, #text25, #text26, #text27, #text28, #text29, #text30, #text31, #text32, #text33, #text34 {
  color: gray;
}#text1 a, #text2 a, #text3 a, #text4 a, #text5 a, #text6 a, #text7 a, #text8 a, #text9 a, #text10 a, #text11 a, #text12 a, #text13 a, #text14 a, #text15 a, #text16 a, #text17 a, #text18 a {
  color: gray;
  cursor: pointer;
  font-size: 13px;
  line-height: 20px;
  margin-left: 7px;
}
</style>
<script type="text/javascript">
	 $(window).load(function() {  $("#text1").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv1").offset().top  }, 1000);  });     $("#text2").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv2").offset().top  }, 1000);  });     $("#text3").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv3").offset().top  }, 1000);  });     $("#text4").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv4").offset().top  }, 1000);  });     $("#text5").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv5").offset().top  }, 1000);  });     $("#text6").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv6").offset().top  }, 1000);  });     $("#text7").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv7").offset().top  }, 1000);  });     $("#text8").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv8").offset().top  }, 1000);  });     $("#text9").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv9").offset().top  }, 1000);  });     $("#text10").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv10").offset().top  }, 1000);  });     $("#text11").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv11").offset().top  }, 1000);  });     $("#text12").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv12").offset().top  }, 1000);  });     $("#text13").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv13").offset().top  }, 1000);  });     $("#text14").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv14").offset().top  }, 1000);  });     $("#text15").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv15").offset().top  }, 1000);  });     $("#text16").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv16").offset().top  }, 1000);  });     $("#text17").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv17").offset().top  }, 1000);  });     $("#text18").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv18").offset().top  }, 1000);  });     $("#text19").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv19").offset().top  }, 1000);  });     $("#text20").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv20").offset().top  }, 1000);  });     $("#text21").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv21").offset().top  }, 1000);  });     $("#text22").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv22").offset().top  }, 1000);  });     $("#text23").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv23").offset().top  }, 1000);  });     $("#text24").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv24").offset().top  }, 1000);  });     $("#text25").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv25").offset().top  }, 1000);  });     $("#text26").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv26").offset().top  }, 1000);  });     $("#text27").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv27").offset().top  }, 1000);  });     $("#text28").click(function() {  $('html, body').animate({   scrollTop: $("#myDiv28").offset().top  }, 1000);  });        $("#text29").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv29").offset().top  }, 1000);  });     $("#text30").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv30").offset().top  }, 1000);  });     $("#text31").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv31").offset().top  }, 1000);  });     $("#text32").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv32").offset().top  }, 1000);  });     $("#text33").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv33").offset().top  }, 1000);  }); $('.go_top2').click(function(){ $('body,html').animate({scrollTop:0},800); });   });
    </script> 

<div style="left: 0px; right: 0px; z-index: 100; position: fixed; top: 0px;" class="appheader">
<?php echo mobilhead();?>

<div><div class="header"><div onclick="goBack();" class="icon back noselect "></div><div class="text title noselect"><?php echo lang('gizlilik');?>
</div><div onclick="go('index')" style="padding-left:20px" class="icon logo noselect"></div></div></div></div>

<div class="page slide top in" id="page1"><div class="scroll_container" style=""><div class="scroll_wrapper" style="padding-top: 85px; padding-bottom: 44px;"><div class="appcontent"><div>  </div>

<div id="ticket_bodys">
<div class="edtitle " style="border: 1px solid #000"><div class="text">

<div style="font-size:20px;line-height:30px;text-align:left;padding-left:10px">
<div class="support-text">
            <div id="text1"><i class="fa fa-angle-double-right"></i><a>I. Genel</a></div>
            <div id="text2"><i class="fa fa-angle-double-right"></i><a>II. Kazançlar ve kazançların tespiti</a></div>
            <div id="text3"><i class="fa fa-angle-double-right"></i><a>III. Para çekme ve kazanç limitleri</a></div>
            <div id="text4"><i class="fa fa-angle-double-right"></i><a>IV. Hesap / Hesap açma</a></div>
            <div id="text5"><i class="fa fa-angle-double-right"></i><a>V. Para Çekme</a></div>
            <div id="text6"><i class="fa fa-angle-double-right"></i><a>VI. www.<?php echo @title;?>
.com’da bahis yapma</a></div>
            <div id="text7"><i class="fa fa-angle-double-right"></i><a>VII. Hesap Bilgileri</a></div>
            <div id="text8"><i class="fa fa-angle-double-right"></i><a>VIII. Bahis Bilgileri</a></div>
            <div id="text9"><i class="fa fa-angle-double-right"></i><a>IX. Bahis Oynama ve Bayi işlemleri  İçin Düzenlemeler</a></div>
            <div id="text10"><i class="fa fa-angle-double-right"></i><a>X. Genel Bahis Kuralları</a></div>
            <div id="text11"><i class="fa fa-angle-double-right"></i><a>XI. Bahis Pazarları</a></div>
            <div id="text12"><i class="fa fa-angle-double-right"></i><a>XII. Spor Çeşitleri</a></div>
            <div id="text13"><i class="fa fa-angle-double-right"></i><a>XIII. Casino</a></div>
            <div id="text14"><i class="fa fa-angle-double-right"></i><a>XIV. Veri koruma yönetmeliği</a></div>
            <div id="text15"><i class="fa fa-angle-double-right"></i><a>XV. Şikayetler</a></div>
        </div><div class="support-text">
            <div id="myDiv1"></div>
            <h1>I. Genel</h1>
            <ol>
                <li>
                    <p><?php echo @title;?>
 Spor Bahisleri, Curaçao yasalarına göre kurulmuş olan New Vision MNG N.V. tarafından işletilmektedir. 137841  kayıt numarasıyla Şirketler Sicili'ne kaydedilmiştir ve işyeri adresi Dr. Hugenholtzweg z/n, UTS Gebouw, Vredenberg Willemstad, Curacao’dur. Vision MNG N.V., C.I.L. Curacao Interactive Licensing N.V. tarafından lisanslıdır ve denetlenmektedir. Bu sebeple online (çevrimiçi) bahis ve şans oyunları alanında hizmet sunma yetkisine sahiptir. Lisans 1668/Jaz lisans numarası ile başlamıştır. </p>
                    <p>İşbu genel kural ve şartlarda New Vision MNG N.V. "<?php echo @title;?>
" olarak anılacaktır. </p>
                </li>
                <li>
                    <p><?php echo @title;?>
.com domain adresi <?php echo @title;?>
 tarafından işletilmektedir. <?php echo @title;?>
 farklı sebeplerden dolayı, örneğin farklı ülkelerden ulaşımı sağlamak amacıyla farklı üst-seviye domain adreslerini kullanabilir. </p>
                </li>
                <li>
                    <p>Web sayfası ya da anlaşmalı bayiler vasıtası ile yapılan tüm bahisler, Curacao,da düzenlenir, saklanır, alınır, oynanır ve işletilir. <?php echo @title;?>
 bahislere ait vergileri ve diğer vergileri Curaçao’da öder. </p>
                </li>
                <li>
                    <p>Her bahis sözleşmesinde taraflar <?php echo @title;?>
 ve bahis müşterisidir. </p>
                </li>
                <li>
                    <p><?php echo @title;?>
'te bahis oynayabilmesi için müşteri genel kural ve şartları kabul etmelidir. </p>
                </li>
                <li>
                    <p><?php echo @title;?>
’in bu genel kural ve şartlarda herhangi bir zamanda değişiklik yapma hakkı saklıdır. Güncel ve geçerli kuralları takip etmek müşterinin sorumluluğundadır. </p>
                </li>
                <li>
                    <p>Belirli ülkelerde ikamet eden bir kısım veya tüm kişilerin ya da bu ülkelerde bulunanların web sayfasına erişimlerinin engellendiği durumlar ihtimal dahilindedir. Bahis ve şans oyunlarının yasadışı olduğu ülkelerde bulunan bireylerin web sitesini bu amaçlar dahilinde kullanması <?php echo @title;?>
 tarafından amaçlanmaz. Web sitesi, bu gibi etkinliklerin yasadışı olduğu ülke ve bölgelerde kullanılmasını teşvik eden bir hizmet, tanıtım veya davetiye olarak algılanmamalıdır. </p>
                </li>
                <li>
                    <p>Bulunduğu ülke ve bölgeye ait konu ile ilgili yasalar hakkında bilgi sahibi olmak, müşterinin kendi sorumluluğu dahilindedir. </p>
                </li>
                <li>
                    <p>Müşteri bireysel olarak web sitesini kullanırken ve/veya bahis yaparken, yaşadığı bölgede yasalara uygun davrandığından emin olmalıdır. Müşterinin yerel yasalararı ihlal ettiği durumlarda, <?php echo @title;?>
 hiçbir yargı alanında sorumlu tutulamaz. </p>
                </li>
                <li>
                    <p>Bahis kayıt ekibi, bahis bayileri ve onların çalışanları adına veya hesabına yapılan bahisler kabul edilmez. Müşterinin şahsi olarak içerisinde yer aldığı (örneğin müsabakada oynayan sporcu, kulüp başkanı/sahibi, teknik direktör veya kulüp yöneticisi) müsabakalara yapılan bahisler kabul edilmez. <?php echo @title;?>
’nin, bahis halihazırda yapılmış dahi olsa, bu bahisleri iptal etme hakkı saklıdır. </p>
                </li>
                <li>
                    <p><?php echo @title;?>
 herhangi bir sebep göstermeksizin aşağıdaki işlemleri yapma hakkına sahiptir:</p>
                    <p>- Bahis hesabı açmak için yapılan talebi reddetme;</p>
                    <p>- Yapılan bir bahsi kabul etmeme;</p>
                    <p>- Herhangi bir bahis için yapılabilecek bahis miktarını limitlendirme;</p>
                    <p>- Herhangi bir müşterinin yapabilecegi bahis miktarını limitlendirme.</p>
                </li>
                <li>
                    <p><?php echo @title;?>
’in mevcut bir bahis hesabını herhangi bir sebep göstermeksizin kapatma hakkı saklıdır. Bu gibi hallerde müşteriyle mevcut bakiye ile irtibata gecilir. Özellikle bahis yapılırken, hile ya da hile girişimi söz konusu olduğunda, müşterinin üyeliğine derhal son verilir. </p>
                </li>
                <li>
                    <p>Bahis verilerine ait transferlerde ve müsabaka sonuçları ile ilgili bilgilerde oluşabilecek hatalar için <?php echo @title;?>
 sorumluluk kabul etmez. <?php echo @title;?>
 kendi sunduğu hizmetler için üçüncü şahıs ve şirketler tarafından sunulan hizmetlerden de yararlanmaktadır ve bu anlaşmalarda da belirtildiği üzere muhtemel hatalarda <?php echo @title;?>
 sorumlu tutulmaz. Bu sebeple hatalı, gecikmiş, manipüle edilmiş veya kötüye kullanılmış veri aktarımı ya da veri aktarımında oluşabilecek herhangi bir hata söz konusu olduğunda, <?php echo @title;?>
 tarafından tazmin edilme zorunluluğu yoktur. </p>
                </li>
                <li>
                    <p>Bahis müşterisi, <?php echo @title;?>
'ten alacaklarını karşılıklı veya karşılıksız olarak devretme veya ipotek ettirme yetkisine sahip değildir. </p>
                </li>
                <li>
                    <p>Müşteriye ait bahis hesabının farklı kişilerce kullanıcı adı ve şifre girilerek, hatalı şekilde kullanımında <?php echo @title;?>
 hiçbir sorumluluk kabul etmez. Bahis müşterisi, kullanıcı adı ve şifresinin gizliliğinden kendisi sorumludur. Tüm hesap hareketler, para yatırma ve çekme işlemleri bu bilgilerin ait olduğu hesapta kayıt altına alınır. </p>
                </li>
                <li>
                    <p>Güvenlik gerekçesiyle üyelik şifresi en az 8 karakter olmalıdır. Büyük ve küçük harfler, rakamlar ve semboller kullanılabilir. Ancak çift noktalı harfler kullanılamaz. Müşteri hesap bilgilerinde belirtilmiş olan isim ve ikamet edilen şehir gibi bilgilerle benzeşmemelidir. </p>
                </li>
                <li>
                    <p><?php echo @title;?>
, müşterilerine bu genel kural ve şartlara ve gelecekte yapılacak tüm hesap hareketlerine ait verilere ait yazılı birer çıktı almalarını, muhtemel bir anlaşmazlığı veya itirazı önlemek amacı ile tavsiye eder. </p>
                </li>
                <li>
                    <p><?php echo @title;?>
, bir Google Inc. ("Google") online analiz hizmeti olan Google Analytics'i kullanır. Google Analytics, müşterinin bilgisayarında saklanan ve müşteri tarafından bir web sayfasının kullanımının analizini sağlayan "çerez" adlı metin dosyalarını kullanır. Çerez aracılığıyla üretilen, bu web sayfasının kullanımı hakkındaki bilgiler (ve IP adresi) Google'ın ABD'deki sunucularından birine aktarılır ve orada saklanır. Google bu bilgileri web sayfasının kullanımını değerlendirmek, <?php echo @title;?>
 için web sayfası etkinlikleri hakkında raporlar hazırlamak ve web sayfası ve internet kullanımına bağlı diğer hizmetleri üretmek için kullanır. Google ayrıca, kanunen öngörülmüş ise ve Google adına kullanacaklarsa bu bilgileri gerektiğinde üçüncü kişilere aktarabilir. Google IP adreslerini hiç bir durumda Google'ın diğer verileri ile ilişkilendirmez. Müşteri tarayıcı yazılımın ilgili ayarları aracılığıyla çerezlerin kurulumunu engelleyebilir; ancak bu durumda web sitesinin tüm işlevlerinin tam kapsamlı olarak kullanılamayabileceğini belirtmek durumundayız. Bu web sitesini kullanarak müşteri, toplanan verilerin Google tarafından önceden belirtilmiş olan yollarla ve önceden belirtilmiş olan amaçlar için işleneceğini kabul etmiş olur. </p>
                    <p><?php echo @title;?>
 bu web sitesinin kullanımını değerlendirmek amacı ile ek servisler kullanma hakkını saklı tutar. </p>
                </li>
                <li>
                    <p>Bir bahis "geçersiz" (örn. oyunun iptali durumunda) olarak belirtilmiş ise, bu bahis 1,0 oranıyla "kazanıldı" olarak değerlendirilir. Tekli bahisler için bu, müşterinin bahis için yatırdığı miktar tutarında bir meblağ elde edeceği anlamına gelir. Çoklu (kombine) bahis için ise, toplam oran geçersiz olan maçın oranına (1.0) göre hesaplanır. Kuponda bulunan diğer müsabakalara yapılmış olan bahislerin kazanması durumunda, çoklu bahis kuponu da kazanacaktır. Muhtemel ücretler, öreneğin tekli bahislerde, tazmin edilmez. </p>
                </li>
                <li>
                    <p>Bahislerin kabulu esnasında, bahsin sonucunun belirlenmesini sağlayabilecek herhangi bir bilginin ortaya çıkması halinde, <?php echo @title;?>
 bahis Kabul süresini yeniden belirler, ya da bahisleri "geçersiz" ilan eder. </p>
                </li>
                <li>
                    <p><?php echo @title;?>
; giriş, aktarma ve/veya değerlendirmelerde oluşabilecek hatalar için sorumluluk Kabul etmez. <?php echo @title;?>
’in özellikle &ndash;müsabaka sonuçlansa dahi- bahis oranlarının belirlenmesinde ve/veya sonuçlandırılmasında yapılmış olan bariz hataları (örnek: yazım hatası, hatalı müsabaka, hatalı oran, hatalı handikap bilgileri ya da alt/üst bahisleri için verilen gol sayısı) düzeltme ya da ilgili bahisleri iptal etme hakkı saklıdır. Ayrıca <?php echo @title;?>
; bilgilendirme amaçlı hizmetlerinin doğruluğu, eksiksizliği veya güncelliği konusunda (örnek: canlı skor ya da oran listesi) herhangi bir garanti vermez. </p>
                </li>
                <li>
                    <p><?php echo @title;?>
, hatalı şekilde verilmiş ya da hesaplanmış kazançları sonradan düzeltme hakkına sahiptir. Bahis daha sonra düzeltilmiş oranlarla hesaplanır ve, bahsin kazanması halinde, düzeltilmiş olan oranlar üzerinden ödeme yapılır. Hatalı şekilde yapılan ödemeler geri ödenir. </p>
                </li>
                <li>
                    <p><?php echo @title;?>
 işbu kural ve şartlardan doğan özlük haklarından feragat etme hakkına sahiptir. Müşteri, gelecekte feragat edilebilecek bu haklar ile ilgili talepte bulunamaz. </p>
                </li>
                <li>
                    <p>Yukarıda ya da aşağıda belirtilen herhangi bir maddenin geçersiz olduğu durumlarda işbu anlaşma geçerliliğini korur. Münferit hükümlerin geçersiz kılındığı durumlarda sözleşmenin içeriği; kanunen uygun olan ve bahis sözleşmesi içeriğinde bulunan hükümlerden, geçersiz kılınan hükme en yakın olan hükme göre düzenlenir. Curaçao yasaları geçerlidir. </p>
                </li>
                <li>
                    <p>İşbu genel kural ve şartlarda, çoğul olarak atıfta bulunulan her olgu tekilleri de kapsar. Aynı şekilde tekil olarak atıfta bulunulan her oldu çoğulları da kapsar. Tüm erkek olarak atıfta bulunulan olgu kadınları, tüm kadın olarak atıfta bulunulan olgu erkekleri de kapsar. Metnin içinde bulunan başlıklar yalnızca referans amaçlıdır ve içeriğin anlamına ya da işbu kural ve şartların bir bölümünün yorumlanmasına etki etmez. </p>
                </li>
            </ol>
            <a class="go_top2"><i class="fa fa-angle-double-up"></i>Yukarı / Başa Dön</a>
            <div id="myDiv2"></div>
            <h1>II. Kazançlar ve kazançların tespiti</h1>
            <ol>
                <li>
                    <p>Sabit orana sahip bahislerde kazanç, oran ve yatırılan tutarın çarpılmasıyla hesaplanır. </p>
                </li>
                <li>
                    <p>2 Sonuç belirlendiğinde ve değerlendirildiğinde tüm bahisler kesinleşir. <?php echo @title;?>
 yalnızca müsabaka süresince oluşan sonuçları tanır. Bu sürenin dışında gerçekleşen herhangi bir değişiklik, bahsin açıldığı müsabakanın sonuçlandırılmasına etki etmez. Ertelenen ya da tatil edilen müsabakalarda; müsabakanın tatil edildiği, durdurulma veya devam etme zamanın, halihazırda sonucu belli olan bahislere (canlı bahisler, ilk yarı bahisleri, maç süresi bahisleri, alt/üst bahisleri, ilk gol bahisleri, vb.) etkisi yoktur. Bahis açılan müsabakanın normal sürenin sonunda (örnek: uzatma dakikaları süresince / penalty atışları süresince) tatil edilmesi halinde, normal süreye ait skor geçerlidir. </p>
                </li>
                <li>
                    <p>Ertelenen, tatil edilen ya da iptal edilen bir müsabakanın bir sonraki gün (müsabakanın oynandığı ülkenin saat dilimine göre) bitimine kadar tekrar başlaması ya da kaldığı yerden devam etmesi halinde, bahisler tekrar başlayan maçın sonucuna göre değerlendirilir. Bahis, müsabaka tarafsız sahada tekrarlanıyor, devam ettiriliyor veya gerçekleşiyor ise de geçerliliğini korur. Müsabakanın tekrar başlamadığı ya da devam etmediği hallerde bahisler geçersiz ilan edilir. Bu, müsabakanın durduğu ana kadar sonucu kesinleşmiş bahisler (örnek: ilk gol, bir sonraki gol, ilk yarı bahisleri, alt/üst bahisleri) için geçerli değildir. </p>
                    <p>Bir lig maçında veya kupa maçlarında olduğu gibi bir turnuvanın parçası olan bir karşılaşmanın normal sürenin bitiminden önce hakem tarafından sona erdirilmesi halinde, yapılan tüm bahisler için maçın geçerli olarak sayılması, puan tablosunda yer alması ve tekrarlanması yada devam edilmesine karar verilmemesi halinde hakemin son düdüğü çaldığı andaki sonuçlara göre değerlendirilir. </p>
                </li>
                <li>
                    <p>Tüm spor bahislerinde, üzerine bahis yapılan oyuncunun hangi nedenlerle olursa olsun müsabakaya iştirak etmemesi halinde, oyuncunun katılması gereken müsabaka gerçekleşirse, bahis kaybeder. Bahis etkinliği tamamıyla gerçekleşmediyse, bahisler iptal edilir.
                        "Skor oyuncusu" bahis türü için, üzerine bahis oynanan oyuncunun etkinliğin başında maça katılması gerekmektedir; aksi takdirde bahis geçersizdir. Sonraki oyuncu değişiklikleri dikkate alınmaz. </p>
                </li>
                <li>
                    <p>Beraberlik: Bir müsabakada iki ya da daha fazla oyuncu galip ilan edilirse, bahis oranı da uygun bir şekilde bölünür. </p>
                </li>
                <li>
                    <p><?php echo @title;?>
 bazı bahis kuponları için "geri satın alma" seçeneği sunmaktadır. Bu hizmet <?php echo @title;?>
’in insiyatifindedir ve müşteri herhangi bir kuponu için geri satma talebinde bulunamaz. </p>
                </li>
                <li>
                    <p>Bahis etkinliği çerçevesinde gizli anlaşmalar yapmaya veya doğrudan yahut dolaylı bir şekilde böyle bir anlaşmaya katılmayı tasarlamaya yönelik herhangi bir girişim kesinlikle yasaktır. Skripte (Betik), Bots (robot) veya Spieder (örümcek) (bunlarla sınırlı değildir v.s.) gibi herhangi bir yardımcı aracın kullanılması da kesinlikle yasaktır. </p>
                </li>
                <li>
                    <p>Tüm işlemler olası bir para aklama girişimine karşın denetlenir. Bir hesaptaki şüpheli herhangi bir hareket, müşterinin ilgili resmi makamlara bildirilmesine ve bahis hesabındaki bakiyenin dondurulmasına neden olabilir. Aynı şekilde bahis hesabının kapatılabilir ve mevcut bakiyeye el konulabilir. </p>
                </li>
            </ol>
            <a class="go_top2"><i class="fa fa-angle-double-up"></i>Yukarı / Başa Dön</a>
            <div id="myDiv3"></div>
            <h1>III. Para çekme ve kazanç limitleri</h1>
            <ol>
                <li>
                    <p>Spor bahislerinde haftalık kazançlar / ödemeler için geçerli olan genel limit, bir haftada müşteri başına 100.000€ olarak belirlenmiştir. </p>
                </li>
                <li>
                    <p>Bahislerde veya karşılaşmalarda sabit sonuçlu bahis gibi şüpheli durumların oluşması halinde, <?php echo @title;?>
 konuyla ilgili olarak tam bir inceleme gerçekleşene kadar söz konusu karşılaşma ile ilgili ödemeleri bloke etme hakkını saklı tutar. Karşılaşmalar hakkındaki incelemeler tamamen tamamlanana kadar kazançların ödemesi ertelenebilir. </p>
                </li>
                <li>
                    <p>Kazançların ödemeleri 30 güne kadar ertelenebilir. </p>
                </li>
                <li>
                    <p>Herhangi bir bahisin sabit sonuçlu spor bahisi olarak tesbit edilmesi veya manipülasyonların tesbiti ve isbatı halinde <?php echo @title;?>
 etkilenen bahislerden yapılan kazançları geri çekme ve bahisleri geçersiz kılma hakkını saklı tutar, bu gibi durumlarda yatırılan miktarlar iade edilecektir. </p>
                </li>
            </ol>
            <a class="go_top2"><i class="fa fa-angle-double-up"></i>Yukarı / Başa Dön</a>
            <div id="myDiv4"></div>
            <h1>IV. Hesap / Hesap açma</h1>
            <ol>
                <li>
                    <p>Müşteri bir bahis/para yatırma hesabı açtığında, aşağıda belirtilenleri taahhüt eder:</p>
                </li>
                <ol>
                    <li>
                        <p>18 yaşından büyük olduğunu; </p>
                    </li>
                    <li>
                        <p>Ticari faaliyetler ile ilgili herhangi bir kısıtlamaya konu olmadığını; </p>
                    </li>
                    <li>
                        <p>Bahis hesabına yatırdığı paranın suç unsuru teşkil eden bir yolla elde edilmediğini; </p>
                    </li>
                    <li>
                        <p>Bahis hesabını kişisel kullanım için açtığı ve ticari amaç gütmediğini; </p>
                    </li>
                    <li>
                        <p>Hesabın gerçek sahibidir ve başkası adına veya başkasının çıkarı için hareket etmiyordur; </p>
                    </li>
                    <li>
                        <p><?php echo @title;?>
’in güncel kural ve şartları hakkında bilgi sahibi olduğu ve tümünü kabul etiğini. </p>
                    </li>
                </ol>
                <li>
                    <p>Kayıt esnasında müşteri, ev adresi ve e-posta adresi dahil olmak üzere, kişisel bilgilerini doğru bir şekilde yazmakla yükümlüdür. </p>
                </li>
                <li>
                    <p><?php echo @title;?>
, madde IV.1’e aykırı şekilde bir hesap açıldığının anlaşılması halinde, bahse konu olan hesaba ait tüm bakiyeye el koyma hakkını saklı tutar. </p>
                </li>
                <li>
                    <p><?php echo @title;?>
, tüm müşteri hesaplarını tam gizlilikle ele alır. Hesap bilgileri yalnızca yetkili Curaçao makamları ile paylaşılabilir. </p>
                </li>
                <li>
                    <p>Müşteri; bahis hesabı ile ilgili sorularını, <?php echo @title;?>
 web sayfasında bulunan iletişim formunu kullanarak iletebilir. </p>
                </li>
                <li>
                    <p>Çoğunlikla kullanılan para birimi Euro’dur. <?php echo @title;?>
, Euro bölgesi dışındaki ülkelerde bulunan üyelerin hesaplarını ulusal para birimleri ile kullanmasına müsade edebilir. Müşteri tarafından seçilen para birimi daha sonra değiştirilemez. Müşteri, bahis hesabına ait para birimini değiştirme konusunda herhangi bir hak iddia edemez. </p>
                </li>
                <li>
                    <p>Bahis hesapları bir şahıstan başka bir şahısa devredilemez, satılamaz. Aynı şekilde; bir bahis hesabına ait bakiye, bir başka bahis hesabına aktarılamaz. </p>
                </li>
                <li>
                    <p>Her müşteri, yalnızca bir adet bahis hesabına sahip olabilir. Halihazırda kayıt olmuş müşterilerin, farklı isim veya e-posta adresi kullanarak yeni bahis hesabı açmaları kesinlikle yasaktır. Bu hükmün ihlali halinde, yapılmış olan tüm bahisler sonradan iptal edilebilir ve silinebilir. Bu paragrafta belirtilen kurallarla ilgili olarak; <?php echo @title;?>
 müşteri kartına sahip olunması, ek bir bahis hesabına sahip olunması anlamına gelmez. </p>
                </li>
                <li>
                    <p>Muğlak bahisler: <?php echo @title;?>
, belirsiz bahisler için kabul etmeme ve geçersiz ilan etme hakkını saklı tutar. </p>
                </li>
                <li>
                    <p>Örgütlü bahisler: Müşteriler bahislerini kişisel olarak yapmalıdır. Bir veya daha fazla müşterinin aynı bahsi birkaç defa yapmayı denemesi halinde, bu bahisler iptal edilebiilir. Birkaç müşterinin bir bahis birliği oluşturmuş olduğuna dair ciddi şüphe oluşması halinde ya da benzer bahislerin kısa bir zaman dilimi içerisinde bir veya birden fazla üye tarafından yapılması halinde veya bahislerin beraber hazırlandığı hallerde, aynı kural geçerlidir. Bu gibi durumlarda <?php echo @title;?>
’in bahis hesabı bakiyesini alıkoyma hakkı saklıdır. </p>
                </li>
                <li>
                    <p>Bahis müşterisi, bahis hesabına yatabilecek tüm hatalı bakiyeyi en kısa sürede bildirmek zorundadır. Bir hatadan kaynaklanan tüm kazançlar, ne şekilde oluşmuş olursa olsun, geçersizdir. </p>
                </li>
                <li>
                    <p>Yapılan bahis kuponu, bahis hesabının "bahislerim" kısmında görünene değin onaylanmış sayılmaz. </p>
                </li>
                <li>
                    <p>Gerekli şartların sağlanması halinde, <?php echo @title;?>
’in müşterisine bonus verme hakkı saklıdır. Bahsin yapıldığı andaki şartlar geçerlidir ve bu şartlar müşteriye bayi/acenta aracılığı ile, e-posta ile ya da online olarak bildirilir. Verilen bonus otomatik olarak bahis hesabına yatırılır. </p>
                </li>
                <li>
                    <p>Müşteri, kendine ait bahis hesabını geçici ya da süresiz olarak kapatabilir. Gerekli ayarlar ‘kişisel bilgilerim’ kısmında bulunmaktadır. Bahis bağımlılığını önleme amacı ile, bahis hesabı yalnızca <?php echo @title;?>
 tarafından tekrar açılabilir. </p>
                </li>
                <li>
                    <p>Müşteri, yapabileceği bahis miktarını ve maksimum kayıp miktarını limitlendirebilir. Gerekli ayarlar "kişisel bilgilerim" kısmında bulunmaktadır. Limit düşürme işlemleri derhal, yükseltme işlemleri ise yedi (7) gün sonra aktif olur. </p>
                </li>
                <li>
                    <p><?php echo @title;?>
 iki tip bahis hesabı sunmaktadır: </p>
                </li>
                <ol>
                    <ol>
                        <li>
                            <p>Online bahis hesabı<br>
                                Bir bahis hesabına erişim için, müşteri www.<?php echo @title;?>
.com adresinden bir bahis hesabı açmalıdır.</p>
                        </li>
                        <ol>
                            <li>
                                <p>Müşteri, kullanıcı adını ve şifresini gizli tutmakla yükümlüdür. Bu bilgilerin üçüncü şahıslar tarafından ele geçirmesi ve bahis yapılması gibi durumlarda, <?php echo @title;?>
 herhangi bir sorumluluk kabul etmez. </p>
                            </li>
                            <li>
                                <p>Bahis hesabına yapılan para yatırma ve çekme işlemleri; kredi kartı, e-cüzdan, banka havalesi ve benzeri yöntemler kullanılarak yapılabilir. Nakit para yatırma ve çekme mümkün değildir. Genel olarak havale işlemleri 2-4 işgünü içerisinde gerçekleşmektedir. <?php echo @title;?>
; ödeme işlemlerinin gerçekleştirilmesinde, uzman aracı kurumların hizmetlerinden yararlanma hakkını saklı tutar. </p>
                            </li>
                            <li>
                                <p>Tüm ödemeler, yetkisiz üçüncü şahısların erişimini engellemek amacı ile güvenli bağlantılar aracılığıyla yapılır. </p>
                            </li>
                            <li>
                                <p><?php echo @title;?>
’in, belirli ödeme yöntemleri ile yapılan para yatırma işlemleri için maksimum limit belirleme hakkı saklıdır. Herhangi bir kısıtlama olduğunda <?php echo @title;?>
 web sayfasının "Ödeme olanakları" bölümünden ulaşılabilir ve ödeme esnasında açıkça belirtilir. </p>
                            </li>
                            <li>
                                <p><?php echo @title;?>
’in belirli ödeme yöntemleri için işlem ücreti alma hakkı saklıdır. Muhtemel işlem ücretlerine <?php echo @title;?>
 web sayfasının "Ödeme olanakları" bölümünden ulaşalabilir ve ödeme esnasında açıkça belirtilir.  <?php echo @title;?>
 muhtemel banka işlem ücretlerini yatırılan miktardan tahsil etme ve ek işlem ücreti alma hakkını saklı tutar. </p>
                            </li>
                            <li>
                                <p><?php echo @title;?>
’in yeni ödeme imkanları sunma ve mevcut ödeme yöntemlerini kaldırma ya da düzenleme hakkı saklıdır. </p>
                            </li>
                            <li>
                                <p>Yanlış para ödemesi nedeniyle ortaya çıkan ücretlendirmeler, iptal ücretleri, ters kayıtlar ve benzeri maliyetler, bahis müşterisine tarafından karşılanır. </p>
                            </li>
                            <li>
                                <p>Müşteri; elektronik ödeme yöntemlerinden birini tercih ettiğinde ve işlem olması gerektiği şekilde tamamlandığında, işlemi geri alma ve benzeri haklarından feragat eder. Ek olarak, elektronik ödemelerde uluslararası şekilde kabul gören hüküm ve kanunlar geçerlidir. </p>
                            </li>
                            <li>
                                <p><?php echo @title;?>
 bir finans kurumu değildir. Bahis hesaplarında bulunan bakiyeye, miktarı ne olursa olsun, faiz verilmez. </p>
                            </li>
                            <li>
                                <p><?php echo @title;?>
 yasal olarak üyelerinin kimlik bilgilerini teyit etmekle yükümlüdür. <?php echo @title;?>
, gerekli gördüğü hallerde müşterilerinin kimlik bilgileri ile ilgili daha detaylı inceleme yapma hakkını saklı tutar. </p>
                            </li>
                        </ol>
                        <li>
                            <p><?php echo @title;?>
 müşteri kartı<br>
                                Bu kart iştirak eden tüm bayilerden elde edilebilir. Müşteri kartının verilmesi üyeye verilen otomatik bir hak değildir. <?php echo @title;?>
 ya da yetkili bayi herhangi bir sebep göstermeksizin kart talebini reddetme hakkına sahiptir. </p>
                        </li>
                        <ol>
                            <li>
                                <p>Müşteri kartında bulunan bakiyeden yalnızca kartı veren bayi sorumludur. <?php echo @title;?>
 müşteri kartı bakiyesi ile ilgili herhangi bir sorumluluk kabul etmez. Para yatırma ve çekme işlemleri yalnızca bayide yapılabilir. </p>
                            </li>
                            <li>
                                <p>Müşteri kartı sahibi adına kayıtlıdır ve bir başkasına devredilemez. Kartın mülkiyeti <?php echo @title;?>
'e aittir. Denetleme ve muhtemel istismarın önlenmesi amacıyla; talep edilmesi halinde müşteri, kimlik belgesini bayi çalışanlarına göstermekle yükümlüdür. </p>
                            </li>
                            <li>
                                <p>Müşteri, kullanıcı adını ve şifresini gizli tutmakla yükümlüdür. Bu bilgilerin üçüncü şahıslar tarafından ele geçirmesi ve bahis yapılması gibi durumlarda, <?php echo @title;?>
 herhangi bir sorumluluk kabul etmez. </p>
                            </li>
                            <li>
                                <p>Kaybolma ve hileli kullanımı önlemek amacıyla, müşteri kartı özenle saklanmalıdır. Kartın kaybolması halinde vakit kaybetmeden bayi haberdar edilmeli, böylece <?php echo @title;?>
 tarafından kart kullanıma kapatılmalıdır. Kartın kötüye kullanıldığı durumlarda <?php echo @title;?>
 sorumlu tutulamaz. </p>
                            </li>
                            <li>
                                <p>Müşteri kartının kaybolması halinde, gerekli dökümanlar ibraz edilerek yeni bir kart elde edilebilir. Kaybedilen kartta bulunabilecek muhtemel bakiye yeni karta aktarılamaz. <?php echo @title;?>
 bu işlemlerden oluşabilecek masrafları talep etme hakkını saklı tutar. </p>
                            </li>
                            <li>
                                <p>Müşteri, müşteri kartı aracılığıyla kullandığı bahis hesabını düzenli olarak takip etmekle yükümlüdür. Müşteri bunun için bayide bulunan duyuru panosu ve otomatını kullanabilir. Ayrıca tüm hesap hareketleri <?php echo @title;?>
 web sitesindeki "Hesap özeti" bölümünden takip edilebilir. Müşteri; herhangi bir düzensizlik ya da hata tespit etmesi halinde, hiçbir gecikme olmaksızın, kartı veren bayi ile irtibata geçmelidir. </p>
                            </li>
                            <li>
                                <p>Feshetme, kartın geri alınması ya da gerekli görülen hallerde bloke edilmesi ile gerçekleşir. Bu gibi durumlarda, verilmiş bonusların tümü ya da bir kısmı da dahil olmak üzere, mevcut bakiyenin tazmini mümkün değildir. Müşteri kartının kötü niyetli kullanımı halinde, <?php echo @title;?>
 ’nun yasal mercilere başvurma hakkı saklıdır. </p>
                            </li>
                            <li>
                                <p><?php echo @title;?>
; müşteri kartı sistemini, herhangi bir zamanda, müşterinin haklarını uygun bir şekilde muhafaza ederek, bir başka programla değiştirme ya da tümüyle iptal etme hakkını saklı tutar. Bu gibi durumlarda müşteri, kartı temin eden bayi tarafından bilgilendirilir. Önemli hallerde (örnek: yasalarda değişiklik) sunulan hizmet ya da bir bölümü, herhangi bir uyarı olmaksızın; iptal edilebilir, geliştirilebilir, tadil edilebilir. </p>
                            </li>
                            <li>
                                <p>Müşterinin uğrayabileceği, müşteri kartından veya kartın kullanımından kaynaklanabilecek zararlardan <?php echo @title;?>
 sorumlu tutulamaz. Müşteri kartının kullanımı ile ilgili oluşabilecek tüm anlaşmazlıklar icin yetkili alan Curaçao’dur. </p>
                            </li>
                        </ol>
                    </ol>
                </ol>
            </ol>
            <a class="go_top2"><i class="fa fa-angle-double-up"></i>Yukarı / Başa Dön</a>
            <div id="myDiv5"></div>
            <h1>V. Para Çekme</h1>
            <ol>
                <li>
                    <p>Online bahis hesapları için</p>
                </li>
                <ol>
                    <li>
                        <p>Tüm para çekme talepleri manuel olarak kontrol edilir ve ödenir. Ödeme işlemleri otomatik olarak yapılmaz. </p>
                    </li>
                    <li>
                        <p>Yatırılan meblağın tümü bahis ve casino oyunlarında kullanılmalıdır. Tüm bahis ve casino ve bingo kazançları için para çekme talebi verilebilir. Belirtilmiş bonus şartları yerine getirilmelidir. </p>
                    </li>
                    <li>
                        <p>Müşteri dilediği zaman mevcut kazanlarının veya bir kısmının bahis hesabından tarafına ödenmesini talep edebilir; bunun önkoşulu, hesaptan yapılan tüm ödemelerin onaylanmış ve ödenen tüm tutarların kullanılmış olmasıdır. Bahis müşterisi ödeme talebini <?php echo @title;?>
'e web sitesindeki ilgili form aracılığıyla gönderir. </p>
                    </li>
                    <li>
                        <p>Ödeme; müşterinin seçeceği ödeme yöntemi ile, müşterinin adına olan bir hesaba yapılır. Herhangi bir şüphe halinde, <?php echo @title;?>
 ödemeyi yapmadan önce müşteriden pasaport ya da benzeri bir kimlik belgesini talep etme hakkını saklı tutar. <?php echo @title;?>
 prensip olarak kredi kartını veren banka tarafından, kartın son kontrolü yapılana kadar bu ödemeyi askıya alma hakkını saklı tutar. </p>
                    </li>
                    <li>
                        <p>Ödemelere ilişkin şikâyetler, talebi takip eden 30 gün içerisinde yapılmalıdır. </p>
                    </li>
                    <li>
                        <p><?php echo @title;?>
; herhangi bir sebep göstermeksizin, müşterinin para çekme talebi için kullandığı yöntemi reddetme ve müşteriden para çekme işlemi için banka havalesi yöntemini kullanmasını talep etme hakkını saklı tutar. </p>
                    </li>
                </ol>
                <li>
                    <p><?php echo @title;?>
 müşteri kartı için</p>
                </li>
                <ol>
                    <li>
                        <p>Müşteri kartında kayıtlı bahislerden gelen tüm kazançlar otomatik olarak karta işlenir. Geçmiş bahislerin çıktıları yalnız kullanıcının bilgisi içindir ve herhangi bir ödeme talebi için kanıt teşkil etmez. Müşteri kartında bulunan bakiyenin ödemesi, kartın alındığı bayide veya onun yetkilendireceği bir başka bayide, ödeme makbuzunun imzalanması ile mümkündür. Denetleme ve muhtemel istismarın önlenmesi amacıyla; talep edilmesi halinde müşteriye ait uygun bir kimlik belgesi talep edilebilir. </p>
                    </li>
                    <li>
                        <p>Müşterinin alacak bakiyesi yalnız kartı veren bahis acentası tarafından yönetilir. <?php echo @title;?>
 tarafından hesaba ödeme yapılması talebinde bulunulamaz. </p>
                    </li>
                </ol>
            </ol>
            <a class="go_top2"><i class="fa fa-angle-double-up"></i>Yukarı / Başa Dön</a>
            <div id="myDiv6"></div>
            <h1>VI. www.<?php echo @title;?>
.com’da bahis yapma</h1>
            <ol>
                <li>
                    <p>Yapılan her bahiste müşteri, bahsin güncel halinde bulunan hükümlerin geçerliliği ve uygulanabilirliğini kabul eder. Genel kural ve şartların İngilizce versiyonu ile diğer dillerdeki versiyonlar arasında farklılıklar olması durumunda, İngilizce metin belirleyicidir. </p>
                </li>
                <li>
                    <p>Prensipte; bir bahis, ancak müşterinin bahis hesabında yeterli bakiye varsa kabul edilir. </p>
                </li>
                <li>
                    <p>Herhangi bir teknik hatadan dolayı bahis yeterli bakiye bulunmamasına rağmen kabul edildiyse, bahis ‘geçersiz’ ilan edilir. Muhtemel zararlardan <?php echo @title;?>
 sorumlu tutulamaz. </p>
                </li>
                <li>
                    <p>Bahisler online olarak www.<?php echo @title;?>
.com adresinde yapılır.Bahisler posta, fax, e-posta ya da başka bir yöntemle gönderilemez. <?php echo @title;?>
'e bu şekilde gönderilen bahisler, kazanıp kaybetmesine bakılmaksızın geçersizdir. </p>
                </li>
                <li>
                    <p>Bahis <?php echo @title;?>
 tarafından elektronik olarak online şekilde onaylandığı an geçerli bir bahistir (Bahis onaylandı). </p>
                </li>
                <li>
                    <p>İletim hataları sebebiyle, bahsin yapıldığı tarih ve zaman veya bahsi yapan müşteriye ait gerekli kişisel bilgiler eksik olduğunda bahis geçersizdir. Bahis miktarı iade edilir. </p>
                </li>
                <li>
                    <p>Bahis açılan müsabakanın başladığı andan itibaren kabul edilen tüm bahisler geçersizdir. Bu kural canlı bahisler için geçerli değildir. </p>
                </li>
                <li>
                    <p>Bahis kabul zaman diliminin ne zaman sona ereceği <?php echo @title;?>
 tarafından belirlenir. </p>
                </li>
                <li>
                    <p>Kazançlar otomatik olarak bahis hesabına işlenir. Münferit durumlarda kazançların bahis hesabına yansıtılması, müsabakaya ait resmi sonuçlar yayınlanana kadar ertelenebilir. </p>
                </li>
                <li>
                    <p>En düşük bahis miktarı 1.00 TL’dir. Sistem ve kombine bahislerde, her bahis kombinasyonu için en düşük bahis miktarı 0.10 TL’dir. Müşteri kartları için farkli minimum bahis miktarları mümkündür. Bu gibi durumlarda kartı veren bayi müşterisini bilgilendirmelidir. </p>
                </li>
                <li>
                    <p>İçerik bakımından tüm bahislerde <?php echo @title;?>
'e ait kayıtlar geçerlidir. Talep edilmesi halinde bu kayıtlar <?php echo @title;?>
 tarafından gösterilebilir. Bahis üzerinde ancak açık bir yanlışlığın veya yazım/hesaplama hatasının ortadan kaldırılması amacıyla düzeltme yapılabilir. </p>
                </li>
                <li>
                    <p>Yapılan bahislere ait detayların isabetliliğini kontrol etmek müşterinin sorumluluğundadır. Belirli koşullar altında <?php echo @title;?>
 belirli bahis kuponlarının iptaline müsade eder. Bu hizmet <?php echo @title;?>
 tarafından gönüllü olarak verilmektedir. Bahis kuponunun iptali müşterinin otomatik olarak sahip olduğu bir hak değildir. İptal talebi yalnızca web sayfasında bulunan "Bahislerim" bölümünden gerçekleştirilebilir. İptal talepleri e-posta, fax, posta, telefon ya da başka komünikasyon yöntemleriyle gerçekleştirilemez. Prensipte, canlı bahislerin iptali mümkün değildir. </p>
                </li>
            </ol>
            <a class="go_top2"><i class="fa fa-angle-double-up"></i>Yukarı / Başa Dön</a>
            <div id="myDiv7"></div>
            <h1>VII. Hesap Bilgileri</h1>
            <ol>
                <li>
                    <p>1. Her müşteri istediği zaman, "Hesap özeti" altında bahis hesabı özeti biçiminde bir rapor talep edebilir.Bahis hesabına kullanıcı adı ve şifre aracılığı ile girilmesiyle, farklı tarihlere ait tüm bahis hareketleri görüntülenebilir ve yazdırılabilir.</p>
                </li>
                <li>
                    <p>2. Belirli kayıtlara ilişkin şikâyetler yalnız kayıt gününü/bahis oynama gününü takip eden 30 gün içinde kabul edilir.</p>
                </li>
            </ol>
            <a class="go_top2"><i class="fa fa-angle-double-up"></i>Yukarı / Başa Dön</a>
            <div id="myDiv8"></div>
            <h1>VIII. Bahis Bilgileri</h1>
            <ol>
                <li>
                    <p><?php echo @title;?>
 web sayfasında ve diğer iletişim ortamlarında sunulan tüm bahis bilgileri için garanti verilmez. Özellikle başlangıç zamanları <?php echo @title;?>
'in bilgisi olmadan değişebilir veya <?php echo @title;?>
 üçüncü kişilerce yanlış bilgilendirilmiş olabilir. Sabit kazanç fırsatları ve oranlar serbest arz ve talebe tabidir. </p>
                </li>
                <li>
                    <p>Dosluk maçlarının sonuçları karşılaşmanın resmi bitiş düdüğüne göre 90 dk dan bağımsız olarak (ekstra süreler hariç ) değerlendirilmektedir. Bu duruma istisna olarak oyun süresi değişiklik gösterirse (e.g 3x45dk, 1x45dk, 2x30dk) bu durumda bahisler gecersiz ve odemesi 1.00 orandan degerlendirilicektir. </p>
                </li>
                <li>
                    <p><?php echo @title;?>
, yayınladığı tüm sonuç, istatistik, canlı skor vs. bilgiler için garanti vermez. </p>
                </li>
            </ol>
            <a class="go_top2"><i class="fa fa-angle-double-up"></i>Yukarı / Başa Dön</a>
            <div id="myDiv9"></div>
            <h1>IX. Bahis Oynama ve Bayi işlemleri  İçin Düzenlemeler</h1>
            <ol>
                <li>
                    <p>Aracı/acenta <?php echo @title;?>
'i temsil etme yetkisine sahip değildir. <?php echo @title;?>
 için veya <?php echo @title;?>
'e karşı açıklamalarda bulunmak veya kabul etmek için yetkili değildir. Aracı/acenta özellikle <?php echo @title;?>
 için oran değişiklikleri yapamaz. Aracı/acenta müşterinin temsilcisidir. Bu yüzden, bahis oynama ile ilgili niyet açıklamaları ve ödemeler için müşterinin yetkili aracısıdır. </p>
                </li>
                <li>
                    <p>Tüm oran listeleri www.<?php echo @title;?>
.com web sayfasında güncel olarak yayınlanır. Aynı zamanda aracıda/acentada mevcutturlar. Oran listelerinde görüntülenen başlangıç saatleri yalnız bilgilendirmeye yöneliktir. Kesin olan, etkinliğin gerçek başlangıç saatidir. </p>
                </li>
                <li>
                    <p><?php echo @title;?>
, münferit bahisler, bahis türleri, maç eşleştirmeleri, kombinasyonlar vs. için ücret talep etme hakkını saklı tutar. Bunun için sebep göstermek zorunda değildir. Ücretin miktarını yalnız <?php echo @title;?>
 belirler. Ücretler farklı bahislerde, bahis türlerinde vs. farklı miktarlarda olabilir. Mağazadaki duyuru panosundan muhtemel ücretler hakkında bilgi edinebilirsiniz. Ücretler bahis kuponunda belirtilir. </p>
                </li>
                <li>
                    <p>Birden fazla kişi birlikte bahis oynayabilir. Oyun topluluklarında, bahsi yatıran üye <?php echo @title;?>
'in sözleşme tarafıdır. <?php echo @title;?>
, şüphe halinde kimlik gösterimi talep etme hakkını saklı tutar. </p>
                </li>
                <li>
                    <p>Kazançlar yalnız orijinal bahis kuponunun gösterilmesi durumunda ödenir. </p>
                </li>
                <li>
                    <p>Bahis oyna </p>
                </li>
                <ol>
                    <li>
                        <p>Bahis, müşterinin bahis başvurusu aracı/acenta aracılığıyla <?php echo @title;?>
 merkezi bilgisayarına ulaştıktan ve <?php echo @title;?>
 tarafından online olarak onayladıktan veya kabul edildikten sonra oynanmış olur. Bahis başvuruları posta, faks veya e-posta aracılığıyla <?php echo @title;?>
'e gönderilemez. <?php echo @title;?>
'e bu yolla ulaşan bahis başvuruları kabul edilmez. Bu yolla bahis oynanması için, <?php echo @title;?>
 'nun açık ve kesin kabulü gerekmektedir. Aracı/acenta bu bahisleri kabul etme yetkisine sahiptir. </p>
                    </li>
                    <li>
                        <p>Bahis müşterisi, bahis başvurusunu yapmadan önce bahsinin doğruluğunu kontrol etmekle yükümlüdür. Daha sonraki şikâyetler dikkate alınmayacaktır. Aktarım hataları nedeniyle bahsin oynandığı tarih ve saat ispat edilemez şekilde eksik olduğunda, bahis geçersizdir. Bahis için yatırılan para geri ödenir. </p>
                    </li>
                    <li>
                        <p>Orijinal bahis kuponu veya bahis acentası onayı üzerindeki kayıtlarda yapılan değişiklikler veya diğer manipülasyonlar müşterinin kazanç talep etme hakkını ortadan kaldırır. Yatırılan tutar geri ödenmez. </p>
                    </li>
                    <li>
                        <p>Müşterilerin belirli bir bahis hakkındaki şikâyetleri yalnız kayıt gününü/bahis oynama gününü takip eden 30 gün içinde kabul edilir. </p>
                    </li>
                </ol>
            </ol>
            <a class="go_top2"><i class="fa fa-angle-double-up"></i>Yukarı / Başa Dön</a>
            <div id="myDiv10"></div>
            <h1>X. Genel Bahis Kuralları</h1>
            <ol>
                <li>
                    <p>Belirli spor türleri ve bahis pazarları için özel bahis kuralları vardır. Müşteri bu özel kurallar, genel bahis kurallarından önce geldikleri için göz önünde bulundurmalıdır. </p>
                </li>
                <li>
                    <p>Spor bahisleri, münferit bahisler, kombine bahisler (birleştirmeli bahis) veya sistem bahisleri olarak oynanabilirler. Spor türüne ve organizasyona/etkinliğe göre tekli bahis oynanması yasaklanmış olabilir. Buna ilişkin bilgileri güncel oran listelerinden (örn. en az 3 oyun) edinebilirsiniz. Kombi bahislerde aynı karşılaşma için iki değişik bahis yapılamaz. (Örn: Real Madrid Kazanır ve Sonuç:2-0). </p>
                </li>
                <li>
                    <p>Tüm spor türlerinde normal oyun süresi sonundaki sonuç geçerlidir. Uzatmaların ve penaltı atışlarının kazanç değerlendirmesine etkisi yoktur. Buna ilişkin istisnalar doğrudan bahis pazarlarında veya spor türlerine ilişkin özel kurallarda belirtilir. </p>
                </li>
                <li>
                    <p>Uzun süreli bahisler</p>
                </li>
                <ol>
                    <li>
                        <p>Uzun süreli bahis hizmeti genelde büyük bir etkinliğin (turnuvanın) sonucuna yönelik sunulur. Böyle bir bahis hizmeti aşağıdaki sorular aracılığıyla sunulur:</p>
                        <ol>
                            <ol>
                                <ol>
                                    <li>
                                        <p>Dünya Kupasını kim kazanır? </p>
                                    </li>
                                    <li>
                                        <p>Wimbledon tenis turnuvasını kim kazanır? </p>
                                    </li>
                                    <li>
                                        <p>Almanya Bundesliga'ya kim yükselir? </p>
                                    </li>
                                </ol>
                            </ol>
                        </ol>
                    </li>
                    <li>
                        <p>Uzun süreli bahisler tüm yarışmacıların kayıtlı veya katılmış olup olmadığından bağımsız olarak değerlendirilir. Uzun süreli bahislerde eğer üzerine bahis oynanan yarışmacı/takım etkinliğe katılmamış veya etkinliği terk etmiş ise yapılan tüm bahisler kayıp ilan edilir. </p>
                    </li>
                    <li>
                        <p>Bir bahis etkinliğinin kesin sonucu saat gece 24.00’e (organizasyonun düzenlendiği yerdeki yerel saat) kadarki son maç/etkinlik (örn. final maçı veya sonraki maç günü) ile belirlenir. Bu süre sonrasındaki hangi nedenle olursa olsun sonuç değişikliğinin bahis sonucunun değerlendirilmesine etkisi olmaz. </p>
                    </li>
                    <li>
                        <p>İki ya da daha fazla oyuncu belirli bir final konumunu paylaşırlarsa, oranlar konumu paylaşan oyuncu sayısına bölünür. </p>
                    </li>
                </ol>
                <li>
                    <p>Canlı bahisler</p>
                </li>
                <ol>
                    <li>
                        <p>Canlı bahisler Canlı, Live, Top yada DA gibi ekler ile tanımlanmaktadır. Bu bahisler spor karşılaşmasının başlamasından sonrada açılmaktadır. Oranlar sürekli olarak karşılaşmanın gidişatına göre uyarlanmakta ve değiştirilmektedir. Yüksek derecede güncel olmaları sebebiyle canlı oranlar sadece özel ekran çözümleri yada internette görüntülenmektedir. DA ile etiketlenen bahisler sadece devre arasında sunulmaktadır. </p>
                    </li>
                    <li>
                        <p><?php echo @title;?>
 kabul edilen bir canlı bahis iptal edilemez. </p>
                    </li>
                    <li>
                        <p>Canlı bahislerde veri taşınması sırasında yaşanacak olan geçikmeler veya zamanlama olarak geçikmeli TV haberleri sebebiyle oranlamada göz önünde bulundurulmayan, karşılaşmanın akışında ani değişikliklerin olması durumunda <?php echo @title;?>
 yapılmış olan bahisleri geçersiz kılma hakkını saklı tutar. </p>
                    </li>
                    <li>
                        <p>Bir müşterinin kasıtlı ve açıkça olası zamanlama geçikmelerinden haksız olarak finansal avantajlar sağlamaya çalışmasının tesbiti halinde, <?php echo @title;?>
 bu müşterinin, müşteri hesabını kapatma ve hesabın bakiyesine el koyma hakkını saklı tutar. </p>
                    </li>
                    <li>
                        <p>Her canlı bahis ile birlikte aktüel sonuç/yarı skoru sunulmaktadır. Bahisin yapıldığı tahmin belirtilen devre sonucunun önemli ölçüde yanlış olması halinde geçersiz sayılır. </p>
                    </li>
                    <li>
                        <p>Canlı bahisler için sunulan spor çeşitleri için bu spor çeşitlerinde kullanılan aynı bahis kuralları geçerli olmaktadır. </p>
                    </li>
                </ol>
            </ol>
            <a class="go_top2"><i class="fa fa-angle-double-up"></i>Yukarı / Başa Dön</a>
            <div id="myDiv11"></div>
            <h1>XI. Bahis Pazarları</h1>
            <p><?php echo @title;?>
, güncel formları her zaman www.<?php echo @title;?>
.com web sayfasında görüntülenen spor etkinliklerine ilişkin çok sayıda bahis sunmaktadır. Genelde tek bir karşılaşma için aynı anda birden fazla bahis birlikte kombine edilemez. </p>
            <a class="go_top2"><i class="fa fa-angle-double-up"></i>Yukarı / Başa Dön</a>
            <div id="myDiv12"></div>
            <h1>XII. Spor Çeşitleri</h1>
            <li>
                <p>Her spor türü için özel bahis hizmetleri ve değerlendirme ölçütleri vardır. En popüler ve en çok sunulan spor türlerinin listesi aşağıda mevcuttur. <?php echo @title;?>
, etkinliklerin türüne ve zamanına bağlı olarak farklı spor türleri için (örn. boks) oranlar sunar. Listelenmemiş spor türleri için genel bahis kuralları geçerlidir. </p>
            </li>
            <ol>
                <li>
                    <p>Futbol<br>
                        Futbol maçları için sunulan tüm bahis olanakları, başka bir değerlendirme formu konusunda açıkça bilgi verilmemişse normal maç süresinin sonundaki sonuca ilişkindir. Normal maç süresinden kasıt, 90 dakikalık maç süresi ve hakem tarafından eklenen sakatlıklar için ek sürenin de dahil olduğu, ancak uzatmaların veya penaltı atışlarının dahil olmadığı maç süresidir.
                        Maç tarafsız sahada yapılıyorsa, solda belirtilen takım ev sahibi, sağda belirtilen takım ise konuk takım olarak anlaşılmalıdır </p>
                </li>
                <li>
                    <p>Buz hokeyi<br>
                        Buz hokeyi maçları için sunulan tüm bahis olanakları, başka bir değerlendirme formu konusunda açıkça bilgi verilmemişse normal maç süresinin sonundaki sonuca ilişkindir. Normal maç süresinden kasıt, 60 dakikalık maç süresi ve hakem tarafından eklenen sakatlıklar için ek sürenin de dâhil olduğu, ancak uzatmaların veya penaltı atışlarının vb. dâhil olmadığı maç süresidir. </p>
                </li>
                <li>
                    <p>Tenis<br>
                        Tüm bahisler ilk top oynandıktan sonra geçerlilik kazanır. En az bir top değişikliği yapıldıktan sonra bir oyuncu maçtan ayrılır, oyun iptal olursa (sakatlık, ayrılma, diskalifikasyon) bahis etkinliği iptal edilir. Bu, önceden canlı bahis olarak sunulan ve önceden değerlendirilmiş olan bahis pazarları için geçerli değildir (örn. set kazanma, oyun kazanma, alt/üst bahisler). Bir maç yarıda kalır veya ertelenirse, turnuva çerçevesindeki bahisler maçlar tamamlanana kadar askıya alınır.
                        Eger maç bir turnuvanın parçasi degil ise, tekrarı oynanmadigi veya ertesi gün devamı oynanmadığı sürece, maç geçersiz olarak değerlendirilir </p>
                </li>
                <li>
                            <p>Basketbol<br>
                                Basketbol için sunulan başlamamış karşılaşmalar için 2 seçenekli Tahmin bahis çeşidi dışındaki tüm bahis seçenekleri uzatma dahil değildir. Canlı basketbol karşılaşmalarında ise 2 seçenekli Tahmin ve Handikap bahis çeşidi dışındaki yanında (+uzatma) olmayan tüm bahis seçenekleri de  uzatma dahil değildir. Bu durumda normal maç süresinin bitimindeki sonuç geçerlidir. </p>
                        </li>
            </ol>
            <a class="go_top2"><i class="fa fa-angle-double-up"></i>Yukarı / Başa Dön</a>
            <div id="myDiv13"></div>
            <h1>XIII. Casino</h1>
            <p><?php echo @title;?>
 Casino´da sunulmakta olan Jackpotlar ve bu Jackpotlara ait tutarlar düzenli aralıklarla güncellenecektir ancak bu güncellemeler gerçek zamanlı olarak yapılmamaktadır. Bu sebebten dolayı gösterilen tutarın sunulan tutar ile %100 aynı olmaması söz konusu olabilir. Jackpot´un kazanılmasıyla birlikte tutar tam olarak hesaplanacak ve Jackpot´un kazanılmasına kadar oynanılan turlarda belir-tilecektir. Ne yazık ki Türkiye´de ikamet etmekte olan müşterilerimizin sunulmakta olan Jackpot oyunlarına katılmaları mümkün olmamaktadır. </p>
            <a class="go_top2"><i class="fa fa-angle-double-up"></i>Yukarı / Başa Dön</a>
            <div id="myDiv14"></div>
            <h1>XIV. Veri koruma yönetmeliği</h1>
            <ol>
                <li>
                    <p>Bahis müşterisi, <?php echo @title;?>
'te bahis oynaması ile ilgili kişisel verilerinin saklanmasını ve normal bahis işlemleri çerçevesinde kullanılmasını kabul eder. </p>
                </li>
                <li>
                    <p><?php echo @title;?>
'in müşterilerin kişisel verilerini toplamadaki asıl amacı müşteriye online bahis hizmetleri sunmaktır. </p>
                </li>
                <li>
                    <p><?php echo @title;?>
, yasalar veya mahkeme kararları doğrultusunda gerekli olmadıkça müşteri verilerini üçüncü kişilerle paylaşmaz. <?php echo @title;?>
, kamu yararına ilişkin bir açıklama gerekli olduğunda müşteri verilerini yayınlama hakkını saklı tutar. </p>
                </li>
                <li>
                    <p>Müşterinin verilerine erişim ve bunları değiştirme hakkı bulunur. Verilerin tamamen silinmesi mümkün değildir. </p>
                </li>
                <li>
                    <p>Müşteri, bu bilgilerinin alınmasını engelleme hakkını saklı tutar. Bunun için <?php echo @title;?>
 destek departmanının bilgilendirilmesi yeterlidir. Müşterinin kendisi de bu bilgilerinin alınmasını hesap ayarlarında etkinleştirebilir veya etkinliğini kaldırabilir. </p>
                </li>
            </ol>
            <a class="go_top2"><i class="fa fa-angle-double-up"></i>Yukarı / Başa Dön</a>
            <div id="myDiv15"></div>
            <h1>XV. Şikayetler</h1>
            <p><?php echo @title;?>
 mümkün olduğunca www.<?php echo @title;?>
.com’un keyifli kullanılması icin her türlü çabayı göstermektedir. Ancak, müşterinin sunulan hizmetten tatminsiz olduğu durumlar ortaya cıkabilir. Böyle bir durumda müşteri <?php echo @title;?>
 destek bölümüne başvurabilir ya da info@<?php echo @title;?>
.com adresine bir e-posta gönderebilir. Genel olarak, şikayet 48 saat içinde işlenir ve gerektiginde yönetime iletilir.<a class="go_top2"><i class="fa fa-angle-double-up"></i>Yukarı / Başa Dön</a> </p>
        </div>
</div>

</div></div>

</div>
<div style="height:20px;">&nbsp;</div></div></div></div></div>

<?php echo $_smarty_tpl->getSubTemplate ("mobil/footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>
<?php }} ?>