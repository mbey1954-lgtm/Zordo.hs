<?php /* Smarty version Smarty-3.1.8, created on 2018-08-26 19:57:55
         compiled from "application/views/templates/hesaphareket.tpl" */ ?>
<?php /*%%SmartyHeaderCode:18629389495b82dc137b59b3-59955434%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '95c386d7554d422d3767984577063033de5ad24d' => 
    array (
      0 => 'application/views/templates/hesaphareket.tpl',
      1 => 1495298271,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '18629389495b82dc137b59b3-59955434',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'bayilist' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_5b82dc1389bdf1_28866873',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5b82dc1389bdf1_28866873')) {function content_5b82dc1389bdf1_28866873($_smarty_tpl) {?><?php if (!is_callable('smarty_modifier_date_format')) include '/home/beyplaying/public_html/system/libs/smarty/libs/plugins/modifier.date_format.php';
?><?php echo $_smarty_tpl->getSubTemplate ("header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<?php echo $_smarty_tpl->getSubTemplate ("left.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>



<script>
function kouponcall() {
	
	loadgir("#kupons");
	var order = $("#order").val();
	var ascdesc = $("#ascdesc").val();
	var tarih1 = $("#tarih1").val();
	var tarih2 = $("#tarih2").val();
	var islemtip = $("#islemtip").val();
	var k_user = $("#k_user").val();
	var ciftler = $("#ciftler").val();
	
	$.post(baseurl+'raporlar/hesaphareketdata',{ciftler:ciftler,order:order,ascdesc:ascdesc,tarih1:tarih1,tarih2:tarih2,k_user:k_user},function(data) { 
		$("#kupons").html(data);
	});
}

function asdes(order,as) {
		$("#order").val(order);	
		$("#ascdesc").val(as);
		kouponcall(1);
	}
	
$(document).ready(function(e) {
	kouponcall(1);	
});

</script>

<div class="coupons">	
	<div class="coupon-title">
		<div class="account-table-blue"><span>
			<div class="icon"><i class="fa fa-user"></i></div>
			</span>
			<p><?php echo lang('hsphrkt');?>
</p>
		</div>
		<div class="account-table-gray">		
			<form >
			<?php if ($_smarty_tpl->tpl_vars['bayilist']->value){?>					
			<label><?php echo lang('byler');?>
 :</label>
			<div class="selectbox">
			<select id="k_user">
			<option value=""></option>
			<?php echo $_smarty_tpl->tpl_vars['bayilist']->value;?>

			</select>
			</div>
			<?php }?>
			<label><?php echo lang('trh');?>
 :</label>
			<input type="text" id="tarih1" value="<?php echo smarty_modifier_date_format(time(),'%d-%m-%Y');?>
" readonly>
			<input type="text" class="inputbet" id="tarih2" value="<?php echo smarty_modifier_date_format(time(),'%d-%m-%Y');?>
" readonly>
			<label><?php echo lang('tip');?>
 :</label>
			<div class="selectbox">
			<select id="islemtip">
				<option value=""><?php echo lang('hpsi');?>
</option>
				<option value="ekle"><?php echo lang('giren');?>
</option>
				<option value="cikar"><?php echo lang('cikan');?>
</option>
			</select>	
			</div>
			<button type="button" id="sorgu" onclick="kouponcall(1);"><?php echo lang('gtr');?>
</button>
			<input type="hidden" id="order" value="zaman">
			<input type="hidden" id="ascdesc" value="desc">
			</form>			
		</div>
	</div>
	
	<div id="kupons" class="coupon-content"></div>
	
	
</div>

<?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>
<?php }} ?>