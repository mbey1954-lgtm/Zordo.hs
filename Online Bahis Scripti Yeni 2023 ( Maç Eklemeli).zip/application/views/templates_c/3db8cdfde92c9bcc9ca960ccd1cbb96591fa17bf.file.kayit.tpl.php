<?php /* Smarty version Smarty-3.1.8, created on 2018-08-12 02:40:18
         compiled from "application/views/templates/kayit.tpl" */ ?>
<?php /*%%SmartyHeaderCode:16622044335b6f73e2e9cb83-51232578%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '3db8cdfde92c9bcc9ca960ccd1cbb96591fa17bf' => 
    array (
      0 => 'application/views/templates/kayit.tpl',
      1 => 1495924359,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '16622044335b6f73e2e9cb83-51232578',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_5b6f73e2f01d32_70154830',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5b6f73e2f01d32_70154830')) {function content_5b6f73e2f01d32_70154830($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ("header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>


<script>
function emailtest(email) {
    var re = /^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i;
    return re.test(email);
}
$(document).ready(function(e) {
	$("input[name=user]").change(function(e) {
		var val = $(this).val();
        $.post(baseurl+'kayit/kontrol/?user=1',{useri:val},function(data) { 
			if(data>0) { 
				failcont('Seçtiğiniz kullanıcı adı müsait değildir. Lütfen başka bir kullanıcı adı seçiniz.');
				$("input[name=user]").val('');
			} else { 
				$("#usval").val('1');
			} 
		});
    });
});

function kayit(){
	var f = self.document.regform;
	if(f.ad.value.length<2) { f.ad.select(); } else
	if(emailtest(f.email.value)==false) { f.email.select(); } else
	if(f.user.value.length<2) { f.user.select(); } else
	if(f.sifre.value.length<4) { f.sifre.select(); } else
	if(f.sifre1.value.length<4) { f.sifre1.select(); } else
	if(f.sifre1.value!=f.sifre.value) { 
		failcont('Yazdığınız 2 parola farklıdır. Lütfen iki alanada aynı parolayı giriniz.'); 
	}else if($("#usval").val()==0) { 
		f.username.value='';
		failcont('Lütfen geçerli bir kullanıcı adı seçiniz');
	}else if(!$("input[name=tc]").val()) { 
		failcont('Lütfen T.C. Numaranız Yazınız.'); f.tc.select(); 
	} else if(!$("input[name=cep]").val()) { 
		failcont('Lütfen Telefonunuzu Yazınız.'); f.cep.select(); 
	} else{
		$.ajax({type:'POST',url:baseurl+'kayit/gonder',data:$("form#regform").serialize(),
		success:function(snc){
			if(snc==1) { 
				alert('Üyelik Kaydınız yapıldı. En kısa zamanda sizinle iletiş krulacaktır. Kullanıcı adı ve Şifreniz ile giriş yapabilirsiniz.');
				window.location.href=baseurl;
			}else { 
				failcont("HATA Oluştu. Lütfen yeniden deneyiniz."); 
			}			
		}	
		});
	}
	return false;
}  
</script>

<input type="hidden" id="usval" value="0">
<input type="hidden" id="usemailval" value="0">

<div class="coupons" style="width:100%">	
	<div class="coupon-title">
	
<div class="account-table-blue"><span>
	<div class="icon"><i class="fa fa-user"></i></div>
	</span>
	<p><?php echo lang('kytol');?>
</p>
</div>

<form name="regform" id="regform" onsubmit="return kayit();" method="post">
	<table style="margin:10px 0px 20px 10px;width:98%;color: <?php if (@tema==1){?>#000<?php }else{ ?>#fff<?php }?>;" id="table_step">
	<td>&nbsp;</td>
		<tr>
			<td><?php echo lang('ad');?>
:</td>				
			<td>
			<input placeholder="Ad" name="ad" maxlength="15" type="text" required="required">
			<input placeholder="Soyad" name="ad1" maxlength="20" type="text" required="required">
			</td>			
		</tr>
		<td>&nbsp;</td>
		<tr>
			<td><?php echo lang('dogum');?>
:</td>				
			<td>
			<select class="form-control" name="d1" style="margin-right: 10px"><option value="0" selected="selected">Gün</option><option value="01">01</option><option value="02">02</option><option value="03">03</option><option value="04">04</option><option value="05">05</option><option value="06">06</option><option value="07">07</option><option value="08">08</option><option value="09">09</option><option value="10">10</option><option value="11">11</option><option value="12">12</option><option value="13">13</option><option value="14">14</option><option value="15">15</option><option value="16">16</option><option value="17">17</option><option value="18">18</option><option value="19">19</option><option value="20">20</option><option value="21">21</option><option value="22">22</option><option value="23">23</option><option value="24">24</option><option value="25">25</option><option value="26">26</option><option value="27">27</option><option value="28">28</option><option value="29">29</option><option value="30">30</option><option value="31">31</option></select>
			
			<select class="form-control" name="d2" style="margin-right: 10px"><option value="0" selected="selected">Ay</option><option value="01">01</option><option value="02">02</option><option value="03">03</option><option value="04">04</option><option value="05">05</option><option value="06">06</option><option value="07">07</option><option value="08">08</option><option value="09">09</option><option value="10">10</option><option value="11">11</option><option value="12">12</option></select>
			
			<select class="form-control" name="d3"><option value="0" selected="selected">Yıl</option><option value="1999">1999</option><option value="1998">1998</option><option value="1997">1997</option><option value="1996">1996</option><option value="1995">1995</option><option value="1994">1994</option><option value="1993">1993</option><option value="1992">1992</option><option value="1991">1991</option><option value="1990">1990</option><option value="1989">1989</option><option value="1988">1988</option><option value="1987">1987</option><option value="1986">1986</option><option value="1985">1985</option><option value="1984">1984</option><option value="1983">1983</option><option value="1982">1982</option><option value="1981">1981</option><option value="1980">1980</option><option value="1979">1979</option><option value="1978">1978</option><option value="1977">1977</option><option value="1976">1976</option><option value="1975">1975</option><option value="1974">1974</option><option value="1973">1973</option><option value="1972">1972</option><option value="1971">1971</option><option value="1970">1970</option><option value="1969">1969</option><option value="1968">1968</option><option value="1967">1967</option><option value="1966">1966</option><option value="1965">1965</option><option value="1964">1964</option><option value="1963">1963</option><option value="1962">1962</option><option value="1961">1961</option><option value="1960">1960</option><option value="1959">1959</option><option value="1958">1958</option><option value="1957">1957</option><option value="1956">1956</option><option value="1955">1955</option><option value="1954">1954</option><option value="1953">1953</option><option value="1952">1952</option><option value="1951">1951</option><option value="1950">1950</option><option value="1949">1949</option><option value="1948">1948</option><option value="1947">1947</option><option value="1946">1946</option><option value="1945">1945</option><option value="1944">1944</option><option value="1943">1943</option><option value="1942">1942</option><option value="1941">1941</option><option value="1940">1940</option><option value="1939">1939</option></select>
			</td>			
		</tr>
		<td>&nbsp;</td>
		<tr>
		
			<td><?php echo lang('adres');?>
:</td>				
			<td><input placeholder="Adres" name="adres" type="text" style="width: 100%"></td>
					
		</tr>
		<td>&nbsp;</td>
		<tr>
			<td><?php echo lang('sehir');?>
:</td>				
			<td><input placeholder="Şehir" name="sehir" maxlength="20"  type="text"></td>	
			<td><?php echo lang('pkod');?>
:</td>				
			<td><input placeholder="Posta kodu" name="pkod" maxlength="10" type="text"></td>
					
		</tr>
		<td>&nbsp;</td>
		<tr>
			<td><?php echo lang('ulke');?>
:</td>				
			<td><select name="ulke">
				<option value="">Ülke Seçiniz</option>
				<option value="Türkiye">Türkiye</option>
				<option value="England">England</option>
				<option value="Germany">Germany</option>
				<option value="Argentina">Argentina</option>
				<option value="Australia">Australia</option>
				<option value="Azerbaijan">Azerbaijan</option>
				<option value="Belgium">Belgium</option>
				<option value="Bulgaria">Bulgaria</option>
				<option value="France">France</option>
				<option value="Greece">Greece</option>
				<option value="Iceland">Iceland</option>
				<option value="Italy">Italy</option>
				<option value="Netherlands">Netherlands</option>
				<option value="Poland">Poland</option>
				<option value="Romania">Romania</option>
				<option value="Sweden">Sweden</option>
			  </select></td>	
			<td><?php echo lang('para');?>
:</td>				
			<td><select name="parasi" >
				<option value="">Para birimi</option>
				<option value="TL">TL</option>
				<option value="EUR">EUR</option>                    
				<option value="USD">USD</option>
				<option value="BRL">BRL</option>
				<option value="CHF">CHF</option>
				<option value="MXN">MXN</option>
				<option value="PLN">PLN</option>
				<option value="RUB">RUB</option>                    
			  </select></td>
					
		</tr>
		<td>&nbsp;</td>
		<tr>
			<td><?php echo lang('tc');?>
:</td>				
			<td><input placeholder="T.C No" name="tc" maxlength="20" required="required" type="text"></td>	
			<td><?php echo lang('tel');?>
:</td>				
			<td><input placeholder="Cep telefonu" name="cep" maxlength="10" required="required"  type="text"></td>
					
		</tr>
		<td>&nbsp;</td>
		<tr>
			<td><?php echo lang('user');?>
:</td>				
			<td><input placeholder="Kullanıcı adı (5-20 Karakter)" name="user" maxlength="20" required="required"  type="text"></td>	
			<td><?php echo lang('sifre');?>
:</td>				
			<td><input placeholder="Şifre (6-12 Karakter)" name="sifre" maxlength="20" required="required"  type="password"></td>	
			<td><?php echo lang('sifre');?>
:</td>				
			<td><input placeholder="Şifre (Tekrar)" name="sifre1" maxlength="20" required="required"  type="password"></td>
		</tr>
		<td>&nbsp;</td>
		<tr>
			<td><?php echo lang('email');?>
:</td>				
			<td><input placeholder="E-posta" name="email" maxlength="100" required="required" type="text">(Lütfen Hotmail hesabı kullanmayınız!)</td>	
		</tr>
		<td>&nbsp;</td>
		<tr style="height:50px">
			<td colspan="6" class="formbaslik"><p>18 Yaş üzerindeyim. <a class="footinfo" href="#"> Kullanım şartlarını </a> okudum ve onaylıyorum. Diğer veri ve bilgileri kayıt işleminden sonra dilediğiniz zaman ekleyebilir yada değiştirebilirsiniz. İstediğiniz zaman bu hizmeti hesabınızdan kapatabilirsiniz.</p></td>
		</tr>
		<td>&nbsp;</td>
		<tr>
			<td colspan="2">
			<button class="button" type="submit">HESABIMI OLUŞTUR</button></td>				
		</tr>
	</table>
</form>
</div>
</div>
<?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>
<?php }} ?>