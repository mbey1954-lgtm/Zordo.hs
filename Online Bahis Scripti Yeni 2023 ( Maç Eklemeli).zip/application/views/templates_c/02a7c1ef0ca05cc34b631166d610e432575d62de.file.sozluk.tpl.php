<?php /* Smarty version Smarty-3.1.8, created on 2018-08-13 02:14:59
         compiled from "application/views/templates/sozluk.tpl" */ ?>
<?php /*%%SmartyHeaderCode:16404535635b70bf73ef5908-63495658%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '02a7c1ef0ca05cc34b631166d610e432575d62de' => 
    array (
      0 => 'application/views/templates/sozluk.tpl',
      1 => 1495440365,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '16404535635b70bf73ef5908-63495658',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_5b70bf74035601_87581602',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5b70bf74035601_87581602')) {function content_5b70bf74035601_87581602($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ("header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>


<style>
.support-text {
  color: gray;
  float: left;
  padding: 10px;
  width: 100%;
}#myDiv1, #myDiv2, #myDiv3, #myDiv4, #myDiv5, #myDiv6, #myDiv7, #myDiv8, #myDiv9, #myDiv10, #myDiv11, #myDiv12, #myDiv13, #myDiv14, #myDiv15, #myDiv16, #myDiv17, #myDiv18, #myDiv19, #myDiv20, #myDiv21, #myDiv22, #myDiv23, #myDiv24, #myDiv25, #myDiv26, #myDiv27, #myDiv28, #myDiv29, #myDiv30, #myDiv31, #myDiv32, #myDiv33, #myDiv34 {
  height: 50px;
  margin-bottom: 0;
  width: 100%;
}.support-text h1, .bonus-text h1 {
  color: #de7b24;
  font-size: 17px;
}.support-text ol, .bonus-text ol {
  padding: 20px;
}.support-text ol li, .bonus-text ol li {
  list-style-type: decimal;
  margin-left: 20px;
  padding: 5px;
}#text1, #text2, #text3, #text4, #text5, #text6, #text7, #text8, #text9, #text10, #text11, #text12, #text13, #text14, #text15, #text16, #text17, #text18, #text19, #text20, #text21, #text22, #text23, #text24, #text25, #text26, #text27, #text28, #text29, #text30, #text31, #text32, #text33, #text34 {
  color: gray;
}#text1 a, #text2 a, #text3 a, #text4 a, #text5 a, #text6 a, #text7 a, #text8 a, #text9 a, #text10 a, #text11 a, #text12 a, #text13 a, #text14 a, #text15 a, #text16 a, #text17 a, #text18 a {
  color: gray;
  cursor: pointer;
  font-size: 13px;
  line-height: 20px;
  margin-left: 7px;
}
</style>
<script type="text/javascript">
	 $(window).load(function() {  $("#text1").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv1").offset().top  }, 1000);  });     $("#text2").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv2").offset().top  }, 1000);  });     $("#text3").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv3").offset().top  }, 1000);  });     $("#text4").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv4").offset().top  }, 1000);  });     $("#text5").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv5").offset().top  }, 1000);  });     $("#text6").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv6").offset().top  }, 1000);  });     $("#text7").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv7").offset().top  }, 1000);  });     $("#text8").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv8").offset().top  }, 1000);  });     $("#text9").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv9").offset().top  }, 1000);  });     $("#text10").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv10").offset().top  }, 1000);  });     $("#text11").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv11").offset().top  }, 1000);  });     $("#text12").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv12").offset().top  }, 1000);  });     $("#text13").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv13").offset().top  }, 1000);  });     $("#text14").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv14").offset().top  }, 1000);  });     $("#text15").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv15").offset().top  }, 1000);  });     $("#text16").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv16").offset().top  }, 1000);  });     $("#text17").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv17").offset().top  }, 1000);  });     $("#text18").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv18").offset().top  }, 1000);  });     $("#text19").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv19").offset().top  }, 1000);  });     $("#text20").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv20").offset().top  }, 1000);  });     $("#text21").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv21").offset().top  }, 1000);  });     $("#text22").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv22").offset().top  }, 1000);  });     $("#text23").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv23").offset().top  }, 1000);  });     $("#text24").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv24").offset().top  }, 1000);  });     $("#text25").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv25").offset().top  }, 1000);  });     $("#text26").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv26").offset().top  }, 1000);  });     $("#text27").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv27").offset().top  }, 1000);  });     $("#text28").click(function() {  $('html, body').animate({   scrollTop: $("#myDiv28").offset().top  }, 1000);  });        $("#text29").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv29").offset().top  }, 1000);  });     $("#text30").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv30").offset().top  }, 1000);  });     $("#text31").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv31").offset().top  }, 1000);  });     $("#text32").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv32").offset().top  }, 1000);  });     $("#text33").click(function() {  $('html, body').animate({  scrollTop: $("#myDiv33").offset().top  }, 1000);  }); $('.go_top2').click(function(){ $('body,html').animate({scrollTop:0},800); });   });
    </script> 

<div class="coupons" style="width:100%">	

	<div class="coupon-title">
		<div class="account-table-blue"><span>
			<div class="icon"><i class="fa fa-user"></i></div>
			</span>
			<p><?php echo lang('szlk');?>
</p>
		</div>		
		<div style="background:#ccc"><div class="support-text">
                    <p><?php echo @title;?>
.com´da farklı bahis türleri için geniş seçenekler bulabilirsiniz. Bunların arasında, bütün bahis severlerin muhtemelen bilmediği ancak gerilim ve heyecan konularında, en yaygın bahis türlerinden aşağıda kalmayan bahislerde yer almaktadır.</p>
                    <p>Bizim bahis programımızda belkide çok cazip oranlar buldunuz fakat bahis çeşidini tanımadığınızdan dolayı, bu oranlarla bahis yapmaya cesaret edemediniz. Aşağıda sizlere kısaca <?php echo @title;?>
´te sunulan bahis çeşitlerini tanıtmak istemekteyiz. Spor bahislerinin büyüleyici dünyasından ortak terimler ve açıklamalarla bahis sözlüğümüzü tamamlıyoruz.</p>
                    <p>Ancak, daha fazla açıklamaya ihtiyaç duymanız, sözlüğümüzde bulamadığınız bir terim olması yada başka sorularınız varsa ise lütfen müşteri destek servisimize yazınız. Konusunda uzman personelimiz sizlere yardımcı olmaktan memnuniyet duyacaktır.</p>
                </div><div class="support-list">
                    <ul class="support">
                        <li id="text1">Asya Handikap</li>
                        <li id="text2">Banko</li>
                        <li id="text3">Bahis Bakiyesi</li>
                        <li id="text4">Bahis Firmasi</li>
                        <li id="text5">Bahis Hesabı</li>
                        <li id="text6">Bet</li>
                        <li id="text7">Bonus</li>
                        <li id="text8">Bookie /-ler</li>
                        <li id="text9">Canlı Bahis (ler)</li>
                        <li id="text10">Çift (Double)</li>
                        <li id="text11">Çifte Şans</li>
                        <li id="text12">Galibiyet (sonuç) bahisleri</li>
                        <li id="text13">Gol bahisleri</li>
                        <li id="text14">Handikap Bahis</li>
                        <li id="text15">İki yollu bahis</li>
                        <li id="text16">ilk golcü</li>
                    </ul>
                    <ul class="support2">
                        <li id="text17">Ilk Yarı/sonuç bahisler</li>
                        <li id="text18">Kombinasyon (kombo/kombi) bahis</li>
                        <li id="text19">Over/Under veya Üst/Alt</li>
                        <li id="text20">Oran</li>
                        <li id="text21">Özel Bahisler</li>
                        <li id="text22">Para yatırma Bonusu</li>
                        <li id="text23">Sistem Bahisleri</li>
                        <li id="text24">Bankolar İle Sistem Bahisleri</li>
                        <li id="text25">Sonuç (skor) Bahisi</li>
                        <li id="text26">Sonuç Bahisleri</li>
                        <li id="text27">Stake</li>
                        <li id="text28">Tekli Bahis</li>
                        <li id="text29">Üç yollu bahisler</li>
                        <li id="text30">X</li>
                        <li id="text31">1</li>
                        <li id="text32">2</li>
                    </ul>
                </div><div class="support-text">
                    <div id="myDiv1"></div>
                    <h1>Asya Handikap</h1>
                    <p>Asya Handikap ile bahis yaparken, iki takım arasında olası bir beraberlik baştan itibaren ortadan kaldırılmaktadır. 
                        Bu durumda genellikle dezavantajda olan tarafa 0,25, 0,50 veya 0,75 oranında fazladan kurgusal gol verilmektedir. 
                        Aynı zamanda favori oyuna aynı Handikapla başlayarak, aradaki kurgulanmış olan farkıda oyun süresince kapatmak durumdadır.</p>
                    <p>Asya Handikap bahislerinin en büyük avantajı, normal 3 yollu bahislerde (1-2-X) kazanma oranının matematiksel olarak %33 olması ve 
                        bu şekilde kazanma şansının %50´ye çıkmasıdır. Bunun sebebi ise iki takımın beraberlik olasılığının baştan itibaren ortadan kaldırılmış olmasıdır. 
                        Buna ek olarak, yüksek Asya Handikap bahislerinde, kaybeden tarafa bahis yaparakta kazanabilirsiniz.</p>
                    <a class="go_top2"><i class="fa fa-angle-double-up"></i>Yukarı / Başa Dön</a>
                    <div id="myDiv2"></div>
                    <h1>Banko</h1>
                    <p>Banko olarak seçilen bir takım veya oyuncu karşılaşmalarını kazanmak zorundadır ve bütün kombinasyonlarda hesaplamalara eklenecektir. 
                        Bahis kuponunuzdaki bütün bankoları tuturmanız gerekmektedir aksi taktirde kuponunuzdaki bütün kombinasyonlarınız kaybedecektir.</p>
                    <a class="go_top2"><i class="fa fa-angle-double-up"></i>Yukarı / Başa Dön</a>
                    <div id="myDiv3"></div>
                    <h1>Bahis bakiyesi</h1>
                    <p>Spor bahisleri için kullanabileceğiniz, <?php echo @title;?>
´te ki bahis hesabınızda bulunan paranız. 
                        Aynı zamanda bazen promosyonların bir parçası olarak bizden ücretsiz bahis bakiyeside elde etmektesinizdir.</p>
                    <a class="go_top2"><i class="fa fa-angle-double-up"></i>Yukarı / Başa Dön</a>
                    <div id="myDiv4"></div>
                    <h1>Bahis firması</h1>
                    <p><?php echo @title;?>
 gibi müşterilerine sabit oranlı spor bahisleri sunan bir şirket.</p>
                    <a class="go_top2"><i class="fa fa-angle-double-up"></i>Yukarı / Başa Dön</a>
                    <div id="myDiv5"></div>
                    <h1>Bahis hesabı</h1>
                    <p><?php echo @title;?>
´te ki, para yatıracağınız, bahis yapacağınız ve bahislerden kazançlarınızı çekebileceğiniz oyuncu hesabınız.</p>
                    <a class="go_top2"><i class="fa fa-angle-double-up"></i>Yukarı / Başa Dön</a>
                    <div id="myDiv6"></div>
                    <h1>Bet</h1>
                    <p>Bahis kelimesi için İngilizce terim.</p>
                    <a class="go_top2"><i class="fa fa-angle-double-up"></i>Yukarı / Başa Dön</a>
                    <div id="myDiv7"></div>
                    <h1>Bonus</h1>
                    <p><?php echo @title;?>
'in müşterilerine promosyonlar dahilinde verdiği, normal şartlar altında para yatırma işlemlerine karşılık verilen ek miktar.</p>
                    <a class="go_top2"><i class="fa fa-angle-double-up"></i>Yukarı / Başa Dön</a>
                    <div id="myDiv8"></div>
                    <h1>Bookie /-ler</h1>
                    <p><?php echo @title;?>
 için sunulan bahislerin oranlarını ayarlayan çalışanlar.</p>
                    <a class="go_top2"><i class="fa fa-angle-double-up"></i>Yukarı / Başa Dön</a>
                    <div id="myDiv9"></div>
                    <h1>Canlı Bahis(ler)</h1>
                    <p>Canlı bahisler karşılaşmanın başlamasıyla yapılan bahis çeşitleridir. Tabiiki bu durumda, oranlar sürekli olarak güncellenecektir.
                        <?php echo @title;?>
' te çok sayıdaki çeşitli canlı bahisler, kombo bahis olarakta oynanabilmektedir ancak normal bahisler ve canlı bahislerin, kombo bahis olarak kombine edilmesi mümkün olmamaktadır.
                        Canlı Bahisler son yıllarda giderek dahada popüler hale gelmiştir. <?php echo @title;?>
 bu nedenle, sürekli olarak canlı bahis programını müşterilerine daha fazla heyecan sunmak için genişletmektedir.</p>
                    <a class="go_top2"><i class="fa fa-angle-double-up"></i>Yukarı / Başa Dön</a>
                    <div id="myDiv10"></div>
                    <h1>Çift (Double)</h1>
                    <p>Çift veya İkili bahisler, 2 karşılaşmadan oluşan bir kombine bahis. Çift veya İkili bahislerin kazanabilmesi için her iki oyununda, doğru tahmin edilmiş olması gerekir.</p>
                    <a class="go_top2"><i class="fa fa-angle-double-up"></i>Yukarı / Başa Dön</a>
                    <div id="myDiv11"></div>
                    <h1>Çifte şans</h1>
                    <p>Bu ??bahis türünde, bir bahiste, bir karşılaşmanın iki olası sonucu kombine edilebilir. Bu şekilde, bir takımın kazanacağı yada en azından bir beraberlik alacağı üzerine bahse girilebilir. Böyle bir bahisi kazanma şansı oldukça yüksek olmakla beraber, bu bahisler için oranlar nispeten düşüktür.</p>
                    <a class="go_top2"><i class="fa fa-angle-double-up"></i>Yukarı / Başa Dön</a>
                    <div id="myDiv12"></div>
                    <h1>Galibiyet (sonuç) bahisleri</h1>
                    <p>Bir oyunda yada yarışta, bir atletin veya takımın galibiyetine yapılan bahislerdir..</p>
                    <a class="go_top2"><i class="fa fa-angle-double-up"></i>Yukarı / Başa Dön</a>
                    <div id="myDiv13"></div>
                    <h1>Gol bahisleri</h1>
                    <p>Bir karşılaşmada, karşılaşma sırasında atılan gollere yapılan bahisler. Bu bahisler, bir oyun sırasında atılan gol sayısının tamamına yada oyunun belirli dönemlerinde, belirli sürelerde atılan toplam gol sayısına yapılabilir. <?php echo @title;?>
´te gol bahislerinin çeşitleri her zaman, anlaşılır şekilde açıkça belirtilmektedir.</p>
                    <a class="go_top2"><i class="fa fa-angle-double-up"></i>Yukarı / Başa Dön</a>
                    <div id="myDiv14"></div>
                    <h1>Handikap Bahis</h1>
                    <p>Bu ??bahis türünde bir takım genelde dezavantajda olmaktadır ve oyuna kurgusal bir veya daha fazla gol avantajıyla ile başlar. Kurgusal goller oyunun sonunda fiili normal sonuca eklenir. Bu nedenle, bahisten elde edilen kazancın hesaplanmasında resmi kesin sonuçlar değil, bilakis Handikaptan kaynaklanan bu gollerin skora eklendikten sonraki durum esas alınmaktadır. Handikap bahisleri bu sebeble büyük favorilerin umutsuz denilebilecek rakiplerle karşılaşması halinde oldukça ilginç olmaktadır.</p>
                    <p>Örneğin, umutsuz durumdaki tabela sonuncusunun deplasmanda tabela lideriyle karşılaşması halinde, 0:2 Handikap verilecektir. Bunun anlamı tabela sonuncusunun oyuna 2 gol avantajla başlamasıdır. Bu nedenle beraberliğe yapılan bir bahis, ilk olarak tabela liderinin iki gol farkla maçı kazanması halinde kazanmış olacaktır. Tabela sonuncusunun galibiyetine yapılan bir bahis ise, tabela liderinin sadece bir gol kaydetmesi yada karşılaşmanın beraberlikle sonuçlanması halinde kazanmış sayılacaktır. İlk olarak tabela liderinin karşılaşmayı iki golden fazla farkla kazanması halinde, Handikap bahislerine görede tabela lideri karşılaşmayı kazanmış sayılır.</p>
                    <a class="go_top2"><i class="fa fa-angle-double-up"></i>Yukarı / Başa Dön</a>
                    <div id="myDiv15"></div>
                    <h1>İki yollu bahis</h1>
                    <p>Sadece iki sonucun mümkün olduğu bir bahis, örnek, tenis, oyunculardan birinci (A) yada ikicinin (B) kazanabileceği ve beraberliğin mümkün olmadığı durum ve sporlar için.</p>
                    <a class="go_top2"><i class="fa fa-angle-double-up"></i>Yukarı / Başa Dön</a>
                    <div id="myDiv16"></div>
                    <h1>ilk golcü</h1>
                    <p>Bir oyunda, oyun süresi içerisinde ilk geçerli golü atan oyuncu üzerine yapılan bahislerdir.</p>
                    <a class="go_top2"><i class="fa fa-angle-double-up"></i>Yukarı / Başa Dön</a>
                    <div id="myDiv17"></div>
                    <h1>Ilk Yarı/sonuç bahisler</h1>
                    <p>Bu ??bahis türünde, bir karşılaşmanın ilk yarısının nasıl geçeceğine ve devamında karşılaşmanın nasıl sona ereceğine bahis yapılır. 1. veya 2. takımın galibiyeti yada beraberliğe (X olarak gösterilir) bahis yapılabilir. Olası varyasyonlar her zaman takip eden bu karakter dizeleriyle gösterilir / işareti solunda ise '/' işareti devre skoruna, '/' işareti sağında ise oyunun skorunu göstermektedir.</p>
                    <a class="go_top2"><i class="fa fa-angle-double-up"></i>Yukarı / Başa Dön</a>
                    <div id="myDiv18"></div>
                    <h1>Kombinasyon (kombo/kombi) bahis</h1>
                    <p>Kombinasyon bahislerinde (kombo/kombi bahisler olarakta adlandırılmaktadır), en azından iki farklı oyun yada bahis konusu -farklı spor çeşitleride- bir bahiste kombine edilmektedir. Kombo bahislerden kısmen hatırı sayılır kazançlar elde edilebilir, ancak bu bahisler büyük bir risk faktörünüde beraberinde getirmektedir. Kombo bahislerde bahise dahil olan bütün karşılaşmalar ve tahminler kazanmalıdır ancak bu şekilde kombo bahiste kazanmış olarak sayılacaktır.
                        Kombo bahislerde olası kazanç, yatırılan miktarla bahis için seçilen karşılaşmaların oranlarının çarpılması sonucu hesaplanmaktadır. Örnek, 100 TL yatırılan bir kombo bahiste, takım A´nın galibiyeti için oran 1,5, takım B´nin takım C´ye karşı beraberliği için oran 2,0, takım D´nin galibiyeti için oran ise 3´dür. Olası kazanç şu şekilde hesaplanacaktır, 10x1,5x2x3. Şimdi bizim örneğimizde, tüm oyunların doğru tahmin edilmesi halinde, kazanç 900 TL tutarında olacaktır .
                        <?php echo @title;?>
 kombinasyon bahislerini sevenler için başka bir teşvikde sunmaktadır, <?php echo @title;?>
 Kombo Bonus.</p>
                    <a class="go_top2"><i class="fa fa-angle-double-up"></i>Yukarı / Başa Dön</a>
                    <div id="myDiv19"></div>
                    <h1>Over/Under veya Üst/Alt</h1>
                    <p>Oldukça popüler bir bahis türü. Bu bahislerde bir spor etkinliğinde kaç gol veya sayı elde edileceğine bahis yapılmaktadır. Bir futbol karşılaşmasında, 2,5´dan fazla gol atılması halinde Over/Üstü, 2,5´dan az gol atılması halinde ise Under/Altı kavramlarından bahsedilmektedir.
                        Over/Under bahisleri <?php echo @title;?>
´te nasıl sunulmaktadır? Over / Under (3.5) A ve B takımlarına, 2,4 ve 1,8 oranları sunulmaktadır. Karşılasmada 4 gol atılması halinde 
                        yatırmış olduğunuz miktara 2,4 oranı verilecektir. Ancak karşılaşmada 3 gol atılması halinde alacağınız oran 1,8 olacaktır.</p>
                    <a class="go_top2"><i class="fa fa-angle-double-up"></i>Yukarı / Başa Dön</a>
                    <div id="myDiv20"></div>
                    <h1>Oran</h1>
                    <p>Oran (bahis oranı) kavramı altında <?php echo @title;?>
´te kazanılan bir bahisle elde edilmesi mümkün olan kazanç anlaşılmaktadır. Bu şekilde <?php echo @title;?>
´te bir bahis için olasılıkları örnek, takım A takım B´ye karşı, doğru şekilde hesaplamaya çalışmakta ve bunu karşılık gelen oranlarla (bahis oranları) belirtmekteyiz.
                        Bu şekilde bahisçi, yatırdığı miktara karşılık olası toplam kazancını önceden hesap edebilmektedir.
                        Bahis oranları <?php echo @title;?>
´te şu şekilde gösterilmektedir: Takım A - Takım B, 1: 1,70 X: 3,40 2: 2,80; Bunun anlamı Takım A´nın kazanması 
                        halinde yatırılan miktar 1,7, beraberlik halinde 3,4, Takım B´nin galibiyeti halinde ise 2,8 ile çarpılmasıdır.</p>
                    <a class="go_top2"><i class="fa fa-angle-double-up"></i>Yukarı / Başa Dön</a>
                    <div id="myDiv21"></div>
                    <h1>Özel Bahisler</h1>
                    <p>Özel bahisler, standart bahis ve bahis çeşitlerine girmeyen bahis ve bahis çeşitleridir fakat aynı zamanda günlük bahislerin dışında kalan toplumsal ve 
                        politik olaylara yapılan bahisler içinde kullanılır. Özel bahisler Eklbet´te bazen özel günlerde sunulmaktadır.</p>
                    <a class="go_top2"><i class="fa fa-angle-double-up"></i>Yukarı / Başa Dön</a>
                    <div id="myDiv22"></div>
                    <h1>Para yatırma Bonusu</h1>
                    <p><?php echo @title;?>
´te birçok değişik çeşidi bulunmaktadır ve yine birçok değişik şekilde verilmektedir</p>
                    <a class="go_top2"><i class="fa fa-angle-double-up"></i>Yukarı / Başa Dön</a>
                    <div id="myDiv23"></div>
                    <h1>Sistem Bahisleri</h1>
                    <p>Sunmakta olduğumuz bahis kuponu çeşitlerinden biri olan sistem bahislerinde, değişik takımlara, değişik bahis kombinasyonlarını aynı kupon üzerinde yapabilirsiniz. Belirli sayıda seçilmiş olan takımlardan, her takım için ayrı ayrı tekli bahisler yapabilirsiniz.</p>
                    <p>Burada 4 seçilmiş olan takımdan oluşan bir sistem bahisi örneğini ve kombinasyon çeşitlerini görebilirsiniz:</p>
                    <p>1 x Komb. (4 Bahis) - Galip gelen takımlara yapılan 4 ayrı bahis</p>
                    <p>2 x Komb. (6 Bahis) - 4´den 2´li kombinasyonlar. Toplam 6 bahis, 6 tane 2´li kombinasyona kadar</p>
                    <p>3 x Komb. (4 Bahis) - 4´den 3´lü kombinasyonlar. 4 Bahis, 4 tane 3´lü kombinasyona kadar</p>
                    <p>Kaç tane takım seçtiğinize bağlı olarak kombinasyon çeşitleride farklılık gösterecektir. Mümkün olan her kombinasyonun toplam sayısı bahis kuponunuzda gösterilecektir. Bu şekilde kolaylıkla, karşılık gelen kombinasyon çeşitlerini yatırdığınız miktarla çarpabilirsiniz ve böylece yapmak istediğiniz bütün bahisler için toplam yatırılan miktarı görebilirsiniz.</p>
                    <p>Sistem bahisleri anlaması biraz kompleks bir bahis çeşidi teşkil edebilir. Bu sebeble bu bahis çeşidine başlamadan önce bu bahislerin konseptini anlamanızı tavsiye ederiz.</p>
                    <a class="go_top2"><i class="fa fa-angle-double-up"></i>Yukarı / Başa Dön</a>
                    <div id="myDiv24"></div>
                    <h1>Bankolar İle Sistem Bahisleri</h1>
                    <p>Bir sistem bahisi yaparken ek olarak seçebileceğiniz banko olarak adlandırılan bir seçeneğiniz daha mevcut. Banko olarak belirlenen bahisin kazanması gerekmektedir. Bu bahisin kaybetmesi durumunda bahisin tamamı kaybedilmiş sayılmaktadır. Bir takımı yada oyuncuyu banko olarak belirlemek için sadece bahis kuponundaki’’B’’harfine tıklamanız yeterli olmaktadır. B harfinin siyah arkaplanda beyaz olarak belirmesi ile birlikte bankonuzu seçmiş olacaktınız.</p>
                    <p>Banko olarak seçtiğiniz tahmininiz bahis kuponunuzdaki bütün kombinasyonlara eklenecektir. Bu sebebşe bu tahmininizin kaybetmesi halinde ise bütün bahis kuponunuz kaybetmiş olacaktır. Yapılabilecek olan kombinasyonların sayısı kaç takım veya oyuncunun banko olarak seçildiğine bağlı olarak değişiklik göstermektedir. Bunun sebebi seçilen bütün bankoların mümkün olan bütün kombinasyonlara eklenecek olmasıdır.</p>
                    <p>Örnek:</p>
                    <p>Bahis kuponunda seçilmiş olan 5 takımlı normal bir sistem bahisinde, 1/2/3/4. takımlar basis alınarak 4 kombinasyon çeşidi mümkün olmaktadır.</p>
                    <p>Banko tahmin yapılmış olması durumunda kombinasyon çeşitleride değişiklik gösterecektir. Bunun sebebi yapılmış olan banko tahminin her kombinasyona eklenecek olmasıdır. 2 Bankolu ve 5 takımlı bir bahis kuponunun kombinasyon çeşitleri aşağıdaki gibidir:</p>
                    <p>2 x Komb. (1 Bahis) - 2 Bankodan oluşan 1 kombinasyon</p>
                    <p>3 x Komb. (3 Bahis) - 2 Banko ve en az geriye kalan 3 takımdan başarılı olan 1 tanesinden oluşan kombinasyonlar</p>
                    <p>4 x Komb. (4 Bahis) - 2 Banko ve en az geriye kalan 3 takımdan başarılı olan 2 tanesinden oluşan kombinasyonlar</p>
                    <p>5 x Komb. (1 Bahis) - Bankolarda dahil seçilmiş olan bütün takımlardan oluşan kombinasyonlar. Bahis kuponunun üzerindeki başarılı bütün tahminlerden oluşan normal bir sistem bahisine denk gelmektedir.</p>
                    <p>Daha fazla takım ve daha fazla bankonun seçilmiş olması halinde kombinasyonlar yukarıdaki örneğe göre farklılık gösterecektir.</p>
                    <p>Bankolarınızı ve bahis tipinizi seçtikten sonra yapılabilecek olan kazancın hesaplaması ve bahislerin yapılması normal sistem bahisleriyle aynıdır. Burada dikkat edilmesi gerekli olan tek nokta ise banko tahminlerin kaybetmemesi gerektiğidir! Aksi takdirde bütün bahisi kaybedeceksinizdir.</p>
                    <a class="go_top2"><i class="fa fa-angle-double-up"></i>Yukarı / Başa Dön</a>
                    <div id="myDiv25"></div>
                    <h1>Sonuç (skor) Bahisi</h1>
                    <p>Bu ??bahis çeşidinde, bir spor organizasyonunun kesin sonucu üzerine, örnek bir futbol oyununda, 2:1´e bahis yapılmaktadır. 
                        Sonuç bahislerinde yüksek risk söz konusu olmaktadır ancak bu risk çok cazip ve yüksek oranlar ve kazanılması durumunda 
                        ise yine yüksek bir kazançla karşılanmaktadır. Bahis sonucu aksi belirtilmedikçe, genellikle uzatmalar ve penaltı atışları hariç normal oyun süresi üzerinden hesaplanmaktadır. Ancak oyun süresine eklenen süre normal oyun süresi olarak sayılmaktadır.</p>
                    <a class="go_top2"><i class="fa fa-angle-double-up"></i>Yukarı / Başa Dön</a>
                    <div id="myDiv26"></div>
                    <h1>Sonuç Bahisleri</h1>
                    <p>Skor bahisleri için başka bir terim, bir spor karşılaşmasının kesin sonuçları (gol veya puan) üzerine bahis yapılmaktadır.</p>
                    <a class="go_top2"><i class="fa fa-angle-double-up"></i>Yukarı / Başa Dön</a>
                    <div id="myDiv27"></div>
                    <h1>Stake</h1>
                    <p>Bahise yatırılan miktar ve bu miktarın turarı için kullanılan İngilizce terimdir.</p>
                    <a class="go_top2"><i class="fa fa-angle-double-up"></i>Yukarı / Başa Dön</a>
                    <div id="myDiv28"></div>
                    <h1>Tekli Bahis</h1>
                    <p>Tekli bir bahiste sadece belirli bir spor organizasyonunun yine belirli bir karşılaşmasına bahis yapılabilir. Yapılabilecek tahminler 1 ev sahibi takımın galibiyeti, X yada 0 beraberlik yada 2 deplasman takımının galibiyeti yönünde olabilir. Tekli bahislerden yapılabiecek kazançlar, şu şekilde hesaplanır yatırılan miktar çarpı, sunulan oran. Örnek, bir futbol oyununda ev sahibi takımın galibiyetine 10 TL yatırarak bahis yapmanız halinde, ev sahibi takımın 1,8 gibi bir oranla kazanması durumunda, 18 TL geri alacaksınızdır.</p>
                    <a class="go_top2"><i class="fa fa-angle-double-up"></i>Yukarı / Başa Dön</a>
                    <div id="myDiv29"></div>
                    <h1>Üç yollu bahisler</h1>
                    <p>Üç olasılıklı bahisler. Özellikle futbol başta olmak üzre takım oyunlarında, takım A veya takım B´nin galibiyetleri yada beraberliklerinin mümkün olduğu durumlarda.</p>
                    <a class="go_top2"><i class="fa fa-angle-double-up"></i>Yukarı / Başa Dön</a>
                    <div id="myDiv30"></div>
                    <h1>X</h1>
                    <p>veya nadiren 0, üç yollu bahislerde iki takım arasındaki olası beraberlik için.</p>
                    <a class="go_top2"><i class="fa fa-angle-double-up"></i>Yukarı / Başa Dön</a>
                    <div id="myDiv31"></div>
                    <h1>1</h1>
                    <p>Galibiyete yapılan bahislerde, ev sahibi takım, ilk takım veya ilk oyuncu/-lar</p>
                    <a class="go_top2"><i class="fa fa-angle-double-up"></i>Yukarı / Başa Dön</a>
                    <div id="myDiv32"></div>
                    <h1>X</h1>
                    <p>Galibiyete yapılan bahislerde, deplasman takımı, ikinci takım veya ikinci oyuncu/-lar</p>
                    <a class="go_top2"><i class="fa fa-angle-double-up"></i>Yukarı / Başa Dön</a> </div>
</div></div>
		
</div>
</div>

<?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>
<?php }} ?>