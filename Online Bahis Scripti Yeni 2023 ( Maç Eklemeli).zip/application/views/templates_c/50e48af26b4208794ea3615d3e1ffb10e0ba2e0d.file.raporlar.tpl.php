<?php /* Smarty version Smarty-3.1.8, created on 2022-10-19 01:27:43
         compiled from "application/views/templates/mobil/raporlar.tpl" */ ?>
<?php /*%%SmartyHeaderCode:771556957634f285f4c5f69-41403791%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '50e48af26b4208794ea3615d3e1ffb10e0ba2e0d' => 
    array (
      0 => 'application/views/templates/mobil/raporlar.tpl',
      1 => 1495298419,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '771556957634f285f4c5f69-41403791',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'bayilist' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_634f285f517346_50393424',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_634f285f517346_50393424')) {function content_634f285f517346_50393424($_smarty_tpl) {?><?php if (!is_callable('smarty_modifier_date_format')) include '/home/bbcanbets/public_html/system/libs/smarty/libs/plugins/modifier.date_format.php';
?><?php echo $_smarty_tpl->getSubTemplate ("mobil/header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>



<script>
function kouponcall(val) {
	
	loadgir("#kupons");
	$('.sb-slidebar').hide();
	var tarih1 = $("#tarih1").val();
	var tarih2 = $("#tarih2").val();
	var satir = $("#k_satir").val();
	var tip = $("#k_tip").val();	
	var userid = $("#k_user").val();
	$.post(baseurl+'raporlar/data',{userid:userid,tarih1:tarih1,tarih2:tarih2,satir:satir,tip:tip},function(data) { 
		$("#kupons").html(data.govde); 
		$("#ustgenel").html(data.msg);
	},'json');
}

$(document).ready(function(e) {
	$('#panelac').on('click', function() {
		$('.sb-slidebar').show();
	});
	
	$('#panelkapat').on('click', function() {
		$('.sb-slidebar').hide();
	});
	kouponcall();
	
	$("#tarih1, #tarih2").datepicker({
		dateFormat: 'dd-mm-yy', changeMonth: true, changeYear: true
	});
	
	
});
kuponTemizledirek();
kuponsay();
</script>
<style>
.kay{
	color: #f00;
}.ipt{
	color: #4e4e4e;
}.kaz{
	color: #458b00;
}.od{
	color: #000;
}

</style>


<div class="sb-slidebar">
	<div >
	<label >Arama Kriterleri</label>
	<hr>
	<form>
	<?php if ($_smarty_tpl->tpl_vars['bayilist']->value){?>
	<label >Bayiler</label>
	<select name="tur" id="k_user" data-placeholder="Seçiniz" class="chosen-deselect" >
	<option value="">Bayiler</option>
	<?php echo $_smarty_tpl->tpl_vars['bayilist']->value;?>

	</select><br>
	<?php }?>
	<label >Tarih</label>
	<input type="text" class="inputbet" id="tarih1" value="<?php echo smarty_modifier_date_format(time(),"%d-%m-%Y");?>
" readonly style="width:90%">
	<label >Tarih</label>
	<input type="text" class="inputbet" id="tarih2" value="<?php echo smarty_modifier_date_format(time(),"%d-%m-%Y");?>
" readonly style="width:90%">
	
	<label >Tip</label>
	<select name="tur" id="k_tip" data-placeholder="Hepsi" class="chosen-select-no-single" >
		<option value="">Hepsi</option>
		<option value="1">Normal</option>
		<option value="2">Canlı</option>
	</select>
	<hr>
	<input type="button" value="Sorgula" style="background:#2A7394;color: #fff;" id="sorgu" onclick="kouponcall(1);">
	<input type="button" value="Kapat (X)" style="background: #F4092A;color: #fff;width:47%;float:left" id="panelkapat">
	<input type="button" value="Temizle" style="background: #D38747;color: #fff;width:47%;float:left" onClick="this.form.reset();$('.chosen-select-no-single').val('').trigger('chosen:updated');">
	</form>
	</div>
</div>

<div id="macd" style="display:none"></div>

<div style="left: 0px; right: 0px; z-index: 100; position: fixed; top: 0px;" class="appheader">
<?php echo mobilhead();?>

<div><div class="header"><div onclick="goBack();" class="icon back noselect "></div><div class="text title noselect">Raporlar</div><div onclick="go('index')" style="padding-left:20px" class="icon logo noselect"></div></div></div></div>

<div class="page slide top in" id="page1" >
<div class="scroll_container" style="">
<div class="scroll_wrapper" style="padding-top: 85px; padding-bottom: 44px;">
<div class="appcontent">
<div>  </div>

<div class="filterbar">
<input type="button" value="Filtrele" style="border:1px solid #000;" id="panelac">
</div>
<hr style="background-color:#fff">
<div id="kupons" style="background-color:#fff" class="kupons"></div>
<div id="ustgenel" class="kupons"></div>

<div style="height:20px;">&nbsp;</div>

</div></div></div></div>

<?php echo $_smarty_tpl->getSubTemplate ("mobil/footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>
<?php }} ?>