<?php /* Smarty version Smarty-3.1.8, created on 2018-11-07 22:00:29
         compiled from "application/views/templates/oranmerkezi.tpl" */ ?>
<?php /*%%SmartyHeaderCode:21207261655be3364d587de6-88887825%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'a5d362bdaea78e0754d8e3899562b7af6656d239' => 
    array (
      0 => 'application/views/templates/oranmerkezi.tpl',
      1 => 1495298298,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '21207261655be3364d587de6-88887825',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_5be3364d622749_00837217',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5be3364d622749_00837217')) {function content_5be3364d622749_00837217($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ("header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<?php echo $_smarty_tpl->getSubTemplate ("left.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>



	<div class="coupons">	
	<div class="coupon-title" style="position:relative">
		<div class="account-table-blue"><span>
	<div class="icon"><i class="fa fa-user"></i></div>
	</span>
	<p><?php echo lang('foranduz');?>
</p>
</div>
		<table style="margin-left:10px;margin-top: 40px;width:98%;color: #<?php if (@tema==1){?>#000<?php }else{ ?>#fff<?php }?>;margin-bottom:30px">
		<tr>
		<td><?php echo lang('secin');?>
</td>
		<td>
		<select onchange="self.location.href='?secim='+this.value+'';" name="duzenleme" >
			<option value=""><?php echo lang('islm');?>
</option>
			<optgroup label="<?php echo lang('futbol');?>
">
				<option value="1" <?php if ($_GET['secim']=='1'){?>selected<?php }?>><?php echo lang('tumlg');?>
</option>
				<option value="2" <?php if ($_GET['secim']=='2'){?>selected<?php }?>><?php echo lang('llg');?>
</option>
				<option value="3" <?php if ($_GET['secim']=='3'){?>selected<?php }?>><?php echo lang('tkmac');?>
</option>
			</optgroup>
			<optgroup label="<?php echo lang('canli');?>
">
				<option value="13" <?php if ($_GET['secim']=='13'){?>selected<?php }?>><?php echo lang('tummac');?>
</option>
				<option value="14" <?php if ($_GET['secim']=='14'){?>selected<?php }?>><?php echo lang('cduz');?>
</option>
			</optgroup>
		</select>			
		</td>
			
		</tr>		
		</table>
		
		<div style="position: absolute; right: 0;top:40px;width:500px;float: right;color:#<?php if (@tema==1){?>#000<?php }else{ ?>#fff<?php }?>;">
		<?php echo lang('duztxt');?>
</div>
		
		<?php if (isset($_GET['secim'])){?>
			<?php if ($_GET['secim']=='1'){?>		
				<?php echo $_smarty_tpl->getSubTemplate ("all_oran.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>
			
			<?php }elseif($_GET['secim']=='2'){?>		
				<?php echo $_smarty_tpl->getSubTemplate ("lig_oran.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>
	
			<?php }elseif($_GET['secim']=='3'){?>		
				<?php echo $_smarty_tpl->getSubTemplate ("mac_oran.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

			<?php }elseif($_GET['secim']=='13'){?>		
				<?php echo $_smarty_tpl->getSubTemplate ("all_oran_canli.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

			<?php }elseif($_GET['secim']=='14'){?>		
				<?php echo $_smarty_tpl->getSubTemplate ("mac_oran_canli.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>
		
			<?php }?>
		<?php }?>
</div>
	
	


<?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>
<?php }} ?>