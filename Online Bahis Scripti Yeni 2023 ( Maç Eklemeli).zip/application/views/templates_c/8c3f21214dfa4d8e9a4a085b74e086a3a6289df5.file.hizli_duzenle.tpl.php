<?php /* Smarty version Smarty-3.1.8, created on 2018-10-22 12:41:22
         compiled from "application/views/templates/hizli_duzenle.tpl" */ ?>
<?php /*%%SmartyHeaderCode:3008248765bcd9b42b47931-03392156%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '8c3f21214dfa4d8e9a4a085b74e086a3a6289df5' => 
    array (
      0 => 'application/views/templates/hizli_duzenle.tpl',
      1 => 1495725356,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '3008248765bcd9b42b47931-03392156',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'tipyok' => 0,
    'ligler' => 0,
    'liste' => 0,
    'vr' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_5bcd9b42c2def9_81955788',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5bcd9b42c2def9_81955788')) {function content_5bcd9b42c2def9_81955788($_smarty_tpl) {?><?php if (!is_callable('smarty_modifier_date_format')) include '/home/beyplaying/public_html/system/libs/smarty/libs/plugins/modifier.date_format.php';
?><?php echo $_smarty_tpl->getSubTemplate ("header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<?php echo $_smarty_tpl->getSubTemplate ("left.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>



<style>

</style>
<script>
function orankaydet() {
	$.ajax({
		type: 'post',
		data: $( "#siraform" ).serialize(),
		url: baseurl+"ayar/orankaydet",
		success: function(data) {
			if(data){
				alert('Oranlar Kaydedildi..');
			}else{
				alert('Lütfen formu kontrol edip yeniden deneyiniz..!');
			}
		} 
	});
}
function gosteroran(id,tb) {	
	
	$.post(baseurl+'ayar/macoran',{id:id,tb:tb},function(data) {	
		$( ".macici" ).dialog({
		  modal: true,
		  width: 1000,
		  position:['top',30],
		  close : function(){
			 $( ".macici" ).html('');
		  }
		});
		$(".macici").html(data);
	});
}

function gostergizle(id,durum) {
	
	var tablo = $("#tablo").val();
	$.post(baseurl+'ayar/macgizlemedurum',{id:id,tb:tablo,durum:durum},function(data) { 
		failcont('Düzenleme tamamlandı.');
		if(durum==0) {
			$("#gosterbutton_"+id+"").hide();
			$("#gizlebutton_"+id+"").show();
		} else
		if(durum==1) {
			$("#gosterbutton_"+id+"").show();
			$("#gizlebutton_"+id+"").hide();		
		}
	});
	
}

function kaydet(id,p) {
	var tb = $("#tablo").val();
	var kod = $("#kod_"+id+"").val();
	var saat = $("#saat_"+id+"").val();
	var trh = $("#trh_"+id+"").val();
	var ev_takim = $("#ev_"+id+"").val();
	var konuk_takim = $("#kt_"+id+"").val();
	$.post(baseurl+'ayar/mackaydet',{tb:tb,id:id,trh:trh,saat:saat,ev_takim:ev_takim,konuk_takim:konuk_takim,kod:kod,p:p},function(data) { 
		failcont('Maç Düzenlemesi tamamlandı.');
	});	
}
jQuery(function($){
	$("#tablo").change(function () {
		if($(this).val()==''){
			alert('Lütfen Program Seçiniz');
			return false;
		}else{
			document.location.href = '?tablo='+$(this).val();
			return true;
		}
	});
	$( "#degis" ).toggle(function() {
	  $('#yenimac').show();
	}, function() {
	  $('#yenimac').hide();
	});
});
</script>

<div class="macici" style="display:none" title="Maça Ait Oranlar"></div>
	
	<div class="coupons" >
	
		<div class="coupon-title">
			<div class="account-table-blue"><span>
				<div class="icon"><i class="fa  fa-clone"></i></div>
				</span>
				<p>Hızlı Düzenle</p>
			</div>
			<div class="account-table-gray">
				<?php if ($_smarty_tpl->tpl_vars['tipyok']->value==0){?>
				<div style="float: left; width: 200px; padding: 3px 0 0 5px;"><h2><a href="javascript:;" id="degis" class="d2">Yeni Maç Ekle</a></h2></div>
				<?php }?>
				<form method="get" action="<?php echo base_url();?>
sonucgirsistem" name="ilk">
				<label>Program Seçin</label>
				<div class="selectbox">
				<select name="tablo" id="tablo">
					<option value="<?php echo $_GET['tablo'];?>
"><?php echo $_GET['tablo'];?>
</option>
					<option value="">--------</option>
					<option value="Futbol">Futbol</option>
					<option value="Basketbol">Basketbol</option>
					<option value="Tenis">Tenis</option>
					<option value="Hentbol">Hentbol</option>
					<option value="Hokey">Buz Hokeyi</option>
				</select>
				</div>
				</form>
			</div>
			<hr>
		<div id="sonuc">
			<?php if ($_smarty_tpl->tpl_vars['tipyok']->value==0){?>
			<form method="post" action="<?php echo base_url();?>
ayar/macekle" style="display:none;" id="yenimac">
			<table class="tftable" style="width:100%;background:#ccc" cellspacing="0" cellpadding="0">
			<thead>
			<tr>
				<th colspan="7"><div class="formbaslik" style="margin: 0">Yeni Maç Ekleme Formu</div></th>
			</tr>
			<tr>
			<th width="7%">Kodu</td>
			<th width="7%">Saat</td>
			<th width="7%">Tarih</td>
			<th width="30%">Ev Sahibi</td>
			<th width="30%">Deplasman</td>
			<th width="30%">Lig Seçimi</td>
			<th width="15%" colspan="2">İşlem</td>
			</tr></thead><tbody>
			<tr>
			<td><input class="" size="4" name="kod" type="text"></td>
			<td><input class="" size="4" name="saat" type="text"></td>
			<td><input class="" size="7" name="trh" type="text"></td>
			<td><input class="" style="width: 100%" name="ev" type="text"></td>
			<td><input class="" style="width: 100%" name="kt" type="text"></td>
			<td>
			<select name="kupa_id">
			<?php echo $_smarty_tpl->tpl_vars['ligler']->value;?>

			</select>
			</td>
			<td colspan="2"><input class="button" style="padding: 2px;" value="Kaydet" type="submit"></td>
			</tr>
			</tbody></table>
			<input type="hidden" name="tb" value="<?php echo $_GET['tablo'];?>
">
			</form>
			<?php }?>
		<?php if ($_smarty_tpl->tpl_vars['tipyok']->value==0){?>
		<table class="tftable" style="width:100%" cellspacing="0" cellpadding="0">
			<thead>
			<tr>
				<th colspan="7"><div class="formbaslik" style="margin: 0"><?php echo $_GET['tablo'];?>
 Maç Listesi</div></th>
			</tr>
			<tr>
			<th width="7%">Kodu</td>
			<th width="7%">Saat</td>
			<th width="7%">Tarih</td>
			<th width="30%">Ev sahibi</td>
			<th width="30%">Konuk takım</td>
			<th width="15%" colspan="2">İşlem</td>
			</tr></thead><tbody>
			<?php  $_smarty_tpl->tpl_vars['vr'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['vr']->_loop = false;
 $_smarty_tpl->tpl_vars['tip'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['liste']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['vr']->key => $_smarty_tpl->tpl_vars['vr']->value){
$_smarty_tpl->tpl_vars['vr']->_loop = true;
 $_smarty_tpl->tpl_vars['tip']->value = $_smarty_tpl->tpl_vars['vr']->key;
?>
				<tr>
					<td><input type="text" class="" size="4" id="kod_<?php echo $_smarty_tpl->tpl_vars['vr']->value->id;?>
" value="<?php if ($_smarty_tpl->tpl_vars['vr']->value->mac_kodu){?><?php echo $_smarty_tpl->tpl_vars['vr']->value->mac_kodu;?>
<?php }elseif($_smarty_tpl->tpl_vars['vr']->value->iddaa_kodu){?><?php echo $_smarty_tpl->tpl_vars['vr']->value->iddaa_kodu;?>
<?php }elseif($_smarty_tpl->tpl_vars['vr']->value->d_kodu){?><?php echo $_smarty_tpl->tpl_vars['vr']->value->d_kodu;?>
<?php }?>"></td>
					
					<td><input type="text" class="" size="4" id="saat_<?php echo $_smarty_tpl->tpl_vars['vr']->value->id;?>
" value="<?php echo smarty_modifier_date_format($_smarty_tpl->tpl_vars['vr']->value->mac_time,'%H:%M');?>
"></td>
					
					<td><input type="text" class="" size="7" id="trh_<?php echo $_smarty_tpl->tpl_vars['vr']->value->id;?>
" value="<?php echo smarty_modifier_date_format($_smarty_tpl->tpl_vars['vr']->value->mac_time,'%d.%m.%y');?>
"></td>
					
					<td><input type="text" class="" style="width: 100%" id="ev_<?php echo $_smarty_tpl->tpl_vars['vr']->value->id;?>
" value="<?php echo $_smarty_tpl->tpl_vars['vr']->value->ev_takim;?>
"></td>
					
					<td><input type="text" class="" style="width: 100%" id="kt_<?php echo $_smarty_tpl->tpl_vars['vr']->value->id;?>
" value="<?php echo $_smarty_tpl->tpl_vars['vr']->value->konuk_takim;?>
"></td>
					
					<td ><input type="button" class="button" style="padding: 2px;" onclick="kaydet('<?php echo $_smarty_tpl->tpl_vars['vr']->value->id;?>
','<?php if ($_smarty_tpl->tpl_vars['vr']->value->mac_kodu){?>mac_kodu<?php }elseif($_smarty_tpl->tpl_vars['vr']->value->iddaa_kodu){?>iddaa_kodu<?php }elseif($_smarty_tpl->tpl_vars['vr']->value->d_kodu){?>d_kodu<?php }?>');" value="Kaydet">
					<?php if ($_smarty_tpl->tpl_vars['vr']->value->adminid){?>
					&nbsp;&nbsp;<a href="javascript:;" onClick="gosteroran('<?php echo $_smarty_tpl->tpl_vars['vr']->value->id;?>
','<?php echo $_GET['tablo'];?>
');" class="d2">ORANLAR</a>
					<?php }?>
					</td>
					<?php if ($_GET['tablo']=='Futbol'||$_GET['tablo']=='Basketbol'){?>
					<td >
					<a <?php if ($_smarty_tpl->tpl_vars['vr']->value->gizlimi==0){?>style="display:none;"<?php }?> href="javascript:;" id="gosterbutton_<?php echo $_smarty_tpl->tpl_vars['vr']->value->id;?>
" onClick="gostergizle('<?php echo $_smarty_tpl->tpl_vars['vr']->value->id;?>
',0);" class="d2">GÖSTER</a>
					<a <?php if ($_smarty_tpl->tpl_vars['vr']->value->gizlimi==1){?> style="display:none;"<?php }?> href="javascript:;" id="gizlebutton_<?php echo $_smarty_tpl->tpl_vars['vr']->value->id;?>
" onClick="gostergizle('<?php echo $_smarty_tpl->tpl_vars['vr']->value->id;?>
',1);" class="d3">GİZLE</a>
					</td>
					<?php }?>
				</tr>
			<?php } ?>
			</tbody>
			</table>
			<?php }else{ ?>
				<div class="bos">Program Seçmediniz</div>
			<?php }?>
		</div>
</div>
</div>

<?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>
<?php }} ?>