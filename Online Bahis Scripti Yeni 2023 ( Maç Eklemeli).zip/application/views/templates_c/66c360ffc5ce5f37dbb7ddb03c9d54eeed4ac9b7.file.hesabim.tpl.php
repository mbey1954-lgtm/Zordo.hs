<?php /* Smarty version Smarty-3.1.8, created on 2022-09-24 04:53:55
         compiled from "application/views/templates/hesabim.tpl" */ ?>
<?php /*%%SmartyHeaderCode:50253891632e6333655115-65477718%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '66c360ffc5ce5f37dbb7ddb03c9d54eeed4ac9b7' => 
    array (
      0 => 'application/views/templates/hesabim.tpl',
      1 => 1495533664,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '50253891632e6333655115-65477718',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_632e633369f7b2_74019089',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_632e633369f7b2_74019089')) {function content_632e633369f7b2_74019089($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ("header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<?php echo $_smarty_tpl->getSubTemplate ("left.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>



<script>
$(function() {
	
	$("#kaydet").click(function(e) {
		var yazici = $("#yazici").val();
		var tel = $("#tel").val();
		var email = $("#email").val();
		var tc = $("#tc").val();
		var newpass = $("#newpass").val();
		var newpasst = $("#newpasst").val();
		if(newpass && newpass != newpasst){alert('şifreler uyuşmuyor.');return false;}
		$.post(baseurl+'home/newpass',{newpass:newpass,yazici:yazici,tel:tel,email:email,tc:tc},function(data) {	
			if(data=="1") { 
				failcont('Ayarlarınız Kaydedildi.');
			}else{
				alert(data);
			}
		});
    });
	
});
</script>

<div class="coupons">	
	<div class="coupon-title">
		<div class="account-table-blue"><span>
			<div class="icon"><i class="fa fa-user"></i></div>
			</span>
			<p>Hesap Ayarlarım</p>
		</div>


<form method="post">
<table style="margin:10px 0px 20px 10px;width:98%;color:<?php if (@tema==1){?>#000<?php }else{ ?>#fff<?php }?>;" id="table_step">
		<tr style="height:50px">		
			<td colspan="2"><div class="formbaslik"><?php echo lang('girbilgi');?>
</div></td>				
		</tr>
		<tr>
			<td><?php echo lang('tc');?>
</td>				
			<td><input class="input" id="tc" type="text" value="<?php echo @tc;?>
"></td>				
		</tr>
		<tr>
			<td><?php echo lang('email');?>
</td>				
			<td><input class="input" id="email" type="text" value="<?php echo @email;?>
"></td>				
		</tr>
		<tr>
			<td><?php echo lang('tel');?>
</td>				
			<td><input class="input" id="tel" type="text" value="<?php echo @tel;?>
"></td>				
		</tr>
		<tr style="height:50px">		
			<td colspan="2"><div class="formbaslik"><?php echo lang('sfredit');?>
</div></td>				
		</tr>
		<tr>
			<td><?php echo lang('sifre');?>
</td>				
			<td><input class="input" id="newpass" type="text"> <span>Şifrenizi değiştirmek istemiyorsanız boş bırakın.</td>				
		</tr>
		<tr>
			<td><?php echo lang('sifre');?>
</td>				
			<td><input class="input" id="newpasst" type="text"></td>				
		</tr>
		<tr style="height:50px">		
			<td colspan="2"><div class="formbaslik"><?php echo lang('yzcsec');?>
</div></td>				
		</tr>
		<tr>
			<td><?php echo lang('yzcsec');?>
</td>				
			<td><select id="yazici" class="finput" style="width:120px;">
				<option value="normal" <?php if (@yazici=='normal'){?>selected<?php }?>>Normal</option>
				<option value="termal" <?php if (@yazici=='termal'){?>selected<?php }?>>Termal</option>
			</select>
			</td>
		</tr>
		<tr>
			<td colspan="2" class="trenayar"><input type="button" class="button" value="<?php echo lang('kyt');?>
" id="kaydet"></td>				
		</tr>
</table>
</form>



</div>
</div>

<?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>
<?php }} ?>