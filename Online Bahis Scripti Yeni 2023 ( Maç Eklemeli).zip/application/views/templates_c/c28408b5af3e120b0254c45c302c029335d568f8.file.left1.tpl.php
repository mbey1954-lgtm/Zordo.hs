<?php /* Smarty version Smarty-3.1.8, created on 2018-08-10 12:36:51
         compiled from "application/views/templates/left1.tpl" */ ?>
<?php /*%%SmartyHeaderCode:5971589865b6d5cb36bb833-70001479%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c28408b5af3e120b0254c45c302c029335d568f8' => 
    array (
      0 => 'application/views/templates/left1.tpl',
      1 => 1495532455,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '5971589865b6d5cb36bb833-70001479',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'ayr' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_5b6d5cb37816c9_10167561',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5b6d5cb37816c9_10167561')) {function content_5b6d5cb37816c9_10167561($_smarty_tpl) {?><div class="menu">		


<?php $_smarty_tpl->tpl_vars['ayr'] = new Smarty_variable(explode("|",bultensay()), null, 0);?>

	<div class="search">
	  <form action="#">
		<input placeholder="<?php echo lang('macara');?>
" type="text" id="takimara">
		<button type="button"><i class="fa fa-search"></i></button>
	  </form>
	</div>
	
	<div class="bet-list">
		<div class="timeline-container">
            <div class="title"><?php echo lang('home');?>
</div>
        </div>
	
	<div id="cssmenu">		
		<div class="allmatch">
			<div class="amatchselect" onclick="bulsathac();">
			  <p id="satilk"><?php echo lang('saatall');?>
</p>
			  <div class="arrowall"><i class="fa fa-caret-down"></i></div>
			</div>
			<ul class="amatchdrop saatac" style="display:none">
				<li onclick="$('#saat').val(60);$('#satilk').text('1 saat');loadbulten();bulsathac(1);"><p >1 <?php echo lang('saat');?>
</p></li>
				<li onclick="$('#saat').val(180);$('#satilk').text('3 saat');loadbulten();bulsathac(1);"><p >3 <?php echo lang('saat');?>
</p></li>
				<li onclick="$('#saat').val(360);$('#satilk').text('6 saat');loadbulten();bulsathac(1);"><p >6 <?php echo lang('saat');?>
</p></li>
				<li onclick="$('#saat').val(720);$('#satilk').text('12 saat');loadbulten();bulsathac(1);"><p >12 <?php echo lang('saat');?>
</p></li>
				<li onclick="$('#saat').val('');$('#satilk').text('tümü');loadbulten();bulsathac(1);"><p ><?php echo lang('saatall');?>
</p></li>
			</ul>
			<input type="hidden" id="saat">
			<div class="amatchselectt" onclick="bultrhac();">
			  <p id="trhilk"><?php echo lang('tarihall');?>
</p>
			  <div class="arrowall"><i class="fa fa-caret-down"></i></div>
			</div>
			<ul class="amatchdropt trhac" style="display:none">
				<li onclick="$('#tarihb').val('');$('#trhilk').text('tümü');loadbulten();bultrhac(1);"><p ><?php echo lang('tarihall');?>
</p></li>
				<?php if ((curpagename(1)=='home'||curpagename(1)=='')&&curpagename(2)==''){?><?php echo bultentarih('',0);?>

				<?php }elseif(curpagename(2)=='basketbol'){?><?php echo bultentarih('b',0);?>

				<?php }elseif(curpagename(2)=='tenis'){?><?php echo bultentarih('t',0);?>

				<?php }elseif(curpagename(2)=='hentbol'){?><?php echo bultentarih('h',0);?>

				<?php }elseif(curpagename(2)=='buzhokeyi'){?><?php echo bultentarih('o',0);?>

				<?php }elseif(curpagename(2)=='duello'){?><?php echo bultentarih('',1);?>

				<?php }?>			
			</ul>
			<input type="hidden" id="tarihb">
        </div>
		<ul>
			<li>
				<a href="<?php if ((curpagename(1)=='home'||curpagename(1)=='')&&curpagename(2)==''){?>javascript:void(0);<?php }else{ ?><?php echo base_url();?>
home<?php }?>" class="itemac" id="flig">
					<div class="icon-1"></div>
					<div class="sports ng-binding"><?php echo lang('futbol');?>
</div>
					<em ><?php echo $_smarty_tpl->tpl_vars['ayr']->value[0];?>
</em>
				</a>
				<ul style="display:none;" id="ligler"></ul>
			</li>
			<?php if (@basketbol=='1'&&@baskapat=='0'){?>
			<li>
				<a href="<?php if (curpagename(2)=='basketbol'){?>javascript:void(0);<?php }else{ ?><?php echo base_url();?>
home/basketbol<?php }?>" class="itemac" id="blig">
					<div class="icon-2"></div>
					<div class="sports ng-binding"><?php echo lang('basket');?>
</div>
					<em ><?php echo $_smarty_tpl->tpl_vars['ayr']->value[3];?>
</em>
				</a>
				<ul style="display:none;" id="liglerb"></ul>
			</li>
			<?php }?>
			<?php if (@duello=='1'&&@dukapat=='0'){?>
			<li>
				<a href="<?php echo base_url();?>
home/duello" class="itemac">
					<div class="icon-1"></div>
					<div class="sports ng-binding"><?php echo lang('duello');?>
</div>
					<em ><?php echo $_smarty_tpl->tpl_vars['ayr']->value[2];?>
</em>
				</a>
			</li>
			<?php }?>
			<li>
				<a href="<?php if (curpagename(2)=='tenis'){?>javascript:void(0);<?php }else{ ?><?php echo base_url();?>
home/tenis<?php }?>" class="itemac" id="tlig">
					<div class="icon-5"></div>
					<div class="sports ng-binding"><?php echo lang('tenis');?>
</div>
					<em ><?php echo $_smarty_tpl->tpl_vars['ayr']->value[5];?>
</em>
				</a>
				<ul style="display:none;" id="liglert"></ul>
			</li>
			
			<li>
				<a href="<?php if (curpagename(2)=='hentbol'){?>javascript:void(0);<?php }else{ ?><?php echo base_url();?>
home/hentbol<?php }?>" class="itemac" id="hlig">
					<div class="icon-6"></div>
					<div class="sports ng-binding"><?php echo lang('hentbol');?>
</div>
					<em ><?php echo $_smarty_tpl->tpl_vars['ayr']->value[6];?>
</em>
				</a>
				<ul style="display:none;" id="liglerh"></ul>
			</li>
			
			<li>
				<a href="<?php if (curpagename(2)=='buzhokeyi'){?>javascript:void(0);<?php }else{ ?><?php echo base_url();?>
home/buzhokeyi<?php }?>" class="itemac" id="olig">
					<div class="icon-4"></div>
					<div class="sports ng-binding"><?php echo lang('hokey');?>
</div>
					<em ><?php echo $_smarty_tpl->tpl_vars['ayr']->value[7];?>
</em>
				</a>
				<ul style="display:none;" id="liglero"></ul>
			</li>
			<?php if (@canlibahis=='1'&&@canliyasak=='0'){?>
			<li>
				<a href="<?php echo base_url();?>
canlibahis" class="itemac">
					<div class="icon-1"></div>
					<div class="sports ng-binding"><?php echo lang('canli');?>
</div>
					<em ><?php echo $_smarty_tpl->tpl_vars['ayr']->value[4];?>
</em>
				</a>
			</li>
			<?php }?>
		</ul>
	</div>
	
</div>



<?php if (@direk=='0'){?>
<div class="user-menu-container"> 
<div class="user-menu-title"><?php echo lang('istsnc');?>
</div>
<ul>
	
	<li>
		<a href="<?php echo base_url();?>
ayar/macistatistikleri"><div class="icon"><i class="fa fa-area-chart"></i></div><span><?php echo lang('mcist');?>
</span></a>
	</li>
	<li>
		<a href="<?php echo base_url();?>
ayar/takimistatistikleri"><div class="icon"><i class="fa fa-bar-chart"></i></div><span><?php echo lang('tkmist');?>
</span></a>
	</li>
	<li><a class="footinfo fancybox.iframe" href="<?php echo base_url();?>
canlibahis/macsonuclari"><div class="icon"><i class="fa fa-bar-chart"></i></div><span><?php echo lang('snclar');?>
</span></a></li>
  
</ul> 
</div>
<?php }?>
</div><?php }} ?>