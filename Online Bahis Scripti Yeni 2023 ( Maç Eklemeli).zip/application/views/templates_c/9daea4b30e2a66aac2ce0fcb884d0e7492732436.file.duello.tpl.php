<?php /* Smarty version Smarty-3.1.8, created on 2018-08-13 02:14:46
         compiled from "application/views/templates/duello.tpl" */ ?>
<?php /*%%SmartyHeaderCode:9210089085b70bf66639b42-64453117%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '9daea4b30e2a66aac2ce0fcb884d0e7492732436' => 
    array (
      0 => 'application/views/templates/duello.tpl',
      1 => 1495302838,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '9210089085b70bf66639b42-64453117',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_5b70bf66686b84_34813049',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5b70bf66686b84_34813049')) {function content_5b70bf66686b84_34813049($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ("header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<?php echo $_smarty_tpl->getSubTemplate ("left1.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>



<script>

function loadbulten(ligid){

	var takim = $("#takimara").val(); 
	var kod = $("#mac_kodu").val(); 
	var tarih = $("#tarihb").val();
	var saat = $("#saat").val(); 
	loadgir(".bulten");
	
	$.post(baseurl+'home/bulten/',{duelmi:1,ligid:ligid,takim:takim,tarih:tarih,kod:kod,saat:saat},function(data) {
		
		var arayi = {};
		var byaz ='';
		
		if(data.yok){
			byaz +="<div class='bos'><?php echo lang('bosbhs');?>
</div>";
		}else{
		
		$.each(data,function(lig,d1){
				var ayr=lig.split('|');
				byaz +='<div><div><div class="general-table-title-blue"><div class="icon icon-1"></div><p>'+ayr[0]+'</p></div> <div class="general-subtitle-gray"><ul><li><span class="icon-time"></span></li><li><i class="fa fa-flag"></i></li><li></li><li> <strong><?php echo lang("thm");?>
</strong> <span>1</span> <span>X</span> <span>2</span> </li><li style="width: 141px"> <strong><?php echo lang("cs");?>
</strong> <span style="width: 33.3%">1-0</span> <span style="width: 33.3%">1-2</span><span style="width: 33.3%">0-2</span> </li><li></li></ul></div></div>';
				
				$.each(d1,function(v,d2){	
					byaz +='<ul class="match-list-default zebra">  <li>'+d2.gun+' '+d2.st+'</li><li>'+d2.d_kodu+'</li><li><em class="xcard"></em> <span class="t1">'+d2.ev_takim+'</span> <span class="score">-:-</span><em class="xcard"></em> <span class="t2">'+d2.konuk_takim+'</span> </li>  <li><a class="ratio-box" class="qbut all'+d2.id+'-'+d2.tipi+'" onclick="kupon(\''+d2.evk+'\');" id="'+d2.id+'-1-'+d2.tipi+'" href="javascript:;"><span>'+d2.ev+'</span></a> <a class="ratio-box" class="qbut all'+d2.id+'-'+d2.tipi+'" onclick="kupon(\''+d2.bk+'\');" id="'+d2.id+'-2-'+d2.tipi+'" href="javascript:;"><span>'+d2.brb+'</span></a> <a class="ratio-box" class="qbut all'+d2.id+'-'+d2.tipi+'" onclick="kupon(\''+d2.kk+'\');" id="'+d2.id+'-3-'+d2.tipi+'" href="javascript:;"><span>'+d2.knk+'</span></a> </li> <li style="width: 141px"><a class="ratio-box" class="qbut all'+d2.id+'-'+d2.tipi+'" onclick="kupon(\''+d2.cs1k+'\');" id="'+d2.id+'-31-'+d2.tipi+'" href="javascript:;"><span>'+d2.cs1+'</span></a> <a class="ratio-box" class="qbut all'+d2.id+'-'+d2.tipi+'" onclick="kupon(\''+d2.cs0k+'\');" id="'+d2.id+'-32-'+d2.tipi+'" href="javascript:;"><span>'+d2.cs0+'</span></a> <a class="ratio-box" class="qbut all'+d2.id+'-'+d2.tipi+'" onclick="kupon(\''+d2.cs2k+'\');" id="'+d2.id+'-33-'+d2.tipi+'" href="javascript:;"><span>'+d2.cs2+'</span></a> </li><li></li></ul>';
				});
				byaz+='</div>';
			});
			kuponguncelle(1);
		}
		$(".bulten").html(byaz);
		
	}, "json");	
}	

$(document).ready(function(e) {
	
	loadbulten();
	$('#takimara').keypress(function(event){
		var keycode = (event.keyCode ? event.keyCode : event.which);
		if(keycode == '13'){ loadbulten(); }
	});


	$('#mac_kodu').live( "keyup", function() {
		var mackodu = $("#mac_kodu").val();
		if(mackodu.length>2) { 
			loadbulten();
		}else if(mackodu.length<1) { 
			loadbulten(); 		
		}
	});
	
});
	
</script>


<main><div class="table-container bulten"></div></main>

<?php echo $_smarty_tpl->getSubTemplate ("right.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>
<?php }} ?>