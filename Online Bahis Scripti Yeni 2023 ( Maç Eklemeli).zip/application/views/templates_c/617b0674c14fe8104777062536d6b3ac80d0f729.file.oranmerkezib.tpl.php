<?php /* Smarty version Smarty-3.1.8, created on 2018-12-03 00:02:54
         compiled from "application/views/templates/oranmerkezib.tpl" */ ?>
<?php /*%%SmartyHeaderCode:12159316825c04487e94b631-50498548%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '617b0674c14fe8104777062536d6b3ac80d0f729' => 
    array (
      0 => 'application/views/templates/oranmerkezib.tpl',
      1 => 1495298300,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '12159316825c04487e94b631-50498548',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_5c04487e99f3e8_27487336',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5c04487e99f3e8_27487336')) {function content_5c04487e99f3e8_27487336($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ("header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<?php echo $_smarty_tpl->getSubTemplate ("left.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>


	<div class="coupons">	
	<div class="coupon-title" style="position:relative">
		<div class="account-table-blue"><span>
	<div class="icon"><i class="fa fa-user"></i></div>
	</span>
	<p><?php echo lang('boranduz');?>
</p>
</div>
		<table style="margin-left:10px;margin-top: 40px;width:98%;color: #<?php if (@tema==1){?>#000<?php }else{ ?>#fff<?php }?>;margin-bottom:30px">
		<tr>
		<td><?php echo lang('secin');?>
</td>
		<td>
		<select onchange="self.location.href='?secim='+this.value+'';" name="duzenleme" class="chosen-select-no-single">
			<option value=""><?php echo lang('islm');?>
</option>
			<optgroup label="<?php echo lang('basket');?>
">
				<option value="1" <?php if ($_GET['secim']=='1'){?>selected<?php }?>><?php echo lang('tumlg');?>
</option>
				<option value="2" <?php if ($_GET['secim']=='2'){?>selected<?php }?>><?php echo lang('llg');?>
</option>
				<option value="3" <?php if ($_GET['secim']=='3'){?>selected<?php }?>><?php echo lang('tkmac');?>
</option>
			</optgroup>
			<optgroup label="<?php echo lang('cbasket');?>
">
				<option value="13" <?php if ($_GET['secim']=='13'){?>selected<?php }?>><?php echo lang('tummac');?>
</option>
				<option value="14" <?php if ($_GET['secim']=='14'){?>selected<?php }?>><?php echo lang('cduz');?>
</option>
			</optgroup>
		</select>			
		</td>		
		</tr>		
		</table>
		
		<div style="position: absolute; right: 0;top:40px;width:500px;float: right;color:#<?php if (@tema==1){?>#000<?php }else{ ?>#fff<?php }?>;">
		<?php echo lang('duztxt');?>
</div>
		
		<?php if ($_GET['secim']=='1'){?>		
			<?php echo $_smarty_tpl->getSubTemplate ("all_oranb.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>
			
		<?php }elseif($_GET['secim']=='2'){?>		
			<?php echo $_smarty_tpl->getSubTemplate ("lig_oranb.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>
	
		<?php }elseif($_GET['secim']=='3'){?>		
			<?php echo $_smarty_tpl->getSubTemplate ("mac_oranb.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

		<?php }elseif($_GET['secim']=='13'){?>		
			<?php echo $_smarty_tpl->getSubTemplate ("all_oranb_canli.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

		<?php }elseif($_GET['secim']=='14'){?>		
			<?php echo $_smarty_tpl->getSubTemplate ("mac_oranb_canli.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>
		
		<?php }?>
</div>
	
	


<?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>
<?php }} ?>