<?php /* Smarty version Smarty-3.1.8, created on 2019-01-03 11:37:50
         compiled from "application/views/templates/transfer_left.tpl" */ ?>
<?php /*%%SmartyHeaderCode:9628424855c2dc9de9989a6-25386185%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '85fb9b43c6867fb70812f5e93d66966997202bdf' => 
    array (
      0 => 'application/views/templates/transfer_left.tpl',
      1 => 1495629595,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '9628424855c2dc9de9989a6-25386185',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_5c2dc9de9a0e52_29760985',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5c2dc9de9a0e52_29760985')) {function content_5c2dc9de9a0e52_29760985($_smarty_tpl) {?><ul>		
		<li>
			<a href="<?php echo base_url();?>
ayar/paracekme" class="<?php if (curpagename(2)=='paracekme'){?>active<?php }?>"><div class="icon"><i class="fa fa-cc-visa"></i></div><span><?php echo lang('pcek');?>
</span></a>
		</li>		
		<li>
			<a href="<?php echo base_url();?>
info/banka_hesap" class="<?php if (curpagename(2)=='banka_hesap'){?>active<?php }?>"><div class="icon"><i class="fa fa-bank"></i></div><span><?php echo lang('pyatir');?>
</span></a>
		</li>		
	</ul><?php }} ?>