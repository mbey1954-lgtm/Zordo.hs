<?php /* Smarty version Smarty-3.1.8, created on 2018-09-03 15:28:39
         compiled from "application/views/templates/mobil/ana.tpl" */ ?>
<?php /*%%SmartyHeaderCode:8399614605b8d28f7510069-12718515%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'a2e057ca2d8369dcb6a267a219e3d818170b8dcb' => 
    array (
      0 => 'application/views/templates/mobil/ana.tpl',
      1 => 1495555485,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '8399614605b8d28f7510069-12718515',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_5b8d28f755f378_52264701',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5b8d28f755f378_52264701')) {function content_5b8d28f755f378_52264701($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ("mobil/header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>


<script>
function loadbulten(ligid){
	
	loadgir(".bulten");
	var takim = $("#takimara").val(); 
	var kod = $("#mac_kodu").val(); 
	var tarih = $("#tarihb").val();
	var ulke = $("#ulke").val();
	var saat = $("#saat").val(); 
	
	$.post(baseurl+'home/bulten/',{duelmi:0,ligid:ligid,takim:takim,ulke:ulke,tarih:tarih,kod:kod,saat:saat},function(data) {		
		$(".bulten").html(data);
		kuponsay();		
	});	
}	

$(document).ready(function(e) {
	loadbulten();
	
	$('#mac_kodu').live( "keyup", function() {
		var mackodu = $("#mac_kodu").val();
		if(mackodu.length>2) { 
			loadbulten();
		}else if(mackodu.length<1) { 
			loadbulten(); 		
		}
	});
	$('#takimara').live( "keyup", function() {
		var takimara = $("#takimara").val();
		if(takimara.length>2) { 
			loadbulten();
		}else if(takimara.length<1) { 
			loadbulten(); 		
		}
	});
});
	
</script>



<div id="macd" style="display:none"></div>

<div style="left: 0px; right: 0px; z-index: 100; position: fixed; top: 0px;" class="appheader">
<?php echo mobilhead();?>


<div><div class="header"><div onclick="goBack();" class="icon back noselect "></div><div class="text title noselect">Futbol Bahisleri</div><div onclick="go('index')" style="padding-left:20px" class="icon logo noselect"></div></div></div></div>

<div class="page slide top in" id="page1">
<div class="scroll_container" style="">
<div class="scroll_wrapper" style="padding-top: 85px; padding-bottom: 44px;">
<div class="appcontent">
<div>  </div>
<div class="filterbar" style="height: 80px;">
<select data-placeholder="Tüm Tarihler" class="chosen" style="width:150px;" id='tarihb' onChange="loadbulten();">
<option value=''>Hepsi</option>
	<?php echo bultentarihm('',0);?>

</select>

<select data-placeholder="Ülkeler" class="chosen" style="width:150px;" id='ulke' onChange="loadbulten();">
<option value=''>Ülkeler</option>
	<?php echo ulkeler(1);?>

</select>

<input type="text" id="mac_kodu" class="inputbet" style="width:150px;float: left;height: 30px" placeholder="Maç Kodu">
<input type="text" id="takimara" class="inputbet" style="width:150px;float: left;height: 30px" placeholder="Maç Ara">
</div>
<div class="bulten"></div>

<div style="height:20px;">&nbsp;</div>

</div></div></div></div>

<?php echo $_smarty_tpl->getSubTemplate ("mobil/footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>
<?php }} ?>