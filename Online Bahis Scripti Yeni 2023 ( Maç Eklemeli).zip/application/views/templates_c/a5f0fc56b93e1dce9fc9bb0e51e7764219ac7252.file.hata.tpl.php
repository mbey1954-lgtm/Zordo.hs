<?php /* Smarty version Smarty-3.1.8, created on 2022-09-30 01:44:38
         compiled from "application/views/templates/mobil/hata.tpl" */ ?>
<?php /*%%SmartyHeaderCode:35813743463361fd6e2c273-16785905%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'a5f0fc56b93e1dce9fc9bb0e51e7764219ac7252' => 
    array (
      0 => 'application/views/templates/mobil/hata.tpl',
      1 => 1495365828,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '35813743463361fd6e2c273-16785905',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_63361fd6e70c71_56704384',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_63361fd6e70c71_56704384')) {function content_63361fd6e70c71_56704384($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ("mobil/header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>


<script>
kuponsay();

</script>

<div id="macd" style="display:none"></div>
<div style="left: 0px; right: 0px; z-index: 100; position: fixed; top: 0px;" class="appheader">
<?php echo mobilhead();?>

<div><div class="header"><div onclick="goBack();" class="icon back noselect "></div><div class="text title noselect">Hata Sayfası</div><div onclick="go('index')" style="padding-left:20px" class="icon logo noselect"></div></div></div></div>

<div class="page slide top in" id="page1"><div class="scroll_container" style=""><div class="scroll_wrapper" style="padding-top: 85px; padding-bottom: 44px;"><div class="appcontent"><div>  </div>

<div id="ticket_bodys">
<div class="edtitle "><div class="text">

<h1>Aradığınız sayfa bulunamadı.. !!!</h1>
		<div style="font-size:20px;line-height:30px;text-align:left;padding-left:10px">
		Yetkiniz olmayan bir sayfaya ulaşıyorsunuz.<br>Lütfen yetkilendirme için sistem yöneticiniz ile görüşünüz.
		</div>
		
		</div></div>

</div>
<div style="height:20px;">&nbsp;</div></div></div></div></div>

<?php echo $_smarty_tpl->getSubTemplate ("mobil/footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>
<?php }} ?>