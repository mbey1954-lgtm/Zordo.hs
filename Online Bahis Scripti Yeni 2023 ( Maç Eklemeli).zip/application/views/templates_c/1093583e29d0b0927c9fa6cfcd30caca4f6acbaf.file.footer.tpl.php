<?php /* Smarty version Smarty-3.1.8, created on 2022-10-19 01:13:10
         compiled from "application/views/templates/footer.tpl" */ ?>
<?php /*%%SmartyHeaderCode:18504161015b6d5cb38029b4-65086274%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '1093583e29d0b0927c9fa6cfcd30caca4f6acbaf' => 
    array (
      0 => 'application/views/templates/footer.tpl',
      1 => 1666131167,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '18504161015b6d5cb38029b4-65086274',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_5b6d5cb38651e0_44641489',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5b6d5cb38651e0_44641489')) {function content_5b6d5cb38651e0_44641489($_smarty_tpl) {?></div>
</div>

<footer class="v2_footer" style="position:relative">
<div class="footer-main" style="width:1250px">
	<div class="age">
		<img src="../..//imglogin/payment/pp.png" style="margin: 15px 0px;" width="200px">
	</div>
	<div class="center_logo"> 
		<img src="../..//imglogin/payment/1.png"><img src="../..//imglogin/payment/2.png"><img src="../..//imglogin/payment/3.png"><img src="../..//imglogin/payment/4.png"><img src="../..//imglogin/payment/5.png"><img src="../..//imglogin/payment/6.png"><img src="../..//imglogin/payment/7.png"><img src="../..//imglogin/payment/8.png"><img src="../..//imglogin/payment/9.png"><img src="../..//imglogin/payment/10.png"><img src="../..//imglogin/payment/11.png"><img src="../..//imglogin/payment/12.png">
	</div>
	<div class="gambling"> 
		<img src="../..//imglogin/payment/secure.png" style="margin: -1px 0px 0px -20px;" width="150px">
	</div>
<div class="center_logo"><h3>Lisans:
	  <a class="action_button"href="http://www.gaminglicences.com/pages/validate.php?lid=8048-R0308781" target="_blank">Samsalabet N.V. license (8048/JAZ2014-014) </a>Curacao, CW. Samsalabet® N.V.Tescilli Markasıdır.<br/></strong></h3><li>This product is authorized by the Government of Curaçao, as an Information Provider legally authorized to conduct online egaming operations from Curaçao. Egaming Licensing and Supervision provided by Antillephone N.V.</li>
                </div></div>
				
	<div class="licensed"></div>

<section id="bottom" style="background: none">			
	<ul style="margin:0 0 10px">
		<li>
			<ul>
			<h3>Zirvedekiler</h3>
			<li><a>Champions League</a></li>
			<li><a>1. Bundesliga</a></li>
			<li><a>Premier League</a></li>	
			<li><a>Primera Division</a></li>	
			<li><a>Süper Lig</a></li>	
			<li><a>Serie A</a></li>	
			</ul>			
		</li>
		<li>
			<ul>
			<h3>Ekstralar</h3>
			<li><a href="<?php echo base_url();?>
home"><?php echo lang('home');?>
</a></li>
			<li><a href="<?php echo base_url();?>
canlibahis"><?php echo lang('canli');?>
</a></li>
			<li><a class="footinfo fancybox.iframe" href="<?php echo base_url();?>
canlibahis/macsonuclari">Maç Sonuçları</a></li>	
			<li><a href="<?php echo base_url();?>
LiveGames/casino" class="<?php if (curpagename(1)=='casino'){?>active<?php }?>"><?php echo lang('slot1');?>
</a></li>	
			<li><a>İstatistikler</a></li>	
			<li><a>Promosyon</a></li>	
			</ul>			
		</li>
		<li>
			<ul>
			<h3>Casino</h3>
			<li><a href="<?php echo base_url();?>
poker">Poker</a></li>
			<li><a href="<?php echo base_url();?>
casino">Casino</a></li>
			<li><a href="<?php echo base_url();?>
rulet">Rulet</a></li>	
			<li><a href="<?php echo base_url();?>
tombala">Tombala</a></li>	

			</ul>			
		</li>
		<li>
			<ul>
			<h3>SamsalaBet</h3>
			<li><a href="<?php echo base_url();?>
info/hakkimizda"><?php echo lang('hakk');?>
</a></li>
			<li><a href="<?php echo base_url();?>
info/gizlilik"><?php echo lang('gizlilik');?>
</a></li>
			<li><a href="<?php echo base_url();?>
info/sozluk"><?php echo lang('szlk');?>
</a></li>
			<li><a href="<?php echo base_url();?>
info/yardim"><?php echo lang('yrd');?>
</a></li>	
			</ul>			
		</li>		

		<li style="width:100px">
			<ul>
				<li></li>
				<li><img src="<?php echo base_url();?>
imglogin/18.png" width="120px"></li>
			</ul>
		</li>
	</ul>
				
</section>
</div>
<div class="bottomfooter">
	<div class="container" style="margin-left: auto;
margin-right: auto;
padding-left: 15px;
padding-right: 15px;max-width: 1170px;">
		<div style="min-height: 1px;
padding-left: 15px;
padding-right: 15px;padding-bottom: 15px;
position: relative;float:left;width: 41.6667%;">
		<p style="color:white;font-size:16px;font-weight:700;font-style:italic">Samsala<span style="color:#ff3333;">Bet</span></p>
		</div>
		<div style="min-height: 1px;
padding-left: 15px;
padding-right: 15px;padding-bottom: 15px;
position: relative;float:left;width: 58.3333%;">
			<p style="color:white;font-size:12px;font-weight:700;">2022 <span style="color:#ff3333;font-size:13px">©</span> All Rights Reserved.</p>
		</div>
	</div>
</div>

<a class="go_top_gray"><i class="fa fa-caret-up"></i></a>
<div id="chat_sec_div" title="Online Destek Hattı / Kullanıcı Seçiniz." style="display: none;"></div>
<div id="chat_alert"></div>

<div id="foot"></div>
<div id="alarm" title="<?php echo lang('ipttalp');?>
"></div>
<div id="mkalarm" title="<?php echo lang('msjktu');?>
"></div>

<div class="okmsg" id="okdurum"></div>
<div class="failmsg" id="faildurum"></div>

<div id="livelock"></div>
<div id="printerlock"></div>

<div id="macdetay"></div>
<div id="macista" style="display:none"><iframe id="myIframe" src="" style="height: 500px;width:100%"></iframe></div>
<div id="uyarip" title="<?php echo lang('dialtit');?>
"></div>
<div class="kuponici" style="display:none" title="<?php echo lang('kupdetay');?>
"></div>
<div class="kupon_iptal" style="display:none" title="<?php echo lang('kupiptbld');?>
"><?php echo lang('msjtxt');?>
 : <textarea id="iptmsg"></textarea></div>

<div id="black" style="display:none">
	<div class="failcont">
	<div class="failcontt"></div>
	<div><input type="button" class="button1" value="Kapat" id="failkap"></div>
	</div>
	
</div>

<div class="kupond">
	<div id="ickupon">
		
	</div>
</div>

<input type="hidden" id="closewarm" value="0">

<?php if (sesionlar('gecis')){?>
<div class="usergecis" style="padding:5px"><?php ob_start();?><?php echo @username;?>
<?php $_tmp1=ob_get_clean();?><?php echo lang('gecistxt',array($_tmp1));?>
<br>
<button onclick="gerigecis();"><?php echo lang('gecisgeri');?>
</button></div>

<script>
function gerigecis() {
	failcont('Bekleyin...');
	$.post(baseurl+'home/gecisoff',function(data) {
	if(data=="1") {
		self.location.href=baseurl+'bayiler'; 
	}
	});	
}
</script>

<?php }?>



<style>
.fixo {
  left: 0;
  position: fixed;
  top: 0;
  z-index: 999;
}
</style>
<script>

$(document).ready(function(e) {
	$(window).scroll(function(){
		if ($(window).scrollTop() >= 200) {
		   $('.big_header_blue').addClass('fixo');
		}
		else {
		   $('.big_header_blue').removeClass('fixo');
		}
	});
	$("#tarih1, #tarih2").datepicker({
		dateFormat: 'dd-mm-yy', changeMonth: true, changeYear: true
	});
	if(<?php echo @direk;?>
==0){
		setInterval(function() { 
			var cao = $("#caola").val();
			if(cao==1) {
				kuponguncelle();
			}
		},7000);
	}
});
</script>
<!--Start of Zendesk Chat Script-->
<script type="text/javascript">
window.$zopim||(function(d,s){var z=$zopim=function(c){z._.push(c)},$=z.s=
d.createElement(s),e=d.getElementsByTagName(s)[0];z.set=function(o){z.set.
_.push(o)};z._=[];z.set._=[];$.async=!0;$.setAttribute("charset","utf-8");
$.src="https://v2.zopim.com/?1tFtvQG7toz7Z6ErbP6rzbPH589w0q78";z.t=+new Date;$.
type="text/javascript";e.parentNode.insertBefore($,e)})(document,"script");
</script>
<!--End of Zendesk Chat Script-->



</footer>
</body>
</html><?php }} ?>