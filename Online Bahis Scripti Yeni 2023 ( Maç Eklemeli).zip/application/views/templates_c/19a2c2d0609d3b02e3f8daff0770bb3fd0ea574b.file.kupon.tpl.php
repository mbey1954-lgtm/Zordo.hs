<?php /* Smarty version Smarty-3.1.8, created on 2018-09-03 20:38:26
         compiled from "application/views/templates/mobil/kupon.tpl" */ ?>
<?php /*%%SmartyHeaderCode:5065253305b8d7192ed6733-73930626%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '19a2c2d0609d3b02e3f8daff0770bb3fd0ea574b' => 
    array (
      0 => 'application/views/templates/mobil/kupon.tpl',
      1 => 1495373066,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '5065253305b8d7192ed6733-73930626',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_5b8d7193079572_12220852',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5b8d7193079572_12220852')) {function content_5b8d7193079572_12220852($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ("mobil/header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>


<script>
kuponguncelle(1);
kuponsay();

function numaralar() {
	$("#macd").fadeIn();
	var yatantutar = $("#yatantutar").text();
	var toporan1 = $("#toplamoran").text();
	$.post(baseurl+'kupon/numaralar/',{oran:toporan1,yatantutar:yatantutar},function(data) { 
		$("#macd").html(data);
	});
}
function formatNumber(number)
{
	var number = number.toFixed(2) + '';
	var x = number.split('.');
	var x1 = x[0];
	var x2 = x.length > 1 ? '.' + x[1] : '';
	var rgx = /(\d+)(\d{3})/;
	while (rgx.test(x1)) {
		x1 = x1.replace(rgx, '$1' + ',' + '$2');
	}
	return x1 + x2;
}
function nums(yatantutar) {
	var toplamoran = $("#toplamoran").text();
	var varos = yatantutar*toplamoran;
	if(yatantutar==0) {
		$("#yatantutar").val('');
	}
	var yansit = $("#yatantutar").val()*$("#toplamoran").text();
	if(varos> <?php echo @maxodeme;?>
) {
	hata('Maksimum ödeme tutarı <?php echo nf(@maxodeme,2);?>
 <?php echo @para;?>
 \'dir');
		$("#yatantutar").val('0');
		$("#muhtemelkazanc,#bonusuhak").html('0.00');
	} else {
		/*$("#yatantutar").val(yatantutar);*/
		$("#macd").fadeOut('fast');
		minimalhesapla();
	}
	
	/*$("#muhtemelkazanc").html(formatNumber(yansit));*/
}
function minimalhesapla() {
	var bonusu = $("#bonusu").val();
	var yatan = $("#yatantutar").val();
	var toplamoran = $("#toplamoran").text();
	var kazancilko = yatan*toplamoran;
	
	var kazanc = kazancilko;
	if(toplamoran> <?php echo @maxoran;?>
) {
		hata('Maksimum oran sınırına bağlı olarak oran ayarlandı');
		$("#toplamoran").html('<?php echo nfss(@maxoran,2);?>
');
	}else if(yatan><?php echo @maxodeme;?>
) {
		hata('Maksimum ödeme tutarı <?php echo nf(@maxodeme,2);?>
 <?php echo @para;?>
\'dir');
		$("#muhtemelkazanc,#bonusuhak").html('0.00');
	}else{	
		$("#muhtemelkazanc").html(formatNumber(kazanc));
		$("#bonusuhak").html( formatNumber(((parseFloat(kazanc) / 100) * bonusu) + kazanc));
	}
	$("#yatantutar").val(yatan);
}
$(document).ready(function(e) {
	if(<?php echo @direk;?>
==0){
		setInterval(function() { 
		var cao = $("#caola").val();
		if(cao==1) {
			kuponguncelle();
		}
	},7000);
	}
});
</script>

<div id="macd" style="display:none"></div>
<div style="left: 0px; right: 0px; z-index: 100; position: fixed; top: 0px;" class="appheader">
<?php echo mobilhead();?>

<div><div class="header"><div onclick="goBack();" class="icon back noselect "></div><div class="text title noselect">Kuponlar</div><div onclick="go('index')" style="padding-left:20px" class="icon logo noselect"></div></div></div></div>

<div class="page slide top in" id="page1"><div class="scroll_container" style=""><div class="scroll_wrapper" style="padding-top: 85px; padding-bottom: 44px;"><div class="appcontent"><div>  </div>

<div id="ticket_bodys">
<div class="edtitle bartitle" style="background: #<?php if (@tema==1){?>126f8e<?php }else{ ?>b4201b<?php }?>;"><div class="text">Bahis Kuponu (<span id="topsa">0</span>)</div><div class="value"><button style="width:100px" onClick="kupontemizle();" id="tumsil"><div class="text">Tümünü Sil</div></button></div></div>

<div id="kuponalan" style="border: 1px solid #<?php if (@tema==1){?>126f8e<?php }else{ ?>b4201b<?php }?>;width: 95%;margin-left: 2.5%;background: #<?php if (@tema==1){?>fff<?php }else{ ?>000<?php }?>;">

</div>
<input type="hidden" id="countgeri" value="">
<div class="clear " style="height:20px"></div>
<div class="kuponalt" style="<?php if (@tema==1){?>background: #126f8e;<?php }?>display:none;border: 1px solid #000;width: 95%;margin-left: 2.5%;float: left;">

<div class="barmiddle preload2"><div class="text">Toplam Oran</div>
<div class="value" id="toplamoran"></div>
</div>

<div class="barmiddle preload1">
<div class="text">Bahis</div>
<div class="" style="float: right"><input type="text" id="yatantutar" onkeyup="nums(this.value);" onclick="this.select();" class="inputbet" style="width:60px;"></div>
</div>

<div style="display:table;" class="barbottom">
<div class="text">Olası Kazanç</div><div class="value"><span id="muhtemelkazanc">0</span> <?php echo @para;?>
</div>
</div>

<div style="display:table;" class="barbottom" id="bonsgiz">
<div class="text">Bonus</div><div class="value"><span id="bonusuhak">0</span> <?php echo @para;?>
</div>
</div>

<div class="bigbutton_wrapper blue" onclick="kuponok();" style="margin-right:2.5%;background: #<?php if (@tema==1){?>D38747<?php }else{ ?>8C1C17<?php }?>;text-align: center;color: #fff;">
<div style="padding: 10px" >Bahsini yap</div>
</div>

<input type="hidden" id="songeri" value="3">


		
</div>
</div><div class="clear "></div>
<div style="height:20px;">&nbsp;</div></div></div></div></div>

<?php echo $_smarty_tpl->getSubTemplate ("mobil/footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>
<?php }} ?>