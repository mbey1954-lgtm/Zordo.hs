<?php /* Smarty version Smarty-3.1.8, created on 2018-08-20 12:14:47
         compiled from "application/views/templates/mobil/canli.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1162554685b7a8687ac30f8-01721401%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '5b3a79174d4a7a1caaba0383bcdde961c30ba5db' => 
    array (
      0 => 'application/views/templates/mobil/canli.tpl',
      1 => 1495439100,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1162554685b7a8687ac30f8-01721401',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_5b7a8687b213b4_87223735',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5b7a8687b213b4_87223735')) {function content_5b7a8687b213b4_87223735($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ("mobil/header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>


<script>
var tip=0;

function changebet(bettip){
	tip=bettip;
	$('.secme').removeClass( "betfilter-selected" );
	$('.sel'+bettip).addClass( "betfilter-selected" );
	loadlive(tip);
}
function loadlive(tip){
	$.post(baseurl+'canlibahis/livelist/',{tip:tip},function(data) {		
		if(data.ust=='yok'){
			$(".canlilist").html('<div class="bonusSloganBox"> <span>Canlı Bahis Bulunamadı</span><br><span></span> </div><button onclick="go(\'\')" class="bigbutton"><div class="text">Geri</div></button>');
			clearInterval(dongu);
		}else{	
			$(".canlilist").html(data.ust);		
		}
	},'json');	
}
function canliekle(varo) {

	$.post(baseurl+'kupon/liveadd/',{warrior:varo},function(data) { 
		if(data=="2") { msg('faildurum','Bu maç şu an askıda. Bahis yapılamaz.'); } else
		if(data=="6") { msg('faildurum','Oran süresi doldu.'); } else
		if(data=="3") { failcont('Veri Kaynağında sorun oluştu. Lütfen kuponunuzu kontrol ediniz.');} else
		if(data=="5") { failcont('Aynı Kupon İçerisine İki Farklı Canlı Bahisten Oyun Yapamazsınız.');} else
		if(data=="4") { failcont('Sistem Şuanda Bahislere Kapalıdır.');} else
		if(data=="1") { kuponsay(); }
	});
}
loadlive(tip);
kuponsay();

var dongu=setInterval(function(){ 
	loadlive(tip);			
}, 7000);
</script>
<style>
.ratio-box.active {
  background: #b4201b none repeat scroll 0 0;
  border-color: #000;
  color: #ffffff;
}
.betfilterbar-sport, .betfilterbar {
  border-top: 1px solid #000;
  float: left;
  width: 100%;
}
.betfilterbar-sport .betfilter-selected, .betfilterbar .betfilter-selected {
  background: #b4201b none repeat scroll 0 0;
  color: black;
}
.betfilterbar-sport li, .betfilterbar li {
  background: #3d3d3d none repeat scroll 0 0;
  border-right: 1px solid #000;
  display: table;
  float: left;
  height: 44px;
  text-align: center;
  vertical-align: middle;
  width: 25%;
}
.betfilterbar li a {
  color: white;
  display: table-cell;
  font: 12px "Roboto Condensed",helvetica,sans-serif;
  text-align: center;
  vertical-align: middle;
}
.sports-caption {
  -moz-border-bottom-colors: none;
  -moz-border-left-colors: none;
  -moz-border-right-colors: none;
  -moz-border-top-colors: none;
  background: #1e1e1e none repeat scroll 0 0;
  border-color: currentcolor currentcolor #000000;
  border-image: none;
  border-style: none none solid;
  border-width: 0 0 1px;
  display: table;
  float: left;
  height: 24px;
  width: 100%;
}.sports-caption .liveicon-left {
  float: left;
  height: 20px;
  margin: 2px 0 0 5px;
  width: 20px;
}
.liveicon-left {
  float: left;
  height: 20px;
  margin: -2px 0 0 16px;
  width: 20px;
}
.licon-1 {
  background: transparent url("/img/ico-23_w.png") no-repeat scroll left center / 20px 20px;
}
.sports-caption .navtitle1 {
  color: #b4201b;
  float: left;
}.navtitle1 {
  color: #3e3e3e;
  float: left;
}
.sports-caption .navtitle1 span {
  float: left;
  font: bold 16px "Roboto Condensed",helvetica,sans-serif;
  margin: 2px 0 0 12px;
}
.navtitle1 span {
  float: left;
  font: bold 16px "Roboto Condensed",helvetica,sans-serif;
  margin: -1px 0 0 12px;
  max-width: 300px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.live-match {
  border-bottom: 1px solid #000000;
  float: left;
  width: 100%;
}
.sports-tip {
  border: 0 none;
  display: table;
  float: left;
  height: 24px;
  width: 100%;
}
.sports-tip a {
  align-items: center;
  background: #3d3d3d none repeat scroll 0 0;
  color: #fff;
  display: flex;
  flex-direction: row;
  width: 100%;
}
a {
  text-decoration: none;
}
.datetime-caption {
  float: left;
  padding: 5px;
  text-align: center;
}
.sports-tip .team-caption {
  float: left;
  margin: 3px 0 0 11px;
  text-align: left;
}
.rg2 {
  float: right;
  margin-left: auto;
  width: auto;
}
.table-row-3 {
  background: #3d3d3d none repeat scroll 0 0;
  float: left;
  width: 100%;
}.row_3-caption {
  align-items: center;
  display: flex;
  flex-direction: row;
  float: left;
  height: 33px;
  margin-bottom: 6px;
  margin-left: auto;
  margin-right: auto;
  text-align: center;
  width: 49.7%;
}
.row_4-caption span, .row_3-caption span, .row_2-caption span {
  color: #fff;
  float: left;
  font: bold 11px/10px "Roboto Condensed",helvetica,sans-serif;
  margin-left: 5px;
  text-align: left;
  width: 100%;
}
.table-row-3 ul {
  float: right;
  padding: 0 2px;
  width: 50.3%;
}
.table-row-3 ul li {
  float: left;
  margin-bottom: 5px;
  padding: 0 2px;
  width: 50%;
}
.ratio-box {
  background: #3d3d3d none repeat scroll 0 0;
  border: 1px solid #000;
  color: #fff;
  float: left;
  height: 34px;
  width: 100%;
}
.row-span {
  float: left;
  font: bold 12px "Roboto Condensed",helvetica,sans-serif;
  padding: 9px 3px;
  position: relative;
}
.row-strong {
  float: right;
  font: 12px "Roboto Condensed",helvetica,sans-serif;
  padding: 9px 3px;
  position: relative;
}
.table-row-2 {
  background: #3d3d3d none repeat scroll 0 0;
  float: left;
  width: 100%;
}.row_2-caption {
  align-items: center;
  display: flex;
  flex-direction: row;
  float: left;
  height: 33px;
  margin-left: auto;
  margin-right: auto;
  text-align: center;
  width: 25%;
}.table-row-2 ul {
  float: right;
  padding: 0 2px;
  width: 74.9%;
}.table-row-3 ul {
  float: right;
  padding: 0 2px;
  width: 50.3%;
}.table-row-2 ul li {
  float: left;
  margin-bottom: 5px;
  padding: 0 2px;
  width: 33.33%;
}.table-row-3 ul li {
  float: left;
  margin-bottom: 5px;
  padding: 0 2px;
  width: 50%;
}
</style>



<div style="left: 0px; right: 0px; z-index: 100; position: fixed; top: 0px;" class="appheader">
<?php echo mobilhead();?>

<div>  <div class="header"><div class="icon back noselect " onclick="goBack();"></div><div class="text title noselect">Canlı Bahis</div><div onclick="go('index')" style="padding-left:20px" class="icon logo noselect"></div></div></div></div>

<div class="page slide top in" id="page1" >
<div class="scroll_container">
<div class="scroll_wrapper" style="padding-top: 85px; padding-bottom: 44px;">
<div class="appcontent">
<div>  </div>

<ul class="betfilterbar">
	<li onclick="changebet(1)" class="secme sel1 betfilter-selected"><a >Tahmin</a></li>
	<li onclick="changebet(2)" class="secme sel2"><a>Üst/Alt</a></li>
	<li onclick="changebet(24)" class="secme sel24"><a >Sonraki gol</a></li>
	<li onclick="changebet(28)" class="secme sel28"><a>Kalan süre</a></li>
</ul>

			
<div class="canlilist"></div>
<div class="clear"></div>

</div></div></div></div>

<?php echo $_smarty_tpl->getSubTemplate ("mobil/footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>
<?php }} ?>