<?php /* Smarty version Smarty-3.1.8, created on 2022-10-21 01:26:40
         compiled from "application/views/templates/header.tpl" */ ?>
<?php /*%%SmartyHeaderCode:16951117195b6d5cb35e6e03-94916993%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'd304e7d7913bc61a5ba57117e97d53a86f77f79d' => 
    array (
      0 => 'application/views/templates/header.tpl',
      1 => 1666304660,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '16951117195b6d5cb35e6e03-94916993',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_5b6d5cb36b5ab6_20729081',
  'variables' => 
  array (
    'dvarmi' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5b6d5cb36b5ab6_20729081')) {function content_5b6d5cb36b5ab6_20729081($_smarty_tpl) {?><!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>SamsalaBet</title>
<link rel="stylesheet" href="<?php echo base_url();?>
css/reset.css">
<script type="text/javascript" src="<?php echo base_url();?>
js/jquery.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>
js/main.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>
js/fancy.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>
js/jquery-ui-1.8.21.custom.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>
js/mousehold.js"></script>

<link rel="stylesheet" href="<?php echo base_url();?>
css/base.css">
<link rel="stylesheet" href="<?php echo base_url();?>
css/ie.css">
<link rel="stylesheet" href="<?php echo base_url();?>
css/font-awesome.css">
<link rel="stylesheet" href="<?php echo base_url();?>
css/jquery-ui.css">
<link rel="stylesheet" href="<?php echo base_url();?>
css/icomoon.css">
<link rel="stylesheet" href="<?php echo base_url();?>
css/fancy.css">
<?php if (@tema=='1'){?>
<link rel="stylesheet" href="<?php echo base_url();?>
css/tema.css">
<?php }?>

<link rel="stylesheet" href="<?php echo base_url();?>
csslogin/login.css">


<script>
	var baseurl = "<?php echo base_url();?>
";
	
	$(function() {				
		$(".ui-widget-overlay").live( "click", function() {
			$(".ui-icon.ui-icon-closethick").trigger("click");
		});
	});
	<?php if (@direk==0){?>

	kuponTemizledirek();

	var myx, myy;
	var dakika1="-";
	var dakika2="-";
	var dakika3="-";
	$(document).mousemove(function(e){
		myx = e.pageX;
		myy = e.pageY;
	});
	window.setInterval(function() {
		dakika3=dakika2;
		dakika2=dakika1;
		dakika1=myx+'-'+myy;
		
		if(dakika3!="-" && dakika2!="-" && dakika2!="-" && dakika3==dakika1){
			location.href="/login/logout";
		}
	}, 500000);
	
	<?php }?>
	
	function dil_cevir(lang){
		$.post(baseurl+"home/lang/", { dil: lang}).done(function(e) {		
			window.location.reload();
		});
	}
</script>

<?php if (detect_mobile()){?>


<style>
header{
	width:1100px;
}
footer{
	width:1100px;
}
.wp{
	width:1080px !important;
}
.kupbura{
	width:1010px !important;
}

.match-list-default li:nth-child(5){
	display:none !important;
}
.general-subtitle-gray li:nth-child(5){
	display:none !important;
}
.table-title-211 li:nth-child(4), .table-ratio-211 li:nth-child(4){
	display:block !important;
}
.table-ratio-211 li:nth-child(5),.table-title-211 li:nth-child(5){
	display:none !important;
}
</style>

<?php }?>
</head>

<body>
<?php echo sonislemtime();?>

<div class="page-overlay" id="preloader" style="display:none">
<div class="ng-scope"><div class="coupon-popup ng-scope"><div class="status">&nbsp;</div>
</div></div>
</div>

<header class="big_header_blue">
	<div class="wp" style="<?php if (@direk=='0'){?>position: relative<?php }?>">
    <div class="logo"><a href="<?php echo base_url();?>
"><img src="<?php echo base_url();?>
img/<?php if (@tema==1){?>logo.svg<?php }else{ ?>logo.svg<?php }?>" alt=""></a></div>
    <?php if (@direk=='0'){?>
		<?php $_smarty_tpl->tpl_vars['dvarmi'] = new Smarty_variable(duyurular(), null, 0);?>
		<?php if ($_smarty_tpl->tpl_vars['dvarmi']->value){?>
			<marquee onmouseover="this.setAttribute('scrollamount', 0, 0);" onmouseout="this.setAttribute('scrollamount', 6, 0);" scrollamount="6" style="font-size: 14px; float: left; position: absolute; top: 0px; left: 200px; color: #ccc; width: 65%;">
			<ul style="list-style:none;margin-top: 6px;float: left;"><?php echo $_smarty_tpl->tpl_vars['dvarmi']->value;?>
</ul></marquee>
		<?php }?>
	<?php }?>
	<nav>
      <ul>
        <?php if (@futbol=='1'){?>
		<li><a href="<?php echo base_url();?>
home" class="<?php if ((curpagename(1)=='home'||curpagename(1)=='')&&curpagename(2)==''){?>active<?php }?>"><?php echo lang('home');?>
</a></li>
		<?php }?>
		<?php if (@canlibahis=='1'&&@canliyasak=='0'){?>
        <li><a href="<?php echo base_url();?>
canlibahis" class="<?php if (curpagename(1)=='canlibahis'){?>active<?php }?>"><?php echo lang('canli');?>
</a></li>
		<?php }?>
		
        <li><a href="<?php echo base_url();?>
LiveGames/poker" class="<?php if (curpagename(1)=='poker'){?>active<?php }?>"><?php echo lang('poker');?>
</a></li>
		
        <li><a href="<?php echo base_url();?>
LiveGames/casino" class="<?php if (curpagename(1)=='casino'){?>active<?php }?>"><?php echo lang('slot1');?>
</a></li>
		
        <li><a href="<?php echo base_url();?>
LiveGames/rulet" class="<?php if (curpagename(1)=='rulet'){?>active<?php }?>"><?php echo lang('rulet');?>
</a></li>
		
        <li><a href="<?php echo base_url();?>
LiveGames/tombala" class="<?php if (curpagename(1)=='tombala'){?>active<?php }?>"><?php echo lang('tombala');?>
</a></li>
		
		
		<li><a class="footinfo fancybox.iframe" href="<?php echo base_url();?>
canlibahis/macsonuclari"><?php echo lang('snclar');?>
</a></li>
      </ul>
    </nav>
    <div class="user-area">
      <div class="lang">
        <div class="lng lng_blue">
        
          <div class="flag-icon flag-icon-<?php echo @dil;?>
"></div>
          <p><?php if (@dil=='tr'){?>Türkçe<?php }elseif(@dil=='en'){?>English<?php }elseif(@dil=='de'){?>Deutsch<?php }elseif(@dil=='fr'){?>Francais<?php }?></p>
          <div class="lng_arrow"><i class="fa fa-caret-down"></i></div>
		
        </div>
        <ul>
          <li class="lang_li_blue" onclick="dil_cevir('tr');">
            <div class="flag-icon flag-icon-tr"></div>
            <p>Türkçe</p>
          </li>
          <li class="lang_li_blue" onclick="dil_cevir('en');">
            <div class="flag-icon flag-icon-en"></div>
            <p>English</p>
          </li>
          <li class="lang_li_blue" onclick="dil_cevir('de');">
            <div class="flag-icon flag-icon-de"></div>
            <p>Deutsch</p>
          </li>
          <li class="lang_li_blue" onclick="dil_cevir('fr');">
            <div class="flag-icon flag-icon-fr"></div>
            <p>Francais</p>
          </li>
        </ul>
      </div>      
     
	<?php if (@direk==1){?>
		 <div class="user-logged" style="margin-top: -12px;">
		 <form id="form1" name="form1" method="post" action="<?php echo base_url();?>
login/giris">	  
			<div class="login" style="z-index: 5;">
				<table border="0" align="right" cellpadding="0" cellspacing="0" width="100%"> 
					<fieldset>
						<input type="text" name="username" placeholder="<?php echo lang('user');?>
" />
						<input type="password" name="password" placeholder="<?php echo lang('sifre');?>
" />
					</fieldset>
					<tr>
						<td><button type="button" class="btn" value="Şifremi Unuttum" onclick="window.location.href='<?php echo base_url();?>
info/sifremi_unuttum'"/>Şifremi Unuttum</button></td>
						<td></td>
						<td><input type="submit" value="Giriş Yap" style="width: 90px; float: right;"/></td>
					</tr>
				</table>
			</div>
		</form>
		</div>
	<?php }else{ ?>
		<div class="user-logged">
		<p class="user_logged_blue"><strong class="user_logged_strong_blue"><?php echo lang('user');?>
</strong><span><?php echo @username;?>
</span></p>
		<p class="user_logged_blue"><strong class="user_logged_strong_blue"><?php echo lang('bakiye');?>
</strong><span id="bakiyem"><?php echo nf(@bakiye);?>
</span></p>              
		   
		<ul class="user-logged-button">
		  <li><a class="user_logged_button_blue" href="<?php echo base_url();?>
kuponlar"><?php echo lang('kpnlar');?>
</a></li>
		  <li><a class="user_logged_button_blue" href="<?php echo base_url();?>
raporlar/hesaphareket"><?php echo lang('hsp');?>
</a></li>
		  <li><a class="user_logged_button_blue" href="<?php echo base_url();?>
info/banka_hesap"><?php echo lang('trns');?>
</a></li>
		  <li><a class="user_logged_button_blue" href="<?php echo base_url();?>
login/logout"><?php echo lang('cik');?>
</a></li>
		</ul>
		</div>
	<?php }?>
      
    </div>
  </div>

</header>

<div class="page">
<div class="wp" ><?php }} ?>