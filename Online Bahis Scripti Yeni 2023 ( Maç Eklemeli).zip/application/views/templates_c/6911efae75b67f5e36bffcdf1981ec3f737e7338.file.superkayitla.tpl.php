<?php /* Smarty version Smarty-3.1.8, created on 2022-10-20 16:39:35
         compiled from "application/views/templates/superkayitla.tpl" */ ?>
<?php /*%%SmartyHeaderCode:179266844063514f979d8f94-35652659%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '6911efae75b67f5e36bffcdf1981ec3f737e7338' => 
    array (
      0 => 'application/views/templates/superkayitla.tpl',
      1 => 1495298312,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '179266844063514f979d8f94-35652659',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_63514f97a0f114_06878468',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_63514f97a0f114_06878468')) {function content_63514f97a0f114_06878468($_smarty_tpl) {?><div class="account-table-blue"><span>
	<div class="icon"><i class="fa fa-user"></i></div>
	</span>
	<p>Yeni Süper Admin Kaydı</p>
</div>

<form method="post" action="<?php echo base_url();?>
bayikayit/kayit" name="kform">
<table style="margin:10px 0px 20px 10px;width:98%;color: <?php if (@tema==1){?>#000<?php }else{ ?>#fff<?php }?>;" id="table_step">
		<tr>
			<td colspan="2"><div class="formbaslik">Giriş Bilgileri</div></td>				
		</tr>
		<tr>
			<td>Kullanıcı Adı</td>				
			<td><input type="text" class="inputbet" name="user" id="userkontrol" onChange="adkontrol();"></td>				
		</tr>
		<tr>
			<td>Şifre</td>				
			<td><input type="text" class="inputbet" name="sifre" ></td>				
		</tr>
		<tr>
			<td>Firma Adı</td>				
			<td><input type="text" class="inputbet" name="firma" ></td>
		</tr>		
		<tr>
			<td colspan="2" class="trenayar"><div class="formbaslik">Yetkileri / Yapabilecekleri</div></td>				
		</tr>
		<tr  height="40">
			<td>Site Yetkisi</td>				
			<td>
			<?php echo domainver(3);?>

			</td>				
		</tr>
		<tr>
			<td>Alt Kullanıcı Limiti</td>				
			<td><input type="text" class="inputbet" name="alt_sinir" value="10" size="5" maxlength="2"> Kaç tane admin oluşturabilir?</td>				
		</tr>		
		<tr>
			<td colspan="2" class="trenayar"><input type="button" class="button" value="Kaydet" id="kaydets"></td>			
		</tr>
	</table>
</form><?php }} ?>