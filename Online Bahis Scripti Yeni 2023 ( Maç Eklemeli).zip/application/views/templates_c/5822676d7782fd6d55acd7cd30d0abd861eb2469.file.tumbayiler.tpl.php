<?php /* Smarty version Smarty-3.1.8, created on 2018-08-26 19:57:57
         compiled from "application/views/templates/tumbayiler.tpl" */ ?>
<?php /*%%SmartyHeaderCode:13386197085b82dc15900e53-57374058%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '5822676d7782fd6d55acd7cd30d0abd861eb2469' => 
    array (
      0 => 'application/views/templates/tumbayiler.tpl',
      1 => 1495298314,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '13386197085b82dc15900e53-57374058',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_5b82dc15979661_90220760',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5b82dc15979661_90220760')) {function content_5b82dc15979661_90220760($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ("header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<?php echo $_smarty_tpl->getSubTemplate ("left.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>



<script>

function bayiler(id) {
	
	loadgir("#bayiler");
	var order = $("#order").val();
	var ascdesc = $("#ascdesc").val();	
	var name = $("#name").val();	
	var durum = $("#durum").val();	
	$.post(baseurl+'bayiler/tumbayilerdata',{id:id,order:order,ascdesc:ascdesc,name:name,durum:durum},function(data) { 
		$("#bayiler").html(data); 
	});
}
function validate(evt) {
  var theEvent = evt || window.event;
  var key = theEvent.keyCode || theEvent.which;
  key = String.fromCharCode( key );
  var regex = /[0-9]|\./;
  if( !regex.test(key) ) {
    theEvent.returnValue = false;
    if(theEvent.preventDefault) theEvent.preventDefault();
  }
}
function gecis(id) {

	failcont("<?php echo lang('bekle');?>
");
	$.post(baseurl+'home/gecis',{id:id},function(data) {
	
	if(data=="1") {
		self.location.href=baseurl;
	} else
	if(data=="2") {
		failcont("<?php echo lang('gecyok');?>
");
	}
	});
}

function bakiye(tip,id) {

	if(tip=="ekle") { $("#eklecikar_"+id+"").html("(+) <?php echo lang('tekle');?>
"); } else
	if(tip=="cikar") { $("#eklecikar_"+id+"").html("(-) <?php echo lang('tcikar');?>
"); }
	$("#bakiyedurum_"+id+"").val(tip);
	$("#b_"+id+"").fadeIn('fast');
	$("#bakiye_"+id+"").focus();
}

function isle(uid) {

	var tutar = $("#bakiye_"+uid+"").val();
	if(!tutar){alert("<?php echo lang('yatkont');?>
");return false;}
	var tip = $("#bakiyedurum_"+uid+"").val();
	$.post(baseurl+'bayiler/bakiyeislem',{tip:tip,tutar:tutar,uid:uid},function(data) {	
		if(data=="1") { 
			failcont("<?php echo lang('bislendi');?>
");
			bayiler(<?php echo sesionlar('id');?>
);
			$("#b_"+uid+"").fadeOut();
		}else if(data=="0") { 
			failcont("<?php echo lang('byyok');?>
");
		}else if(data=="3") { 
			failcont("<?php echo lang('ttrgir');?>
");
		}else if(data=="2") { 
			failcont("<?php echo lang('bakiolmaz');?>
");
		}else if(data=="4") { 
			failcont("<?php echo lang('dtyetrsz');?>
");
		}
	});
}

$(function() {

	bayiler(<?php echo sesionlar('id');?>
);
	
    $('#test1').live( "click", function() {
        $( "#bakiyedurum" ).dialog({
		modal: true,
		buttons: {
			İşle: function() {
			  $( this ).dialog( "close" );
			}
		  }
		});
    });
	
    $( "#bak" ).live( "click", function() {
      $( ".bakiyedurum" ).toggle( 'scale', { percent: 0 }, 500 );
    });
});

</script>

<div class="coupons">	
	<div class="coupon-title">
		<div class="account-table-blue"><span>
			<div class="icon"><i class="fa fa-user"></i></div>
			</span>
			<p><?php echo lang('byler');?>
</p>
		</div>
		<div class="account-table-gray">		
			<form >
			<label><?php echo lang('byler');?>
 :</label>
			<input type="text" id="name" size="7" >	
			<label><?php echo lang('drm');?>
</label>
			<div class="selectbox">
			<select id="durum">
				<option value=""><?php echo lang('hpsi');?>
</option>
				<option value="1"><?php echo lang('aktf');?>
</option>
				<option value="0"><?php echo lang('psf');?>
</option>
			</select>
			</div>
			<button type="button" id="sorgu" onclick="bayiler(<?php echo sesionlar('id');?>
);"><?php echo lang('gtr');?>
</button>
			<input type="hidden" id="order" value="firma">
			<input type="hidden" id="ascdesc" value="asc">
			</form>			
		</div>
	</div>
	
	<div id="bayiler" class="coupon-content"></div>
	
</div>

<?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>
<?php }} ?>