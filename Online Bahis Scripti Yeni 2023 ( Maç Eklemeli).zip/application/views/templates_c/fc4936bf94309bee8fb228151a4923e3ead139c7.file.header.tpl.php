<?php /* Smarty version Smarty-3.1.8, created on 2018-08-11 20:11:22
         compiled from "application/views/templates/mobil/header.tpl" */ ?>
<?php /*%%SmartyHeaderCode:21336984845b6f18ba7ecf27-46700657%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'fc4936bf94309bee8fb228151a4923e3ead139c7' => 
    array (
      0 => 'application/views/templates/mobil/header.tpl',
      1 => 1495560916,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '21336984845b6f18ba7ecf27-46700657',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_5b6f18ba817de7_68028700',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5b6f18ba817de7_68028700')) {function content_5b6f18ba817de7_68028700($_smarty_tpl) {?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" manifest="/manifest.mf">
<head>

<script type="text/javascript">
	var baseurl = "<?php echo base_url();?>
mobil/";
</script>

<meta name="robots" content="noindex,nofollow" />
<title><?php echo @title;?>
 Mobile</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<meta name="apple-mobile-web-app-capable" content="yes"/>
<meta name="viewport" content="width=device-width, maximum-scale=1, initial-scale=1.0, user-scalable=no"/><meta name="mobile-web-app-capable" content="yes"/>
<meta name="apple-mobile-web-app-status-bar-style" content="black"/>
<meta name="format-detection" content="telephone=no"/>
<meta http-equiv="x-ua-compatible" content="IE=8"/>
<link type="text/css" rel="stylesheet" href='https://fonts.googleapis.com/css?family=Roboto|Roboto+Condensed:400,700&subset=latin,cyrillic'/>
<link type="text/css" rel="stylesheet" href="<?php echo base_url();?>
css/mobil/mobile.css"/>
<script type="text/javascript" src="<?php echo base_url();?>
js/jquery.js"></script>
<script src="<?php echo base_url();?>
js/jquery-ui-1.8.21.custom.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>
js/mobil/home.js"></script>
<link rel="stylesheet" href="<?php echo base_url();?>
css/jquery-ui.css">
<link rel="stylesheet" href="<?php echo base_url();?>
css/icomoon.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">	

<script>
<?php if (@direk==0){?>
var myx, myy;
var dakika1="-";
var dakika2="-";
var dakika3="-";
$(document).mousemove(function(e){
	myx = e.pageX;
	myy = e.pageY;
});
window.setInterval(function() {
	dakika3=dakika2;
	dakika2=dakika1;
	dakika1=myx+'-'+myy;
	
	if(dakika3!="-" && dakika2!="-" && dakika2!="-" && dakika3==dakika1){
		location.href="/login/logout";
	}
}, 500000);
<?php }?>
</script>
<!--Start of Zendesk Chat Script-->
<script type="text/javascript">
window.$zopim||(function(d,s){var z=$zopim=function(c){z._.push(c)},$=z.s=
d.createElement(s),e=d.getElementsByTagName(s)[0];z.set=function(o){z.set.
_.push(o)};z._=[];z.set._=[];$.async=!0;$.setAttribute("charset","utf-8");
$.src="https://v2.zopim.com/?1tFtvQG7toz7Z6ErbP6rzbPH589w0q78";z.t=+new Date;$.
type="text/javascript";e.parentNode.insertBefore($,e)})(document,"script");
</script>
<script>

$zopim(function() {
   $zopim.livechat.hideAll();
});

</script>

</head>

<body id="body" ><?php echo sonislemtime();?>
<?php }} ?>