<?php /* Smarty version Smarty-3.1.8, created on 2018-08-10 15:28:18
         compiled from "application/views/templates/tombala.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1228845655b6d84e2294cf0-04169408%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c1971ee581f9e5e907efa564b718a5da08ba14f3' => 
    array (
      0 => 'application/views/templates/tombala.tpl',
      1 => 1495553584,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1228845655b6d84e2294cf0-04169408',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_5b6d84e23da391_97589977',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5b6d84e23da391_97589977')) {function content_5b6d84e23da391_97589977($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ("header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<div class="coupons">	
	<div class="coupon-title">
		<div class="account-table-blue"><span>
			<div class="icon"><i class="fa fa-user"></i></div>
			</span>
			<p>Canlı Tombala</p>
		</div>
		
		<iframe name="my-iframe" src="http://www.chipkings.com/Tombala" scrolling="no" style="width:100%;height:1000px" frameBorder="0"></iframe>
		
</div>
</div>
<?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>
<?php }} ?>