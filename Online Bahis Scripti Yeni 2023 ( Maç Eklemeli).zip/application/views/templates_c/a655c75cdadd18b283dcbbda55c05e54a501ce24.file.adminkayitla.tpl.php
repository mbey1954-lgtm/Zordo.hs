<?php /* Smarty version Smarty-3.1.8, created on 2018-08-26 19:58:51
         compiled from "application/views/templates/adminkayitla.tpl" */ ?>
<?php /*%%SmartyHeaderCode:3018100575b82dc4b058e49-57091702%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'a655c75cdadd18b283dcbbda55c05e54a501ce24' => 
    array (
      0 => 'application/views/templates/adminkayitla.tpl',
      1 => 1495298249,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '3018100575b82dc4b058e49-57091702',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_5b82dc4b096e37_44096485',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5b82dc4b096e37_44096485')) {function content_5b82dc4b096e37_44096485($_smarty_tpl) {?><div class="account-table-blue"><span>
	<div class="icon"><i class="fa fa-user"></i></div>
	</span>
	<p><?php echo lang('adins');?>
</p>
</div>
<form method="post" action="<?php echo base_url();?>
bayikayit/kayit" name="kform">
<table style="margin:10px 0px 20px 10px;width:98%;color: <?php if (@tema==1){?>#000<?php }else{ ?>#fff<?php }?>;" id="table_step">
		<tr>
			<td colspan="2"><div class="formbaslik"><?php echo lang('girbilgi');?>
</div></td>				
		</tr>
		<tr>
			<td><?php echo lang('user');?>
</td>				
			<td><input type="text" class="inputbet" name="user" id="userkontrol" onChange="adkontrol();"></td>				
		</tr>
		<tr>
			<td><?php echo lang('sifre');?>
</td>				
			<td><input type="text" class="inputbet" name="sifre" ></td>				
		</tr>
		<tr>
			<td><?php echo lang('firma');?>
</td>				
			<td><input type="text" class="inputbet" name="firma" ></td>
		</tr>
		<tr>
			<td><?php echo lang('tel');?>
</td>				
			<td><input type="text" class="inputbet" name="tel" ></td>				
		</tr>
		<tr>
			<td colspan="2" class="trenayar"><div class="formbaslik"><?php echo lang('yetbaslik');?>
</div></td>				
		</tr>
		<tr height="40">
			<td><?php echo lang('iptal_yetki');?>
</td>				
			<td>
				<select name="iptal_yetki" class="chosen-select-no-single" style="width:120px;">
					<option value="1" ><?php echo lang('yetkili');?>
</option>
					<option value="0" ><?php echo lang('yetkisiz');?>
</option>		
				</select>
			</td>				
		</tr>
		<tr height="40">
			<td><?php echo lang('kupon_degistirme');?>
</td>
			<td>
				<select name="kupon_degistirme" class="chosen-select-no-single" style="width:120px;">
					<option value="1" ><?php echo lang('yetkili');?>
</option>
					<option value="0" ><?php echo lang('yetkisiz');?>
</option>		
				</select>
			</td>				
		</tr>
		<tr height="40">
			<td><?php echo lang('oranduzenleme');?>
</td>				
			<td>
				<select name="oranduzenleme" class="chosen-select-no-single" style="width:120px;">
					<option value="1" ><?php echo lang('yapar');?>
</option>
					<option value="0" ><?php echo lang('yapamaz');?>
</option>		
				</select>
			</td>				
		</tr>
		<tr  height="40">
			<td><?php echo lang('silme_yetki');?>
</td>				
			<td>
				<select name="silme_yetki" class="chosen-select-no-single" style="width:120px;">
					<option value="1" ><?php echo lang('yapar');?>
</option>
					<option value="0" ><?php echo lang('yapamaz');?>
</option>		
				</select>
			</td>				
		</tr>
		<tr  height="40">
			<td>Tema Seçimi</td>				
			<td>
				<select name="tema" class="chosen-select-no-single" style="width:120px;">
					<option value="" >Tema1 (Koyu)</option>
					<option value="1" >Tema2 (Açık)</option>		
				</select>
			</td>				
		</tr>
		<tr height="40">
			<td><?php echo lang('altsinir1');?>
</td>				
			<td><input type="text" class="inputbet" name="alt_sinir" value="10" size="5" maxlength="2"> <?php echo lang('altsinir');?>
</td>				
		</tr>
		<tr  height="40">
			<td><?php echo lang('siteytk');?>
</td>				
			<td>
			<?php echo domainver(3);?>

			</td>
		</tr>
		<tr>
			<td colspan="2" class="trenayar"><input type="button" class="button" value="<?php echo lang('kyt');?>
" id="kaydets"></td>				
		</tr>
	</table>
</form><?php }} ?>