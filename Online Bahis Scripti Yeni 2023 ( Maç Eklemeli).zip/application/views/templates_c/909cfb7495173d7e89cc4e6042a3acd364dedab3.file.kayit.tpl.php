<?php /* Smarty version Smarty-3.1.8, created on 2018-09-23 05:44:47
         compiled from "application/views/templates/mobil/kayit.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1098876305ba6fe1fbab445-09458659%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '909cfb7495173d7e89cc4e6042a3acd364dedab3' => 
    array (
      0 => 'application/views/templates/mobil/kayit.tpl',
      1 => 1495438788,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1098876305ba6fe1fbab445-09458659',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_5ba6fe1fbfaf69_67961729',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5ba6fe1fbfaf69_67961729')) {function content_5ba6fe1fbfaf69_67961729($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ("mobil/header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>


<script>
function emailtest(email) {
    var re = /^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i;
    return re.test(email);
}
$(document).ready(function(e) {
	$("input[name=user]").change(function(e) {
		var val = $(this).val();
        $.post(baseurl+'kayit/kontrol/?user=1',{useri:val},function(data) { 
			if(data>0) { 
				hata('Seçtiğiniz kullanıcı adı müsait değildir. Lütfen başka bir kullanıcı adı seçiniz.');
				$("input[name=user]").val('');
			} else { 
				$("#usval").val('1');
			} 
		});
    });
});

function kayit(){
	var f = self.document.regform;
	if(f.ad.value.length<2) { f.ad.select(); } else
	if(emailtest(f.email.value)==false) { f.email.select(); } else
	if(f.user.value.length<2) { f.user.select(); } else
	if(f.sifre.value.length<4) { f.sifre.select(); } else
	if(f.sifre1.value.length<4) { f.sifre1.select(); } else
	if(f.sifre1.value!=f.sifre.value) { 
		hata('Yazdığınız 2 parola farklıdır. Lütfen iki alanada aynı parolayı giriniz.'); 
	}else if($("#usval").val()==0) { 
		f.username.value='';
		hata('Lütfen geçerli bir kullanıcı adı seçiniz');
	}else if(!$("input[name=tc]").val()) { 
		hata('Lütfen T.C. Numaranız Yazınız.'); f.tc.select(); 
	} else if(!$("input[name=cep]").val()) { 
		hata('Lütfen Telefonunuzu Yazınız.'); f.cep.select(); 
	} else{
		$.ajax({type:'POST',url:baseurl+'kayit/gonder',data:$("form#regform").serialize(),
		success:function(snc){
			if(snc==1) { 
				hata('Üyelik Kaydınız yapıldı. En kısa zamanda sizinle iletişime geçilecektir.');
				$("form#regform").find('input, select').val('').removeAttr('selected');
			}else { 
				hata("HATA Oluştu. Lütfen yeniden deneyiniz."); 
			}			
		}	
		});
	}
	return false;
}  
</script>
<style>
body{width:100%}
#siff  a {
    border-top: 1px solid #b2b2b2;
    color: black;
    display: block;
    margin-bottom: -20px;
    margin-left: -7px;
    padding-bottom: 5px;
    padding-left: 7px;
    padding-top: 10px;
}.main {
  float: left;
  height: auto;
  margin-bottom: 20px;
  margin-top: 70px;
  width: 100%;
}.main_banner img {
  width: 100%;
}.small_table {
  background: #3d3d3d none repeat scroll 0 0;
  float: left;
  margin-left: 2.5%;
  margin-right: 2.5%;
  width: 95%;
  padding-bottom: 70px;
  margin-top: 10px;
}
button, input, fieldset {
  border: 0 none;
}
label {
  color: #b4201b;
  float: left;
  font-weight: bold;
  padding: 0 8px;
  text-shadow: 2px 1px 0 rgba(0, 0, 0, 0.4);
  width: 100%;
  font-size: 16px;
}.caption {
  align-items: center;
  background: #2e2e2e none repeat scroll 0 0;
  border: 1px solid #000000;
  display: flex;
  flex-direction: row;
  float: left;
  font-weight: bold;
  padding: 14px 10px;
  width: 100%;
}.main_category .mright {
  float: right;
  width: 50%;
}.icon-left-x {
  float: left;
  height: 20px;
  width: 20px;
}.icon-left-x .fa {
  background: rgba(0, 0, 0, 0) linear-gradient(to top, #8c1c17 0%, #b4201b 100%) repeat scroll 0 0;
  border-radius: 3px;
  color: white;
  filter: drop-shadow(1px 1px 1px black);
  float: left;
  font-size: 15px;
  height: 20px;
  line-height: 20px;
  margin: 0;
  width: 20px;
}.fa {
  float: right;
  margin-left: 10px;
  text-align: center;
  width: 15px;
}.main_category li, .panel_language li, .panel_settings li, .coupon_detail li, .panel li, .login li, .change_password li, .credit_transfer li {
  align-items: center;
  background: #3d3d3d none repeat scroll 0 0;
  border-bottom: 1px solid #000;
  border-left: 1px solid #000000;
  border-right: 1px solid #000000;
  color: white;
  display: flex;
  flex-direction: row;
  float: left;
  width: 100%;
}.main_category .mleft {
  border-right: 1px solid #000;
  float: left;
  width: 50%;
}.main_category li a, .sport_category li a, .panel_language li a, .panel_settings li a, .panel li a {
  align-items: center;
  color: white;
  display: flex;
  flex-direction: row;
  float: left;
  padding: 14px 10px;
  width: 100%;
}* {
  box-sizing: border-box;
  list-style-type: none;
  margin: 0;
  padding: 0;
}.right {
  align-items: center;
  display: flex;
  flex-direction: row;
  float: right;
  justify-content: center;
  margin-left: auto;
  text-align: center;
  width: auto;
}.main_banner {
  float: left;
  margin-top: 20px;
  margin-bottom: 20px;
  margin-left: 2.5%;
  margin-right: 2.5%;
  position: relative;
  width: 95%;
}.main_banner .text {
  color: #fff;
  float: left;
  height: auto;
  margin: 2% 0 0 5%;
  position: absolute;
  width: auto;
}.main_banner .text h2 {
  font-size: 4vw;
}.main_banner .text h1 {
  font-size: 2.3vw;
  margin-top: 8%;
  position: relative;
}.clear {
  float: left;
  height: 50px;
  margin-top: 7px;
  text-align: center;
  width: 100%;
}.register-container, .lost-password-container {
  background: #3b3b3b none repeat scroll 0 0;
  border-left: 1px solid #000000;
  border-right: 1px solid #000000;
  float: left;
  width: 100%;
}.register-container .inner {
  float: left;
  width: 100%;
}.register-container fieldset.fieldset2 {
  float: left;
  padding: 10px;
  width: 100%;
}.register-container fieldset {
  float: left;
  padding: 10px;
  width: 50%;
}.sex {
  background: rgba(0, 0, 0, 0) linear-gradient(to top, #575757 0%, #7d7d7d 100%) repeat scroll 0 0;
  display: inline-block;
  height: 23px;
  line-height: 23px;
  margin-right: -5px;
  position: relative;
  width: 105px;
}.sex input[type="radio"] {
  height: 0;
  opacity: 0;
  width: 0;
}.register-container input {
  float: left;
  font: 80% "Roboto",sans-serif;
  width: 100%;
}.sex label {
  border: 1px solid #000;
  color: white;
  cursor: pointer;
  font-size: 12px;
  height: 100%;
  left: 0;
  position: absolute;
  text-align: center;
  top: 0;
  transition: transform 0.4s ease 0s, color 0.4s ease 0s, background-color 0.4s ease 0s;
  width: 100%;
}.register-container label {
  float: left;
  margin-bottom: 5px;
  width: 100%;
}.sex {
  background: rgba(0, 0, 0, 0) linear-gradient(to top, #575757 0%, #7d7d7d 100%) repeat scroll 0 0;
  display: inline-block;
  height: 23px;
  line-height: 23px;
  margin-right: -5px;
  position: relative;
  width: 105px;
}.register-container .row {
  float: left;
  width: 100%;
}.register-container input[type="text"], .register-container input[type="password"] {
  background-color: #4d4d4d;
  border: 1px solid #000000;
  color: white;
  float: left;
  height: 30px;
  padding-left: 5px;
  width: 85%;
}.register-container input {
  float: left;
  font: 80% "Roboto",sans-serif;
  width: 100%;
}.custom-select1 {
  cursor: pointer;
  float: left;
  height: 31px;
  width: 49px;
}.custom-select1 select {
  color: #000;
  font: 11px Arial,sans-serif;
  height: 31px;
  padding: 0 0 0 5px;
  width: 49px;
}.custom-select2 {
  cursor: pointer;
  float: left;
  height: 31px;
  margin: 0 3px;
  width: 79px;
}.custom-select2 select {
  color: #000;
  font: 11px Arial,sans-serif;
  height: 31px;
  padding: 0 0 0 5px;
  width: 79px;
}.custom-select3 {
  cursor: pointer;
  float: left;
  height: 31px;
  width: 76px;
}.custom-select3 select {
  color: #000;
  font: 11px Arial,sans-serif;
  height: 31px;
  padding: 0 0 0 5px;
  width: 76px;
}.custom-select4 {
  cursor: pointer;
  float: left;
  height: 31px;
  text-align: left;
  width: 180px;
}.custom-select4 select {
  color: #000;
  font: 11px Arial,sans-serif;
  height: 31px;
  padding: 0 0 0 5px;
  width: 170px;
}.register-container .title {
  color: #fff;
  float: left;
  height: auto;
  padding: 7px;
  text-align: left;
  width: 100%;
}.register-container .title p {
  font-size: 11px;
  line-height: 15px;
}.footinfo {
  color: #16977b;
}.promobutton {
  background: #b4201b none repeat scroll 0 0;
  border-bottom: 1px solid #000000;
  border-top: 1px solid #000000;
  color: #000000;
  float: left;
  font: bold 23px Arial,sans-serif;
  height: 50px;
  text-align: center;
  width: 100%;
}.sex input[type="radio"]:checked ~ label {
  background: rgba(0, 0, 0, 0) linear-gradient(to bottom, #353535 0%, #565656 100%) repeat scroll 0 0;
}
</style>

<input type="hidden" id="usval" value="0">
<input type="hidden" id="usemailval" value="0">
<div style="left: 0px; right: 0px; z-index: 100; position: fixed; top: 0px;" class="appheader">
<?php echo mobilhead();?>

</div>

<div class="page slide top in" id="page1"><div class="scroll_container" style=""><div class="scroll_wrapper" style="padding-top: 85px; padding-bottom: 44px;"><div class="appcontent"><div>  </div>

<div class="small_table">
            <div class="caption">
                <i class="fa fa-user fa-lg"></i>
                <label>Üyelik - Yeni Hesap Oluştur</label>
            </div>
            <div class="register-container">
                <form name="regform" id="regform" onsubmit="return kayit();" method="post">
                <div class="row">
                    <div class="inner">
                        <fieldset class="fieldset2">
                            <div class="switch">
                                <div class="sex">
                                    <input id="q1" name="cins" value="Bay" type="radio">
                                    <label for="q1">Bay</label>
                                </div>
                                <div class="sex">
                                    <input id="q2" name="cins" value="Bayan" type="radio">
                                    <label for="q2">Bayan</label>
                                </div>
                            </div>
                        </fieldset>
                        <fieldset>
                            <input placeholder="Ad" name="ad" maxlength="15" type="text" required="required">
                        </fieldset>
                        <fieldset>
                            <input placeholder="Soyad" name="ad1" maxlength="20" type="text" required="required">
                            
                        </fieldset>
                        <fieldset class="fieldset2">
                            <div class="custom-select1">
                               <select class="form-control" name="d1"><option value="0" selected="selected">Gün</option><option value="01">01</option><option value="02">02</option><option value="03">03</option><option value="04">04</option><option value="05">05</option><option value="06">06</option><option value="07">07</option><option value="08">08</option><option value="09">09</option><option value="10">10</option><option value="11">11</option><option value="12">12</option><option value="13">13</option><option value="14">14</option><option value="15">15</option><option value="16">16</option><option value="17">17</option><option value="18">18</option><option value="19">19</option><option value="20">20</option><option value="21">21</option><option value="22">22</option><option value="23">23</option><option value="24">24</option><option value="25">25</option><option value="26">26</option><option value="27">27</option><option value="28">28</option><option value="29">29</option><option value="30">30</option><option value="31">31</option></select>
                            </div>
                            <div class="custom-select2">
                              <select class="form-control" name="d2"><option value="0" selected="selected">Ay</option><option value="01">01</option><option value="02">02</option><option value="03">03</option><option value="04">04</option><option value="05">05</option><option value="06">06</option><option value="07">07</option><option value="08">08</option><option value="09">09</option><option value="10">10</option><option value="11">11</option><option value="12">12</option></select>
                            </div>
                            <div class="custom-select3">
                              <select class="form-control" name="d3"><option value="0" selected="selected">Yıl</option><option value="1999">1999</option><option value="1998">1998</option><option value="1997">1997</option><option value="1996">1996</option><option value="1995">1995</option><option value="1994">1994</option><option value="1993">1993</option><option value="1992">1992</option><option value="1991">1991</option><option value="1990">1990</option><option value="1989">1989</option><option value="1988">1988</option><option value="1987">1987</option><option value="1986">1986</option><option value="1985">1985</option><option value="1984">1984</option><option value="1983">1983</option><option value="1982">1982</option><option value="1981">1981</option><option value="1980">1980</option><option value="1979">1979</option><option value="1978">1978</option><option value="1977">1977</option><option value="1976">1976</option><option value="1975">1975</option><option value="1974">1974</option><option value="1973">1973</option><option value="1972">1972</option><option value="1971">1971</option><option value="1970">1970</option><option value="1969">1969</option><option value="1968">1968</option><option value="1967">1967</option><option value="1966">1966</option><option value="1965">1965</option><option value="1964">1964</option><option value="1963">1963</option><option value="1962">1962</option><option value="1961">1961</option><option value="1960">1960</option><option value="1959">1959</option><option value="1958">1958</option><option value="1957">1957</option><option value="1956">1956</option><option value="1955">1955</option><option value="1954">1954</option><option value="1953">1953</option><option value="1952">1952</option><option value="1951">1951</option><option value="1950">1950</option><option value="1949">1949</option><option value="1948">1948</option><option value="1947">1947</option><option value="1946">1946</option><option value="1945">1945</option><option value="1944">1944</option><option value="1943">1943</option><option value="1942">1942</option><option value="1941">1941</option><option value="1940">1940</option><option value="1939">1939</option></select>
                            </div>
                        </fieldset>
                        <fieldset class="fieldset2">
                            <input placeholder="Adres" name="adres" class="ng-pristine ng-invalid ng-invalid-required ng-valid-minlength" type="text">
                        </fieldset>
                        <fieldset>
                            <input placeholder="Şehir" name="sehir" maxlength="20"  type="text">
                        </fieldset>
                        <fieldset>
                            <input placeholder="Posta kodu" name="pkod" maxlength="10" type="text">
                        </fieldset>                      
                        <fieldset class="fieldset2">
                            <div class="custom-select4">
                                <select name="ulke">
                                    <option value="">Ülke Seçiniz</option>
                                    <option value="Türkiye">Türkiye</option>
                                    <option value="England">England</option>
                                    <option value="Germany">Germany</option>
                                    <option value="Argentina">Argentina</option>
                                    <option value="Australia">Australia</option>
                                    <option value="Azerbaijan">Azerbaijan</option>
                                    <option value="Belgium">Belgium</option>
                                    <option value="Bulgaria">Bulgaria</option>
                                    <option value="France">France</option>
                                    <option value="Greece">Greece</option>
                                    <option value="Iceland">Iceland</option>
                                    <option value="Italy">Italy</option>
                                    <option value="Netherlands">Netherlands</option>
                                    <option value="Poland">Poland</option>
                                    <option value="Romania">Romania</option>
                                    <option value="Sweden">Sweden</option>
                                  </select>
                            </div>                  
                            <div class="custom-select2">
                                <select name="parasi" >
                                    <option value="">Para birimi</option>
                                    <option value="TL">TL</option>
                                    <option value="EUR">EUR</option>                    
                                    <option value="USD">USD</option>
                                    <option value="BRL">BRL</option>
                                    <option value="CHF">CHF</option>
                                    <option value="MXN">MXN</option>
                                    <option value="PLN">PLN</option>
                                    <option value="RUB">RUB</option>                    
                                  </select>
                            </div>
                        </fieldset>
						 <fieldset>
                            <input placeholder="T.C No" name="tc" maxlength="20" required="required" type="text">
                        </fieldset>
                        <fieldset class="fieldset3">
                            <input placeholder="Cep telefonu" name="cep" maxlength="10" required="required"  type="text">
                        </fieldset>
                        <fieldset class="fieldset2">
                            <input placeholder="Kullanıcı adı (5-20 Karakter)" name="user" maxlength="20" required="required"  type="text">
                            <p id="">Kullanıcı adı kullanımda</p>
                        </fieldset>
                        <fieldset>
                            <input placeholder="Şifre (6-12 Karakter)" name="sifre" maxlength="20" required="required"  type="password">
                            
                        </fieldset>
                        <fieldset>
                            <input placeholder="Şifre (Tekrar)" name="sifre1" maxlength="20" required="required"  type="password">
                        </fieldset>
                        <fieldset class="fieldset2">
                            <input placeholder="E-posta" name="email" maxlength="100"  type="text">
                            
                        </fieldset>
                    </div>
                    <div class="inner">
                        <div class="title">
                            <p>18 Yaş üzerindeyim. <a class="footinfo" href="#"> Kullanım şartlarını </a> okudum ve onaylıyorum. Diğer veri ve bilgileri kayıt işleminden sonra dilediğiniz zaman ekleyebilir yada değiştirebilirsiniz. İstediğiniz zaman bu hizmeti hesabınızdan kapatabilirsiniz.</p>
                        </div>
                    </div>
                    <div class="promo"> <button type="submit" class="promobutton">HESABIMI OLUŞTUR</button> </div>
                </div>
                </form>
            </div>
        </div>
<div style="height:90px;">&nbsp;</div></div></div></div></div>

<?php echo $_smarty_tpl->getSubTemplate ("mobil/footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>
<?php }} ?>