<?php /* Smarty version Smarty-3.1.8, created on 2022-09-24 04:53:53
         compiled from "application/views/templates/silinenbayi.tpl" */ ?>
<?php /*%%SmartyHeaderCode:589183903632e6331e0b595-85859822%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '77d776a6eeb554fb8d7d58df54cb20a3596f0a3f' => 
    array (
      0 => 'application/views/templates/silinenbayi.tpl',
      1 => 1495298310,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '589183903632e6331e0b595-85859822',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_632e6331e5a2c3_20111011',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_632e6331e5a2c3_20111011')) {function content_632e6331e5a2c3_20111011($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ("header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<?php echo $_smarty_tpl->getSubTemplate ("left.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>



<script>

function bayiler(id) {
	loadgir("#bayiler");
	var order = $("#order").val();
	var ascdesc = $("#ascdesc").val();	
	var name = $("#name").val();	
	var durum = $("#durum").val();	
	$.post(baseurl+'bayiler/gerigetirdata',{id:id,order:order,ascdesc:ascdesc,name:name,durum:durum},function(data) { 
		$("#bayiler").html(data); 
	});
}

function gecis(id) {

	failcont("<?php echo lang('bekle');?>
");
	$.post(baseurl+'home/gecis',{id:id},function(data) {
	
	if(data=="1") {
		self.location.href=baseurl;
	} else
	if(data=="2") {
		failcont("<?php echo lang('gecyok');?>
");
	}
	});
}

$(function() {

	bayiler(<?php echo sesionlar('id');?>
);
	
});

</script>

<div class="coupons">	
	<div class="coupon-title">
		<div class="account-table-blue"><span>
			<div class="icon"><i class="fa fa-user"></i></div>
			</span>
			<p><?php echo lang('sbygetir');?>
</p>
		</div>
		<div class="account-table-gray">
			<form >
			<label><?php echo lang('user');?>
 :</label>
			<input type="text" id="name" size="7" >
			<button type="button" id="sorgu" onclick="bayiler(<?php echo sesionlar('id');?>
);"><?php echo lang('gtr');?>
</button>
			<input type="hidden" id="order" value="username">
			<input type="hidden" id="ascdesc" value="asc">
			</form>			
		</div>
	</div>
	
	<div id="bayiler" class="coupon-content"></div>
	
</div>

<?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>
<?php }} ?>