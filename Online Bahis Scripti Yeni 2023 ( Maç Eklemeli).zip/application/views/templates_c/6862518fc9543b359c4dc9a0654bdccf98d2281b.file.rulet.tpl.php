<?php /* Smarty version Smarty-3.1.8, created on 2018-08-10 15:28:26
         compiled from "application/views/templates/rulet.tpl" */ ?>
<?php /*%%SmartyHeaderCode:12620511975b6d84eaedb702-58016518%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '6862518fc9543b359c4dc9a0654bdccf98d2281b' => 
    array (
      0 => 'application/views/templates/rulet.tpl',
      1 => 1495553706,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '12620511975b6d84eaedb702-58016518',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_5b6d84eaf13851_81870712',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5b6d84eaf13851_81870712')) {function content_5b6d84eaf13851_81870712($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ("header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<div class="coupons">	
	<div class="coupon-title">
		<div class="account-table-blue"><span>
			<div class="icon"><i class="fa fa-user"></i></div>
			</span>
			<p>Canlı Rulet</p>
			</div>
		
		<iframe name="my-iframe" src="https://livecasino-static.casinomodule.com/live_casino/live_roulette_mobile_html/?lobbyURL=https%3A%2F%2Fclientarea.netent.com%2Fnetentlive%2Fdemo&server=https%3A%2F%2Flivecasino-admin.casinomodule.com%2F&callbackurl=https%3A%2F%2Flivecasino-admin.casinomodule.com%2Fmobile-game-launcher%2FGameCallback&operatorId=livecasinodemo&gameId=lcroulette_mobile&lang=tr&integration=standard&keepAliveURL=&tableId=2&liveCasinoHost=livecasino-livegame.casinomodule.com&accountType=CASINOMODULE_WALLET&staticServer=https%3A%2F%2Flivecasino-static.casinomodule.com%2F" scrolling="no"  style="width:100%;height:700px" frameBorder="0"></iframe>
</div>
</div>
<?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>
<?php }} ?>