<?php /* Smarty version Smarty-3.1.8, created on 2022-10-19 01:19:43
         compiled from "application/views/templates/mobil/bultenb.tpl" */ ?>
<?php /*%%SmartyHeaderCode:543870506634f267f546aa3-33077485%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '9d9c07fd411cf36ba7ad38b9c3bf21ea0ff311bf' => 
    array (
      0 => 'application/views/templates/mobil/bultenb.tpl',
      1 => 1495298412,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '543870506634f267f546aa3-33077485',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_634f267f576849_58587076',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_634f267f576849_58587076')) {function content_634f267f576849_58587076($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ("mobil/header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>



<script>

function loadbulten(ligid){
	
	loadgir(".bulten");
	var takim = $("#takimara").val(); 
	var kod = $("#mac_kodu").val(); 
	var tarih = $("#tarihb").val();
	var saat = $("#saat").val(); 
	var ulke = $("#ulke").val(); 
	
	$.post(baseurl+'home/bultenb/',{ligid:ligid,takim:takim,tarih:tarih,kod:kod,saat:saat,ulke:ulke},function(data) {
		$(".bulten").html(data);
		kuponsay();	
	});	
}

$(document).ready(function(e) {
	
	loadbulten();
	
	$('#takimara').keypress(function(event){
		var keycode = (event.keyCode ? event.keyCode : event.which);
		if(keycode == '13'){ loadbulten(); }
	});


	$('#mac_kodu').live( "keyup", function() {
		var mackodu = $("#mac_kodu").val();
		if(mackodu.length>2) { 
			loadbulten();
		}else if(mackodu.length<1) { 
			loadbulten(); 		
		}
	});
	
});
	
</script>

<div id="macd" style="display:none"></div>

<div style="left: 0px; right: 0px; z-index: 100; position: fixed; top: 0px;" class="appheader">
<?php echo mobilhead();?>

<div>  <div class="header"><div onclick="goBack();" class="icon back noselect "></div><div class="text title noselect">Basketbol Bahisleri</div><div onclick="go('index')" style="padding-left:20px" class="icon logo noselect"></div></div></div></div>

<div class="page slide top in" id="page1">
<div class="scroll_container" style="">
<div class="scroll_wrapper" style="padding-top: 85px; padding-bottom: 44px;">
<div class="appcontent">
<div>  </div>

<div class="filterbar">
<select data-placeholder="Tüm Tarihler" class="chosen" style="width:110px;" id='tarihb' onChange="loadbulten();">
<option value=''>Hepsi</option>
	<?php echo bultentarihm('b',0);?>

</select>

<select data-placeholder="Ülkeler" class="chosen" style="width:90px;" id='ulke' onChange="loadbulten();">
<option value=''>Ülkeler</option>
	<?php echo ulkeler(2);?>

</select>

<input type="text" id="mac_kodu" class="inputbet" style="width:60px;float: left;height: 28px" placeholder="Maç Kodu">
</div>

<div class="bulten"></div>

<div style="height:20px;">&nbsp;</div>

</div></div></div></div>

<?php echo $_smarty_tpl->getSubTemplate ("mobil/footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>
<?php }} ?>