<?php /* Smarty version Smarty-3.1.8, created on 2018-08-26 19:58:09
         compiled from "application/views/templates/adminedit.tpl" */ ?>
<?php /*%%SmartyHeaderCode:8167543605b82dc21cc00e3-47909982%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'e591a504cc9de0759a4291b7ddfd9479d9339e0c' => 
    array (
      0 => 'application/views/templates/adminedit.tpl',
      1 => 1495298249,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '8167543605b82dc21cc00e3-47909982',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'veri' => 0,
    'ayr' => 0,
    'tipayr' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_5b82dc21d476f1_23998164',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5b82dc21d476f1_23998164')) {function content_5b82dc21d476f1_23998164($_smarty_tpl) {?><div class="account-table-blue"><span>
	<div class="icon"><i class="fa fa-user"></i></div>
	</span>
	<p> <?php echo lang('admedit',array($_smarty_tpl->tpl_vars['veri']->value->username));?>
</p>
</div>
<form method="post" action="<?php echo base_url();?>
bayikayit/editform" name="kform">
<table style="margin:10px 0px 20px 10px;width:98%;color: <?php if (@tema==1){?>#000<?php }else{ ?>#fff<?php }?>;" id="table_step">
		<tr>
			<td colspan="2"><div class="formbaslik"><?php echo lang('girbilgi');?>
</div></td>				
		</tr>
		<tr>
			<td><?php echo lang('user');?>
</td>				
			<td><input type="text" class="inputbet" readonly value="<?php echo $_smarty_tpl->tpl_vars['veri']->value->username;?>
"></td>				
		</tr>
		<tr>
			<td><?php echo lang('sifre');?>
</td>				
			<td><input type="text" class="inputbet" readonly value="*****"> <?php echo lang('gizli');?>
</td>				
		</tr>
		<tr>
			<td><?php echo lang('firma');?>
</td>				
			<td><input type="text" class="inputbet" name="firma" value="<?php echo $_smarty_tpl->tpl_vars['veri']->value->firma;?>
"></td>				
		</tr>
		<tr>
			<td><?php echo lang('tel');?>
</td>				
			<td><input type="text" class="inputbet" name="tel" value="<?php echo $_smarty_tpl->tpl_vars['ayr']->value->tel;?>
"></td>				
		</tr>
		<tr>
			<td colspan="2" class="trenayar"><div class="formbaslik"><?php echo lang('yetbaslik');?>
</div></td>				
		</tr>
		<tr height="40">
			<td><?php echo lang('iptal_yetki');?>
</td>				
			<td>
				<select name="iptal_yetki" class="chosen-select-no-single" style="width:120px;">
					<option value="1" <?php if ($_smarty_tpl->tpl_vars['ayr']->value->iptal_yetki=='1'){?>selected<?php }?>><?php echo lang('yetkili');?>
</option>
					<option value="0" <?php if ($_smarty_tpl->tpl_vars['ayr']->value->iptal_yetki=='0'){?>selected<?php }?>><?php echo lang('yetkisiz');?>
</option>		
				</select>
			</td>				
		</tr>
		<tr height="40">
			<td><?php echo lang('kupon_degistirme');?>
</td>
			<td>
				<select name="kupon_degistirme" class="chosen-select-no-single" style="width:120px;">
					<option value="1" <?php if ($_smarty_tpl->tpl_vars['ayr']->value->kupon_degistirme=='1'){?>selected<?php }?>><?php echo lang('yetkili');?>
</option>
					<option value="0" <?php if ($_smarty_tpl->tpl_vars['ayr']->value->kupon_degistirme=='0'){?>selected<?php }?>><?php echo lang('yetkisiz');?>
</option>		
				</select>
			</td>				
		</tr>
		<tr height="40">
			<td><?php echo lang('oranduzenleme');?>
</td>				
			<td>
				<select name="oranduzenleme" class="chosen-select-no-single" style="width:120px;">
					<option value="1" <?php if ($_smarty_tpl->tpl_vars['ayr']->value->oranduzenleme=='1'){?>selected<?php }?>><?php echo lang('yapar');?>
</option>
					<option value="0" <?php if ($_smarty_tpl->tpl_vars['ayr']->value->oranduzenleme=='0'){?>selected<?php }?>><?php echo lang('yapamaz');?>
</option>		
				</select>
			</td>				
		</tr>
		<tr  height="40">
			<td><?php echo lang('silme_yetki');?>
</td>				
			<td>
				<select name="silme_yetki" class="chosen-select-no-single" style="width:120px;">
					<option value="1" <?php if ($_smarty_tpl->tpl_vars['ayr']->value->silme_yetki=='1'){?>selected<?php }?>><?php echo lang('yapar');?>
</option>
					<option value="0" <?php if ($_smarty_tpl->tpl_vars['ayr']->value->silme_yetki=='0'){?>selected<?php }?>><?php echo lang('yapamaz');?>
</option>		
				</select>
			</td>				
		</tr>
		<tr  height="40">
			<td>Tema Seçimi</td>				
			<td>
				<select name="tema" class="chosen-select-no-single" style="width:120px;">
					<option value="" <?php if ($_smarty_tpl->tpl_vars['ayr']->value->tema=='1'){?>selected<?php }?>>Tema1 (Koyu)</option>
					<option value="1" <?php if ($_smarty_tpl->tpl_vars['ayr']->value->tema=='0'){?>selected<?php }?>>Tema2 (Açık)</option>		
				</select>
			</td>				
		</tr>
		<tr height="40">
			<td><?php echo lang('altsinir1');?>
</td>				
			<td><input type="text" class="inputbet" name="alt_sinir" value="<?php echo $_smarty_tpl->tpl_vars['ayr']->value->alt_sinir;?>
" size="5" maxlength="2"> <?php echo lang('altsinir');?>
</td>				
		</tr>
		<tr  height="40">
			<td><?php echo lang('siteytk');?>
</td>				
			<td>
			<?php $_smarty_tpl->tpl_vars['tipayr'] = new Smarty_variable(explode("|",$_smarty_tpl->tpl_vars['ayr']->value->domain), null, 0);?>
			<?php echo domainver(3,'',$_smarty_tpl->tpl_vars['tipayr']->value);?>

			</td>
		</tr>
		<tr>
			<td colspan="2" class="trenayar"><input type="button" class="button" value="<?php echo lang('kyt');?>
" id="kaydets"></td>				
		</tr>
	</table>
	
	<input type="hidden" name="userid" value="<?php echo $_GET['id'];?>
">
</form><?php }} ?>