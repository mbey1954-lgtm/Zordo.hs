<?php /* Smarty version Smarty-3.1.8, created on 2018-08-26 19:57:55
         compiled from "application/views/templates/left.tpl" */ ?>
<?php /*%%SmartyHeaderCode:705160985b82dc138cbe91-01423693%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '1eae12bdbaad520f268832086e49c5fca04a67fc' => 
    array (
      0 => 'application/views/templates/left.tpl',
      1 => 1495704480,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '705160985b82dc138cbe91-01423693',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_5b82dc13996713_87637119',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5b82dc13996713_87637119')) {function content_5b82dc13996713_87637119($_smarty_tpl) {?><div class="menu">
<div class="user-menu-container"> 
<div class="user-menu-title"><?php echo lang('soltit');?>
</div>
<ul>
	<?php if (@yetki=='4'){?>
		
	<li>
		<a href="<?php echo base_url();?>
raporlar"><div class="icon"><i class="fa fa-list-ul"></i></div><span><?php echo lang('rpr');?>
</span></a>
	</li>
	<li>
		<a href="<?php echo base_url();?>
raporlar/gunlukrapor"><div class="icon"><i class="fa fa-list-ul"></i></div><span><?php echo lang('grpr');?>
</span></a>
	</li>
	<li>
		<a href="<?php echo base_url();?>
ayar/hesabim"><div class="icon"><i class="fa fa-key"></i></div><span><?php echo lang('hesayar');?>
</span></a>
	</li>
	<?php }?>
	<?php if (@yetki!='4'&&@yetki!='5'){?>
		
		<li>
			<a href="<?php echo base_url();?>
bayiler" class="<?php if (curpagename(1)=='bayiler'){?>active<?php }?>"><div class="icon"><i class="fa fa-user"></i></div><span><?php echo lang('byler');?>
</span></a>
		</li>
		<li>
			<a href="<?php echo base_url();?>
raporlar"><div class="icon"><i class="fa fa-list-ul"></i></div><span><?php echo lang('rpr');?>
</span></a>
		</li>
		<li>
			<a href="<?php echo base_url();?>
raporlar/gunlukrapor"><div class="icon"><i class="fa fa-list-ul"></i></div><span><?php echo lang('grpr');?>
</span></a>
		</li>
		<?php if (@oranduzenleme=='1'){?>
		<li>
			<a href="<?php echo base_url();?>
oranmerkezi"><div class="icon icon-1"></div><span><?php echo lang('foranduz');?>
</span></a>
		</li>
		<li>
			<a href="<?php echo base_url();?>
oranmerkezib"><div class="icon icon-2"></div><span><?php echo lang('boranduz');?>
</span></a>
		</li>
		<?php }?>
		<?php if (@yetki=='3'){?>
		<li>
			<a href="<?php echo base_url();?>
ayar/bankahesaplari"><div class="icon"><i class="fa fa-bank"></i></div><span><?php echo lang('bnkhesap');?>
</span></a>
		</li>
		<li>
			<a href="<?php echo base_url();?>
ayar/talepler"><div class="icon"><i class="fa fa-cc-visa"></i></div><span>Talepler</span></a>
		</li>
		<?php }?>
		<li>
			<a href="<?php echo base_url();?>
ayar/duyurular"><div class="icon"><i class="fa fa-bullhorn"></i></div><span><?php echo lang('duyru');?>
</span></a>
		</li>
		<li>
			<a href="<?php echo base_url();?>
ayar/iptaltalepleri"><div class="icon"><i class="fa fa-flag"></i></div><span><?php echo lang('ipttalp');?>
</span></a>
		</li>
		<li>
			<a href="<?php echo base_url();?>
ayar/iptallistesi"><div class="icon"><i class="fa fa-flag-o"></i></div><span><?php echo lang('iptkp');?>
</span></a>
		</li>
		<li>
			<a href="<?php echo base_url();?>
ayar/hesabim"><div class="icon"><i class="fa fa-key"></i></div><span>Hesap Ayarlarım</span></a>
		</li>
		<li>
			<a href="<?php echo base_url();?>
bayiler/gerigetir" class="<?php if (curpagename(2)=='gerigetir'){?>active<?php }?>"><div class="icon"><i class="fa fa-user"></i></div><span><?php echo lang('sbygetir');?>
</span></a>
		</li>
		<li>
			<a href="<?php echo base_url();?>
bayikayit"><div class="icon"><i class="fa fa-plus"></i></div><span>
			<?php if (@yetki=='3'){?>
				<?php echo lang('bins');?>

			<?php }elseif(@yetki=='2'){?>
				<?php echo lang('adins');?>

			<?php }elseif(@yetki=='1'){?>
				Yeni Süper Admin Kayıt
			<?php }?>
			</span></a>
		</li>
		<?php if (@yetki=='3'){?>
		<li>
			<a href="<?php echo base_url();?>
genelayarlar"><div class="icon"><i class="fa fa-cog"></i></div><span><?php echo lang('gnlayr');?>
</span></a>
		</li>	
		<?php }?>
		
		<?php if (@yetki=='3'||@yetki=='1'){?>
		<li>
			<a href="<?php echo base_url();?>
ayar/hizliduzenle?tablo=Futbol"><div class="icon"><i class="fa fa-clone"></i></div><span>Hızlı Düzenle</a></span>
		</li>
		<li>
			<a href="<?php echo base_url();?>
detay"><div class="icon"><i class="fa fa-clone"></i></div><span>Detay</a></span>
		</li>		
		<li>
			<a href="<?php echo base_url();?>
kuponlar/degistir"><div class="icon"><i class="fa fa-book"></i></div><span>Kupon Müdahele</a></span>
		</li>		
		<li>
			<a href="<?php echo base_url();?>
sonucgirsistem"><div class="icon"><i class="fa fa-cubes"></i></div><span>Sonuç Gir / Düzelt</a></span>
		</li>
		<li>
			<a href="<?php echo base_url();?>
ayar"><div class="icon"><i class="fa fa-thumbs-o-up"></i></div><span>Bonus Kayıt</a></span>
		</li>
		
		<script>
		function sistemkomplekapat() {
			var ver = "<?php echo @sistemikapat;?>
";
			if(ver==1){
				var kapama=0;var mesajk='Sistem Açıldı.';var confrim='Sistem Açılıcaktır. Eminmisiniz?';
			}else{
				var kapama=1;var mesajk='Sistem Kapatıldı.';var confrim='Sistem Kapatılacaktır. Eminmisiniz?';
			}
			if(confirm(confrim)){				
				$.post(baseurl+'ayar/sistemikapat',{ver:kapama},function(data) {				
					failcont(mesajk);
					setTimeout(function () {
					   window.location.href=baseurl;
					}, 2000);
				});
			}
		}
		function yasakla(yer,ne) {
			if(ne==0){
				var mesajk=yer+' Açıldı.';var confrim=yer+' Açılıcaktır. Eminmisiniz?';
			}else{
				var mesajk=yer+' Kapatıldı.';var confrim=yer+' Kapatılacaktır. Eminmisiniz?';
			}
			if(confirm(confrim)){				
				$.post(baseurl+'ayar/yasakla/'+yer,{ne:ne},function(data) {				
					failcont(mesajk);
					setTimeout(function () {
					   window.location.href=baseurl;
					}, 2000);
				});
			}
		}
		function sistemayaryap(yer,ne,h) {
			if(ne==1){
				var mesajk=yer+' Açıldı.';var confrim=yer+' Açılıcaktır. Eminmisiniz?';
			}else{
				var mesajk=yer+' Kapatıldı.';var confrim=yer+' Kapatılacaktır. Eminmisiniz?';
			}
			if(confirm(confrim)){				
				$.post(baseurl+'ayar/sistemayar/',{ne:ne,h:h},function(data) {				
					failcont(mesajk);
					setTimeout(function () {
					   window.location.href=baseurl;
					}, 2000);
				});
			}
		}
		function aktifcanli(yer) {
			
			var mesajk=yer+' Aktiflendi.';
			var confrim=yer+' Aktifleştirilecektir. Eminmisiniz?';
			
			if(confirm(confrim)){				
				$.post(baseurl+'ayar/aktifcanli/'+yer,function(data) {				
					failcont(mesajk);
					setTimeout(function () {
					   window.location.href=baseurl;
					}, 2000);
				});
			}
		}
		</script>
		
		<li >
			<div class="icon"><i class="fa fa-cog"></i></div>&nbsp;			
			<?php if (@baskapat==1){?>
			<input type="button" class="button" value="--Basketi Aç--" onclick="yasakla('Basket',0);" style="background:green;width: 85%;">
			<?php }elseif(@baskapat==0){?>
			<input type="button" class="button" value="--Basketi Kapat--" onclick="yasakla('Basket',1);" style="width: 85%;">
			<?php }?>	
		</li>
		<li >
			<div class="icon"><i class="fa fa-cog"></i></div>&nbsp;	
			<?php if (@dukapat==1){?>
			<input type="button" class="button" value="--Duello Aç--" onclick="yasakla('Duello',0);" style="background:green;width: 85%;">
			<?php }elseif(@dukapat==0){?>
			<input type="button" class="button" value="--Duello Kapat--" onclick="yasakla('Duello',1);" style="width: 85%;">
			<?php }?>
		</li>
		<!--<li >
			<div class="icon"><i class="fa fa-cog"></i></div>&nbsp;	
			<?php if (@soket==1){?>
			<input type="button" class="button" value="--Soketi Durdur--" onclick="sistemayaryap('Soket',0,1);" style="background:green;width: 85%;">
			<?php }elseif(@soket==0){?>
			<input type="button" class="button" value="--Soketi Aç--" onclick="sistemayaryap('Soket',1,1);" style="width: 85%;">
			<?php }?>
		</li>
		<li style="">
			<div class="icon"><i class="fa fa-cog"></i></div>&nbsp;	
			<?php if (@ref==1){?>
			<input type="button" class="button" value="--Referans Sistemini Durdur--" onclick="sistemayaryap('Referans Sistemi',0,2);" style="background:green;width: 85%;">
			<?php }elseif(@ref==0){?>
			<input type="button" class="button" value="--Referans Sistemini Aç--" onclick="sistemayaryap('Referans Sistemi',1,2);" style="width: 85%;">
			<?php }?>
		</li>-->		
		<li style="">
			<div class="icon"><i class="fa fa-cog"></i></div>&nbsp;
			<?php if (@sistemikapat==1){?>
			<input type="button" class="button" value="Sistemi Aç" id="sistemikapat" onclick="sistemkomplekapat();" style="background:green;width: 85%;">
			<?php }elseif(@sistemikapat==0){?>
			<input type="button" class="button" value="Sistemi Kapat" id="sistemikapat" onclick="sistemkomplekapat();" style="width: 85%;">
			<?php }?>
		</li>
		<?php }?>
		
	<?php }?>
  
</ul> 
</div>

</div><?php }} ?>