<?php /* Smarty version Smarty-3.1.8, created on 2022-10-19 01:37:57
         compiled from "application/views/templates/kupondegistir.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1904239313634f2ac53b5f06-85128904%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'bd08e0d68ebf8fbd9145973cd212094fa4610b53' => 
    array (
      0 => 'application/views/templates/kupondegistir.tpl',
      1 => 1495531633,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1904239313634f2ac53b5f06-85128904',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'kupon_bilgi' => 0,
    'kupic' => 0,
    'kupdegver' => 0,
    'tip' => 0,
    'kupde' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_634f2ac5440453_72458546',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_634f2ac5440453_72458546')) {function content_634f2ac5440453_72458546($_smarty_tpl) {?><?php if (!is_callable('smarty_modifier_date_format')) include '/home/bbcanbets/public_html/system/libs/smarty/libs/plugins/modifier.date_format.php';
?><?php echo $_smarty_tpl->getSubTemplate ("header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<?php echo $_smarty_tpl->getSubTemplate ("left.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>



<style>
button {
  background: rgba(0, 0, 0, 0) linear-gradient(to top, #535353 0%, #797979 100%) repeat scroll 0 0;
  border: 1px solid #000;
  color: #fff;
  float: left;
  height: 22px;
  width: 100%;
}
</style>
<script>
var kupon_id = "<?php echo $_smarty_tpl->tpl_vars['kupon_bilgi']->value['id'];?>
";

function satir_sil(icid,tip,kaz,kid) {
	if(confirm('Maç Silinecektir. Eminmisiniz?')) {
		$.post(baseurl+'kuponlar/kuponicsil/',{icid:icid,tip:tip,kaz:kaz,kid:kid},function(data) {  
			if(data=="1") { self.location.href=baseurl+'kuponlar/degistir/?id='+kupon_id;}else
			if(data=="2") { failcont('Bir hata oluştu. Satır silinemedi.');}
		});
	}
}

function edit_satir(id) {
	if(confirm('Maçın durumu değişecektir.Onaylıyormusunuz?')) {
	var netur = $("#netur_"+id+"").val();
	var mevcutkod = $("#mevcutkod_"+id+"").val();
	var tahmin = $("#tahmin_"+id+"").val();
	var tercih = $("#tercih_"+id+"").val();
	var mkod = $("#edit_mkod_"+id+"").val();
	var iy = $("#edit_iy_"+id+"").val();
	var ms = $("#edit_ms_"+id+"").val();
	var yeni_oran = $("#edit_oran_"+id+"").val();
	var yeni_durum = $("#edit_durum_"+id+"").val();
	var mevcut_oran = $("#mevcut_oran_"+id+"").val();
	var mevcut_durum = $("#mevcut_durum_"+id+"").val();
	
	$.post(baseurl+'kuponlar/kuponicedit',{mevcutkod:mevcutkod,netur:netur,kupon_id:kupon_id,yenioran:yeni_oran,yenidurum:yeni_durum,mevcutoran:mevcut_oran,mevcutdurum:mevcut_durum,idob:id,iy:iy,ms:ms,mkod:mkod,tahmin:tahmin,tercih:tercih},function(data) {  
	if(data=="1") { self.location.href=baseurl+'kuponlar/degistir/?id='+kupon_id;} else
	if(data=="3") { failcont('Bu maç kodunu değiştirmezsiniz. Maç Başlamış veya Bitmiş olabilir.');} else
	if(data=="2") { failcont('Bir hata oluştu. Satır düzenlenemedi.'); }
	});
	}
}

function totalchange(id) {
	if(confirm('Kupon durumu değişecektir.Onaylıyormusunuz?')) {
	var koran = $("#koran_"+id+"").val();
	var knot = $("#knot_"+id+"").val();
	var kyatan = $("#kyatan_"+id+"").val();
	var ktutar = $("#ktutar_"+id+"").val();
	var kbonus = $("#kbonus_"+id+"").val();
	var kdurum = $("#kdurum_"+id+"").val();
	var koncoran = $("#koncoran_"+id+"").val();
	var koncdurum = $("#koncdurum_"+id+"").val();
	
	$.post(baseurl+'kuponlar/kupondurumdegistir/',{koncdurum:koncdurum,koncoran:koncoran,id:id,oran:koran,not:knot,yatan:kyatan,bonus:kbonus,tutar:ktutar,durum:kdurum},function() {
		failcont('Değişiklikler uygulandı.');
		self.location.href=baseurl+'kuponlar/degistir/?id='+kupon_id;
	});
	}
}

function bakiyedurum(id,durum) {
	if(durum==1) {
		if(confirm('Kupon kazancı kullanıcı bakiyesinden geri çekilecektir.')) { 
			$.get('ajax.php?a=bakiyedurum&id='+id+'&durum='+durum+'',function() { 
				self.location.href='kupondegistir.php?id='+kupon_id;
			});
		}
	} else
	if(durum==2) {
		if(confirm('Kupon kazancı kullanıcı bakiyesine eklenecektir.')) { 
			$.get('ajax.php?a=bakiyedurum&id='+id+'&durum='+durum+'',function() { 
				self.location.href='kupondegistir.php?id='+kupon_id;
			});
		}
	}
}
function tercih_al(id,yer,oranval,tablo){
	if(id){
		$.post(baseurl+'kuponlar/tercih_al',{oran_tip:id,oranval:oranval,tablo:tablo}, function(data) {		
			$('#tercih_'+yer+'').html(data);
		});
	}
}
function detaydanekle(kid,id){
	if(id){
		$.post(baseurl+'kuponlar/detaydanekle',{kid:kid,id:id}, function(data) {		
			self.location.href='kupondegistir.php?id='+kupon_id;
		});
	}
}
function detayal() {	
	$.post(baseurl+'kuponlar/detayal',{id:kupon_id},function(data) {	
		$( ".detayal" ).dialog({
		  modal: true,
		  width: 750,
		  position:['top',30],
		  close : function(){
			 $( ".detayal" ).html('');
		  }
		});
		$(".detayal").html(data);
	});
}
</script>


<div class="detayal" style="display:none" title="Detay Kayıtları"></div>

<div class="coupons">	
	<div class="coupon-title">
		<div class="account-table-blue"><span>
			<div class="icon"><i class="fa fa-user"></i></div>
			</span>
			<p>Kupon Düzenleme</p>
		</div>
		
		<form method="get" action="<?php echo base_url();?>
kuponlar/degistir">
		<table style="margin:10px 0px 20px 10px;width:98%;color: <?php if (@tema==1){?>#000<?php }else{ ?>#fff<?php }?>;" id="table_step">
		<tr >		
			<td colspan="5"><div class="formbaslik" style="margin: 5px">Değiştirilecek kuponu bulun</div></td>				
		</tr>
		<tr>
		<td>Kupon Numarası&nbsp;&nbsp;
		<input type="text" name="id" class="inputbet" style="width:80px;" value="<?php echo $_GET['id'];?>
">&nbsp;&nbsp;
		<input type="submit" value="Bul" class="button">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		<input value="Maç Ekle" class="button" type="button" onclick="detayal();">
		</td>		
		</tr>		
		</table>
		</form>
		
		<?php if ($_GET['id']){?>
		<div class="formbaslik" style="border-radius:0px;margin: 5px;width:99%">Kupondaki Maçlar</div>
		<table class="tftable" style="margin:10px 0px 20px 10px;width:98%;" cellspacing="0" cellpadding="0">
		<thead><tr>
		<th>Zaman</th>
		<th>Maç Zamanı</th>
		<th>Spor/Kod</th>
		<th>Takımlar</th>
		<th>Tahmin</th>
		<th>Tercih</th>
		<th>Oran</th>
		<th>İlk Yarı</th>
		<th>Skor</th>
		<th>Durum</th>
		<th>İşlem</th>
		</tr></thead><tbody>
		<?php echo $_smarty_tpl->tpl_vars['kupic']->value;?>

		</tbody></table>

		<div class="formbaslik" style="border-radius:0px;margin: 5px;width:99%">Kupon bilgileri</div>
		<table class="tftable" style="margin:10px 0px 20px 10px;width:98%;" cellspacing="0" cellpadding="0">
		<thead><tr class="bas">
		<th>Kullanıcı</th>
		<th>Kupon Sahibi</th>
		<th>Kupon Tarihi</th>
		<th>Toplam Oran</th>
		<th>Yatırılan Tutar</th>
		<th>Kazanç</th>
		<th>Bonus</th>
		<th>Kupon Durumu</th>
		<th>İşlem</th>
		</tr></thead><tbody>
		
		<tr class="" style="font-size:12px; font-weight:bold;">
		<td><?php echo $_smarty_tpl->tpl_vars['kupon_bilgi']->value['username'];?>
</th>
		<td><?php if ($_smarty_tpl->tpl_vars['kupon_bilgi']->value['kim']==1){?>
		<?php echo $_smarty_tpl->tpl_vars['kupon_bilgi']->value['kupon_nots'];?>

		<?php }else{ ?>
		<input type="text" class="inputbet" size="7" id="knot_<?php echo $_smarty_tpl->tpl_vars['kupon_bilgi']->value['id'];?>
" value="<?php echo $_smarty_tpl->tpl_vars['kupon_bilgi']->value['kupon_nots'];?>
">
		<?php }?></th>
		<td><?php echo smarty_modifier_date_format($_smarty_tpl->tpl_vars['kupon_bilgi']->value['kupon_time'],"%d-%m-%Y %H:%M:%S");?>
</th>
		<td><input type="text" class="inputbet" size="5" id="koran_<?php echo $_smarty_tpl->tpl_vars['kupon_bilgi']->value['id'];?>
" value="<?php echo nf($_smarty_tpl->tpl_vars['kupon_bilgi']->value['oran']);?>
"></th>
		<td><input type="text" class="inputbet" size="4" id="kyatan_<?php echo $_smarty_tpl->tpl_vars['kupon_bilgi']->value['id'];?>
" value="<?php echo ($_smarty_tpl->tpl_vars['kupon_bilgi']->value['yatan']);?>
"></th>
		<td><input type="text" class="inputbet" size="6" id="ktutar_<?php echo $_smarty_tpl->tpl_vars['kupon_bilgi']->value['id'];?>
" value="<?php echo nf($_smarty_tpl->tpl_vars['kupon_bilgi']->value['tutar']);?>
"></th>
		<td><input type="text" class="inputbet" size="6" id="kbonus_<?php echo $_smarty_tpl->tpl_vars['kupon_bilgi']->value['id'];?>
" value="<?php echo $_smarty_tpl->tpl_vars['kupon_bilgi']->value['bonus'];?>
"></th>
		<td><select class="inputbet durum_<?php echo $_smarty_tpl->tpl_vars['kupon_bilgi']->value['durum'];?>
" id="kdurum_<?php echo $_smarty_tpl->tpl_vars['kupon_bilgi']->value['id'];?>
" style="width:auto;">
		<option value="1" <?php if ($_smarty_tpl->tpl_vars['kupon_bilgi']->value['durum']=="1"){?>  selected <?php }?>>Bahis Açık</option>
		<option value="2" <?php if ($_smarty_tpl->tpl_vars['kupon_bilgi']->value['durum']=="2"){?>  selected <?php }?>>Kazandı</option>
		<option value="3" <?php if ($_smarty_tpl->tpl_vars['kupon_bilgi']->value['durum']=="3"){?>  selected <?php }?>>Kaybetti</option>
		<option value="4" <?php if ($_smarty_tpl->tpl_vars['kupon_bilgi']->value['durum']=="4"){?>  selected <?php }?>>İptal</option>
		</select></td>
		<td>
		<input type="hidden" id="koncoran_<?php echo $_smarty_tpl->tpl_vars['kupon_bilgi']->value['id'];?>
" value="<?php echo nf($_smarty_tpl->tpl_vars['kupon_bilgi']->value['oran']);?>
">
		<input type="hidden" id="koncdurum_<?php echo $_smarty_tpl->tpl_vars['kupon_bilgi']->value['id'];?>
" value="<?php echo $_smarty_tpl->tpl_vars['kupon_bilgi']->value['durum'];?>
">
		<button type="button" class="inputbet" onClick="totalchange('<?php echo $_smarty_tpl->tpl_vars['kupon_bilgi']->value['id'];?>
');">Kuponu Düzenle</button>
		</td>
		</tr>
		</tbody></table>
		
		<div class="formbaslik" style="border-radius:0px;margin: 5px;width:99%">Önceden Yapılan Değişiklikler</div>
		<table class="tftable" style="margin:10px 0px 20px 10px;width:98%;" cellspacing="0" cellpadding="0">
		<thead><tr>
		<th>Zaman</th>
		<th>IP Adresi</th>
		<th>Düzenleyen</th>
		<th>Eski Durum</th>
		<th>Yeni Durum</th>
		<th>Eski Oran</th>
		<th>Yeni Oran</th>
		</tr></thead><tbody>
		
		<?php  $_smarty_tpl->tpl_vars['kupde'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['kupde']->_loop = false;
 $_smarty_tpl->tpl_vars['tip'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['kupdegver']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['kupde']->key => $_smarty_tpl->tpl_vars['kupde']->value){
$_smarty_tpl->tpl_vars['kupde']->_loop = true;
 $_smarty_tpl->tpl_vars['tip']->value = $_smarty_tpl->tpl_vars['kupde']->key;
?>
		<tr>		
		<th colspan="8" class="formbaslik"><?php if ($_smarty_tpl->tpl_vars['tip']->value==1){?> Kupon Düzenlemesi<?php }else{ ?> Kupon İçi Düzenlemesi<?php }?></th>
		</tr>
			<?php  $_smarty_tpl->tpl_vars['kupic'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['kupic']->_loop = false;
 $_smarty_tpl->tpl_vars['tip'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['kupde']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['kupic']->key => $_smarty_tpl->tpl_vars['kupic']->value){
$_smarty_tpl->tpl_vars['kupic']->_loop = true;
 $_smarty_tpl->tpl_vars['tip']->value = $_smarty_tpl->tpl_vars['kupic']->key;
?>
				<tr class="durum_<?php echo $_smarty_tpl->tpl_vars['kupic']->value['yeni_durum'];?>
">		
				<td><?php echo smarty_modifier_date_format($_smarty_tpl->tpl_vars['kupic']->value['zaman'],"%d-%m-%Y %H:%M:%S");?>
</td>
				<td><?php echo $_smarty_tpl->tpl_vars['kupic']->value['ipadres'];?>
</td>
				<td><?php echo $_smarty_tpl->tpl_vars['kupic']->value['edit_user'];?>
</td>
				<td><?php echo durumnedir($_smarty_tpl->tpl_vars['kupic']->value['edit_durum']);?>
</td>
				<td><?php echo durumnedir($_smarty_tpl->tpl_vars['kupic']->value['yeni_durum']);?>
</td>
				<td><?php echo nf($_smarty_tpl->tpl_vars['kupic']->value['edit_oran']);?>
</td>
				<td><?php echo nf($_smarty_tpl->tpl_vars['kupic']->value['yeni_oran']);?>
</td>
				</tr>
			<?php } ?>
		<?php } ?>
		</tbody></table>
		
		<?php }?>
</div>
</div>
</div>

<?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>
<?php }} ?>