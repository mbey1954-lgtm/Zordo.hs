<?php /* Smarty version Smarty-3.1.8, created on 2018-08-10 15:26:39
         compiled from "application/views/templates/bultenh.tpl" */ ?>
<?php /*%%SmartyHeaderCode:82697195b6d847f7f5288-23451964%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '93ddd2e1e13d7f46193f1b63baee10acc779a372' => 
    array (
      0 => 'application/views/templates/bultenh.tpl',
      1 => 1495527556,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '82697195b6d847f7f5288-23451964',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_5b6d847f85ad14_97486061',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5b6d847f85ad14_97486061')) {function content_5b6d847f85ad14_97486061($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ("header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<?php echo $_smarty_tpl->getSubTemplate ("left1.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>



<script>
function ligler() {
		$.post(baseurl+'home/ligler/h',function(data) {	
			if(data.f){$('#liglerh').show();}
			$("#liglerh").html(data.f);
		}, "json");
	}
	
function loadbulten(ligid){
	
	var takim = $("#takimara").val(); var kod = $("#mac_kodu").val(); var tarih = $("#tarihb").val();
	var saat = $("#saat").val(); 
	
	loadgir(".bulten");
	
	$.post(baseurl+'home/bultenson/',{t:'h',ligid:ligid,takim:takim,tarih:tarih,kod:kod,saat:saat},function(data) {
	
	var arayi = {};
	var byaz ='';
	
	if(data.yok){
		byaz +="<div class='bos'><?php echo lang('bosbhs');?>
</div>";
		kuponguncelle(1);
	}else{
	
	$.each(data,function(lig,d1){
			var ayr=lig.split('|');
			byaz +='<div><div><div class="general-table-title-blue"><div class="icon icon-6"></div><p>'+ayr[0]+' - '+ayr[1]+'</p></div> <div class="general-subtitle-gray"><ul><li><span class="icon-time"></span></li><li><i class="fa fa-flag"></i></li><li></li><li> <strong ><?php echo lang("thm");?>
</strong> <span>1</span> <span>X</span> <span>2</span> </li><li> <strong ><?php echo lang("1.yariustalt");?>
</strong> <span ><?php echo lang("alt");?>
</span> <span ><?php echo lang("ust");?>
</span> </li><li><span class="icon-mini-statistic"></span></li><li>+</li></ul></div>';
			
			$.each(d1,function(v,d2){
				byaz +='<ul class="match-list-default zebra">  <li>'+d2.gun+' '+d2.st+'</li><li>'+d2.mac_kodu+'</li><li><em class="xcard"></em> <span class="t1">'+d2.ev_takim+'</span> <span class="score">-:-</span><em class="xcard"></em> <span class="t2">'+d2.konuk_takim+'</span> </li>  <li><a class="ratio-box" class="qbut all'+d2.id+'-hentbol" onclick="kupon(\''+d2.evk+'\');" id="'+d2.id+'-1-hentbol" href="javascript:;"><span>'+d2.ev+'</span></a> <a class="ratio-box" class="qbut all'+d2.id+'-'+d2.tipi+'" onclick="kupon(\''+d2.bk+'\');" id="'+d2.id+'-2-hentbol" href="javascript:;"><span>'+d2.brb+'</span></a> <a class="ratio-box" class="qbut all'+d2.id+'-hentbol" onclick="kupon(\''+d2.kk+'\');" id="'+d2.id+'-3-hentbol" href="javascript:;"><span>'+d2.knk+'</span></a> </li> <li><a class="ratio-box" class="qbut all'+d2.id+'-hentbol" onclick="kupon(\''+d2.ak+'\');" id="'+d2.id+'-4-hentbol" href="javascript:;"><span>'+d2.alt+'</span></a> <a class="ratio-box" class="qbut all'+d2.id+'-hentbol" onclick="kupon(\''+d2.uk+'\');" id="'+d2.id+'-5-hentbol" href="javascript:;"><span>'+d2.ust+'</span></a> </li><li></li>';
				if(d2.orsay>0){
					byaz +='<li class="extra-but" onclick="mdf1(\''+d2.id+'\',\'h\');" id="tumac'+d2.id+'"><span>+'+d2.orsay+'</span></li></ul><div id="betdetail_'+d2.id+'" style="display: none;"></div>';
				}else{
					byaz +='<li class="extra-but"><span></span></li></ul>';
				}
			});
			byaz+='</div>';
		});
		ligler();
		kuponguncelle(1);
	}
	$(".bulten").html(byaz);
	
	}, "json");	
}

$(document).ready(function(e) {
	
	loadbulten();
	
	$('#hlig').live( "click", function() {
		$('#liglerh').slideToggle('slow');             
	});
		
	$('#takimara').live( "keyup", function() {
		var mackodu = $("#takimara").val();
		if(mackodu.length>2) { 
			loadbulten();
		}else if(mackodu.length<1) { 
			loadbulten(); 		
		}
	});


	$('#mac_kodu').live( "keyup", function() {
		var mackodu = $("#mac_kodu").val();
		if(mackodu.length>2) { 
			loadbulten();
		}else if(mackodu.length<1) { 
			loadbulten(); 		
		}
	});
	
});
	
</script>


<main><div class="table-container bulten"></div></main>

<?php echo $_smarty_tpl->getSubTemplate ("right.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>
<?php }} ?>