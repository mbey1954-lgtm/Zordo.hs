<?php /* Smarty version Smarty-3.1.8, created on 2022-09-24 04:53:52
         compiled from "application/views/templates/iptal_talepleri.tpl" */ ?>
<?php /*%%SmartyHeaderCode:538399533632e63301dabf3-66084364%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '4d47cbde06368e0b3b8437a4f94bc5a8772cc805' => 
    array (
      0 => 'application/views/templates/iptal_talepleri.tpl',
      1 => 1495298277,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '538399533632e63301dabf3-66084364',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'ilkt' => 0,
    'ikit' => 0,
    'bayilist' => 0,
    'liste' => 0,
    'row' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_632e633022c703_35432579',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_632e633022c703_35432579')) {function content_632e633022c703_35432579($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ("header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

<?php echo $_smarty_tpl->getSubTemplate ("left.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>



<script>
function sil(id) {
	if(confirm("<?php echo lang('duyrudel');?>
")) {
		self.location.href=baseurl+'ayar/iptaltalepleri/?ipid='+id;			
	}
}
function kupon_iptal(id) {

	if(confirm(id+" <?php echo lang('kupiptcnf');?>
")) {

	$.post(baseurl+'kuponlar/kuponiptal',{id:id},function(data) { 
	if(data=="1") { failcont("<?php echo lang('kupiptlshp');?>
"); } else
	if(data=="2") { failcont("<?php echo lang('iptonce');?>
"); } else
	if(data=="3") { failcont("<?php echo lang('kupiptlshp1');?>
"); } else {
		self.location.href=baseurl+'ayar/iptaltalepleri/';	
	}
	});
	}
}
$(document).ready(function(e) {
	
	$("#tarih1i, #tarih2i").datepicker({
		dateFormat: 'yy-mm-dd', changeMonth: true, changeYear: true
	});
});
</script>


	<div class="coupons">	
	<div class="coupon-title">
		<div class="account-table-blue"><span>
			<div class="icon"><i class="fa fa-user"></i></div>
			</span>
			<p><?php echo lang('ipttalp');?>
</p>
		</div>
		
		<div class="account-table-gray">
		<form method="post" action="<?php echo base_url();?>
ayar/iptaltalepleri">
		<label><?php echo lang('trh');?>
 :</label>
		<input name="tarih" type="text" id="tarih1i" value="<?php echo $_smarty_tpl->tpl_vars['ilkt']->value;?>
" readonly style="width:90px">  <input name="tarih1" type="text" id="tarih2i" value="<?php echo $_smarty_tpl->tpl_vars['ikit']->value;?>
" readonly style="width:90px">		
		
		<?php if ($_smarty_tpl->tpl_vars['bayilist']->value){?>					
		<label><?php echo lang('byler');?>
 :</label>
		<div class="selectbox">
		<select name="bayi" id="k_user">
		<option value=""></option>
		<?php echo $_smarty_tpl->tpl_vars['bayilist']->value;?>

		</select>
		</div>
		<?php }?>
		<button type="submit" id="sorgu"><?php echo lang('gtr');?>
</button>	
		
		</form>
		</div>
		
		<table style="width:100%" class="tftable" cellspacing="0" cellpadding="0">
		<thead>
		<th class="t"><?php echo lang('user');?>
</td>
		<th class="t"><?php echo lang('kpno');?>
</td>
		<th class="t"><?php echo lang('trh');?>
</td>
		<th class="t"><?php echo lang('msjtxt');?>
</td>
		<th class="t"><?php echo lang('sil');?>
</td>
		</tr></thead><tbody>
		
		<?php  $_smarty_tpl->tpl_vars['row'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['row']->_loop = false;
 $_smarty_tpl->tpl_vars['mac'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['liste']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['row']->key => $_smarty_tpl->tpl_vars['row']->value){
$_smarty_tpl->tpl_vars['row']->_loop = true;
 $_smarty_tpl->tpl_vars['mac']->value = $_smarty_tpl->tpl_vars['row']->key;
?>		
		<tr>
		<td width="80"><?php echo $_smarty_tpl->tpl_vars['row']->value->useri;?>
</td>
		<td width="30"><?php echo $_smarty_tpl->tpl_vars['row']->value->kuponid;?>
</td>
		<td width="10"><?php echo $_smarty_tpl->tpl_vars['row']->value->tarih;?>
</td>
		<td width="80"><?php echo $_smarty_tpl->tpl_vars['row']->value->mesaj;?>
</td>
		<td width="20">
		<?php if ($_smarty_tpl->tpl_vars['row']->value->kupdurum!=4){?><a href="javascript:;" style="color:green" onclick="kupon_iptal(<?php echo $_smarty_tpl->tpl_vars['row']->value->kuponid;?>
)">İptal Et</a> /<?php }?>
		<a href="javascript:;" style="color:red" onclick="sil(<?php echo $_smarty_tpl->tpl_vars['row']->value->id;?>
)">Sil</a></td>
		</tr>
		<tr></tr>
		
		<?php } ?>
		</tbody>
		</table>
		
		
</div>
</div>

<?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>
<?php }} ?>