<?php /* Smarty version Smarty-3.1.8, created on 2018-08-13 02:14:43
         compiled from "application/views/templates/macsonuclari.tpl" */ ?>
<?php /*%%SmartyHeaderCode:949077415b70bf63662904-81646129%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c739cfe9c64d98188e8d761bb5d75552aeade50b' => 
    array (
      0 => 'application/views/templates/macsonuclari.tpl',
      1 => 1495298292,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '949077415b70bf63662904-81646129',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'trh' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_5b70bf636c03e3_38328228',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5b70bf636c03e3_38328228')) {function content_5b70bf636c03e3_38328228($_smarty_tpl) {?><link rel="stylesheet" href="<?php echo base_url();?>
css/reset.css">
<link rel="stylesheet" href="<?php echo base_url();?>
css/base.css">
<?php if (@tema=='1'){?>
<link rel="stylesheet" href="<?php echo base_url();?>
css/tema.css">
<?php }?>
<script type="text/javascript" src="<?php echo base_url();?>
js/jquery.js"></script>

<script>
var baseurl = "<?php echo base_url();?>
";
function skorlarigetir() {
	var tarih = $("#livs_tarih").val();
	var sc = $("#livs_sc").val();
	var takim = $("#livs_takim").val();
	
	$.post(baseurl+'canlibahis/macsonuclaridata',{tarih:tarih,takim:takim},function(data) { 
		$("#canliskol").html(data); 
	});
}

$(document).ready(function(e) {

    $("#livs_tarih").change(function() { skorlarigetir(); });
	$("#livs_sc").change(function() { skorlarigetir(); });
	
	$("#livs_takim").change(function() { skorlarigetir(); });
	$("#livs_takim").keyup(function() { if($("#livs_takim").val()=="") { skorlarigetir(); } });
	skorlarigetir();

});
</script>


<div class="coupons">	
	<div class="coupon-title">
		<div class="account-table-blue"><span>
			<div class="icon"><i class="fa fa-user"></i></div>
			</span>
			<p><?php echo lang('msnclar');?>
</p>
		</div>
		
		<div class="account-table-gray">
		<form >
		<label><?php echo lang('trh');?>
 :</label>
		<div class="selectbox">
			<select id="livs_tarih">
				<?php echo $_smarty_tpl->tpl_vars['trh']->value;?>

			</select>
			</div>
		<label><?php echo lang('tkmadi');?>
 :</label>
		<input type="text" class="inputbet" id="livs_takim" >
		</form>
		</div>

		<div id="canliskol"></div>
</div>
</div>
<?php }} ?>