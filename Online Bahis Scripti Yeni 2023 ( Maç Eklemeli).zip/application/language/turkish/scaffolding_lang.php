<?php

$lang['scaff_view_records']		= 'Kayıtları Göster';
$lang['scaff_create_record']	= 'Yeni Kayıt Ekle';
$lang['scaff_add']				= 'Veri Ekle';
$lang['scaff_view']				= 'Veri Göster';
$lang['scaff_edit']				= 'Düzenle';
$lang['scaff_delete']			= 'Sil';
$lang['scaff_view_all']			= 'Tümünü Göster';
$lang['scaff_yes']				= 'Evet';
$lang['scaff_no']				= 'Hayır';
$lang['scaff_no_data']			= 'Bu tabloya henüz veri girilmemiş.';
$lang['scaff_del_confirm']		= 'Bu satırı silmek istediğinize emin misiniz ?';


/* End of file scaffolding_lang.php */
/* Location: ./system/language/english/scaffolding_lang.php */