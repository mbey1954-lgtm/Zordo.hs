<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$route['default_controller'] = "home";
$route['canlibahis/Superbahis'] = "canlibahis/index/Superbahis";
$route['canlibahis/Bwin'] = "canlibahis/index/Bwin";
$route['sonucgir'] = "sonucgir/sonucgir/index";

$route['mobil/canlibahis/Superbahis'] = "mobil/canlibahis/index/Superbahis";
$route['mobil/canlibahis/Bwin'] = "mobil/canlibahis/index/Bwin";
$route['mobil'] = "mobil/index";

$route['404_override'] = "hata";
