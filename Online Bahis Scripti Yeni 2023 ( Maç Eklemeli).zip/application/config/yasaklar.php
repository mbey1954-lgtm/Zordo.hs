<?php 
		$config['baskapat']="0";
		$config['dukapat']="0";
		$config['supkapat']="0";
		$config['bwinkapat']="0";
		?>