<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');


$autoload['packages'] = array();


$autoload['libraries'] = array('smarty','database', 'session','xmlrpc');



$autoload['helper'] = array('language','url', 'kontrol');



$autoload['config'] = array();



$autoload['language'] = array();



$autoload['model'] = array();
