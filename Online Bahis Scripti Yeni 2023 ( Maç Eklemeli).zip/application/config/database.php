<?php  
            //MySQL için Veritabani Ayarlari Degisiklik Tarihi : 09.17.2022 11:43:16 
            if ( ! defined('BASEPATH')) exit('No direct script access allowed');

            $active_group = "default";
            $active_record = TRUE;

            $db['default']['hostname'] = "localhost";
            $db['default']['username'] = "bbcanbets_onlinesystem";
            $db['default']['password'] = "bbcanbets_onlinesystem";
            $db['default']['database'] = "bbcanbets_onlinesystem";
            $db['default']['dbdriver'] = "mysqli";
            $db['default']['dbprefix'] = "";
            $db['default']['pconnect'] = false;
            $db['default']['db_debug'] = false;//veri tabanı hatası gösterme false
            $db['default']['cache_on'] = false;
            $db['default']['cachedir'] = "application/cache/";
            $db['default']['char_set'] = "utf8";
            $db['default']['dbcollat'] = "utf8_turkish_ci";
            
            
             