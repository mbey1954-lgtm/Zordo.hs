<?php
	
	function ajaxvarmi() {
		
		$ci=&get_instance();
		if (!$ci->input->is_ajax_request()) {
			//redirect(base_url()."login");
		    exit;
		}
	}
	
	function logged_admin($git='') {
		
		$ci=&get_instance();
		$is_logged_in = $ci->session->userdata('is_logged_Bet');
		//$masaustu = $ci->session->userdata('masaustu');
		define('title','BeyPlaying');
		/*if($git=='' && $masaustu==''){
			redirect(base_url()."mobil/index");
		}*/
		if(empty($is_logged_in) || $is_logged_in != true){
			/*if($ci->input->is_ajax_request()){
				echo'<script>window.top.location.href="'.base_url().''.$git.'login/logout";</script>';
				exit;
			}else{
				redirect(base_url()."".$git."login/logout");
				exit;
			}*/
			if(curpagename(1)=='kuponlar' || curpagename(1)=='raporlar' || curpagename(1)=='oranmerkezi' || curpagename(1)=='ayar' || curpagename(1)=='bayiler' || curpagename(1)=='bayikayit' || curpagename(1)=='detay' || curpagename(1)=='sonucgirsistem' || curpagename(1)=='mesaj'){
				redirect(base_url());exit;
			}
			if(curpagename(2)=='kuponlar' || curpagename(2)=='raporlar'){
				redirect(base_url($git));exit;
			}
			$bayigel = $ci->db->query("select a.*,(select CONCAT(soket,'|',ref,'|',aktifcanli,'|',domainler) from sistemayar where id=1) as sisayar from kullanici a where a.id=7 ")->row();
			
			$sayr=explode('|',$bayigel->sisayar);
			$soket=$sayr[0];
			$ref=$sayr[1];
			$aktifcanli=$sayr[2];
			$domainler=$sayr[3];
			
			define('direk',1);
			unset($bayigel->sisayar);
			define('ref',$ref);
			define('aktifcanli',$aktifcanli);
			define('domainler',$domainler);
			define('soket',$soket);
			
			$badi='';
			if($bayigel->yetki==4){//bayi
				$kendi=$bayigel->hesap_sahibi_id;
				$ustu=$bayigel->hesap_root_id;
			}else{
				$kendi=$bayigel->hesap_sahibi_id;
				$ustu=$bayigel->hesap_sahibi_id;
			}
			$patron=1;
			
			//print_R($ci->session->all_userdata());			
			define('sesid',$ci->session->userdata('session_id'));
			define('ustbayi',$badi);
			define('kendi',$kendi);
			define('ustu',$ustu);
			define('patron',1);
			define('para','TL');
			
			foreach($bayigel as $id=>$tumrow){
				@define($id,$tumrow);
				if($id=='ayarlar'){
					$ayr=@unserialize($tumrow);
					foreach($ayr as $aid=>$ayarlar){
						//print_R($aid);
						define($aid,$ayarlar);
					}
				}
			}
			if($ci->session->userdata('dil')){
				define('dil',$ci->session->userdata('dil'));
				define('dilb',str_replace('tr','',$ci->session->userdata('dil')));
			}else{
				define('dil','tr');
				define('dilb','');
			}
			dilal();
		}else{
			
			$bayigel = $ci->db->query("select a.*,(select CONCAT(soket,'|',ref,'|',aktifcanli,'|',domainler) from sistemayar where id=1) as sisayar from kullanici a where a.id=".sesionlar('id')." ")->row();
			if($bayigel->durum==0 || $bayigel->aktif==0){
				redirect(base_url()."".$git."login/logout");
				exit;
			}
			
			$sayr=explode('|',$bayigel->sisayar);
			$soket=$sayr[0];
			$ref=$sayr[1];
			$aktifcanli=$sayr[2];
			$domainler=$sayr[3];
			if($ref==1 && $ci->uri->segment(1) && $_SERVER['HTTP_REFERER']=='' && !isset($_GET['p'])){
				redirect(base_url()."".$git."hata/uyari");
				exit;
			}
			unset($bayigel->sisayar);
			define('ref',$ref);
			define('aktifcanli',$aktifcanli);
			define('domainler',$domainler);
			define('soket',$soket);
			
			$badi='';
			if($bayigel->yetki==4){//bayi
				$kendi=$bayigel->hesap_sahibi_id;
				$ustu=$bayigel->hesap_root_id;
			}else{
				$kendi=sesionlar('id');
				$ustu=$bayigel->hesap_sahibi_id;
			}
			$patron=1;
			
			//print_R($ci->session->all_userdata());			
			define('sesid',$ci->session->userdata('session_id'));
			define('ustbayi',$badi);
			define('kendi',$kendi);
			define('ustu',$ustu);
			define('patron',1);
			define('para','TL');
			//define('cbahis','Canlı Bahis');
			if($ci->session->userdata('dil')){
				define('dil',$ci->session->userdata('dil'));
				define('dilb',str_replace('tr','',$ci->session->userdata('dil')));
			}else{
				define('dil','tr');
				define('dilb','');
			}
			
			
			foreach($bayigel as $id=>$tumrow){
				define($id,$tumrow);
				if($id=='ayarlar'){
					$ayr=@unserialize($tumrow);
					foreach($ayr as $aid=>$ayarlar){
						//print_R($aid);
						define($aid,$ayarlar);
					}
				}
			}
			define('direk',0);
			if(sistemikapat==1 && yetki!=1){
				redirect(base_url()."".$git."login/logout");
				exit;
			}
			if(yetki!=1 && yetki!=2 && domain!='0'){
				redirect(base_url()."".$git."login/logout");			
			}
			if (isset($_GET['p'])){$ci->output->enable_profiler();}
			dilal();
		}		
	}
	function dilal() {
		$ci=&get_instance();
		$dili=$ci->session->userdata('dil');
		if($dili==''){
			$ci->lang->load('site_cevir', 'tr');
		}else{
			$ci->lang->load('site_cevir', $dili);
		}						
	}
	
	function temizle($a){
		$klm = str_replace(array('ğ','ü','ş','ı','ö','ç','/','&',' ','(',')'), array('g','u','s','i','o','c','','','','',''), mb_strtolower($a, 'UTF-8'));
		return trim($klm);
	}
		
	function cikti(){
		$ci=&get_instance();
		return $ci->output->enable_profiler(TRUE); 
	}
		
	function kapalimi() {
		$ci=&get_instance();
		return $ci->config->item('sistemikapat');
	}
	
	function yasaklimi($yer) {
		$ci=&get_instance();
		return $ci->config->item($yer);
	}
	
	function mobilhead(){
		if(tema==1){
			$moblg='logom1';
			$stylesi="border-bottom: 5px solid #126F8E;background:#d38747;box-shadow: 0 0 6px 1px black;box-sizing: border-box;height: 43px;max-height: 43px;  overflow: hidden;padding: 0 2.5%;width: 100%;";
			$cls='';
		}else{
			$moblg='logom';
			$stylesi='';
			$cls='header';
		}
		if(direk==1){
			$ekle='<div class="icon " style="color: #fff;font-size: 25px;"><a href="'.base_url().'kayit/indexm" class="active"><img src="/images/kayit-ol-butonu.png" width="100"></a></div>';
		}else{
			$ekle='<div class="icon " style="color: #fff;font-size: 25px;"><a onclick="go(\'login/logout\')" class="active"><i class="fa fa-power-off "></i></a></div>';
		}
		return '<div class="'.$cls.'" style="'.$stylesi.'">'.$ekle.' 
		<div class="icon" style="max-width: 50px;"><img onclick="$zopim.livechat.window.show();" src="http://m.sakabet.com/assets/img/chat_tr_mob.png"></div>
	<div class="text title noselect" style="width: 100%;color: white;font-weight: bold;text-align: center;"><img onclick="go(\'index\')" src="/images/'.$moblg.'.png" height="28" width="100"></div>
	<div style="max-width: 50px;" class="icon">
		<div class="main-user-account">
			<i class="fa  fa-user"></i>
			<strong id="bakiyem">'.nf(bakiye).'</strong>		
		</div>
	</div>
</div>';
	}
	
	function bayi_ayargetir($alan){		
		$ayr = @unserialize($bayigel->ayarlar);
		return	$ayr[$alan];	
	}
	
	function sesionlar($sess){
		$ci=&get_instance();
		return $ci->session->userdata($sess);
	}
	
	function curpagename($ne){
		$ci=&get_instance();
		return $ci->uri->segment($ne);
		//if($ci->uri->segment(3)){return $ci->uri->segment(3);}else{return $ci->uri->segment(2);}
	}
	
	function sonislemtime(){
		$ci=&get_instance();
		//$ci->session->set_userdata('last_activity', time());
		if($ci->uri->segment(2)!='sistemdekiler' && direk==0){		
			$ci->db->update('kullanici', array('sonislem' => time(),'sayfa' => base_url().$ci->uri->segment(1).'/'.$ci->uri->segment(2)), array('id' =>id));
		}
	}
	
	function acmahakki(){
		$ci=&get_instance();
		if(yetki == 2 || yetki == 3 || (yetki == 4 && wyetki==1)){
			$hakdurum=0;
			$toplam_kullanici = $ci->db->query("select id from kullanici where hesap_sahibi_id='".id."' and durum='1'")->num_rows;
			$acabildigi = alt_sinir;
			if($toplam_kullanici>=$acabildigi) {
				$hakdurum=$acabildigi;
			}
			return $hakdurum;
		}else{
			return 1;
		}
	}
	
	function nf($str) { 
		return number_format($str,2,".",".");
	}
	
	function nfss($str) { 
		return number_format($str,2,".",""); 
	}
	
	function idcode($str) { 
		return md5($str); 
	}
	
	function codekupon($str) { 
		return base64_encode($str); 
	}
	
	function decodekupon($str) { 
		return base64_decode($str); 
	}
	
	function oranana_temizle($orver){
	
	if(strstr($orver, "d")){
		$orver=str_replace('d','',$orver);
		if($orver=="" || $orver<=1.01) {
			$donen = "-";
		}else{
			$donen = nf($orver);
		}
	}else if($orver=="" || $orver<1.01) {
		$donen = "-"; 
	}else{
		$donen = nf($orver);
	}
	return $donen;
	}

	function takimadikisalt($str) {
		return ucwords(mb_substr($str,0,25,'utf-8'));	
	}

	function takimadikisaltkupon($str) {
		return ucwords(mb_substr($str,0,11,'utf-8'));
	}

	function turkce_tarih_kisa($pul) {
		$gunler = array('Pzr', 'Pzt', 'Sal', 'Çar', 'Per', 'Cum', 'Cmt');
		return $gunler[date("w", $pul)];
	}

	function duyurular(){
		
		$ci=&get_instance();
		if(yetki == 4 || yetki == 5){$user=patron.",".kendi.",".ustu;}else{$user=patron.",".id.",".ustu;}
		$sqlyaz="select mesaj from duyurular  where user_id in(".$user.") ORDER BY id desc";
		$sql = $ci->db->query($sqlyaz);
		if($sql->num_rows()>0) {
			$duyuru = '<ul >';
			foreach($sql->result() as $row){
				$duyuru.='<li style="float:left;padding-right:10px">
				'.$row->mesaj.'
				</li>';
			}
			$duyuru.='</ul>';
			//$duyuru.='<span style="float:right"><img src="/img/dyr.png"></img></span>';
		}else{
			$duyuru='';
		}
		return $duyuru;
	}
	
	function turkce_tarih($pul) {
		$gunler = array('Pazar', 'Pazartesi', 'Salı', 'Çarşamba', 'Perşembe', 
		'Cuma', 'Cumartesi');
		$aylar = array('', 'Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran', 
		'Temmuz', 'Ağustos', 'Eylül', 'Ekim', 'Kasım', 'Aralık');
		return date("d ", $pul).$aylar[date("n", $pul)]." ".$gunler[date("w", $pul)];
	}

	function kupa_isim_temizle($str) {
		$o = array(''.date("Y").'-'.date("Y",strtotime("+1 year")).'',''.date("Y").'',''.date("Y",strtotime("-1 year")).'','-');
		$s = array('','','','');
		return mb_substr(str_replace($o,$s,$str),0,50,'utf-8');
	}
	
	function bultenisil($tablo=''){
		
		$ci=&get_instance();
		$suan = time();
		
		$kontrol_sql = $ci->db->query("select id from program$tablo where mac_time<$suan");
		if($kontrol_sql->num_rows()>0) {
			foreach($kontrol_sql->result() as $row){
				$ci->db->query("delete from oranlar$tablo where mac_db_id='".$row->id."'");
				$ci->db->query("delete from program$tablo where id='".$row->id."'");
				$ci->db->query("delete from oranver$tablo where (lig_mac=".$row->id." or gizliler=".$row->id.")");
			}
		}
	}
	
	function canlisil($tablo=''){
		
		$ci=&get_instance();
		$suan = time()-1800;
		$ver="select id,eventid from canli_maclar$tablo where songuncelleme<$suan";
		$kontrol_sql = $ci->db->query($ver);
		if($kontrol_sql->num_rows()>0) {
			foreach($kontrol_sql->result() as $row){
				$ci->db->query("delete from canli_maclar$tablo where id='".$row->id."'");
				//$ci->db->query("delete from canli_gol_list where eventid='".$row->eventid."'");				
				$ci->db->query("delete from canli_oran$tablo where mac_id='".$row->eventid."'");				
				$ci->db->query("delete from coranver$tablo where (lig_mac=".$row->eventid." or gizliler=".$row->eventid.")");
			}
		}
	}

	function hdkal1($id,$oran_val_id) {
	
		$ci=&get_instance();
		$donens = "";
		$oran = $ci->db->query("select oran_val_b from oranlarb where mac_db_id='$id' and oran_val_id in($oran_val_id) ");
		foreach($oran->result_array() as $row){
			$donens.= "$row[oran_val_b]|";
		}
		return substr($donens,0,-1);
	}
	
	function kupondavarmi($tur,$session_id) {
	
		$ci=&get_instance();
		$sor = $ci->db->query("select spor_tip from kupon where session_id='$session_id' and onlem='".sesid."' and spor_tip='$tur'");
		if($sor->num_rows()>0) {
			$donen = "1";
		} else {
			$donen = "0";
		}
		return $donen;
	}
	
	function bonus_hesapla($mac) {
		
		$ci=&get_instance();
		if(bonus == 1){	
			$ver="SELECT bonus FROM bonus WHERE minm <= $mac and maxm >= $mac and user=if(EXISTS(SELECT bonus FROM bonus WHERE user=".kendi."),".kendi.",".patron.")";
			$sor = $ci->db->query($ver);
			if($sor->num_rows() > 0) {
				$row = $sor->row();
				$donen=$row->bonus;
			}else{
				$donen=0;
			}
		}else{
			$donen=0;
		}
		return $donen;
	}
	
	function ulkeler($ne){
		
		$bas='';
		$ci=&get_instance();
		
		if($ne==1){
			$sor = $ci->db->query("select b.lig_ulke,b.lig_adi,count(a.kupa_id) as say,b.id from program a left join program_lig b on b.id=a.kupa_id and b.hangi=1 group by a.kupa_id");
			$fsay=0;
			foreach($sor->result() as $ass){
				//$fsay= $fsay+$ass->say;
				$bas.="<option value=".$ass->id.">".$ass->lig_adi."</option>";
			}
			//$bas['fs'].= $fsay;
		}
		
		if($ne==2){
			$sorb = $ci->db->query("select b.lig_adi,count(a.kupa_id) as say,b.id from programb a left join program_lig b on b.id=a.kupa_id and b.hangi=2 group by a.kupa_id");
			$bsay=0;
			foreach($sorb->result() as $assb){
				//$bsay= $bsay+$assb->say;
				$bas.="<option value=".$assb->id.">".$assb->lig_adi."</option>";
			}
			//$bas['bs'].= $bsay;
		}
		return $bas;
	}
	function bultentarihm($tablo,$duelmi){
		
		$ci=&get_instance();
		$text2="";
		if($duelmi==1){
			$where_ekle = " where program_tip='duello'";
		}else if($tablo!='b'){
			if($tablo=='i'){
				$tablo='';
				$where_ekle = " where program_tip='futbol' and iddaa_kodu !=''";
			}else{
				$where_ekle = " where program_tip='futbol' and (d_kodu !='' or mac_kodu !='')";
			}
		}else if($tablo=='b'){
			$where_ekle = " where mac_kodu !=''";
		}
		$al="SELECT DISTINCT(mac_tarih) FROM program$tablo $where_ekle order by mac_time asc";
		$result = $ci->db->query($al);
		if ($result->num_rows() > 0) {
			foreach($result->result_array() as $row){
				$tarihkes = explode(".",$row['mac_tarih']);
				$guntime = mktime(0,0,0,$tarihkes[1],$tarihkes[0],$tarihkes[2]);
				$tarih = turkce_tarih($guntime);
				$sec='';
				if(date("d.m.Y") == $row['mac_tarih']) {$sec='selected';}else 
				if(date("d.m.y") == $row['mac_tarih']) {$sec='selected';}
				$text2.= "<option value=".$row['mac_tarih']."  ".$sec.">".$tarih."</option>";   
			}			
		}
		return $text2;
	}
	function bultentarih($tablo,$duelmi){
		
		$ci=&get_instance();
		$text2="";
		if($duelmi==1){
			$where_ekle = " where program_tip='duello'";
		}else if($tablo=='t' || $tablo=='h' || $tablo=='o'){
			$where_ekle = "";
		}else if($tablo!='b'){
			if($tablo=='i'){
				$tablo='';
			}else{
			}
			$where_ekle = " where program_tip='futbol'";
		}
		$ptesi=date("d",strtotime('+1 week last Monday'));
		$ver="SELECT DISTINCT(mac_tarih) FROM program$tablo $where_ekle order by mac_time asc";
		$result = $ci->db->query($ver);
		if ($result->num_rows() > 0) {
			foreach($result->result_array() as $row){
				$tarihkes = explode(".",$row['mac_tarih']);
				$guntime = mktime(0,0,0,$tarihkes[1],$tarihkes[0],$tarihkes[2]);
				$tarih = turkce_tarih($guntime);
				$sec='';
				if($tablo!='b'){//&& $tarihkes[0]<=$ptesi				
					if(date("d.m.Y") == $row['mac_tarih']) {$sec='selected';}else 
					if(date("d.m.y") == $row['mac_tarih']) {$sec='selected';}
					$text2.= '<li onclick="$(\'#tarihb\').val(\''.$row['mac_tarih'].'\');$(\'#trhilk\').text(\''.$tarih.'\');loadbulten();bultrhac(1);" id="'.$row['mac_tarih'].'"><p >'.$tarih.'</p></li>';
				}else if($tablo=='b'){
					if(date("d.m.Y") == $row['mac_tarih']) {$sec='selected';}else 
					if(date("d.m.y") == $row['mac_tarih']) {$sec='selected';}
					$text2.= '<li onclick="$(\'#tarihb\').val(\''.$row['mac_tarih'].'\');$(\'#trhilk\').text(\''.$tarih.'\');loadbulten();bultrhac(1);" id="'.$row['mac_tarih'].'"><p >'.$tarih.'</p></li>';
				}
			}			
		}
		return $text2;
	}
	
	function oranmerkez_oranver($oranvalid,$uid,$gelenlig,$dosya,$tablo){
		
		$ci=&get_instance();
		$sor = $ci->db->query("select oran from $tablo where oranvalid=$oranvalid and lig_mac=$gelenlig and uye=$uid and tip='$dosya'");
		if($sor->num_rows()>0) {
			$donecek=$sor->row()->oran;
		}else{
			$donecek='0.00';
		}
		return $donecek;
	}
	
	function oranmerkez_gizlitip($oranvalid,$uid,$gelenlig,$dosya,$tablo) {
	
		$ci=&get_instance();
		$sor = $ci->db->query("select id from $tablo where oranvalid=$oranvalid and lig_mac=$gelenlig and uye=$uid and tip='$dosya'");
		if($sor->num_rows()>0) {
			$donecek = "";
		}else{
			$donecek='checked';
		}
		return $donecek;	
	}
	
	function lig_gizlidurum($uid,$gelenlig,$dosya,$tablo) {
	
		$ci=&get_instance();
		$sor = $ci->db->query("select id from $tablo where gizliler=$gelenlig and uye=$uid and tip='$dosya'");
		if($sor->num_rows()>0) {
			$donecek='1';
		}else{
			$donecek='0';
		}
		return $donecek;
	}
	
	function sabitmbs($uid,$gelenlig,$dosya,$tablo) {
	
		$ci=&get_instance();
		$sor = $ci->db->query("select mbs from $tablo where lig_mac=$gelenlig and uye=$uid and tip='$dosya'");
		if($sor->num_rows()>0) {
			$donecek=$sor->row()->mbs;
		}else{
			$donecek='';
		}
		return $donecek;
	}
	
	function direkoranustlu($oranvalid,$uid,$gelenlig,$dosya,$tablo,$gelenoran) {
	
		$ci=&get_instance();
		$sor = $ci->db->query("select oran from $tablo where oranvalid=$oranvalid and lig_mac=$gelenlig and uye=$uid and tip='$dosya'");
		if($sor->num_rows()==0) {
			$sor = $ci->db->query("select oran from $tablo where oranvalid=$oranvalid and lig_mac=$gelenlig and uye=1 and tip='$dosya'");
		}
		if($sor->num_rows()>0) {
			$donecek=$sor->row()->oran;
		}else{
			$donecek=$gelenoran;
		}
		return nf($donecek);	
	}
	
	function surekli_aski_durum($gol,$sonoranguncelleme,$aski) {
	
		$suan = time();
		$fark = abs($suan-$gol);

		$yuksegi = time()-90;
		if($sonoranguncelleme<$yuksegi) {
			$donen = "1";
		}else
		if($fark<60) {
			$donen = "1";
		}else
		if($aski) {
			$donen = "1"; 
		} else {
			$donen = "0"; 
		}
		//echo $donen;
		return $donen;
	}
	
	function temizyuzde($str) {
		
		if(strlen($str)==1) { $donen = "0".$str.""; } else
		if(strlen($str)==2 && $str<1) { $donen = "0".abs($str).""; } else
		if(strlen($str)==3 && $str<1) { $donen = abs($str); } else
		{ $donen = $str; }
		return $donen;
	}

	function oranyuzdehesapla($oran,$yuzde){
		
		$temizyuzde = temizyuzde($yuzde);
		
		if(strpos($yuzde,".") && $yuzde<0) {
			$donsun = $oran+$yuzde;
		} else	if(strpos($yuzde,".") && $yuzde>0) {
			$donsun = $oran+$yuzde;	
		} else	if(strpos($yuzde,".")!=true && $yuzde<0) {
			$carp = $oran*("0.".$temizyuzde."");
			$donsun = $oran-$carp;	
		} else	if(strpos($yuzde,".")!=true && $yuzde>0) {
			$carp = $oran*("0.".$temizyuzde."");
			$donsun = $oran+$carp;	
		}
		return $donsun;	
	}

	function canlida_oran($userler,$mac_id,$kuponid,$oran_id,$yap) {
	
		$ci=&get_instance();
		
		$us=explode(',',$userler);
		$kendi=$us[0];
		$ustu=$us[1];
		$patron=$us[2];
		$fark = time()-35;
		/*if($yap){
			$songunc='and b.gunceldestek=1';
		}else{
			$songunc='';
		}*/
		$songunc='and b.gunceldestek=1';
		$yeni='SELECT a.aktif,a.dakika,a.devre,a.ev_skor,a.konuk_skor,a.gol,a.sonoranguncelleme,b.askida,
			(SELECT gizliler FROM coranver WHERE oranvalid=0 and lig_mac=0 and uye in('.$userler.') and gizliler=a.eventid and tip="aski") as surekliaski,
			if(a.devre = "1. Yarı" and a.dakika >= '.canli_dk_kes.',1,0) as ilkyarigizle,
			GROUP_CONCAT(
			   (		
				case				
				when c.tip="tumcanli" then CONCAT(ROUND(oranyuzdehesapla(b.oran,(c.oran+IFNULL(m.oran,0))),2))		
				when m.tip="maccanli" then CONCAT(ROUND(oranyuzdehesapla(b.oran,m.oran),2))		
				else CONCAT(ROUND(b.oran,2))
				end
				)
			) as sonoran

			FROM canli_maclar a
			
			left join canli_oran b on b.mac_id=a.eventid and b.canli_tip not in((SELECT oranvalid FROM coranver WHERE lig_mac in(0,a.eventid) and uye in('.$userler.') and tip="gizlioran")) and b.oran_adi not in((SELECT oranvalid FROM coranver WHERE lig_mac in(0,a.eventid) and uye in('.$userler.') and tip="gizlioranic")) and b.oran_adi='.$oran_id.'
			
			left join coranver c on c.oranvalid=b.oran_adi and c.lig_mac = 0 and c.uye =(
			if(EXISTS(SELECT uye FROM coranver WHERE oranvalid=b.oran_adi and lig_mac = 0 and uye='.$kendi.' and tip="tumcanli")
			,'.$kendi.',if(EXISTS(SELECT uye FROM coranver WHERE oranvalid=b.oran_adi and lig_mac = 0 and uye='.$ustu.' and tip="tumcanli"),'.$ustu.','.$patron.'))
			) and c.tip="tumcanli"

			left join coranver m on m.oranvalid=b.oran_adi and m.lig_mac = a.eventid and m.uye=(
			if(EXISTS(SELECT uye FROM coranver WHERE oranvalid=b.oran_adi and lig_mac = a.eventid and uye='.$kendi.' and tip="maccanli")
			,'.$kendi.',if(EXISTS(SELECT uye FROM coranver WHERE oranvalid=b.oran_adi and lig_mac = a.eventid and uye='.$ustu.' and tip="maccanli"),'.$ustu.','.$patron.'))
			) and m.tip="maccanli"
		
			where a.eventid='.$mac_id.' and a.sonoranguncelleme>'.$fark.' '.$songunc.'
			and a.dakika <='.canli_dk_kes1.'
			and a.adminid=(if(a.adminid='.$kendi.','.$kendi.',0))
			group by b.mac_id,a.adminid';
		
		
		$v = $ci->db->query($yeni);
		if($v->num_rows()>0){
			
			$o=$v->row();
			//$farkdestek = time() - $o->gunceldestek;
			
			$surekli_aski_durum = surekli_aski_durum($o->gol,$o->sonoranguncelleme,$o->surekliaski);
			$bulunan_oran=$o->sonoran;
			if(!empty(canli_koruma) && canli_koruma!='0.00' && $bulunan_oran >= canli_koruma){
				$bulunan_oran=canli_koruma;
			}
			//||$guncel<$farkdestek
			if(!$bulunan_oran || $o->aktif==0  || $surekli_aski_durum==1 || $o->askida==0 || $o->ilkyarigizle==1) {
				$ci->db->query("update kupon set aktif='0' where id='$kuponid'");
				return 1;
			}else{
				$ci->db->query("update kupon set aktif='1',oran='$bulunan_oran' where id='$kuponid'");
				return 0;
			}
		}else {
			$ci->db->query("update kupon set aktif='0' where id='$kuponid'");
			return 1;
		}
		
	}
	function canlida_oranb($userler,$mac_id,$kuponid,$oran_id,$yap) {
	
		$ci=&get_instance();
		
		$us=explode(',',$userler);
		$ctip=explode('|',$oran_id);
		$canli_tip=$ctip[0];
		$oran_adi=$ctip[1];
		$kendi=$us[0];
		$ustu=$us[1];
		$patron=$us[2];
		$fark = time()-35;
		$songunc='and b.gunceldestek=1';
		$yeni='SELECT a.aktif,a.dakika,a.devre,a.ev_skor,a.konuk_skor,a.gol,a.sonoranguncelleme,b.askida,
			(SELECT gizliler FROM coranverb WHERE oranvalid=0 and lig_mac=0 and uye in('.$userler.') and gizliler=a.eventid and tip="aski") as surekliaski,
			GROUP_CONCAT(
			   (		
				case				
				when c.tip="tumcanli" then CONCAT(ROUND(oranyuzdehesapla(b.oran,(c.oran+IFNULL(m.oran,0))),2))		
				when m.tip="macbasket" then CONCAT(ROUND(oranyuzdehesapla(b.oran,m.oran),2))		
				else CONCAT(ROUND(b.oran,2))
				end
				)
			) as sonoran

			FROM canli_maclarb a
			
			left join canli_oranb b on b.mac_id=a.eventid and b.canli_tip="'.$canli_tip.'" and b.canli_tip not in((SELECT oranvalid FROM coranverb WHERE lig_mac in(0,a.eventid) and uye in('.$userler.') and tip="gizlioran")) and b.oran_adi not in((SELECT oranvalid FROM coranverb WHERE lig_mac in(0,a.eventid) and uye in('.$userler.') and tip="gizlioranic")) and b.oran_adi="'.$oran_adi.'"
			
			left join coranverb c on c.oranvalid=b.canli_tip and c.lig_mac = 0 and c.uye =(
			if(EXISTS(SELECT uye FROM coranverb WHERE oranvalid=b.canli_tip and lig_mac = 0 and uye='.$kendi.' and tip="tumcanli")
			,'.$kendi.',if(EXISTS(SELECT uye FROM coranverb WHERE oranvalid=b.canli_tip and lig_mac = 0 and uye='.$ustu.' and tip="tumcanli"),'.$ustu.','.$patron.'))
			) and c.tip="tumcanli"

			left join coranverb m on m.oranvalid=b.canli_tip and m.lig_mac = a.eventid and m.uye=(
			if(EXISTS(SELECT uye FROM coranverb WHERE oranvalid=b.canli_tip and lig_mac = a.eventid and uye='.$kendi.' and tip="macbasket")
			,'.$kendi.',if(EXISTS(SELECT uye FROM coranverb WHERE oranvalid=b.canli_tip and lig_mac = a.eventid and uye='.$ustu.' and tip="macbasket"),'.$ustu.','.$patron.'))
			) and m.tip="macbasket"
		
			where a.eventid='.$mac_id.' and a.sonoranguncelleme>'.$fark.' '.$songunc.'
			group by b.mac_id';
		
		
		$v = $ci->db->query($yeni);
		if($v->num_rows()>0){
			
			$o=$v->row();
			//$farkdestek = time() - $o->gunceldestek;
			
			$surekli_aski_durum = surekli_aski_durumb($o->sonoranguncelleme,$o->surekliaski);
			$bulunan_oran=$o->sonoran;
			if(!empty(canli_koruma) && canli_koruma!='0.00' && $bulunan_oran >= canli_koruma){
				$bulunan_oran=canli_koruma;
			}
			//||$guncel<$farkdestek
			if(!$bulunan_oran || $o->aktif==0  || $surekli_aski_durum==1 || $o->askida==0 || $o->ilkyarigizle==1) {
				$ci->db->query("update kupon set aktif='0' where id='$kuponid'");
				return 1;
			}else{
				$ci->db->query("update kupon set aktif='1',oran='$bulunan_oran' where id='$kuponid'");
				return 0;
			}
		}else {
			$ci->db->query("update kupon set aktif='0' where id='$kuponid'");
			return 1;
		}
		
	}
	
	function surekli_aski_durumb($sonoranguncelleme,$aski) {
	
		$yuksegi = time()-90;
		if($sonoranguncelleme<$yuksegi) {
			$donen = "1";
		}elseif($aski) {
			$donen = "1"; 
		} else {
			$donen = "0"; 
		}
		//echo $donen;
		return $donen;
	}
	
	function sporyaz($id) {
		if($id=="futbol") { $donen = lang('futbol'); } else
		if($id=="duello") { $donen = lang('duello'); } else
		if($id=="basketbol") { $donen = lang('basket'); } else
		if($id=="tenis") { $donen = lang('tenis'); } else
		if($id=="hentbol") { $donen = lang('hentbol'); } else
		if($id=="hokey") { $donen = lang('hokey'); } else
		if($id=="canli") { $donen = lang('cfut'); } else
		if($id=="canlib") { $donen = lang('cbasket'); }
		return $donen;
	}
	
	function durumnedir($id) {
		if($id=="1") { $donen = lang('bacik'); } else
		if($id=="2") { $donen = lang('kaz'); } else
		if($id=="3") { $donen = lang('kay'); } else
		if($id=="4") { $donen = lang('ipt'); }else
		if($id=="5") { $donen = lang('ert'); }
		return $donen;
	}
	
	function yuzde($a,$b){
		if(empty($a) || empty($b)) { $donecek = "0"; } else { 
		$c = $a / 100; 
		$donecek = "%".nf($b/$c)."";
		}
		return $donecek;
	}
	
	function n($str) { 
		return number_format($str,0,".","."); 
	}
	
	function hesap_hareket($tip,$username,$uid,$tutar,$aciklama,$kuponid) {

		$ci=&get_instance();
		$uidbul = $ci->db->query("select bakiye from kullanici where id='$uid'")->row_array();
		if($tip=="ekle") {
			$ci->db->query("update kullanici set bakiye=bakiye+$tutar where id='$uid'");
		} else
		if($tip=="cikar") {
			$kalan=$uidbul['bakiye']-$tutar;
			if($kalan<1){$ver=0;}else{$ver="bakiye-$tutar";}
			$ci->db->query("update kullanici set bakiye=$ver where id='$uid'");
		}
		$ci->db->query("insert into hesap_hareket (user_id,username,tip,tutar,aciklama,islemi_yapan,zaman,onceki_tutar,nerden,kuponid) values ('$uid','$username','$tip','$tutar','$aciklama','".username."','".time()."','$uidbul[bakiye]','site','$kuponid')");	
	}
	
	function basla_time($id) {
		$bol = explode("-",$id);
		$donen = mktime(0,0,0,$bol[1],$bol[0],$bol[2]);
		return $donen;
	}

	function bitir_time($id) {
		$bol = explode("-",$id);
		$donen = mktime(23,59,59,$bol[1],$bol[0],$bol[2]);
		return $donen;
	}
	
	function anlasma_turs($id,$tip) {
		$donen='';
		if($tip==1) {
			if($id==0) { $donen = lang('komsuz'); } else
			if($id==1) { $donen = lang('ciro'); } else
			if($id==2) { $donen = lang('srk_kar'); }
		}else if($tip==2) {
			if($id==0) { $donen = lang('komsuz'); } else
			if($id==1) { $donen = lang('ciro'); } else
			if($id==2) { $donen = lang('srk_kar'); }
		}
		return $donen;
	}
	
	function carpan($yuzde){
		
		if(strlen($yuzde)<2) {
			$donen = "0.0".$yuzde."";
		} else {
			$donen = "0.".$yuzde."";
		}
		return $donen;
	}
		
	function wbayilerim($kim){
		$ci=&get_instance();
		$bas='';
		$ver="select id from kullanici where id!=1 and durum=1 and hesap_sahibi_id=".$kim."";
		$sor = $ci->db->query($ver);
		foreach($sor->result() as $ass){				
			$bas.=$ass->id.',';	
		}
		$son= substr($bas,0,-1);
		if($son){$byver=$son.','.$kim;}else{$byver=$kim;}
		return $byver;
	}
	
	function bayioption(){
		
		$ci=&get_instance();
		$bas='';
		$uyelerim='';
		$grup='';
		$wyaz='';
		if(yetki !=5) {
			if(yetki ==2) {
				$uyelerim=' and (hesap_sahibi_id='.id.' or hesap_root_id='.id.')';//super
			}else if(yetki ==3) {
				$uyelerim=' and (hesap_sahibi_id='.id.')';//admin
			}else if(yetki ==4 && wyetki == 1) {
				$wyaz=1;
				$grup='<optgroup label="'.lang('webler').'">';
				$uyelerim=' and hesap_sahibi_id='.id;//bayi
			}else if(yetki == 1) {
				$uyelerim='';
			}else{
				return false;
			}
			$ver="select id,username from kullanici where id!=1 and durum=1 and yetki in(4,5) $uyelerim order by username asc";
			$sor = $ci->db->query($ver);
			foreach($sor->result() as $ass){
				/*if($wyaz){
					$bas.='<option value="'.id.'">(Sadece Kendiniz)</option>';
				}*/
				//$bas.=$grup;		
				$bas.='<option value="'.$ass->id.'">'.$ass->username.'</option>';		
			}
			return $bas;
		}
		return false;
	}
	
	function bahisyasak($yetki,$id,$ne){
		if($yetki == 4 || $yetki == 5){
			$ci=&get_instance();
			$ver="select * from ayar where user=".$id." and neolsun=".$ne."";
			$sorgu = $ci->db->query($ver);
			if ($sorgu->num_rows() > 0) {
				$kapat=$sorgu->row();
				$iv=$kapat->ilkveri;
				$ikv=$kapat->ikiveri;
				$suanzaman=date('H:i');
				if(($iv && $ikv) && $suanzaman >= $iv && $suanzaman <= $ikv){
					return 1;
				}
			}
		}
	}
	
	function bayilerim(){
		
		$ci=&get_instance();
		$bas='';
		if(yetki !=5) {
			if(yetki ==2) {
				$uyelerim=' and (hesap_sahibi_id='.id.' or hesap_root_id='.id.' or hesap_root_root_id='.id.')';//super
			}else if(yetki ==3) {
				$uyelerim=' and (hesap_sahibi_id='.id.' or hesap_root_id='.id.')';//admin
			}else if(yetki ==4 && wyetki == 1) {
				$uyelerim=' and (id='.id.' or hesap_sahibi_id='.id.')';//bayi
			}else{
				$uyelerim='';//patron
			}
			$ver="select id from kullanici where id!=1 and durum=1 $uyelerim order by username asc";
			$sor = $ci->db->query($ver);
			foreach($sor->result() as $ass){				
				$bas.=$ass->id.',';	
			}
			return substr($bas,0,-1);
		}
		return false;
	}
	
	function kuponhesapla($id,$kazanma) {
		
		$ci=&get_instance();
		
		$kupvarmi = $ci->db->query("select user_id,yatan,bonus,toplam_mac from kuponlar where id='$id'");
		if($kupvarmi->num_rows()==0){die("KUPON BULUNAMADI..");}
		
		$kupon_bilgi=$kupvarmi->row_array();
		$oran = 1;
		$sor = $ci->db->query("select oran from kupon_ic where kupon_id='$id'");
		foreach($sor->result() as $row){
			$oran = $oran*$row->oran;
		}		
		
		$ouser = $ci->db->query("select ayarlar from kullanici where id='$kupon_bilgi[user_id]'")->row();
		$ayrv=unserialize($ouser->ayarlar);		
		$maxodeme=$ayrv['maxodeme'];
		$maxoran=$ayrv['maxoran'];
		$bonusune=$ayrv['bonus'];
		
		$yenitutar = $kupon_bilgi['yatan']*$oran;
		
		if($yenitutar>$maxodeme) { $yenitut = $maxodeme; } else { $yenitut = $yenitutar; }
		if($maxoran=="") { $maxoran = 1000; } else { $maxoran = $maxoran; }
		if($oran>$maxoran) { $oran = $maxoran; }

		if($bonusune==1 and $kupon_bilgi['bonus']!='' ){//and ($kazanma==4 || $kazanma==6)
			if($kazanma==4 || $kazanma==6){
				$bonus=bonus_hesapla($kupon_bilgi['toplam_mac']-1);
			}else{
				$bonus=bonus_hesapla($kupon_bilgi['toplam_mac']);
			}			
			$bonus=nf(($yenitut / 100) * $bonus);
		}else{
			$bonus=$kupon_bilgi['bonus'];
		}
		
		$ver="update kuponlar set bonus='$bonus',oran='$oran',tutar='$yenitut' where id=$id";
		$ci->db->query($ver);	
	}
	
	function agent($u_agent) {
		$bname = ''; 
		$platform = ''; 
		if (preg_match('/linux/i', $u_agent)) {
			$platform = 'Linux';
		}
		elseif (preg_match('/macintosh|mac os x/i', $u_agent)) {
			$platform = 'Mac';
		}
		elseif (preg_match('/windows|win32/i', $u_agent)) {
			$platform = 'Windows';
		}
		
		// Next get the name of the useragent yes seperately and for good reason
		if(preg_match('/MSIE/i',$u_agent) && !preg_match('/Opera/i',$u_agent)) 
		{ 
			$bname = 'Internet Explorer'; 
			$ub = "MSIE"; 
		} 
		elseif(preg_match('/Firefox/i',$u_agent)) 
		{ 
			$bname = 'Mozilla Firefox'; 
			$ub = "Firefox"; 
		} 
		elseif(preg_match('/Chrome/i',$u_agent)) 
		{ 
			$bname = 'Google Chrome'; 
			$ub = "Chrome"; 
		} 
		elseif(preg_match('/Safari/i',$u_agent)) 
		{ 
			$bname = 'Apple Safari'; 
			$ub = "Safari"; 
		} 
		elseif(preg_match('/Opera/i',$u_agent)) 
		{ 
			$bname = 'Opera'; 
			$ub = "Opera"; 
		} 
		elseif(preg_match('/Netscape/i',$u_agent)) 
		{ 
			$bname = 'Netscape'; 
			$ub = "Netscape"; 
		} 
		return "$platform $bname";
	}
		
	function yukdurum($yukselis,$dusus) {
		if($dusus==1) { $donen = "backgroundRed"; } else
		if($yukselis==1) { $donen = "backgroundGreen";
		} else { 
		$donen = ""; 
		}
		return $donen;
	}
	function yukdurumsec($yukselis,$dusus) {
		if($dusus==1) { $donen = "backgroundRed"; } else
		if($yukselis==1) { $donen = "backgroundGreen";
		} else { 
		$donen = ""; 
		}
		return $donen;
	}
	function loglama($islem, $detay,$kodyaz){
		
		$ci=&get_instance();
		$ci->db->query("INSERT INTO loglama SET
		kod = '".$kodyaz."',
		bayiid = '".id."',
		islem = '".$ci->db->escape_str($islem)."',
		detay = '".$ci->db->escape_str($detay)."',
		ip = '".$_SERVER['REMOTE_ADDR']."'");
		if($detay=='Kupon Oynama' && email !=''){
			$ci->db->query("INSERT INTO mailgonder SET
			bayiid = '".username."',
			kuponid = '".$kodyaz."',
			email = '".email."'
			");
		}
	}
	
	function loglama1($islem, $detay,$kodyaz){
		
		$ci=&get_instance();
		$detay=$ci->db->escape_str($detay);
		$islemi=$ci->db->escape_str($islem);
		$ver="select islem from loglama where bayiid = '".id."' and detay = '".$detay."' and islem = '".$islem."' and ip = '".$_SERVER['REMOTE_ADDR']."' ";
		$ouser = $ci->db->query($ver);
		if($ouser->num_rows()==0) {
			$ci->db->query("INSERT INTO loglama SET
			bayiid = '".id."',
			islem = '".$islemi."',
			detay = '".$detay."',
			kod = '".$kodyaz."',
			ip = '".$_SERVER['REMOTE_ADDR']."'");
		}
	}
	
	function bultensay(){
		
		$ci=&get_instance();
		$verf="SELECT a.id FROM program a where a.program_tip='futbol' and a.id not in((SELECT gizliler FROM oranver WHERE oranvalid=0 and lig_mac=0 and uye in(".kendi.",".ustu.",".patron.") and gizliler=a.id and tip='gizlimac'))
		and a.kupa_id not in((SELECT gizliler FROM oranver WHERE oranvalid=0 and lig_mac=0 and uye in(".kendi.",".ustu.",".patron.") and gizliler=a.kupa_id and tip='gizlilig'))";
		$fut = $ci->db->query($verf)->num_rows();		
		
		$verfi="SELECT a.id FROM program a where a.program_tip='futbol' and a.iddaa_kodu !='' and a.id not in((SELECT gizliler FROM oranver WHERE oranvalid=0 and lig_mac=0 and uye in(".kendi.",".ustu.",".patron.") and gizliler=a.id and tip='gizlimac'))
		and a.kupa_id not in((SELECT gizliler FROM oranver WHERE oranvalid=0 and lig_mac=0 and uye in(".kendi.",".ustu.",".patron.") and gizliler=a.kupa_id and tip='gizlilig'))";
		$futid = $ci->db->query($verfi)->num_rows();		
		
		$verd="SELECT a.id FROM program a where a.program_tip='duello' and a.id not in((SELECT gizliler FROM oranver WHERE oranvalid=0 and lig_mac=0 and uye in(".kendi.",".ustu.",".patron.") and gizliler=a.id and tip='gizlimac'))
		and a.kupa_id not in((SELECT gizliler FROM oranver WHERE oranvalid=0 and lig_mac=0 and uye in(".kendi.",".ustu.",".patron.") and gizliler=a.kupa_id and tip='gizlilig'))";
		$dusay = $ci->db->query($verd)->num_rows();		
		
		$verb="SELECT count(a.id) as bskt,(SELECT count(id) FROM programt) as tns,(SELECT count(id) FROM programh) as hnt,(SELECT count(id) FROM programo) as hok FROM programb a where a.id not in((SELECT gizliler FROM oranverb WHERE oranvalid=0 and lig_mac=0 and uye in(".kendi.",".ustu.",".patron.") and gizliler=a.id and tip='gizlimac'))
		and a.kupa_id not in((SELECT gizliler FROM oranverb WHERE oranvalid=0 and lig_mac=0 and uye in(".kendi.",".ustu.",".patron.") and gizliler=a.kupa_id and tip='gizlilig'))";
		$tumler = $ci->db->query($verb)->row();	
		
		$basay = $tumler->bskt;		
		$tsay = $tumler->tns;		
		$hsay = $tumler->hnt;		
		$osay = $tumler->hok;		
				
		$kelimeler = explode(',', ckelime);
		$notLike = "";
		if(!empty(ckelime)){
			foreach($kelimeler as $keyword){
				if(trim($keyword)=="")
					continue;
				$notLike .= " AND a.ev_takim NOT LIKE '%".$ci->db->escape_str($keyword)."%'";
				$notLike .= " AND a.konuk_takim NOT LIKE '%".$ci->db->escape_str($keyword)."%'";
			}
		}		
		$fark = time()-60;
		$csql="select *,
		IFNULL((SELECT gizliler FROM coranver WHERE oranvalid=0 and lig_mac=0 and uye in(".kendi.",".ustu.",".patron.") and gizliler=a.eventid and tip='aski'),0) as surekliaski
		from canli_maclar a where a.eventid not in((SELECT gizliler FROM coranver WHERE oranvalid=0 and lig_mac=0 and uye in(".kendi.",".ustu.",".patron.") and gizliler=a.eventid and tip='gizlimac'))
		and a.lig_adi!='' and a.dakika <=".canli_dk_kes1." and a.yer='".aktifcanli."' and a.songuncelleme>$fark ".$notLike."";
		$cbahissay = $ci->db->query($csql)->num_rows();		
		
		return $fut.'|'.$futid.'|'.$dusay.'|'.$basay.'|'.$cbahissay.'|'.$tsay.'|'.$hsay.'|'.$osay;
	}
	
	function domainver($tip,$id='',$sec='') {
		$ver='';
		$ar=explode(',',domainler);
		if($tip==1){
			$ver.=$ar[$id];
		}elseif($tip==2){
			foreach ($ar as $k=>$veri){
				$ver.='<option value="'.$k.'">'.$veri.'</option>';
			}			
		}elseif($tip==3){
			foreach ($ar as $k=>$veri){
				if(in_array($k,$sec)){$checked='checked';}else{$checked='';}
				$ver.='<input type="checkbox" value="'.$k.'" name="domain[]" '.$checked.'/> '.$veri.' &nbsp;';
			}			
		}
		return $ver;
	}
	
	function bol($bir,$iki,$sayi,$kaynak) {
		$bol = explode($bir,$kaynak);
		$bol = explode($iki,$bol[$sayi]);
		$bol = $bol[0];
		return $bol;	
	}
	
	function detect_mobile(){
	if(preg_match('/(alcatel|amoi|android|avantgo|blackberry|benq|cell|cricket|docomo|elaine|htc|iemobile|iphone|ipad|ipaq|ipod|j2me|java|midp|mini|mmp|mobi|motorola|nec-|nokia|palm|panasonic|philips|phone|playbook|sagem|sharp|sie-|silk|smartphone|sony|symbian|t-mobile|telus|up\.browser|up\.link|vodafone|wap|webos|wireless|xda|xoom|zte)/i', $_SERVER['HTTP_USER_AGENT']))
		return true;
	else
		return false;
	}