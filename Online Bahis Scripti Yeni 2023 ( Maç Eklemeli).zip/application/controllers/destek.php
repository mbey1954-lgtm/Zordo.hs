<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class destek extends CI_Controller {

	function __construct(){
		parent::__construct();
			logged_admin();
			ajaxvarmi();
	}
	
	public function index(){
		redirect(base_url()."login");
	}
	
	public function yoneticisec(){
		
		if(yetki==4){
			$ver="select username,tip,id from kullanici where id in(".kendi.",".ustu.") and durum=1 order by username asc";
			$sql = $this->db->query($ver);
			$uybas='<a href="#" id="basgorus" onclick="javascript:chatWith(\'Sistem\',1)" title="Görüşmek İçin Tıklayın."><b>Sistem</b></a><br>';
			foreach($sql->result() as $ass){
				$uybas.='<a href="#" id="basgorus" onclick="javascript:chatWith(\'Admin\','.$ass->id.')" title="Görüşmek İçin Tıklayın."><b>'.$ass->tip.'</b></a><br>';
			}
			echo $uybas;
			
		}else if(yetki==3){
			
			$ver="select username,tip,id from kullanici where id in(".ustu.",".patron.") and durum=1 order by username asc";
			$sql = $this->db->query($ver);
			$bas='';
			foreach($sql->result() as $ass){
				$bas.=' <a href="#" id="basgorus" onclick="javascript:chatWith(\''.str_replace(' ','',$ass->tip).'-'.$assu->username.'\','.$ass->id.')" title="Görüşmek İçin Tıklayın."><b>'.$ass->tip.'</b></a> /';
			}
			echo substr($bas,0,-1);
			$bas2.='<hr><div style="text-align:center;font-weight:bold;background-color: #ccc">Bayiler</div><hr>';
			$veru="select username,id from kullanici where hesap_sahibi_id =".kendi." and durum=1 order by username asc";
			$sqlu = $this->db->query($veru);
			
			foreach($sqlu->result() as $assu){
				$bas2.=' <a href="#" id="basgorus" onclick="javascript:chatWith(\''.$assu->username.'\','.$assu->id.')" title="Görüşmek İçin Tıklayın."><b>'.$assu->username.'</b></a> |';
			}
			echo substr($bas2,0,-1);
			
		}else if(yetki==2){
			
			echo '<a href="#" id="basgorus" onclick="javascript:chatWith(\'Sistem-sistem\',1)" title="Görüşmek İçin Tıklayın."><b>Sistem</b></a><br>';
			
			$bas2.='<hr><div style="text-align:center;font-weight:bold;background-color: #ccc;">Adminler</div><hr>';
			$veru="select username,tip,id from kullanici where hesap_sahibi_id =".kendi." and durum=1 order by username asc";
			$sqlu = $this->db->query($veru);
			
			foreach($sqlu->result() as $assu){
				$bas2.=' <a href="#" id="basgorus" onclick="javascript:chatWith(\'Admin-'.$assu->username.'\','.$assu->id.')" title="Görüşmek İçin Tıklayın."><b>'.$assu->username.'</b></a> |';
			}
			echo substr($bas2,0,-1);
			
			$basus.='<hr><div style="text-align:center;font-weight:bold;background-color: #ccc">Bayiler</div><hr>';
			$verustb="select username,tip,id from kullanici where hesap_root_id =".kendi." and durum=1 order by username asc";
			$sqlus = $this->db->query($verustb);
			
			foreach($sqlus->result() as $assus){
				$basus.=' <a href="#" id="basgorus" onclick="javascript:chatWith(\''.$assus->username.'\','.$assus->id.')" title="Görüşmek İçin Tıklayın."><b>'.$assus->username.'</b></a> |';
			}
			echo substr($basus,0,-1);
			
		}else if(yetki==1){
			
			
			$verus="select username,tip,id from kullanici where durum=1 and yetki=2 order by username asc";
			$sqlus = $this->db->query($verus);
			$basus.='<hr><div style="text-align:center;font-weight:bold;background-color: #ccc">SüperAdminler</div><hr>';
			foreach($sqlus->result() as $assu){
				$basus.=' <a href="#" id="basgorus" onclick="javascript:chatWith(\'SüperAdmin-'.$assu->username.'\','.$assu->id.')" title="Görüşmek İçin Tıklayın."><b>'.$assu->username.'</b></a> |';
			}
			echo substr($basus,0,-1);
			
			$veru="select username,tip,id from kullanici where durum=1 and yetki=3 order by username asc";
			$sqlu = $this->db->query($veru);
			$bas2a.='<hr><div style="text-align:center;font-weight:bold;background-color: #ccc">Adminler</div><hr>';
			foreach($sqlu->result() as $assu){
				$bas2a.=' <a href="#" id="basgorus" onclick="javascript:chatWith(\'Admin-'.$assu->username.'\','.$assu->id.')" title="Görüşmek İçin Tıklayın."><b>'.$assu->username.'</b></a> |';
			}
			echo substr($bas2a,0,-1);
			
			$verub="select username,tip,id from kullanici where durum=1 and yetki=4 order by username asc";
			$sqlub = $this->db->query($verub);
			$bas2b.='<hr><div style="text-align:center;font-weight:bold;background-color: #ccc">Bayiler</div><hr>';
			foreach($sqlub->result() as $assu){
				$bas2b.=' <a href="#" id="basgorus" onclick="javascript:chatWith(\''.$assu->username.'\','.$assu->id.')" title="Görüşmek İçin Tıklayın."><b>'.$assu->username.'</b></a> |';
			}
			echo substr($bas2b,0,-1);
			
		}
		
	}
	
	function sanitize($text) {
		$text = htmlspecialchars($text, ENT_QUOTES);
		$text = str_replace("\n\r","\n",$text);
		$text = str_replace("\r\n","\n",$text);
		$text = str_replace("\n","<br>",$text);
		return $text;
	}

	public function chatHeartbeat() {
		
		$useri = (int)$this->input->post('useri');
		$sql = $this->db->get_where('chat', array('chat.kime' => $useri,'recd' => 0));
		//echo$this->db->last_query();
		$items = '';
		$chatBoxes = array();
		foreach($sql->result_array() as $chat){
			//echo $chat['message'];
			$chat['message'] = $this->sanitize($chat['message']);
			$mesaj=($chat['message']);
			$items .= <<<EOD
						   {"s": "0","f": "{$chat['from']}","k": "{$chat['kimden']}","m": "{$mesaj}","zaman": "{$chat['sent']}"},
EOD;
		
		}
		
		if ($items != '') {
			$sql = "update chat set recd = 1 where chat.kime = '".$useri."' and recd = 0";
			$query = $this->db->query($sql);
			$items = substr($items, 0, -1);
		}
		
		header('Content-type: application/json');
		?>
		{"items": [<?php echo $items;?>]}

	<?php 
	}
	
	public function sendChat() {
		
		$kimden = (int)$this->input->post('kimden');
		$kime = (int)$this->input->post('kime');
		$from = $this->input->post('useri');
		$to = $this->input->post('to');
		$message = $this->input->post('message');
		$messagesan = $this->sanitize($message);
		if(yetki!=4){
		$veru="select username,tip from kullanici where id=".$kimden." and durum=1 and yetki!=4";
		$sqlu = $this->db->query($veru);
		if($sqlu->num_rows()>0) {
			$row=$sqlu->row();
			$from=str_replace(' ','',$row->tip).'-'.$row->username;
		}else{
			$from=$from;
		}
		$veru="select username,tip from kullanici where id=".$kime." and durum=1 and yetki!=4";
		$sqlu1 = $this->db->query($veru);
		if($sqlu1->num_rows()>0) {
			$row1=$sqlu1->row();
			$to=str_replace(' ','',$row1->tip).'-'.$row1->username;
		}else{
			$to=$to;
		}
		}
		
		$sql = "insert into chat (chat.from,chat.to,message,sent,kimden,kime) values ('".addslashes($from)."', '".addslashes($to)."','".addslashes($messagesan)."',NOW(),'".addslashes($kimden)."','".addslashes($kime)."')";
		$query = $this->db->query($sql);
		echo "1";
		exit(0);
	}
}