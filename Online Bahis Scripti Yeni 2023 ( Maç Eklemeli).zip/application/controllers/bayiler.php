<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class bayiler extends CI_Controller {

	function __construct(){
		parent::__construct();
			logged_admin();
			if((yetki == 4 && wyetki==0) || yetki ==5){redirect(base_url());}
	}
	
	public function index(){
		//$this->smarty->assign('sonc',$optver1);
		$this->smarty->view('tumbayiler.tpl');
	}
	
	public function gerigetir(){
		
		$this->smarty->view('silinenbayi.tpl');
	}
	
	public function bayigerigetir(){
		
		ajaxvarmi();
		$id = (int)$this->input->post('id');
		$kimbu=$this->db->query("select * from kullanici where id='$id' and durum=0")->row();
		$ustlugetir=true;
		$updt='';
		$ayrvk=unserialize($kimbu->ayarlar);
		if($kimbu->yetki==4 && $ayrvk['wyetki']==1){
			$where="hesap_sahibi_id='$id' and durum=0";
		}else if($kimbu->yetki==4 && $ayrvk['wyetki']==0){
			$ustlugetir=false;
		}else if($kimbu->yetki==3){
			$where="(hesap_sahibi_id='$id' or hesap_root_id='$id') and durum=0";
		}else if($kimbu->yetki==2){
			$where="(hesap_root_id='$id' or hesap_root_root_id='$id') and durum=0 and yetki in(4,5)";
			$updt="(hesap_sahibi_id='$id' or id='$id') and yetki in(2,3)";
		}
		
		if($ustlugetir){
			
			$onay=false;
			$yaz='';
			
			if($kimbu->yetki==2){				
				$yont=$kimbu->username;
				$veru="select username from kullanici where username ='$yont' and id!='$id'";
				$usustne=$this->db->query($veru);
				if($usustne->num_rows == 0){
					$admbul=$this->db->query("select username,id from kullanici where hesap_sahibi_id='".$kimbu->id."'");
					if($admbul->num_rows > 0){
						$admvarmi=true;
						foreach($admbul->result() as $adm){
							$yonta=$adm->username;
							$adid=$adm->id;
							$verua="select username from kullanici where username ='$yonta' and id!='$adid'";
							$usustad=$this->db->query($verua);
							if($usustad->num_rows > 0){
								$admvarmi=false;
								echo lang('sprvar',array($yonta));
								exit;
							}
						}
						if($admvarmi){
							$this->db->query("update kullanici set durum='1' where $updt");
						}
					}
				}else{
					echo lang('sprvar',array($yont));
					exit;
				}
			}
			
			if($kimbu->yetki==3){	
				$yontad=$kimbu->username;
				$veruad="select username from kullanici where username ='$yontad' and id!=".$kimbu->id."";
				$usustnead=$this->db->query($veruad);
				if($usustnead->num_rows == 0){
					if(acmahakki()){
						echo lang('acmahak',array(acmahakki()));
						exit;
					}else{
						$this->db->query("update kullanici set durum='1' where id=".$kimbu->id."");
					}
				}else{
					echo lang('admvar',array($yontad));
					exit;
				}
			}
			
			if($kimbu->yetki==4 && $ayrvk['wyetki']==1){	
				$yontadw=$kimbu->username;
				$veruadw="select username from kullanici where username ='$yontadw' and id!=".$kimbu->id."";
				$usustneadw=$this->db->query($veruadw);
				if($usustneadw->num_rows == 0){
					if(acmahakki()){
						echo lang('acmahak',array(acmahakki()));
						exit;
					}else{
						$this->db->query("update kullanici set durum='1' where id=".$kimbu->id."");
						//$this->db->query("update kuponlar set hesap_kesim_zaman='' where web_id='".$vr->id."'");
					}
				}else{
					echo lang('byvar',array($yontadw));
					exit;
				}
			}
			
			$bir="select id from kullanici where $where ";
			$usust=$this->db->query($bir);
			foreach($usust->result() as $vr){
				$vrs="select username,id from kullanici where id='".$vr->id."'";
				$us=$this->db->query($vrs);
				if($us->num_rows > 0){
					$ub=$us->row();		
						//$useri=preg_replace("/_silindi\w+/i","",$ub->username);
						$useri=$ub->username;
						$ver="select username from kullanici where username ='".$useri."' and id!='".$ub->id."' ";
						$usvarmi=$this->db->query($ver);
						if($usvarmi->num_rows == 0){
							if(acmahakki()){
								echo lang('acmahak',array(acmahakki()));
								exit;
							}else{
								$this->db->query("update kuponlar set hesap_kesim_zaman='' where user_id='".$vr->id."'");
								$okmu=$this->db->query("update kullanici set durum='1' where id='".$vr->id."'");
								if($okmu==0){
									$onay=true;
									$yaz= lang('hataolustu');
								}else{
									$onay=true;
									$yaz= 'ok';
								}
							}
						}else{
							$onay=true;
							$yaz.= lang('byvar1',array($useri));
						}						
					}else{
						echo lang('byyok');
					}
			}
			if($onay){echo $yaz;}
		}else{
		
		$us=$this->db->query("select username,id,hesap_sahibi_id from kullanici where id='$id' and durum=0 ");
		
		if($us->num_rows > 0){
			$ub=$us->row();
			$ust=$this->db->query("select * from kullanici where id='".$ub->hesap_sahibi_id."' and durum=0 ");
				if($ust->num_rows == 0){
					$useri=$ub->username;
					$bid=$ub->id;
					$ver="select username from kullanici where username ='".$useri."' and id!=$bid";
					$usvarmi=$this->db->query($ver);
					if($usvarmi->num_rows == 0){
						if(acmahakki()){
							echo lang('acmahak',array(acmahakki()));
							exit;
						}else{
							$okmu=$this->db->query("update kullanici set durum='1' where id='$bid'");
							$this->db->query("update kuponlar set hesap_kesim_zaman='' where user_id='$bid'");
							if($okmu==0){
								echo lang('hataolustu');
							}else{
								echo 'ok';
							}
						}
					}else{						
						echo lang('byvar1',array($useri));
					}
				}else{
					echo lang('byonceust');
				}
			}else{
				echo lang('byyok');
			}
		}
		
		exit;
	}
	
	public function adkontrol_kayit(){
		
		ajaxvarmi();
		$user = $this->input->post('user');
		$id = (int)$this->input->post('id');
		$kontrol = $this->db->get_where('kullanici', array('username' => $user,'durum' => 1))->num_rows;		
		if($kontrol > 0){ 
			die("1"); 
		}else{
			$this->db->query("update kullanici set username='$user' where id='$id'");
		}
	}
	
	public function gerigetirdata(){
		
	ajaxvarmi();
	$id = (int)$this->input->post('id');
	$order = $this->input->post('order');
	$ascdesc = $this->input->post('ascdesc');
	$name = $this->input->post('name');
	
	if($name) {
		$where=' and hesap_sahibi_id='.$id.' and username like ("%'.$name.'%")';
	}else{
		$where=' and hesap_sahibi_id='.$id.'';
	}
	
	if($order=="bakiye") {
		$ordered = "order by CAST($order AS UNSIGNED) $ascdesc";
	} else {
		$ordered = "order by $order $ascdesc";
	}
	if($ascdesc=="asc") { $neworder = "desc"; } else { $neworder = "asc"; }
	
	$ver="select * from kullanici where id!=1 and durum=0 $where $ordered";
	$sor = $this->db->query($ver);
	
	if($sor->num_rows()<1) { echo "<div class='bos'>".lang('bos')."</div>";exit; } else {
		
	$obilgi = $this->db->query("select * from kullanici where id='$id'")->row_array();
	?>
	<script>
	function asdes(order,as) {
		$("#order").val(order);	
		$("#ascdesc").val(as);
		$("#suanval").val(1);
		bayiler(<?=$id;?>);
	}
	var baseurl1 = "<?=base_url();?>";
	
	function bayigerigetir(id,uname) {
		if(confirm(uname)) {
		$.post(baseurl1+'bayiler/bayigerigetir',{id:id},function(data) { 
			if(data!='ok'){
				alert(data);
			}else{
				$("#users").html(data);
			}
			bayiler('<?=$id;?>');
		});	
		}	
	}
	
	function bayitamsil(id,uname,wy) {
		if(confirm(uname)) {
		$.post(baseurl1+'bayiler/bayitamsil',{id:id,wy:wy},function(data) {
			bayiler('<?=$id;?>');
		});	
		}	
	}
	
	function gerigel() {
		bayiler($("#ustid").val());
	}
	
	function adkontrol_kayit(id,user) {
		$.post(baseurl+'bayiler/adkontrol_kayit',{user:user,id:id},function(data) { 
		if(data=="1") { 
			failcont('<?=lang('uservar');?>'); 
		}else{
			failcont('<?=lang('userokdevam');?>');
			bayiler('<?=id;?>');
		}
		});		
	}

	$(function() {
		
		$('.yeniad').click(function(event){
			var uyid=$(this).attr('rel');
			adkontrol_kayit(uyid,$("#yenival"+uyid).val());
		});	
	
	});
	</script>
	
	<table style="width:100%" class="tftable" cellspacing="0" cellpadding="0">
	<thead>
	<tr>
	<th><a href="javascript:;" onClick="asdes('username','<?=$neworder;?>');"><?=lang('user');?></a></td>
	<th><?=lang('htip');?></td>
	<th><a href="javascript:;" onClick="asdes('bakiye','<?=$neworder;?>');"><?=lang('bakiye');?></a></td>
	<th><?=lang('altbayi');?></td>
	<th><a href="javascript:;" ><?=lang('oluszaman');?></a></td>
	<th><a href="javascript:;" onClick="asdes('sonislem','<?=$neworder;?>');"><?=lang('songor');?></a></td>
	<th><a href="javascript:;" onClick="asdes('durum','<?=$neworder;?>');"><?=lang('drm');?></a></td>
	<th><?=lang('islm');?></td>
	</tr></thead><tbody>
	<?
	foreach($sor->result_array() as $row){
		
		$ayarlari = @unserialize($row['ayarlar']);		
		$alttotal=$this->db->query("select hesap_sahibi_id from kullanici where hesap_sahibi_id='$row[id]'")->num_rows();
	?>
	<tr>
	<td style="padding:0px">
	<?php if($id==id){?>
	<input type="text" id="yenival<?=$row['id']; ?>" value="<?=$row['username']; ?>" title="<?=lang('ynisimkyt');?>"><input type="button" value="<?=lang('ismedit');?>" class="yeniad" rel="<?=$row['id']; ?>">
	<?php }else if(yetki==1 && ($row['yetki']==2 or $row['yetki']==3)){?>
	<input type="text" id="yenival<?=$row['id']; ?>" value="<?=$row['username']; ?>" title="<?=lang('ynisimkyt');?>"><input type="button" value="<?=lang('ismedit');?>" class="yeniad" rel="<?=$row['id']; ?>">
	<?php }else{?>
	<?=$row['username']; ?>
	<?php }?>
	</td>
	<td ><?=$row['tip']; ?></td>
	<td ><?=nf($row['bakiye']); ?></td>
	<td ><? if($alttotal>0) { ?>
		<a href="javascript:;" onClick="bayiler('<?=$row['id']; ?>');" class="d3"><?=lang('gstr');?></a> (<?=$alttotal?>)
	<? }?>
	</td>
	<td ><?=$ayarlari['olusturma_zaman']; ?></td>
	<td >
		<? if(empty($row['sonislem'])) { echo "Hiç bir zaman"; } else { echo date("d.m H:i",$row['sonislem']);} ?>
	</td>
	<td class="<? if($row['durum']=="1") { echo "d2"; $dur = lang('aktf'); } else if($row['durum']=="0") { echo "d3"; $dur = lang('psf'); } ?>"><?=$dur;?></td>
	<td >
	<? if($dur=="Pasif") { 
		if($id==id) {?>
			<a href="javascript:;" onClick="bayigerigetir('<?=$row['id']; ?>','<?=lang('baygetirconf',array($row['username']));?>');" class="d2"><?=lang('ggetir');?></a> / <a href="javascript:;" onClick="bayitamsil('<?=$row['id']; ?>','<?=lang('baysilconf',array($row['username']));?>','<?=@$ayarlari['wyetki']; ?>');" class="d3"><?=lang('tamsil');?></a>		
		<? } ?>
	<? } ?>
	</td>
	
	</tr>
	<input type="hidden" id="ustid" value="<?=$row['hesap_root_id']; ?>"> 
	<? } ?>
	<tbody></table>
	<? }
	}
	
	public function bayitamsil(){
		ajaxvarmi();
		$id = (int)$this->input->post('id');
		$wy = (int)$this->input->post('wy');
		
		$bas='';
		if($wy ==1) {
			$ver="select id,yetki from kullanici where durum=1 and (id='$id' or hesap_sahibi_id='$id')";
			$sor = $this->db->query($ver);
			foreach($sor->result() as $ass){				
				if(($ass->yetki ==5 || $ass->yetki ==4) && $wy ==1) {
					$bas.=$ass->id.',';
				}
			}
		}
		$son= substr($bas,0,-1);
		if($son){$byver=$son;}else{$byver=$id;}
		$kimbusilinen=$this->db->query("select username from kullanici where id='$id' ")->row()->username;
		$this->db->query("delete from kullanici where (id='$id' or hesap_sahibi_id='$id' or hesap_root_id='$id' or hesap_root_root_id='$id')");		
		
		$this->db->query("delete from oranver where uye='$id'");
		
		$this->db->query("delete from kupon_ic a 
		left join kuponlar b on a.kupon_id= b.id 
		where b.adm_id='$id' or b.sup_id='$id' ");
		
		$this->db->query("delete FROM `hesap_hareket` WHERE user_id in(".$byver.") ");		
		$this->db->query("delete from kupon_ic where user_id in(".$byver.")");
		
		$this->db->query("delete from kuponlar where user_id in(".$byver.")");
		$this->db->query("delete from kuponlar where (adm_id='$id' or sup_id='$id')");
		$bysil[] = array(
			'silme' => $id.' ('.$kimbusilinen.') numaralı bayi <b>'.username.'</b> tarafından Tamamen silinmiştir.'
		);
		loglama1(serialize($bysil), "Bayi Tamamen Silme",0);
	}
	
	public function tumbayilerdata(){
	
	ajaxvarmi();	
	$id = (int)$this->input->post('id');
	$order = $this->input->post('order');
	$ascdesc = $this->input->post('ascdesc');
	$name = $this->input->post('name');
	$durum = $this->input->post('durum');
	$arandimi=false;
	if($name) {
		if(yetki!=4){
			$arandimi=true;
			$where=' and username like("%'.$name.'%")';
		}else{
			$where=' and (hesap_sahibi_id='.$id.' or hesap_root_id='.$id.') and username like("%'.$name.'%")';
		}
	}else if($durum!='') {
		$where=' and aktif='.$durum.' and hesap_sahibi_id='.$id.'';
	}else{
		$where=' and hesap_sahibi_id='.$id.' ';
	}
	
	if($order=="bakiye") {
		$ordered = "order by CAST($order AS UNSIGNED) $ascdesc";
	} else {
		$ordered = "order by $order $ascdesc";
	}
	if($ascdesc=="asc") { $neworder = "desc"; } else { $neworder = "asc"; }
	
	$ver="select * from kullanici where id!=1 and durum=1 $where $ordered";
	$sor = $this->db->query($ver);
	
	if($sor->num_rows()<1) { echo "<div class='bos'>".lang('bos')."</div>";exit; } else {
		
	
	?>
	<script>
	function asdes(order,as) {
		$("#order").val(order);	
		$("#ascdesc").val(as);
		$("#suanval").val(1);
		bayiler(<?=$id;?>);
	}
	var baseurl1 = "<?=base_url();?>";
	
	function bayidurum(id,durum) {
		$.post(baseurl1+'bayiler/bayidurumdegis',{id:id,durum:durum},function(data) { bayiler('<?=$id;?>'); });
	}
	
	function bayisil(id,uname,wy) {
		if(confirm(uname)) {
		$.post(baseurl1+'bayiler/bayisil',{id:id,wy:wy},function(data) { 
			$("#users").html(data); 
			bayiler('<?=$id;?>');
		});	
		}	
	}
	
	function gerigel() {
		bayiler($("#ustid").val());
	}
	</script>
		
	<table style="width:100%" class="tftable" cellspacing="0" cellpadding="0">
	<thead>
	<tr>
	<th><a href="javascript:;" onClick="asdes('firma','<?=$neworder;?>');"><?=lang('firma');?></a></td>
	<th><a href="javascript:;" onClick="asdes('username','<?=$neworder;?>');"><?=lang('user');?></a></td>
	<th><a href="javascript:;" onClick="asdes('bakiye','<?=$neworder;?>');"><?=lang('bakiye');?></a></td>
	<th><?=lang('htip');?></td>	
	<th><?=lang('altbayi');?></td>
	<th><a href="javascript:;" ><?=lang('oluszaman');?></a></td>
	<th><a href="javascript:;" onClick="asdes('sonislem','<?=$neworder;?>');"><?=lang('songor');?></a></td>
	<th><a href="javascript:;" onClick="asdes('durum','<?=$neworder;?>');"><?=lang('drm');?></a></td>
	<th><?=lang('degis');?></td>
	<th><?=lang('bkislm');?></td>
	<th><?=lang('islm');?></td>
	</tr>
	</thead><tbody>
	<?
	foreach($sor->result_array() as $row){
		
		$ayarlari = @unserialize($row['ayarlar']);		
		$alttotal=$this->db->query("select hesap_sahibi_id from kullanici where hesap_sahibi_id='$row[id]' and durum=1")->num_rows();
	?>
	<tr>
	<td ><? if(yetki !=5){?>
		<a href="javascript:;" onClick="gecis('<?=$row['id'];?>');event.stopImmediatePropagation();" class="gecisokstil" title="<?=lang('gecis');?>" style="float:left;">
			<i class="fa fa-eye fa-lg"></i>
		</a>
	<? }?> <font color="red"><?=$row['firma']; ?></font></td>
	<td ><?=$row['username']; ?> <?if(yetki!=4 && $arandimi){echo'('.$row['password'].')';}?></td>
	<td ><?=nf($row['bakiye']); ?></td>
	<td ><?=str_replace('Web Bayi','Üye',$row['tip']); ?></td>
	
	<td ><? if($alttotal>0) { ?>
		<a href="javascript:;" onClick="bayiler('<?=$row['id']; ?>');" class="d3"><?=lang('gstr');?></a> (<?=$alttotal?>)
	<? }?>
	</td>
	
	<td ><?=$ayarlari['olusturma_zaman']; ?></td>
	<td >
		<? if(empty($row['sonislem'])) { echo lang('hicbir'); } else { echo date("d.m H:i",$row['sonislem']);} ?>
	</td>
	<td class="<? if($row['aktif']=="1") { echo "kaz"; $dur = lang('aktf'); } else if($row['aktif']=="0") { echo "kay"; $dur = lang('psf'); } ?>"><?=$dur;?></td>
	
	<td >
	<? if($id==id){
		if($dur=="Aktif") { ?>
	<a href="javascript:;" onClick="bayidurum('<?=$row['id']; ?>','0');" class="d3"><?=lang('drdr');?></a>
	<? } else if($dur=="Pasif") { ?>		
		<a href="javascript:;" onClick="bayidurum('<?=$row['id']; ?>','1');" class="d2"><?=lang('bslt');?></a>
	<? }}else{echo lang('ytkyok');}
	?>
	</td>
	<td >
	<? if($id==id && $row['yetki']!=3){ ?>
	<a href="javascript:;" onClick="bakiye('ekle','<?=$row['id'];?>');" class="d2"><?=lang('ekle');?></a>
	<a href="javascript:;" onClick="bakiye('cikar','<?=$row['id']; ?>');" class="d3"><?=lang('ckr');?></a>
	<div class="bakiyedurum" id="b_<?=$row['id']; ?>">
	<span><?=$row['username']; ?></span>
	<span id="eklecikar_<?=$row['id']; ?>"></span>
	<input type="text" class="input" id="bakiye_<?=$row['id']; ?>" size="4" maxlength="5" onkeypress='validate(event)'>
	<input type="hidden" id="bakiyedurum_<?=$row['id']; ?>" value=""> 	
	<font>
	<input type="button" class="button" value="<?=lang('kyt');?>" onClick="isle('<?=$row['id']; ?>');" style="padding: 0;background: green;"> 
	&nbsp;&nbsp;
	<input type="button" class="button" value="<?=lang('kpt');?>" onClick="$('#b_<?=$row['id'];?>').fadeOut();" style="padding: 0">
	</font>
	</div>
	<? }else{echo lang('ytkyok');} ?>
	</td>
	<td >
	<? if($id!=id) { ?><?=lang('ytkyok');?><? }else{ ?>
	<a href="bayikayit/edit/?id=<?=$row['id']; ?>" class="d2"><?=lang('edit');?></a>
	<? } ?>
	<? if(yetki<4 and silme_yetki==1 and $row['durum']==1 and $id==id) { ?><a href="javascript:;" onclick="bayisil('<?=$row['id']; ?>','<?=lang('baysilconf',array($row['username']));?>','<?=@$ayarlari['wyetki']; ?>');" class="d3"><?=lang('sil');?></a><? }elseif(yetki==3 and silme_yetki==1 and $row['durum']==1) { ?><a href="javascript:;" onclick="bayisil('<?=$row['id']; ?>','<?=lang('baysilconf',array($row['username']));?>','<?=@$ayarlari['wyetki']; ?>');" class="d3"><?=lang('sil');?></a><? }?>
	</td>
	</tr>
	<input type="hidden" id="ustid" value="<?=$row['hesap_root_id']; ?>"> 
	<? } ?>
	</tbody></table>
	<? $sor->free_result();unset($ayarlari,$sor);
		}
	}
	
	public function bayidurumdegis(){
		
		ajaxvarmi();
		$id = (int)$this->input->post('id');
		$durum = $this->input->post('durum');		
		$this->db->query("update kullanici set aktif='$durum' where (hesap_sahibi_id='$id' or hesap_root_id='$id')");		
		$this->db->query("update kullanici set aktif='$durum' where id='$id'");
	}
	
	public function bayisil(){
		
		ajaxvarmi();
		$id = (int)$this->input->post('id');
		$ipadres = $_SERVER['REMOTE_ADDR'];
		$wy = (int)$this->input->post('wy');
		$zm='_'.date('H:i:s');
		
		$bas='';
		if($wy ==1) {
			$ver="select id,yetki from kullanici where durum=1 and (id='$id' or hesap_sahibi_id=".$id.")";
			$sor = $this->db->query($ver);
			foreach($sor->result() as $ass){				
				if(($ass->yetki ==5 || $ass->yetki ==4) && $wy ==1) {
					$bas.=$ass->id.',';
				}
			}
		}
		$son= substr($bas,0,-1);
		if($son){$byver=$son;}else{$byver=$id;}
		//echo$byver;exit;
		$kimbusilinen=$this->db->query("select username from kullanici where id='$id' ")->row()->username;
		$this->db->query("update kullanici set durum='0' where (id='$id' or hesap_sahibi_id='$id' or hesap_root_id='$id' or hesap_root_root_id='$id')");		
		$this->db->query("update kuponlar set hesap_kesim_zaman='".time()."-$ipadres' where (adm_id='$id' or sup_id='$id')");
		$this->db->query("update kuponlar set durum='4',iptalzaman='".date('H:i:s d.m.Y')."' where (adm_id='$id' or sup_id='$id') and durum='1'");
		$this->db->query("update kupon_ic a	left join kuponlar b on	a.kupon_id= b.id 
		set	a.kazanma  = 4 where a.kazanma=1 and (b.adm_id='$id' or b.sup_id='$id')");
		$this->db->query("delete from oranver where uye='$id'");

		//$this->db->query("update kullanici set durum='0' where id='$id'");
		$this->db->query("update kuponlar set hesap_kesim_zaman='".time()."-$ipadres' where user_id in(".$byver.")");
		$this->db->query("update kuponlar set durum='4',iptalzaman='".date('H:i:s d.m.Y')."' where user_id in(".$byver.") and durum='1'");
		$this->db->query("update kupon_ic set kazanma='4' where user_id in(".$byver.") and kazanma='1'");
		$bysil[] = array(
			'silme' => $id.' ('.$kimbusilinen.') numaralı bayi <b>'.username.'</b> tarafından silinmiştir.'
		);
		loglama1(serialize($bysil), "Bayi Silme",0);
	}	
		
	public function adkontrol(){
		
		ajaxvarmi();
		$user = $this->input->post('user');
		$ussil=$user.'_silindi';
		//$ver="select id from kullanici where username like '%$user%' and username like '%$ussil%' ";
		$ver="select id from kullanici where username = '$user' and durum=1";
		$kontrol = $this->db->query($ver);
		if($kontrol->num_rows > 0){ die("1"); }else{die("0");}
	}
	
	public function bakiyeislem(){
		
		ajaxvarmi();
		$tip = $this->input->post('tip');
		$tutar = $this->input->post('tutar');
		$uid = (int)$this->input->post('uid');
		if($tutar == 0){
			die("3");
		}
		
		$ouser = $this->db->query("select username,yetki,bakiye from kullanici where id='$uid' and durum=1");
		if($ouser->num_rows > 0){
			$usrow=$ouser->row_array();
			if($usrow['yetki']==5 && $tip=='ekle'){
				if($tutar > bakiye){die("2");}
				hesap_hareket($tip,$usrow['username'],$uid,$tutar,"".username." tarafından işlendi.",0);
				hesap_hareket('cikar',$usrow['username'],id,$tutar,''.$usrow['username'].' Web kullanıcısından çekildi.',0);
			}elseif($usrow['yetki']==5 && $tip=='cikar'){
				if($usrow['bakiye']<$tutar){die("4");}
				hesap_hareket($tip,$usrow['username'],$uid,$tutar,"".username." tarafından işlendi.",0);
				hesap_hareket('ekle',$usrow['username'],id,$tutar,''.$usrow['username'].' Web kullanıcısına eklendi.',0);
			}else{
				hesap_hareket($tip,$usrow['username'],$uid,$tutar,"".username." tarafından işlendi.",0);
			}				
			die("1");
		}else{
			die("0");
		}
	}
}