<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class genelayarlar extends CI_Controller {

	function __construct(){
		parent::__construct();
			logged_admin();
			
	}
	
	public function index(){
		if(yetki != 3){redirect(base_url().'hata');}
		
		$ver="select * from ayar where user=".id."";
		$sorgu = $this->db->query($ver)->row();
		//print_R($sorgu);exit;
		$sec1=$sec2=$ceng=$ceng2=$cengb=$ceng2b='';
		if($sorgu->neolsun==1){$sec1='selected';}else if($sorgu->neolsun==2){$sec2='selected';}
		if(canliyasak==0){$ceng='selected';}elseif(canliyasak==2){$ceng2='selected';}
		if(canliyasakb==0){$cengb='selected';}elseif(canliyasakb==2){$ceng2b='selected';}
		
		$this->smarty->assign('sec1',$sec1);
		$this->smarty->assign('sec2',$sec2);
		$this->smarty->assign('ilk',$sorgu->ilkveri);
		$this->smarty->assign('iki',$sorgu->ikiveri);
		$this->smarty->assign('ceng',$ceng);
		$this->smarty->assign('ceng2',$ceng2);
		
		$this->smarty->assign('cengb',$cengb);
		$this->smarty->assign('ceng2b',$ceng2b);
		$this->smarty->view('genelayarlar.tpl');
	}
	
	public function kayit(){
		
		if(yetki != 3){redirect(base_url().'hata');}
		
		$ilkveri = $this->input->post('ilkveri');
		$ikiveri = $this->input->post('ikiveri');
		$neolsun = $this->input->post('neolsun');
		$cengelle = $this->input->post('cengelle');
		$cengelleb = $this->input->post('cengelleb');
		$ckelime = $this->input->post('ckelime');
		$futbol = $this->input->post('futbol');
		$duello = $this->input->post('duello');
		$basketbol = $this->input->post('basketbol');
		$ckelime = preg_replace('/([^0-9a-zA-Z,])/si', '', $ckelime);
		
		$ouser = $this->db->query("select ayarlar,id from kullanici where (hesap_sahibi_id=".id." or hesap_root_id=".id." or id=".id.")");
		foreach($ouser->result() as $row){
			$ayrv=unserialize($row->ayarlar);	
			$ayrv['ckelime']=$this->db->escape_str($ckelime);
			$ayrv['futbol']=$this->db->escape_str($futbol);
			$ayrv['duello']=$this->db->escape_str($duello);
			$ayrv['basketbol']=$this->db->escape_str($basketbol);
			$bayiAyari = $ayrv;
			$this->db->query("update kullanici set ayarlar='".$this->db->escape_str(serialize($bayiAyari))."' where id=".$row->id."");
		}
		
		if($cengelle==1 && canliyasak==0){
			$this->db->query("update kullanici set canliyasak='1' where (hesap_sahibi_id=".id." or hesap_root_id=".id.")");
			$this->db->query("update kullanici set canliyasak='2' where id=".id."");
		}
		if($cengelle==2 && canliyasak==2){
			$this->db->query("update kullanici set canliyasak='0' where (hesap_sahibi_id=".id." or hesap_root_id=".id.")");
			$this->db->query("update kullanici set canliyasak='0' where id=".id."");
		}
		
		if($cengelleb==1 && canliyasakb==0){
			$this->db->query("update kullanici set canliyasakb='1' where (hesap_sahibi_id=".id." or hesap_root_id=".id.")");
			$this->db->query("update kullanici set canliyasakb='2' where id=".id."");
		}
		if($cengelleb==2 && canliyasakb==2){
			$this->db->query("update kullanici set canliyasakb='0' where (hesap_sahibi_id=".id." or hesap_root_id=".id.")");
			$this->db->query("update kullanici set canliyasakb='0' where id=".id."");
		}
		
		if($neolsun==3){
			$ver="select * from ayar where user=".id."";
			$sorgu = $this->db->query($ver);
			if ($sorgu->num_rows() > 0) {
				$this->db->delete('ayar', array('user' => id)); 
			}
			redirect(base_url().'genelayarlar');
			exit;
		}
		
		if($ilkveri && $ikiveri && $neolsun){
			$ver="select * from ayar where user=".id."";
			$sorgu = $this->db->query($ver);
			if ($sorgu->num_rows() > 0) {
				$this->db->update('ayar', array('ilkveri' =>addslashes($ilkveri),'ikiveri' =>addslashes($ikiveri),'neolsun' =>addslashes($neolsun),'user' =>id), array('user' =>id));
			}else{
				$this->db->insert('ayar', array('ilkveri' =>addslashes($ilkveri),'ikiveri' =>addslashes($ikiveri),'neolsun' =>addslashes($neolsun),'user' =>id));
			}
		}
		
		redirect(base_url().'genelayarlar');
	}
	
	
}