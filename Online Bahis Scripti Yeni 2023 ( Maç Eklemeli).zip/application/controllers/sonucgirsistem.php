<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class sonucgirsistem extends CI_Controller {

	function __construct(){
		parent::__construct();
		logged_admin();
		if(yetki == 2 || yetki == 4){redirect(base_url().'hata');}
	}
	public function siradakigolkaydet($ne){
		
		ajaxvarmi();
		$mac_kodu = (int)$this->input->post('mac_kodu');
		$mac_db_id = (int)$this->input->post('mac_db_id');
		$tarih = $this->input->post('tarih');
		$goller=$_POST['goller'];
		if($ne==0){
			foreach($goller as $k=>$veri){
				if($veri>0){
					$ver='select * from canli_gol_list where eventid='.$mac_kodu.' and mac_db_id='.$mac_db_id.' and golsayi='.$k.'';
					$varmi = $this->db->query($ver)->num_rows();
					if($varmi==0){
						$ins="insert into canli_gol_list (eventid,mac_db_id,golsayi,atantakim) values ('$mac_kodu','$mac_db_id','$k','$veri')";
						$okmu=$this->db->query($ins);
					}else{
						$upd="update canli_gol_list set golsayi='$k',atantakim='$veri' where eventid='$mac_kodu' and mac_db_id='$mac_db_id' and golsayi='$k'";
						$okmu=$this->db->query($upd);
					}				
				}else if($veri==0){
					$del="delete from canli_gol_list where eventid='$mac_kodu' and mac_db_id='$mac_db_id' and golsayi='$k'";
					$okmu=$this->db->query($del);
				}
			}
			if($okmu){
				echo'1';$this->session->set_flashdata('okmu', 'Goller Kaydedildi.');
			}else{
				echo'0';$this->session->set_flashdata('okmu', 'Lütfen formu kontrol edip yeniden deneyiniz..!');
			}
		}
		
		if($ne>0){
			if(yetki == 3){
				$kimin='and user_id in ((select id from kullanici where hesap_sahibi_id='.kendi.'))';
			}elseif(yetki == 1){
				$kimin='';
			}
			$ilksql="select * from kupon_ic where spor_tip='canli' and mac_db_id = $mac_db_id $tarih and oran_tip like '%Sıradaki Gol%' and direksonuc!='3' $kimin";
			$r1 = $this->db->query($ilksql);			
			if ($r1->num_rows() > 0) {			
				foreach($r1->result() as $r){
					$okmu=$upbe="update kupon_ic set direksonuc=1 where id=".$r->id." ";
					$this->db->query($upbe);		
					$eklenen++;
				}					
			}
			if($okmu){
				echo'1';$this->session->set_flashdata('okmu', 'Kuponlar Hesaplanmak üzere Kaydedildi..');
			}else{
				echo'0';$this->session->set_flashdata('okmu', 'Lütfen formu kontrol edip yeniden deneyiniz..!');
			}
		}
		
	}
	
	public function siradaki(){
		ajaxvarmi();
		$mac_kodu = (int)$this->input->post('mac_kodu');
		$tarih = $this->input->post('tarih');
		$dbid = (int)$this->input->post('dbid');
		
		echo '<b>'.$mac_kodu.'</b> nolu maça ait Gol sıralama kayıt formu <hr><br><form id="siraform">
		<table><tr>';
		$count=1;
		for ( $say=1 ; $say < 9 ; $say++ ){
			$sel=$sel1='';
			$ver='select * from canli_gol_list where eventid='.$mac_kodu.' and mac_db_id='.$dbid.' and golsayi='.$say.' limit 1';
			$row = $this->db->query($ver)->row();
			if($row->golsayi==$say){
				if($row->atantakim==1){
					$sel='selected';
				}else if($row->atantakim==2){
					$sel1='selected';
				}
			}
			echo'
			<td>'.$say.'. GOL<BR><select name="goller['.$say.']">
				<option value="">Gol Yok</option>
				<option value="1" '.$sel.'>Evsahibi</option>
				<option value="2" '.$sel1.'>Deplasman</option>
				</select>
			</td>';
			$count++;
			if ($count == 5) {
				echo  "</tr></tr>";
				$count = 0;
			}
		}
		echo'<tr style="height:40px"><td colspan="5"><hr></td></tr>
		</tr>
		</table>
		<div style="width:100%">
		<input type="button" value="Golleri Kaydet" name="submit" onclick="if(!confirm(\'Goller Kaydedilecek. Emin misiniz?\'))return;siradakikayit('.$mac_kodu.',\''.$tarih.'\','.$dbid.',0);" style="background: #E47200;color:#fff"> 
		<span style="float:right">
		<input type="button" value="Kuponları Hesapla" name="submit" onclick="if(!confirm(\'Kuponlar Hesaplanıcak. Emin misiniz?\'))return;siradakikayit('.$mac_kodu.',\''.$tarih.'\','.$dbid.',1);" style="background:#8EB183;color:#fff">
		</span>	
		'.$this->session->flashdata('okmu') .'
		</div>
		<input type="hidden" name="mac_kodu" value="'.$mac_kodu.'">
		<input type="hidden" name="mac_db_id" value="'.$dbid.'">
		<input type="hidden" name="tarih" value="'.$tarih.'">
		</form>';
	}
	
	public function kupond(){
		
		ajaxvarmi();
		$mac_kodu = (int)$this->input->post('mac_kodu');
		$where = str_replace('\\','',$this->input->post('where'));
		?>
		<table class="tftable">
		<tr>
		<th>Kupon Kodu</td>
		<th>Zaman</td>
		<th>Spor</td>
		<th>Kod</td>
		<th>Ev Sahibi</td>
		<th>Deplasman</td>
		<th>Tahmin</td>
		<th>Tercih</td>
		<th>Oran</td>
		<th>İy</td>
		<th>Ms</td>
		<th style="width:50px">Durum</td>
		<th style="width:50px">Maç</td>
		</tr>
	<?
	$ver='select * from kupon_ic where mac_kodu='.$mac_kodu.' and '.$where.' order by kupon_id asc';
	$sor = $this->db->query($ver);
	foreach($sor->result_array() as $row){
		$ob = explode("|",$row['oran_tip']);
		if($row['spor_tip']=="canli" || $row['spor_tip']=="canlib") {
		if($row['spor_tip']=="canli"){$tbl='';}elseif($row['spor_tip']=="canlib"){$tbl='b';}
		
		$infobol = explode("|",$row['canli_info']);
		$zaman = "$infobol[0] <strong>($infobol[1])</strong>";
		$fark = time()-60;
		$canlibilgi = $this->db->query("select iy_ev,iy_konuk,ev_skor,konuk_skor,songuncelleme,devremi,dakika from canli_maclar$tbl where id='$row[mac_db_id]' and songuncelleme>$fark ");
		
		if($canlibilgi->num_rows()>0) {
			
			$bilgisi = $canlibilgi->row_array();	
			$iy = "$bilgisi[iy_ev]-$bilgisi[iy_konuk]*";
			$ms = "$bilgisi[ev_skor]-$bilgisi[konuk_skor]*";
			$farki = time()-60;
			if($bilgisi['songuncelleme'] < $farki) {
				$macsonucu = "Sonuç bekleniyor"; 
			} else if($bilgisi['devremi']=="1") {
				$macsonucu = "Devrede"; 
			} else{
				$macsonucu = "Devam Ediyor <strong>($bilgisi[dakika].dk)</strong>";
			}
		} else {
			$iy = $row['iy'];
			$ms = $row['ms'];
			$macsonucu = "Sona Erdi";
		}
	} else {
		if($row['mac_time']<time()) { 
			$macsonucu = "Başladı <strong>(".date("H:i",$row['mac_time']).")</strong>"; 
		} else if($row['ertelendi']=="2") {
			$macsonucu = "<strong>Ertelendi</strong>"; 	
		} else {
			$macsonucu = "Başlamadı <strong>".date("d.m H:i",$row['mac_time'])."</strong>"; 
		}
		
		$zaman = date("d.m H:i",$row['mac_time']);	
		$iy = $row['iy'];
		$ms = $row['ms'];
	}
	if($row['kazanma']!="1") { $macsonucu = "Sonuçlandı"; }
	if($iy=="") { $iy= "-"; }
	if($ms=="") { $ms= "-"; }
	$tahmin=$ob[0];
	$tercih=$ob[1];
	?>
	<tr class="durum_<?=$row['kazanma'];?>" >
	<td><?=$row['kupon_id']; ?></td>
	<td><?=$zaman;?></td>
	<td><?=sporyaz($row['spor_tip']); ?><br><?=$row['hangicanli'];?></td>
	<td><?=$row['mac_kodu']; ?></td>
	<td><?=$row['ev_takim']; ?></td>
	<td><?=$row['konuk_takim']; ?></td>
	<td><?=$tahmin;?></td>
	<td><?
	if(strstr($tahmin,"Sıradaki Gol") && $tercih=='Gol Olmaz'){
		$skorver=' ('.str_replace(':','-',$infobol[0]).')';
		echo$tercih=$tercih.$skorver;
	}else{
		echo$tercih;
	}
	?> <? if(!empty($row['oran_val'])) { 
			if($row['spor_tip']=='basketbol'){echo "($row[oran_val])";}else{echo "$row[oran_val]";}
	}?></td>
	<td><strong><? $oranes = nf($row['oran']); echo $oranes; ?></strong></td>
	<td><?=$iy;?></td>
	<td><?=$ms;?></td>
	<td><?=durumnedir($row['kazanma']); ?></td>
	<td><? echo $macsonucu; ?></td>
	</tr>
	<? } ?>
	</table>
	
	<?}
	
	public function index(){	
		
		$mkodsuz = $this->input->get('mkodsuz');
		$hangi = $this->input->get('hangi');
		$tur=$this->input->get('tur');
		$mac_kodu=$this->input->get('mackodu');
		$gtarih = $this->input->get('t1');
		$ctip = $this->input->get('ctip');

		$pages = array("1" => "Futbol","2" => "Basketbol","3" => "Canlı Futbol","4" => "Canlı Basketbol");
		$optver='';
		foreach ($pages as $url => $label) {
			$optver.='<option ';if($hangi== $url){$optver.= "selected=''";}$optver.= " value=$url>$label</option>";
		}
		
		$pages1 = array("1" => "Sonuç Gir","2" => "Sonuç Düzelt");
		$optver1='';
		foreach ($pages1 as $url1 => $label1) {
			$optver1.='<option ';if($tur== $url1){$optver1.= "selected=''";}$optver1.= " value=$url1>$label1</option>";
		}
		
		if($hangi==1){
			$tdiv='Futbol';$spor_tip="spor_tip in('futbol','duello')";$tablo='program';$wheresicanli="and iy!='' and ms!=''  group by mac_kodu";
		}else if($hangi==2){
			$tdiv='Basketbol';$spor_tip="spor_tip='basketbol'";$tablo='programb';$wheresicanli="and iy!='' and ms!=''  group by mac_kodu";
		}else if($hangi==3){
			$tdiv='Canlı Futbol';$spor_tip="spor_tip='canli'";$tablo='program';$wheresicanli='group by mac_db_id';
		}else if($hangi==4){
			$tdiv='Canlı Basketbol';$spor_tip="spor_tip='canlib'";$tablo='program';$wheresicanli='group by mac_db_id';
		}
		
		$bas='';
		
		if($gtarih || $mac_kodu){
			
			list($d, $m, $y) = explode('-', $gtarih);
			$tarih= mktime(00, 00, 00, $m, $d, $y);
			$tarih1= mktime(23,59,59, $m, $d, $y);
			
			if($mac_kodu){
				$mac_koduyaz="and mac_kodu ='$mac_kodu'";
			}else{
				$mac_koduyaz="";
			}
			
			$grup="group by mac_kodu";
			
			if($mkodsuz){
				$mac_koduyaz="and mac_kodu =''";
				$grup="group by mac_db_id";
			}
			
			if($ctip){
				$ctipyaz="and oran_tip like '%$ctip%'";
			}else{
				$ctipyaz="";
			}
			
			if($tur==2){
				$kazanekle="and kazanma !='1' ";
			}else{
				$kazanekle="and kazanma='1' and direksonuc=0";
			}
			
			if($hangi==3 || $hangi==4){
				$tarihara="and ilkgiris >= $tarih and ilkgiris <= $tarih1";
				$mctrh='ilkgiris';
			}else{
				$tarihara="and mac_time >= '$tarih' and mac_time <= $tarih1";
				$mctrh='mac_time';
			}
			$kupdver=$spor_tip.' '.$tarihara;
			if(yetki == 3){
				$kimin='and user_id in ((select id from kullanici where hesap_sahibi_id='.kendi.'))';
			}elseif(yetki == 1){
				$kimin='';
			}
			$swl="select * from kupon_ic where $spor_tip $kazanekle $tarihara and kazanma!=4 $mac_koduyaz  $ctipyaz and direksonuc!='3' $kimin $grup order by $mctrh asc";
			$maclar = $this->db->query($swl);
			
		if ($maclar->num_rows() > 0) { 
			
			$bas.='
			<input type="hidden" id="verial" value="'.$kupdver.'">
			<table class="tftable" style="width:100%" cellspacing="0" cellpadding="0">
			<thead>
			<tr>
			<th width="30">Kodu</td>
			<th width="60" id="sdiv">Sonuç</td>
			<th class="t">Maç</td>
			<th width="90">Maç Tarihi</td>';
			if($hangi==4){
				$bas.='<th width="40">1.Ç</td><td width="40">2.Ç</td><td width="40">3.Ç</td><td width="40">4.Ç</td>';
			}
			$bas.='<th width="40">İY 1</td>
			<th width="40">İY 2</td>
			<th width="40">MS 1</td>
			<th width="40">MS 2</td>
			<th width="40"></td>
			<th width="40"></td>
			</tr></thead><tbody>';
			
			foreach($maclar->result_array() as $r){
			
			$idsi = $r['mac_db_id'];
			$ta  = $r['ev_takim'];
			$tb	 = $r['konuk_takim'];
			$spor_tipi	 = $r['spor_tip'];
			
			if($ctip){
				$ctipdiv='<hr><a href="javascript:;" onClick="siradaki('.$r['mac_kodu'].',\''.$tarihara.'\','.$idsi.');" style="color:inherit; font-weight:bold;" title="Sıradaki Gol Kayıt">[Gol Kayıt]</a>';
			}else{
				$ctipdiv="";
			}
			if($r['ertelendi']==2){
				$durumclas='"color: #006699;font-weight: bold"';
				$ertyaz='<td><span class="button">Ertelendi</span></td>';
			}else{
				$durumclas='';
				$ertyaz='<td><input type="submit" value="Ertele" class="buttonbu" name="submit" onclick="javascript:return confirm(\'Maç Ertelenecektir Eminmisiniz?\');"></td>';
			}
			$ceyr=explode(',',$r['oran_val2']);
			$cy1=explode('-',$ceyr[0]);
			$cy2=explode('-',$ceyr[1]);
			$cy3=explode('-',$ceyr[2]);
			$cy4=explode('-',$ceyr[3]);
			$arrilk=explode('-',$r['iy']);
			$arriki=explode('-',$r['ms']);
			$i1=$i2=$i3=$i4='';
			if($arrilk[0]==''){$i1='border: 2px solid red';}
			if($arrilk[1]==''){$i2='border: 2px solid red';}
			if($arriki[0]==''){$i3='border: 2px solid red';}
			if($arriki[1]==''){$i4='border: 2px solid red';}
								
			$bas.= '
			<form method="post" action="'.base_url().'sonucgirsistem/kaydet" id="sonucform">
			<input type="hidden" name="mac_db_id" value="'.$idsi.'"><input type="hidden" name="mac_kodu" value="'.$r['mac_kodu'].'"><input type="hidden" name="trhsi" value="'.$gtarih.'"><input type="hidden" name="mkodsuz" value="'.$mkodsuz.'"><input type="hidden" name="redirect" value="?hangi='.$hangi.'&tur='.$tur.'&t1='.$gtarih.'&mkodsuz='.$mkodsuz.'&mackodu='.$mac_kodu.'&ctip='.$ctip.'"><input type="hidden" name="spor_tip" value="'.$spor_tip.'"><input type="hidden" name="hangi" value="'.$hangi.'">
			<tr style="'.$durumclas.'">
			<td '.$durumclas.'><a href="javascript:;" onClick="kupond('.$r['mac_kodu'].');" style="cursor:pointer;text-decoration:underline" title="Detaylar">'.$r['mac_kodu'].'</a></td>
			<td '.$durumclas.'><a href="javascript:sonucubul(\''.$hangi.'\',\''.$ta.'\',\''.$tb.'\',\''.$idsi.'\',\''.$r['mac_time'].'\');" style="color:inherit; font-weight:bold;">[BUL]</a>'.$ctipdiv.'<span id="sonucu_'.$idsi.'" style="display:inherit;"></span></td>
			<td '.$durumclas.'>'.$ta.'-'.$tb.' ('.$spor_tipi.')</td>
			<td '.$durumclas.'>'.date('d-m-Y H:i',$r[$mctrh]).'</td>';
			if($hangi==4){
				$bas.= '<td><input type="text" id="c1e_'.$idsi.'" class="editkupon alc" name="c1e" size="5" value="'.@$cy1[0].'" style="'.$i1.'" onkeypress="return SadeceRakam(event,['.']);" onblur="SadeceRakamBlur(event,true);"><input type="text" id="c1d_'.$idsi.'" class="editkupon alc" name="c1d" size="5" value="'.@$cy1[1].'" style="'.$i1.'" onkeypress="return SadeceRakam(event,['.']);" onblur="SadeceRakamBlur(event,true);"></td>
				
				<td><input type="text" id="c2e_'.$idsi.'" class="editkupon alc" name="c2e" size="5" value="'.@$cy2[0].'" style="'.$i1.'" onkeypress="return SadeceRakam(event,['.']);" onblur="SadeceRakamBlur(event,true);"><input type="text" id="c2d_'.$idsi.'" class="editkupon alc" name="c2d" size="5" value="'.@$cy2[1].'" style="'.$i1.'" onkeypress="return SadeceRakam(event,['.']);" onblur="SadeceRakamBlur(event,true);"></td>
				
				<td><input type="text" id="c3e_'.$idsi.'" class="editkupon alc" name="c3e" size="5" value="'.@$cy3[0].'" style="'.$i1.'" onkeypress="return SadeceRakam(event,['.']);" onblur="SadeceRakamBlur(event,true);"><input type="text" id="c3d_'.$idsi.'" class="editkupon alc" name="c3d" size="5" value="'.@$cy3[1].'" style="'.$i1.'" onkeypress="return SadeceRakam(event,['.']);" onblur="SadeceRakamBlur(event,true);"></td>
				
				<td><input type="text" id="c4e_'.$idsi.'" class="editkupon alc" name="c4e" size="5" value="'.@$cy4[0].'" style="'.$i1.'" onkeypress="return SadeceRakam(event,['.']);" onblur="SadeceRakamBlur(event,true);"><input type="text" id="c4d_'.$idsi.'" class="editkupon alc" name="c4d" size="5" value="'.@$cy4[1].'" style="'.$i1.'" onkeypress="return SadeceRakam(event,['.']);" onblur="SadeceRakamBlur(event,true);"></td>';
			}
			$bas.= '<td><input type="text" id="iy1_'.$idsi.'" class="editkupon alc" name="sonuc1" onkeypress="return SadeceRakam(event,['.']);" onblur="SadeceRakamBlur(event,true);" maxlength="4" size="5" value="'.@$arrilk[0].'" style="'.$i1.'"></td>
			<td><input type="text" id="iy2_'.$idsi.'" class="editkupon alc" name="sonuc2" onkeypress="return SadeceRakam(event,['.']);" onblur="SadeceRakamBlur(event,true);" maxlength="4" size="5" value="'.@$arrilk[1].'" style="'.$i2.'"></td>
			<td><input type="text" id="ms1_'.$idsi.'" class="editkupon alc" name="sonuc3" onkeypress="return SadeceRakam(event,['.']);" onblur="SadeceRakamBlur(event,true);" maxlength="4" size="5" value="'.@$arriki[0].'" style="'.$i3.'"></td>
			<td '.$durumclas.'><input type="text" id="ms2_'.$idsi.'" class="editkupon alc" name="sonuc4" onkeypress="return SadeceRakam(event,['.']);" onblur="SadeceRakamBlur(event,true);" maxlength="4" size="5" value="'.@$arriki[1].'" style="'.$i4.'"></td>			
			<td '.$durumclas.'><input type="submit" name="submit" class="buttonbu" value="Uygula" onclick="javascript:return confirm(\'Sonuç Girilecektir Eminmisiniz?\')"></td>
			'.$ertyaz.'
			</tr>
			</form>';
			}
			$bas.='</tbody></table>';
			
		}else{
			$bas.= '<table style="margin:10px 0px 20px 10px;width:98%;color:#fff" id="table_step"><tr><td colspan="5"><div class="formbaslik" style="margin: 5px">Skor kaydedilmesi gereken maç bulunamadı.</div></td></tr></table>';	
		}		
		}
		$this->smarty->assign('sonuc', $this->session->flashdata('sonuc')); 
		$this->smarty->assign('liste',$bas);
		$this->smarty->assign('mac_kodu',$mac_kodu);
		if($gtarih==''){
			$trhveer=date('d-m-Y');
		}else{
			$trhveer=$gtarih;
		}
		$this->smarty->assign('postt',$trhveer);
		$this->smarty->assign('secim',$optver);
		$this->smarty->assign('sonc',$optver1);
		$this->smarty->view('sonucgir.tpl');
		 
	}
	
	public function kaydet(){
		
		$sub = $this->input->post('submit');
				
		if(isset($sub) && $sub == 'Uygula'){
	
			$mkodsuz = $this->input->post('mkodsuz');
			$gtarih = $this->input->post('trhsi');
			$mac_db_id = $this->input->post('mac_db_id');
			$s1 = $this->input->post('sonuc1');
			$s2 = $this->input->post('sonuc2');
			$s3 = $this->input->post('sonuc3');
			$s4 = $this->input->post('sonuc4');
			$c1e = $this->input->post('c1e');
			$c1d = $this->input->post('c1d');
			$c2e = $this->input->post('c2e');
			$c2d = $this->input->post('c2d');
			$c3e = $this->input->post('c3e');
			$c3d = $this->input->post('c3d');
			$c4e = $this->input->post('c4e');
			$c4d = $this->input->post('c4d');
			$hangi = $this->input->post('hangi');
			$mac_kodu = $this->input->post('mac_kodu');
			$spor_tip = str_replace('\\','',$this->input->post('spor_tip'));
			$redirect = $this->input->post('redirect');
			
			list($d, $m, $y) = explode('-', $gtarih);
			$tarih= mktime(00, 00, 00, $m, $d, $y);
			$tarih1= mktime(23,59,59, $m, $d, $y);
			
			if($s1 != '' && $s2 != '' && $s3 != '' && $s4 != '' && $mac_db_id != ''){
				
				if($hangi==3 || $hangi==4 || $mkodsuz){$sqlek='';}else{$sqlek="and mac_kodu = '$mac_kodu' ";}
				
				if($hangi==3 || $hangi==4){
					$tarihara="and ilkgiris >= '$tarih' and ilkgiris <= '$tarih1'";
				}else{
					$tarihara="and mac_time >= '$tarih' and mac_time <= '$tarih1'";
				}
				
				if($ctip){
					$ctipyaz="and oran_tip like '%$ctip%'";
				}else{
					$ctipyaz="";
				}
				if(yetki == 3){
					$kimin='and user_id in ((select id from kullanici where hesap_sahibi_id='.kendi.'))';
				}elseif(yetki == 1){
					$kimin='';
				}
				$ilksql="select * from kupon_ic where $spor_tip and mac_db_id = $mac_db_id $sqlek $tarihara and direksonuc!='3' $kimin";
				$r1 = $this->db->query($ilksql);
				
				if ($r1->num_rows() > 0) {
				
					foreach($r1->result() as $r){				
						$iy=$s1.'-'.$s2;
						$ms=$s3.'-'.$s4;
						$oran_val2=$c1e.'-'.$c1d.','.$c2e.'-'.$c2d.','.$c3e.'-'.$c3d.','.$c4e.'-'.$c4d;
						/*if($hangi==2){
							$sonuc = basket_durum_cek($r->mac_db_id,$r->oran_tip,$r->oran_val,$r->oran_val2,$s1,$s2,$s3,$s4);
						}else if($hangi==1){
							$sonuc = normal_mac_sonuc($iy,$ms,$r['oran_val']);
						}else if($hangi==3){
							$sonuc = canli_normal_sonuc($iy,$ms,$r->oran_tip,$r->id,$r->mac_db_id);
						}*/
						$upbe="update kupon_ic set iy='$iy',ms='$ms',oran_val2='$oran_val2',direksonuc=1 where id=".$r->id." ";
						$this->db->query($upbe);		
						$eklenen++;
					}					
				}
			}
				
			if($eklenen == 0){
				$this->session->set_flashdata('sonuc','<div class="bos">Hiç skor girilmedi.</div>');
			}else{		
				$this->session->set_flashdata('sonuc', '<div class="tamam">'.$mac_kodu.' kodlu maç sonucu eklendi.</div>');
			}
		}else if(isset($sub) && $sub == 'Ertele'){
	
			$gtarih = $this->input->post('trhsi');
			$mac_db_id = $this->input->post('mac_db_id');
			$hangi = $this->input->post('hangi');
			$mac_kodu = $this->input->post('mac_kodu');
			$spor_tip = str_replace('\\','',$this->input->post('spor_tip'));
			$redirect = $this->input->post('redirect');
			
			list($d, $m, $y) = explode('-', $gtarih);
			$tarih= mktime(00, 00, 00, $m, $d, $y);
			$tarih1= mktime(23,59,59, $m, $d, $y);
			
			if($mac_db_id != ''){
				
				if($hangi==3 || $hangi==4){$sqlek='';}else{$sqlek="and mac_kodu = '$mac_kodu' ";}
				if($hangi==3 || $hangi==4){
					$tarihara="and ilkgiris >= '$tarih' and ilkgiris <= '$tarih1'";
				}else{
					$tarihara="and mac_time >= '$tarih' and mac_time <= '$tarih1'";
				}
				if(yetki == 3){
					$kimin='and user_id in ((select id from kullanici where hesap_sahibi_id='.kendi.'))';
				}elseif(yetki == 1){
					$kimin='';
				}
				$ilksql="select id,kupon_id from kupon_ic where ".$spor_tip." and mac_db_id = $mac_db_id $sqlek $tarihara and direksonuc!='3' $kimin";
				$r1 = $this->db->query($ilksql);
				
				if ($r1->num_rows() > 0) {
					$kupidler=array();
					foreach($r1->result() as $r){				
						$upbe="update kupon_ic set iy='-',ms='-',oran='1.00',ertelendi='1',kazanma=5 where id=".$r->id." ";
						$this->db->query($upbe);
						$kupidler[] = $r->kupon_id;												
						$eklenen++;
					}
					//if($eklenen > 0){kuponhesapla_ertelemeli(implode(',',$kupidler));}	
				}
			}
				
			if($eklenen == 0){
				$this->session->set_flashdata('sonuc','<div class="bos">Hiç veri girilmedi.</div>');
			}else{		
				$this->session->set_flashdata('sonuc', '<div class="tamam">'.$mac_kodu.' kodlu Ertelendi.</div>');
			}
		}else{
			$this->session->set_flashdata('sonuc','<div class="bos">veri aktarımı sorunu.</div>');
		}
		
		redirect(base_url()."sonucgirsistem/".$redirect);
	}
	
}