<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class kayit extends CI_Controller {

	function __construct(){
		parent::__construct();
			logged_admin();
	}
	
	public function indexm(){
		$this->smarty->view('mobil/kayit.tpl');
	}
	
	public function index(){
		$this->smarty->view('kayit.tpl');
	}
	
	public function gonder(){
		extract($_POST);
		$bayiAyar = array(
			"domain"=> 0,
			"canli_kupon_sure"=> '3',				
			"canli_koruma"=> '0.00',				
			"sanalbahis"=> '1',		
			"kesinti"=> '0',				
			"ckelime"=> '',				
			"kombine"=> '1',
			"yazici"=> 'normal',				
			"canli_dk_kes"=> 44,				
			"canli_dk_kes1"=> 90,				
			"calisma_sekli"=> 0,				
			"komisyon"=> 0,
			"ccalisma_sekli"=> 0,
			"ckomisyon"=> 0,
			"futbol"=> 1,
			"duello"=> 1,
			"basketbol"=> 1,
			"iptal_sure"=> 5,
			"iptal_limit"=> 10,
			"maxodeme"=> 15000,
			"aynikuponmax"=> 5000,
			"sabitmbs"=> 0,
			"maxmac"=> 15,
			"minmac"=> 1,
			"tekmacmax"=> 1000,
			"canli_tekmac"=> 1000,
			"min_oran"=> '1.50',
			"maxoran"=> 1000,
			"minkupon"=> 1,
			"maxkupon"=> 1000,
			"canli_sure"=> 15,
			"iptal_yetki"=> 0,
			"oranduzenleme"=> 0,
			"sehir"=> $sehir,
			"adres"=> $adres,
			"tc"=> $tc,
			"cins"=> $cins,
			"ad"=> $ad.' '.$ad1,
			"dogum"=> $d1.'-'.$d2.'-'.$d3,
			"pkod"=> $pkod,
			"ulke"=> $ulke,
			"para"=> $parasi,
			"tel"=> $cep,
			"email"=> $email
		);
		
		$buldum=$this->db->query('SELECT * FROM `kullanici` WHERE yetki=3 and ayarlar REGEXP \'.*"domain";s:[0-9]+:"0".*\'');
		if($buldum->num_rows>0){
			$row = $buldum->row();
			$arra = array("password" => $sifre,"username" => $user,"firma" => '',"hesap_sahibi_user" => $row->username,"hesap_sahibi_id" => $row->id,"hesap_root_id" => $row->hesap_sahibi_id,"tip" => 'Bayi','yetki'=>4,"ayarlar" => serialize($bayiAyar));
			$this->db->insert('kullanici', $arra);
			if($this->db->affected_rows()){echo 1;exit;}else{echo '0';exit;}
		}else{
			echo '0';exit;
		}
	}
	
	public function kontrol(){
		$user = $this->input->get('user');
		$email = $this->input->get('email');
		if($email){
			$bemail = $this->input->post('bemail');
			echo$this->db->query("select id from kullanici where bemail='".$bemail."' and durum='1'")->num_rows;exit;
		}elseif($user){
			$useri = $this->input->post('useri');
			echo$this->db->query("select id from kullanici where username='".$useri."' and durum='1'")->num_rows;exit;
		}
	}
}