<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class canlibahisb extends CI_Controller {

	function __construct(){
		parent::__construct();
			logged_admin();
			$this->userler=kendi.','.ustu.','.patron;
			//canlisil('');
			$kelimeler = explode(',', ckelime);
			$this->notLike = "";
			if(!empty(ckelime)){
				foreach($kelimeler as $keyword){
					if(trim($keyword)=="")
						continue;
					$this->notLike .= " AND a.ev_takim NOT LIKE '%".$this->db->escape_str($keyword)."%'";
					$this->notLike .= " AND a.konuk_takim NOT LIKE '%".$this->db->escape_str($keyword)."%'";
				}
			}
			$this->fark = time()-80;
	}
	
	public function index(){
		
		if(canliyasakb >0 || canlibahisb==0){redirect(base_url().'hata');}
		$this->smarty->view('canli.tpl');
		 
	}
	
	public function liveodds($mac_id,$farkliyaz,$x1=0){
		
		ajaxvarmi();
		$bas='';
		if(canliyasak >0 || canlibahis==0){
			$bas.='<div class="bos">'.lang('cbos').'</div>';
			echo ($bas);
			exit; 
		}
		if($mac_id){
			if($x1){$x = $x1;}else{$x = $this->input->post("x");}
			if($x){
				$ekle="and b.id not in (".$x.")";
			}else{
				$ekle='';
			}
			//print_R($alma);exit;
			$yeni='SELECT a.eventid,k.coranid,a.id,a.lig_adi,a.aktif,a.fms,a.dakika,a.ev_takim,a.konuk_takim,a.ev_skor,a.konuk_skor,a.devre,a.gol,a.sonoranguncelleme,
			(SELECT gizliler FROM coranverb WHERE oranvalid=0 and lig_mac=0 and uye in('.$this->userler.') and gizliler=a.eventid and tip="aski") as surekliaski,
			(SELECT group_concat(oranvalid) FROM coranverb WHERE lig_mac in(0,a.eventid) and uye in('.$this->userler.') and tip="gizlioranic") as gizlioranic,
			if(a.devre = "1. Yarı" and a.dakika >= '.canli_dk_kes.',1,0) as ilkyarigizle,
			GROUP_CONCAT(
			ct.tip_isim,"|",
			ct.id,"|",
			b.oran_adi,"|",
			   (		
				case				
				when c.tip="tumcanli" then CONCAT(ROUND(oranyuzdehesapla(b.oran,(c.oran+IFNULL(m.oran,0))),2))		
				when m.tip="macbasket" then CONCAT(ROUND(oranyuzdehesapla(b.oran,m.oran),2))		
				else CONCAT(ROUND(b.oran,2))
				end
				)	
			  ,"|",b.yukselis,"|",b.dusus,"|",b.askida ORDER BY ct.sira asc,b.sira asc
			) as sonoran

			FROM canli_maclarb a
			left join kupon k on k.mac_kodu=a.eventid and session_id='.id.' and onlem="'.sesid.'"
			left join canli_oranb b on b.mac_id=a.eventid and b.canli_tip not in((SELECT oranvalid FROM coranverb WHERE lig_mac in(0,a.eventid) and uye in('.$this->userler.') and tip="gizlioran")) and b.canli_tip not in (1) '.$ekle.'
			
			left join canli_tipb ct on ct.id=b.canli_tip and ct.durum=1
			
			left join coranverb c on c.oranvalid=b.oran_adi and c.lig_mac = 0 and c.uye =(
			if(EXISTS(SELECT uye FROM coranverb WHERE oranvalid=b.oran_adi and lig_mac = 0 and uye='.kendi.' and tip="tumcanli")
			,'.kendi.',if(EXISTS(SELECT uye FROM coranverb WHERE oranvalid=b.oran_adi and lig_mac = 0 and uye='.ustu.' and tip="tumcanli"),'.ustu.','.patron.'))
			) and c.tip="tumcanli"

			left join coranverb m on m.oranvalid=b.oran_adi and m.lig_mac = a.eventid and m.uye=(
			if(EXISTS(SELECT uye FROM coranverb WHERE oranvalid=b.oran_adi and lig_mac = a.eventid and uye='.kendi.' and tip="macbasket")
			,'.kendi.',if(EXISTS(SELECT uye FROM coranverb WHERE oranvalid=b.oran_adi and lig_mac = a.eventid and uye='.ustu.' and tip="macbasket"),'.ustu.','.patron.'))
			) and m.tip="macbasket"
		
			where
			a.eventid not in((SELECT gizliler FROM coranverb WHERE oranvalid=0 and lig_mac=0 and uye in('.$this->userler.') and gizliler=a.eventid and tip="gizlimac"))
			and a.eventid='.$mac_id.'
			and a.lig_adi!=""
			and a.yer="'.aktifcanli.'"
			and a.sonoranguncelleme>'.$this->fark.'
			'.$this->notLike.'
			group by b.mac_id ';
		
			$sor = $this->db->query($yeni);
			$toplam=$sor->num_rows();
			$mb=$sor->row();
			
			
			if ($toplam == 0 || count($mb->sonoran)==0) { 
				$bas.='<div class="bos">'.lang('cbos').'</div>';
				echo ($bas);
				exit; 
			}
			
			$surekli_aski_durum = surekli_aski_durum($mb->gol,$mb->sonoranguncelleme,$mb->surekliaski);
			if($surekli_aski_durum==1 || $mb->aktif=="0") { $aktifi = 0; } else { $aktifi = 1; }
	
			$arr = array();
			
			$bol=explode(',',$mb->sonoran);
			$gizlioranic=explode(',',$mb->gizlioranic);
			
			foreach($bol as $data){					
				$bol1=explode('|',$data);
				//$bol1[3]=($bol1[3].'d');	
				$arr[$bol1[0]][]= $bol1;
			}
			
			$renk=0;
			$bas.='<div class="extra-table-sports blueext">';
			
			if($mb->dakika<45) { $iyari= 'big-'; }else { $iyari= '';}
			if($mb->devre=="Devre arası") { $dkyaz= "Devre";}else 
			if($mb->dakika=="") { $dkyaz= "-"; }else 
			if(is_numeric($mb->dakika)) {$dkyaz=$mb->dakika." '";}
			
			$lg=explode('-',$mb->lig_adi);
			$fms=$mb->fms;
			$ceyr=explode(',',$fms);
			
			$c1a=explode('-',$ceyr[0]);
			$c1=(int)trim($c1a[0]);
			$c1d=(int)trim($c1a[1]);
			
			$c2a=explode('-',$ceyr[1]);
			$c2=(int)trim($c2a[0]);
			$c2d=(int)trim($c2a[1]);
			
			$c3a=explode('-',$ceyr[2]);
			$c3=(int)trim($c3a[0]);
			$c3d=(int)trim($c3a[1]);
			
			$c4a=explode('-',$ceyr[3]);
			$c4=(int)trim($c4a[0]);
			$c4d=(int)trim($c4a[1]);
			
			$bas.='<div class="new-tips-live basketball"> <div class="cnt0 sc"> <div class="title"> <div class="play"><i class="fa fa-clock-o"></i></div> <span>'.$dkyaz.'</span> </div> <div class="cnt sc"> <div class="league">'.$lg[0].' '.$lg[1].'</div> <table class="live-basket-tracker"> <tbody><tr> <th colspan="5"><ul><li class="ng-binding">'.$mb->ev_takim.'</li><li>'.$mb->ev_skor.':'.$mb->konuk_skor.'</li><li class="ng-binding">'.$mb->konuk_takim.'</li></ul></th>   </tr> <tr><td></td><td>'.lang('cyrk',array(1)).'</td> <td>'.lang('cyrk',array(2)).'</td><td>'.lang('cyrk',array(3)).'</td><td>'.lang('cyrk',array(4)).'</td> </tr>
			<tr>
				<td class="ng-binding">'.$mb->ev_takim.'</td>
				<td class="ng-binding">'.$c1.'</td>
				<td class="ng-binding"> '.$c2.'</td>
				<td class="ng-binding"> '.$c3.'</td>
				<td class="ng-binding">'.$c4.'</td>
			</tr>
			<tr>
				<td class="ng-binding">'.$mb->konuk_takim.'</td>
				<td class="ng-binding">'.$c1d.'</td>
				<td class="ng-binding"> '.$c2d.'</td>
				<td class="ng-binding"> '.$c3d.'</td>
				<td class="ng-binding">'.$c4d.'</td>
			</tr></tbody></table> </div> </div> </div>';
			
			foreach ($arr as $tipbaslik => $veri) {
				
				if($renk % 2 == 0){$rdver='zebra';}else{$rdver='';}
				
				$saybe=count($veri);
				if($saybe==2 || strstr($tipbaslik,'Alt/Üst') || strstr($tipbaslik,'Toplam Skor') || strstr($tipbaslik,'Handikap')){
					$cls= 2;
				}elseif($saybe==3){
					$cls= 3;
				}elseif($saybe==4){
					$cls= 4;
				}
				$tipbaslik=temizle($tipbaslik);
				$tipbaslik=lang($tipbaslik);
				$bas.='<div class="table-row-'.$cls.' '.$rdver.'">
				<div class="lenotip-title"><p>'.$tipbaslik.'</p></div><ul>';
				
				$odsay=0;
				foreach($veri as $ass1){
					
					$oran_id=$ass1[1];
					$oran_adi=$ass1[2];
					$oran=$ass1[3];
					$yukselis=$ass1[4];
					$dusus=$ass1[5];
					
					if(!empty(canli_koruma) && canli_koruma!='0.00' && $oran >= canli_koruma){
						$oran=canli_koruma;
					}
					$canli_kupon_sure = time()+(canli_kupon_sure * 60);
					$kuponekle = codekupon("$oran|".$mb->id."|".$oran_id."|".$oran_adi."|".$canli_kupon_sure);	
					$cekle1='onClick="canliekleb(\''.$kuponekle.'\');$(this).addClass(\'active\');"';
					
					if($oran_id."|".$oran_adi==$mb->coranid){
						$seciliclass1='active';
						$ydus=yukdurumsec($yukselis,$dusus);
					}else{
						$ydus=yukdurum($yukselis,$dusus);
						$seciliclass1='';
					}
					if($aktifi==0 || $ass1[6]==0 || in_array($oran_id,$gizlioranic)) {
						$askclass1='ldisabled';
						$kupver1='';
					}else{
						$askclass1='';
						$kupver1=$cekle1;
					}
					
					if($oran<=1.00){
						$kupver1='';
						$oran='-';
					}
					if($askclass1 == 'ldisabled'){
						$oran='';
					}
					if($oran_id==3 || $oran_id==14){						
						$sy=preg_replace('/[^0-9.]*/', "",$oran_adi);
						$sy1=preg_replace('/[^a-z]*/', "",$oran_adi);
						$oadi=temizle($sy1);
						$oran_adi=lang($oadi,array($sy));
						//$oran_adi=$oran_adi;
					}elseif($oran_id==11){
						$sy=preg_replace('/[^0-9-+.]*/', "",$oran_adi);
						$sy1=preg_replace("/[^a-zA-Z]*/", "",$oran_adi);
						$oadi=temizle($sy1);
						$oran_adi=lang($oadi.'11',array($sy));
						//$oran_adi=$sy1;
					}else{
						$oadi=temizle($oran_adi);
						$oran_adi=lang($oadi);
					}
					$oran_adi=str_replace('Ev Sahibi','1',$oran_adi);
					$oran_adi=str_replace('Deplasman','2',$oran_adi);
					$oran_adi=str_replace('Beraberlik','X',$oran_adi);
					$oran_adi=str_replace(array('ten','den','dan'),'',$oran_adi);
					
					$bas.='<li><strong>'.$oran_adi.'</strong><a href="javascript:;" '.$kupver1.' class="icoran '.$askclass1.' '.$ydus.' '.$seciliclass1.'"><span>'.$oran.'</span></a></li>';					
				}				
				$bas.='</ul></div>';
				$renk++;
			}
			$bas.='<a class="closeblue" onclick="orkapat('.$mb->eventid.');">Kapat</a></div>';			
		}
		
		if($farkliyaz==1){
			return $bas;
		}else{
			echo ($bas);
		}
		
	}
	
	public function livelist(){
		
		ajaxvarmi();
		$bas['ust']='';
		$gelenvent = $this->input->post("eventler");
		if(canliyasakb >0 || canlibahisb==0){
			$bas['ust'].='<div class="bos">'.lang('cbos').'</div>';
				echo json_encode($bas);
				exit; 
		}
		
		$yeni='SELECT a.lig_adi,k.coranid,a.orsayi,a.eventid,a.gol,a.gorselkodu,a.id,a.ev_takim,a.konuk_takim,a.aktif,a.dakika,a.devre,a.ev_skor,a.konuk_skor,a.sonoranguncelleme,
		(SELECT gizliler FROM coranverb WHERE oranvalid=0 and lig_mac=0 and uye in('.$this->userler.') and gizliler=a.eventid and tip="aski") as surekliaski,
		(SELECT count(oranvalid) FROM coranverb WHERE lig_mac in(0,a.eventid) and uye in('.$this->userler.') and tip="gizlioranic") as gizlioranic,
		GROUP_CONCAT(
		ct.tip_isim,"|",
		ct.id,"|",
		b.oran_adi,"|",
		   (		
			case				
			when c.tip="tumcanli" then CONCAT(ROUND(oranyuzdehesapla(b.oran,(c.oran+IFNULL(m.oran,0))),2))		
			when m.tip="macbasket" then CONCAT(ROUND(oranyuzdehesapla(b.oran,m.oran),2))		
			else CONCAT(ROUND(b.oran,2))
			end
			)	
		  ,"|",b.yukselis,"|",b.dusus,"|",b.askida,"|",b.id ORDER BY ct.sira asc,b.sira asc
		) as sonoran

		FROM canli_maclarb a
		left join kupon k on k.mac_kodu=a.eventid and session_id='.id.' and onlem="'.sesid.'"
		left join canli_oranb b on b.mac_id=a.eventid and b.canli_tip not in((SELECT oranvalid FROM coranverb WHERE lig_mac in(0,a.eventid) and uye in('.$this->userler.') and tip="gizlioran")) and b.canli_tip in (1,11,3)
		
		left join canli_tipb ct on ct.id=b.canli_tip and ct.durum=1
		
		left join coranverb c on c.oranvalid=b.oran_adi and c.lig_mac = 0 and c.uye =(
		if(EXISTS(SELECT uye FROM coranverb WHERE oranvalid=b.oran_adi and lig_mac = 0 and uye='.kendi.' and tip="tumcanli")
		,'.kendi.',if(EXISTS(SELECT uye FROM coranverb WHERE oranvalid=b.oran_adi and lig_mac = 0 and uye='.ustu.' and tip="tumcanli"),'.ustu.','.patron.'))
		) and c.tip="tumcanli"

		left join coranverb m on m.oranvalid=b.oran_adi and m.lig_mac = a.eventid and m.uye=(
		if(EXISTS(SELECT uye FROM coranverb WHERE oranvalid=b.oran_adi and lig_mac = a.eventid and uye='.kendi.' and tip="macbasket")
		,'.kendi.',if(EXISTS(SELECT uye FROM coranverb WHERE oranvalid=b.oran_adi and lig_mac = a.eventid and uye='.ustu.' and tip="macbasket"),'.ustu.','.patron.'))
		) and m.tip="macbasket"
	
		where
		a.eventid not in((SELECT gizliler FROM coranverb WHERE oranvalid=0 and lig_mac=0 and uye in('.$this->userler.') and gizliler=a.eventid and tip="gizlimac"))
		
		and a.sonoranguncelleme>'.$this->fark.'
		and a.lig_adi!=""
		and a.yer="'.aktifcanli.'"
		'.$this->notLike.'
		group by b.mac_id order by a.id desc
		';
		
		$sor = $this->db->query($yeni);
		$toplam=$sor->num_rows();
		
		if ($toplam == 0) { 
			$bas['ust'].='<div class="bos">'.lang('cbos').'</span></div>';
			echo json_encode($bas);
			exit; 
		}
		
		$oddeve=0;
		$orsayidusur=8;
		
		$set = array();
		foreach($sor->result() as $mb1){
			$lg=explode('-',$mb1->lig_adi);
			$set[$lg[0].' '.$lg[1]][]= $mb1;
		}
		
		foreach ($set as $ligadi => $data) {
			$bas['ust'].='<ul class="table-basket-title-2331">
				<li></li>
				<li>'.$ligadi.'</li>
				<li> <strong>'.lang('thm').'</strong> <span>1</span> <span>X</span> <span>2</span> </li>
				<li></li>
				<li> <strong>'.lang('hdk').'</strong> <span>1</span> <span>2</span> </li>
				<li></li>
				<li> <strong>'.lang('tpskor').'</strong> <span>1</span><span>2</span> </li>
				<li>+</li>
				</ul>';
			foreach($data as $mb){
			
			$surekli_aski_durumo =surekli_aski_durumb($mb->sonoranguncelleme,$mb->surekliaski);
			if($surekli_aski_durumo==1 || $mb->aktif=="0") { $aktif = 0; } else { $aktif = 1; }				
							
			$arr = array();
			$oranlar = array();			
				
			$bol=explode(',',$mb->sonoran);
			//echo'<pre>';print_R($bol);
			foreach($bol as $data){
				$bol1=explode('|',$data);
				$arr[$bol1[0]][]= $bol1;
				
			}//exit;
			$hdkler=$hdkyaz=$topskoryaz=$iyaltust=$sgol=$iygk1=$ms1=$tskorlar=$iyms1=$kv=$ky=$sd=$s0=$ms0=$s1=$cs2=$cs0=$ms2=$cs1=$gk1=$gk0=$gk2=$acoran='';
			$tmp=$iyal=0;
			$bunlarialma='';
			foreach ($arr as $tipbaslik => $veri1) {
				
				//echo'<pre>';print_R($veri1);
				foreach($veri1 as $k=>$veri){
					
					//$evid=$veri[0];
					//if($evid==$mb->eventid){
						//echo'<pre>';print_R($veri);				
					
						$oran_id=$veri[1];
						$oran_adi=$veri[2];
						$oran=$veri[3];
						$yukselis=$veri[4];
						$dusus=$veri[5];
						$oridalma=$veri[7];
						
						//if ($canli_tip==2 && $tmp++ > 2) {continue;}
						if(!empty(canli_koruma) && canli_koruma!='0.00' && $oran >= canli_koruma){
							$oran=canli_koruma;
						}
						$canli_kupon_sure = time()+(canli_kupon_sure * 60);
						$kupverr = codekupon("$oran|".$mb->id."|".$oran_id."|".$oran_adi."|".$canli_kupon_sure);
						$cekle='onClick="canliekleb(\''.$kupverr.'\');$(this).addClass(\'active\');"';
						
						if($oran_id."|".$oran_adi==$mb->coranid){
							$seciliclass='active';
							$ydus=yukdurumsec($yukselis,$dusus);
						}else{
							$ydus=yukdurum($yukselis,$dusus);
							$seciliclass='';
						}
						
						if($aktif==0 || $veri[6]==0 || $mb->gizlioranic==$oran_id) {
							$askclass='ldisabled';
							$kupver='';
						}else{
							$askclass='';
							$kupver=$cekle;
						}
						if($askclass == 'ldisabled'){
							$oran='';
						}
						//$oranlar[$canli_tip][$oran_id]=array($ydus,$kupver,$oran);
						
						if($oran_id==1){
							$ms1.='<a class="ratio-box '.$askclass.' '.$seciliclass.' '.$ydus.'" href="#" id="" '.$kupver.'><span>'.$oran.'</span></a>';
							$bunlarialma.=$oridalma.',';
						}
						
						if($oran_id==11){
							if ($iyal++ > 1) {continue;}
							$hdkyaz='<span class="clear-box"><span>'.str_replace(array('Ev Sahibi','Deplasman',' '),'',$oran_adi).'</span></span>';
							$hdkler.='<a class="ratio-box '.$askclass.' '.$seciliclass.' '.$ydus.'" href="#" id="" '.$kupver.'><span>'.$oran.'</span></a>';
							$bunlarialma.=$oridalma.',';
						}
						if($oran_id==3){
							if ($tmp++ > 1) {continue;}
							$topskoryaz='<span class="clear-box"><span>'.preg_replace('/[^0-9.]*/', "",$oran_adi).'</span></span>';
							$tskorlar.='<a class="ratio-box '.$askclass.' '.$seciliclass.' '.$ydus.'" href="#" id="" '.$kupver.'><span>'.$oran.'</span></a>';
							$bunlarialma.=$oridalma.',';
						}	
					//}
				}
			}
			
			if($mb->devre!='2. Yarı') { 
				if(strstr($mb->devre,'eyrek')){
					$devreyaz=lang('cyrk',array(preg_replace('/[^0-9.]*/', "",$mb->devre))); 
				}else { 
					$devreyaz= lang('drkl');
				}	
			}else { $devreyaz= '';}
			if($mb->devre=="Devre arası") { $dkyaz=lang('dvre');}else 
			if($mb->dakika=="") { $dkyaz= "-"; }else 
			if(is_numeric($mb->dakika)) {$dkyaz=$mb->dakika." '";}
			$bunlarialma=substr($bunlarialma,0,-1);
			if($mb->eventid==$gelenvent){				
				$opened='block';
				$oracclass='extra-but-slcted-orange';
				$acoran=$this->liveodds($mb->eventid,1,$bunlarialma);				
			}else{				
				$opened='none';
				$oracclass=$acoran='';				
			}
			$bas['ust'].='<input type="hidden" id="x_'.$mb->eventid.'" value="'.$bunlarialma.'">';
			$oryaz=$mb->orsayi-$orsayidusur;
			$bas['ust'].='<ul class="table-basket-match-2331">
				<li class="live">'.$dkyaz.'</li>
				<li>
					<em class="xcard hidden"><txt >0</txt></em>
					<span class="t1">'.$mb->ev_takim.'</span>
					<span class="score">'.$mb->ev_skor.':'.$mb->konuk_skor.'</span>
					<em class="xcard hidden"><txt >0</txt></em>
					<span class="t2 ">'.$mb->konuk_takim.'</span>
					<small><span >'.$devreyaz.'</span></small>
				</li>
				<li>'.$ms1.'</li>
				<li>'.$hdkyaz.''.$hdkler.'</li>
				<li>'.$topskoryaz.''.$tskorlar.'</li>
				
				<li onclick="oran_ac('.$mb->eventid.');" id="tumac'.$mb->eventid.'" class="'.$oracclass.' oranstil">+'.$oryaz.'</li>
				</ul>
				<div id="betdetail_'.$mb->eventid.'" class="orkapatall" style="display: '.$opened.';">'.$acoran.'</div>';
			$oddeve++;
		}
		}
		echo json_encode($bas);
	}

}
