<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class LiveGames extends CI_Controller {

	function __construct(){
		parent::__construct();
			logged_admin();
				
	}
	
		
	public function macsonuclari(){
		
		$bas='';
		for($i=0; $i<(date("d")); $i++) {
			$otarih = strtotime("-".$i." days");
			$bas.='<option value="'.date("Y-m-d",$otarih).'">'.date("d.m.Y",$otarih).'</option>';
		}
		$this->smarty->assign('trh',$bas);
		$this->smarty->view('macsonuclari.tpl');
	}
	public function poker(){
		
		$this->smarty->view('poker.tpl');

	}
	
	public function casino(){
		
		$this->smarty->view('casino.tpl');

	}
	
	public function rulet(){
		
		$this->smarty->view('rulet.tpl');

	}
	
	public function tombala(){
		
		$this->smarty->view('tombala.tpl');
	}
	public function macsonuclaridata(){
	
	ajaxvarmi();
	$tarih = $this->input->post('tarih');
	$takim = $this->input->post('takim');
	$url = "http://www.sahadan.com/LiveScores/LiveScoresAjax.aspx?seq=-1&txtDate=".date('d.m.Y',strtotime($tarih))."&iddaa=0&canli=0&allIddaa=0&ddlGrup=&CM=1&st=1&au=0&duel=0";
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/13.0.782.112 Safari/535.1");	
	curl_setopt($ch, CURLOPT_TIMEOUT, 60);
	curl_setopt($ch, CURLOPT_REFERER, "http://www.sahadan.com/");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
	curl_setopt($ch, CURLOPT_URL, $url);
	$page = curl_exec ($ch);
	curl_close ($ch);	

	$tamammi=0;	
	preg_match_all('#C1M(.*?);#Ssie',$page,$sonuc_satirlari);	
		
	if(!empty($sonuc_satirlari[1])){
	?>
	<table class="tftable" style="width:100%" cellspacing="0" cellpadding="0">
		<thead><tr>
		<th style="text-align:right"><?=lang('ev');?></th>
		<th style="text-align:center;width:20px"><?=lang('ms');?></th>		
		<th><?=lang('dep');?></th>		
		<th><?=lang('iy');?></th>		
		</tr></thead><tbody>
	<?
	foreach($sonuc_satirlari[1] as $ss){
			$satir_parcalari = explode(',',$ss);
			$ev_takim = str_replace(array("'"),'',$satir_parcalari[11]);
			$konuk_takim = str_replace(array("'"),'',$satir_parcalari[12]);
			$iyskor = str_replace(array("'"),'',$satir_parcalari[13]);
			$skor = str_replace(array("'"),'',$satir_parcalari[14]);
			$eventid = str_replace(array("'"),'',$satir_parcalari[9]);
			$ligadi = str_replace(array("'"),'',$satir_parcalari[5]).' - '.str_replace(array("'"),'',$satir_parcalari[2]);
			//echo'<pre>';print_r($satir_parcalari);
			$flag = str_replace(array("'"),'',$satir_parcalari[4]);
			$ikitakimda = "".$ev_takim."".$konuk_takim."";
			if((!empty($takim) && stristr($ikitakimda,$takim)) || empty($takim)) {
				
	?>
	<tr class="bas">
	<td style="width:200px; padding:3px; text-align:right;"><?=$ev_takim;?></td>
	<td style="width:50px; padding:3px; text-align:center; font-weight:bold;" class="skorbo" title="Maç Sonucu"><?=$skor;?></td>
	<td style="width:200px; padding:3px;"><?=$konuk_takim;?></td>
	<td style="width:50px; padding:3px;" title="İlk Yarı Sonucu"><?=$iyskor;?></td>
	</tr>
	<? } ?>
	<? } ?>
	</tbody></table>
	<?
	}
	}

}
