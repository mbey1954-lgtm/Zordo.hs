<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class home extends CI_Controller {

	function __construct(){
		parent::__construct();
			logged_admin();
	}
	
	public function index(){		
		//if(futbol == 0){redirect(base_url().'hata');}
		//$this->session->unset_userdata('masaustu');exit;
		$masaustu = $this->input->get('masaustu');
		$masaustuses = $this->session->userdata('masaustu');
		if($masaustu){
			$this->session->set_userdata(array('masaustu'=>1));			
		}
		$masaustuses = $this->session->userdata('masaustu');
		if(detect_mobile() && !$masaustuses){
			redirect(base_url()."mobil/index");
			//$this->session->set_userdata(array('masaustu'=>1));
		}
		$this->smarty->view('ana.tpl');	 
	}
		
	function lang(){
		$this->session->unset_userdata('dil');
		$this->session->set_userdata(array('dil'=>$this->input->post('dil')));
	}
		
	public function puandurumu($id,$id1){
		ajaxvarmi();
		echo' <link rel="stylesheet" type="text/css" href="/css/LeagueTable_2012_01_31.css" />
		 <div style="width:625px !important;height: 500px !important;">
		 <div id="content" style="width: 625px !important;">
		 <div id="performanceTableDataContainer">
		 <div id="leagueTableContainer">
		<div id="mainLeagueTablePage">
		<div class="indexData" style="width: 625px !important;">
		<div id="mainLeagueTablePageContent">
		<div class="indexTeamMainData">
		<div class="mainLeagueTableData">
		<div id="leagueTableInnerContent">
		';
		$url='http://sporx.broadagesports.com/LeagueTable/Index.aspx?sportId=1&countryId='.$id.'&tournamentId='.$id1.'&languageId=1';
		//header('Content-type: text/html; charset=utf-8');
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_USERAGENT, "Firefox/3.6.8");
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, 'Content-Length=33333');
		curl_setopt($ch, CURLOPT_URL, $url);
		$al = curl_exec($ch);
		
		$bir=preg_replace('#../../Default/Content/LeagueTable/Images/#si','/images/',$al);
		$bir=preg_replace('#selectedAlternateItemRow#si','itemRow',$bir);
		$bir=preg_replace("/<a href=\"(.*)\">/i", "",$bir);
		$bir=preg_replace("/onmouseover='(.*?)'/is", "",$bir);
		$bir=preg_replace("/onmouseout='(.*?)'/is", "",$bir);
		preg_match('#<div class="tournamentName">(.*?)</div>#si',$bir,$isim);
		preg_match('#<div class="seasonInfo">(.*?)</div>#si',$bir,$trh);
		echo'<div class="leagueTableTeamHeader">'.$isim[1].' '.$trh[1].' Sezonu</div>';
		echo$bas = bol('<div id="leagueTableInnerContent">','<div id="tinyFixtureContainer">',1,$bir);
		echo'</div></div></div></div></div>';
	}

	public function duello(){		
		if(duello == 0 || dukapat==1){redirect(base_url().'hata');}
		$this->smarty->view('duello.tpl');		 
	}
	
	public function bulten(){
	
		ajaxvarmi();
		bultenisil();
		
		$tarih = $this->input->post('tarih');
		$kod = (int)$this->input->post('kod');
		$takim = $this->input->post('takim');
		$saat = $this->input->post('saat');
		$ligid = $this->input->post('ligid');
		$duelmi = (int)$this->input->post('duelmi');
		$where_ekle = " and a.adminid in(0,".kendi.")";
		if($duelmi==1){
			$kodne='a.d_kodu';
			$tipyaz='duello';
			$oran_val_id = "1,2,3,31,32,33";
			$where_ekle.= " and a.program_tip='duello'";
		}else{
			$kodne='a.mac_kodu';
			$tipyaz='futbol';
			$oran_val_id = "1,2,3,6,7";
			$where_ekle.= " and a.program_tip='futbol'";
		}
		//$where_ekle.= " and (a.mac_kodu !='' or a.d_kodu !='')";
		if(!empty($tarih) && (empty($kod) && empty($takim) && empty($ligid))) {
			$where_ekle.= " and a.mac_tarih='$tarih'";	
		}

		if(!empty($takim)) { 
			if(is_numeric($takim)) { 
				$where_ekle.= " and a.mac_kodu like '%$takim%'";
			}else{
				$where_ekle.= " and (a.ev_takim like '%$takim%' or a.konuk_takim like '%$takim%')";
			}
		}
		if(!empty($kod)) {
			$where_ekle.= " and ($kodne like '%$kod%')";
		}

		if(!empty($saat)) { 
			$carp = ($saat*60); $eksi = time()+$carp; 
			$where_ekle.= " and a.mac_time<$eksi"; 
		} 

		if(!empty($ligid)) { 
			$where_ekle.= " and a.ulke='$ligid'"; 
		}
		
		$where_ekle= '"'.$where_ekle.'"';
		$ver="call bulten (".kendi.",".ustu.",".patron.",$where_ekle,'$kodne asc','and b.oran_val_id in($oran_val_id)')";
		
		$sor = $this->db->query($ver);
		if ($sor->num_rows() == 0) { 
			echo json_encode(array('yok'=>1));
			exit; 
		}		
		
		$start = microtime(true);
		$set = array();
		
		/*$this->db->close();
		$this->load->database();*/
		
		foreach($sor->result() as $ass){			
			
			//$ass->orsay=$this->db->query("select count(id) as orsay from oranlarb where mac_db_id=".$ass->id."")->row()->orsay;
			$ev_kazanc=$beraberlik=$konuk_kazanc=$a25=$u25=$a15=$u15=$kgv=$kgy=$cs1=$cs0=$cs2='';
			if($ass->sonoran==''){continue;}
			$bol=explode(',',$ass->sonoran);
			foreach($bol as $data){
				$bol1=explode('|',$data);
				$orval=$bol1[0];
				if($orval==1){$ev_kazanc=$bol1[1];}
				if($orval==2){$beraberlik=$bol1[1];}
				if($orval==3){$konuk_kazanc=$bol1[1];}
				if($duelmi==1){
					if($orval==31){$cs1=$bol1[1];}
					if($orval==32){$cs0=$bol1[1];}
					if($orval==33){$cs2=$bol1[1];}
				}else{
					if($orval==6){$a25=$bol1[1];}
					if($orval==7){$u25=$bol1[1];}
				}
			}
			$ass->orsayi=$ass->orsayi-1;
			$ass->ev=oranana_temizle($ev_kazanc);
			$ass->brb=oranana_temizle($beraberlik);
			$ass->knk=oranana_temizle($konuk_kazanc);
			if($duelmi==1){
				$ass->cs1=oranana_temizle($cs1);
				$ass->cs0=oranana_temizle($cs0);
				$ass->cs2=oranana_temizle($cs2);
			}else{
				$ass->a25=oranana_temizle($a25);
				$ass->u25=oranana_temizle($u25);
			}
			
			$ass->mbs = $ass->mbssi;
			$ass->zm = date("d.m",$ass->mac_time);
			$ass->gun = turkce_tarih_kisa($ass->mac_time);
			$ass->st = date("H:i",$ass->mac_time);
			
			$ligar=explode('|',$ass->lig);
			$ass->ev_takim=takimadikisalt($ass->ev_takim);
			$ass->konuk_takim=takimadikisalt($ass->konuk_takim);
			$ass->tipi=$tipyaz;
			
			$encoded = $ass->id.'|'.$ass->mbs.'|'.$tipyaz;
			
			$ass->evk=codekupon($encoded.'|1|'.$ass->ev);
			$ass->bk=codekupon($encoded.'|2|'.$ass->brb);
			$ass->kk=codekupon($encoded.'|3|'.$ass->knk);
			if($duelmi==1){
				$ass->cs1k=codekupon($encoded.'|31|'.$ass->cs1);
				$ass->cs0k=codekupon($encoded.'|32|'.$ass->cs0);
				$ass->cs2k=codekupon($encoded.'|33|'.$ass->cs2);
			}else{
				$ass->a25k=codekupon($encoded.'|6|'.$ass->a25);
				$ass->u25k=codekupon($encoded.'|7|'.$ass->u25);
			}
			
			unset($ass->sonoran);
			unset($ass->mbssi);
			
			$set[$ligar[0].'|'.$ligar[2].'|'.$ligar[3]][]= $ass;
		}	
				
		//printf(" %.6fs\n", microtime(true) - $start);
		echo json_encode($set);
		$sor->free_result();unset($sor,$set);
	}
	
	public function iddaa_bulten(){		
		//if(duello == 0){redirect(base_url().'hata');}
		$this->smarty->view('idaa.tpl');		 
	}
	
	public function iddaa_bulten_data(){
	
		ajaxvarmi();
		bultenisil();
		
		$tarih = $this->input->post('tarih');
		$kod = (int)$this->input->post('kod');
		$takim = $this->input->post('takim');
		$saat = $this->input->post('saat');
		$ligid = (int)$this->input->post('ligid');
		$tipyaz='futbol';
		$where_ekle = " and a.iddaa_kodu !=''";

		if(!empty($tarih) && (empty($kod) and empty($takim))) {
			$where_ekle.= " and a.mac_tarih='$tarih'";	
		}

		if(!empty($takim)) { 
			$where_ekle.= " and (a.ev_takim like '%$takim%' or a.konuk_takim like '%$takim%')";
		}

		if(!empty($kod)) {
			$where_ekle.= " and (a.iddaa_kodu like '%$kod%')";
		}

		if(!empty($saat)) { 
			$carp = ($saat*60); $eksi = time()+$carp; 
			$where_ekle.= " and a.mac_time<$eksi"; 
		} 

		if(!empty($ligid)) { 
			$where_ekle.= " and a.kupa_id='$ligid'"; 
		}
		
		$where_ekle= '"'.$where_ekle.'"';
		$ver="call bulten (".kendi.",".ustu.",".patron.",$where_ekle,'a.iddaa_kodu asc','and b.oran_val_id in(1,2,3,6,7,4,5,13,14)')";
		
		$sor = $this->db->query($ver);
		if ($sor->num_rows() == 0) { 
			echo json_encode(array('yok'=>1));
			exit; 
		}		
		
		$start = microtime(true);
		$set = array();
		
		/*$this->db->close();
		$this->load->database();*/
		
		foreach($sor->result() as $ass){			
			
			//$ass->orsay=$this->db->query("select count(id) as orsay from oranlarb where mac_db_id=".$ass->id."")->row()->orsay;
			$ev_kazanc=$beraberlik=$konuk_kazanc=$a25=$u25=$a15=$u15=$kgv=$kgy=$cs1=$cs0=$cs2='';
			if($ass->sonoran==''){continue;}
			$bol=explode(',',$ass->sonoran);
			foreach($bol as $data){
				$bol1=explode('|',$data);
				$orval=$bol1[0];
				if($orval==1){$ev_kazanc=$bol1[1];}
				if($orval==2){$beraberlik=$bol1[1];}
				if($orval==3){$konuk_kazanc=$bol1[1];}
			
				if($orval==6){$a25=$bol1[1];}
				if($orval==7){$u25=$bol1[1];}
				if($orval==4){$a15=$bol1[1];}
				if($orval==5){$u15=$bol1[1];}
				if($orval==13){$kgv=$bol1[1];}
				if($orval==14){$kgy=$bol1[1];}
			}
			$ass->orsayi=$ass->orsayi-1;
			$ass->ev=oranana_temizle($ev_kazanc);
			$ass->brb=oranana_temizle($beraberlik);
			$ass->knk=oranana_temizle($konuk_kazanc);
			
			$ass->a25=oranana_temizle($a25);
			$ass->u25=oranana_temizle($u25);
			$ass->a15=oranana_temizle($a15);
			$ass->u15=oranana_temizle($u15);
			$ass->kgv=oranana_temizle($kgv);
			$ass->kgy=oranana_temizle($kgy);
			
			
			$ass->mbs = $ass->mbssi;
			$ass->zm = date("d.m",$ass->mac_time);
			$ass->gun = turkce_tarih_kisa($ass->mac_time);
			$ass->st = date("H:i",$ass->mac_time);
			
			$ligar=explode('|',$ass->lig);
			$ass->ev_takim=takimadikisalt($ass->ev_takim);
			$ass->konuk_takim=takimadikisalt($ass->konuk_takim);
			$ass->tipi=$tipyaz;
			
			$encoded = $ass->id.'|'.$ass->mbs.'|'.$tipyaz;
			
			$ass->evk=codekupon($encoded.'|1|'.$ass->ev);
			$ass->bk=codekupon($encoded.'|2|'.$ass->brb);
			$ass->kk=codekupon($encoded.'|3|'.$ass->knk);
			
			$ass->a25k=codekupon($encoded.'|6|'.$ass->a25);
			$ass->u25k=codekupon($encoded.'|7|'.$ass->u25);
			$ass->a15k=codekupon($encoded.'|4|'.$ass->a15);
			$ass->u15k=codekupon($encoded.'|5|'.$ass->u15);
			$ass->kgvk=codekupon($encoded.'|13|'.$ass->kgv);
			$ass->kgyk=codekupon($encoded.'|14|'.$ass->kgy);
			
			unset($ass->sonoran);
			unset($ass->mbssi);
			
			$set[$ligar[0].'|'.$ligar[2]][]= $ass;
		}	
				
		//printf(" %.6fs\n", microtime(true) - $start);
		echo json_encode($set);
		$sor->free_result();unset($sor,$set);
	}
	
	public function ligler($ne){
		
		ajaxvarmi();
		$bas['f']='';
		$bas['fs']='';
		$bas['bs']='';
		$bas['b']='';
		
		if($ne==1){
			$sor = $this->db->query("select b.lig_ulke,b.lig_adi,count(a.kupa_id) as say,b.id from program a left join program_lig b on b.id=a.kupa_id and b.hangi=1 where a.program_tip='futbol' and a.id not in((SELECT gizliler FROM oranver WHERE oranvalid=0 and lig_mac=0 and uye in(".kendi.",".ustu.",".patron.") and gizliler=a.id and tip='gizlimac'))
			and a.kupa_id not in((SELECT gizliler FROM oranver WHERE oranvalid=0 and lig_mac=0 and uye in(".kendi.",".ustu.",".patron.") and gizliler=a.kupa_id and tip='gizlilig')) group by b.lig_ulke order by b.lig_ulke asc");
			$fsay=0;
			foreach($sor->result() as $ass){
				$fsay= $fsay+$ass->say;
				$bas['f'].='<li><a class="nav_2 on num_4" title="'.$ass->lig_ulke.'" onclick="loadbulten(\''.$ass->lig_ulke.'\')"><i class="fa fa-angle-double-right"></i>&nbsp;<div class="leuage">'.$ass->lig_ulke.'</div><div class="fav" style="display: block;" id="fcsay">'.$ass->say.'</div></a></li>';
			}
			$sor->free_result();
			$bas['fs'].= $fsay;
		}
		
		if($ne==2){
			$ver="select b.lig_ulke,b.lig_adi,count(a.kupa_id) as say,b.id from programb a left join program_lig b on b.id=a.kupa_id and b.hangi=2  and a.id not in((SELECT gizliler FROM oranver WHERE oranvalid=0 and lig_mac=0 and uye in(".kendi.",".ustu.",".patron.") and gizliler=a.id and tip='gizlimac'))
			and a.kupa_id not in((SELECT gizliler FROM oranver WHERE oranvalid=0 and lig_mac=0 and uye in(".kendi.",".ustu.",".patron.") and gizliler=a.kupa_id and tip='gizlilig')) group by a.kupa_id order by say desc";
			$sorb = $this->db->query($ver);
			$bsay=0;
			foreach($sorb->result() as $assb){
				$bsay= $bsay+$assb->say;
				$bas['b'].='<li><a class="nav_2 on num_4" title="'.$assb->lig_ulke.'" onclick="loadbulten(\''.$assb->id.'\')"><i class="fa fa-angle-double-right"></i>&nbsp;<div class="leuage">'.$assb->lig_ulke.'</div><div class="fav" style="display: block;" id="bcsay">'.$assb->say.'</div></a></li>';
			}
			$sorb->free_result();
			$bas['bs'].= $bsay;
		}
		
		if($ne==3){
			$sor = $this->db->query("select b.lig_ulke,b.lig_adi,count(a.kupa_id) as say,b.id from program a left join program_lig b on b.id=a.kupa_id and b.hangi=1 where a.program_tip='futbol' and a.iddaa_kodu !=''  and a.id not in((SELECT gizliler FROM oranver WHERE oranvalid=0 and lig_mac=0 and uye in(".kendi.",".ustu.",".patron.") and gizliler=a.id and tip='gizlimac'))
			and a.kupa_id not in((SELECT gizliler FROM oranver WHERE oranvalid=0 and lig_mac=0 and uye in(".kendi.",".ustu.",".patron.") and gizliler=a.kupa_id and tip='gizlilig')) group by b.lig_ulke order by b.lig_ulke asc");
			$fsay=0;
			foreach($sor->result() as $ass){
				$fsay= $fsay+$ass->say;
				$bas['f'].='<li><a class="nav_2 on num_4" title="'.$ass->lig_ulke.'" onclick="loadbulten(\''.$ass->lig_ulke.'\')"><i class="fa fa-angle-double-right"></i>&nbsp;<div class="leuage">'.$ass->lig_ulke.'</div><div class="fav" style="display: block;" id="fcsay">'.$ass->say.'</div></a></li>';
			}
			$bas['fs'].= $fsay;
		}
		if($ne=='t' || $ne=='h' || $ne=='o'){
			if($ne=='t'){
				$hangi=3;
			}elseif($ne=='h'){
				$hangi=4;
			}elseif($ne=='o'){
				$hangi=5;
			}
			$sor = $this->db->query("select b.lig_ulke,b.lig_adi,count(a.kupa_id) as say,b.id from program$ne a left join program_lig b on b.id=a.kupa_id and b.hangi=$hangi group by b.lig_ulke order by b.lig_ulke asc");
			$fsay=0;
			foreach($sor->result() as $ass){
				$fsay= $fsay+$ass->say;
				$bas['f'].='<li><a class="nav_2 on num_4" title="'.$ass->lig_ulke.'" onclick="loadbulten(\''.$ass->lig_ulke.'\')"><i class="fa fa-angle-double-right"></i>&nbsp;<div class="leuage">'.$ass->lig_ulke.'</div><div class="fav" style="display: block;" id="fcsay">'.$ass->say.'</div></a></li>';
			}
			$bas['fs'].= $fsay;
		}
		echo json_encode($bas);
		unset($bas);
	}
	
	public function tumoran($id){
		
		ajaxvarmi();
		$id=(int)$id;
		
		$ver="call bulten (".kendi.",".ustu.",".patron.",' and a.id=$id and a.program_tip=\'futbol\' ',' a.id asc','and b.oran_val_id not in(1,2,3,6,7)')";
		$sor = $this->db->query($ver);
		if ($sor->num_rows() == 0 ) { 
			echo "<div class='bos'>".lang('bosbhs')."</div>";
			exit; 
		}
		$row=$sor->row();
		if (!$row->sonoran) { 
			echo "<div class='bos'>".lang('bosbhs')."</div>";
			exit; 
		}
		$bas['html']='';
		$bas['isim']='';
		$this->db->close();
		$this->load->database();
		$sor->free_result();
		
		$ligar=explode('|',$row->lig);
		if($ligar[1]=='Duello'){$tipyaz='duello';}else{$tipyaz='futbol';}
		
		?>
	<div class="extra-table-sports blueext">
	
	<?php
		
		$arr = array();
		
		$bol=explode(',',$row->sonoran);
		foreach($bol as $data){					
			$bol1=explode('|',$data);			
			$orval=$bol1[0];
			$oran_tip=$bol1[2];
			$arr[$oran_tip][]= $bol1;
		}
		foreach ($arr as $oran_tip => $veri) {
			
			$saybe=count($veri);
			$sqlek=$this->db->query("select tip_isim from oran_tip where id='$oran_tip' order by id asc")->row();
			$tipbaslik=$sqlek->tip_isim;
			if($tipbaslik=='Toplam Gol Alt/Üst' || $tipbaslik=='İkinci Yarı Toplam Gol Alt/Üst' || $tipbaslik=='İlk Yarı Toplam Gol Alt/Üst' || $tipbaslik=='İlk Yarı Sonucu Alt/Üst' || $tipbaslik=='İlk Yarı Sonucu Alt/Üst' || $tipbaslik=='Ev Sahibi Maç Sonucu Alt/Üst' || $tipbaslik=='Maç Sonucu ve Toplam Gol' || $tipbaslik=='Deplasman Maç Sonucu Alt/Üst' || $saybe==2){$cls= "2";}else{$cls= "3";}
			$oadit=temizle($tipbaslik);
			$tipbaslik=lang($oadit);
			?>
		<div class="table-row-<?=$cls;?> zebra">
		<div class="lenotip-title"><p><?=$tipbaslik;?></p></div><ul>
		<?php	
		foreach($veri as $oranlari){
			
			$orvalid=$oranlari[0];	
			
			$oran_bilgi = $this->db->query("select id,oran_val from oran_val where id='$orvalid'")->row();
			$tahmin=$oran_bilgi->oran_val;
			
			$mbs = $row->mbssi;
			
			$buoran=oranana_temizle($oranlari[1]);
			
			if($buoran!='-'){
			
			$encoded = $row->id.'|'.$mbs.'|'.$tipyaz;			
			$kupon=$encoded."|$orvalid|$buoran";
			if($tahmin=='Ev Sahibi ve 2.5 Altı'){
				$tahmin='1 2.5 Alt';
			}elseif($tahmin=='Beraberlik ve 2.5 Altı'){
				$tahmin='X 2.5 Alt';
			}elseif($tahmin=='Deplasman ve 2.5 Altı'){
				$tahmin='2 2.5 Alt';
			}elseif($tahmin=='Ev Sahibi ve 2.5 Üstü'){
				$tahmin='1 2.5 Üst';
			}elseif($tahmin=='Beraberlik ve 2.5 Üstü'){
				$tahmin='X 2.5 Üst';
			}elseif($tahmin=='Deplasman ve 2.5 Üstü'){
				$tahmin='2 2.5 Üst';
			}
			$oadi=temizle($tahmin);
			$tahmin=lang($oadi);
			if(!$tahmin){
				$tahmin=$oran_bilgi->oran_val;
			}
			?>
			<li><strong><?=$tahmin; ?></strong><a href="javascript:;" id="<?=$row->id.'-'.$orvalid.'-futbol'; ?>" onClick="kupon('<?=codekupon("$kupon"); ?>');" class="ratio-box"><span><?if($buoran=='-'){echo'-';}else{echo nf($buoran);} ?></span></a></li>
			
		<?php	
			}
		}
		?>
		</ul></div>
		<?php } ?>
		<a class="closeblue" onclick="$('#betdetail_<?=$row->id;?>').hide();$('#tumac<?=$row->id;?>').removeClass('extra-but-slcted');">Kapat</a>
		</div>
		
	<?php 
		unset($row->sonoran);
		unset($row->mbssi);
		unset($arr,$row);
	}
	
	public function basketbol(){
		
		if(basketbol == 0 || baskapat==1){redirect(base_url().'hata');}
		$this->smarty->assign('title','Bilgilerim');
		$this->smarty->view('bultenb.tpl');
		 
	}
	
	public function bultenb(){
		
		ajaxvarmi();
		bultenisil('b');
		
		$tarih = $this->input->post('tarih');
		$kod = $this->input->post('kod');
		$takim = $this->input->post('takim');
		$saat = $this->input->post('saat');
		$ligid = $this->input->post('ligid');
		
		$where_ekle = '';

		if(!empty($tarih) && (empty($kod) and empty($takim) and empty($ligid))) {
			$where_ekle.= " and mac_tarih='$tarih'";	
		}

		if(!empty($takim)) { 
			$where_ekle.= " and (ev_takim like '%$takim%' or konuk_takim like '%$takim%')";
		}

		if(!empty($kod)) {
			$where_ekle.= " and (mac_kodu like '%$kod%')";
		}

		if(!empty($saat)) { 
			$carp = ($saat*60); $eksi = time()+$carp; 
			$where_ekle.= " and mac_time<$eksi"; 
		} 

		if(!empty($ligid)) { 
			$where_ekle.= " and kupa_id='$ligid'"; 
		}
		
		$where_ekle= '"'.$where_ekle.'"';
		$ver="call bultenb (".kendi.",".ustu.",".patron.",$where_ekle,'a.mac_time asc','and b.oran_val_id in(1,2,7,8)')";
		
		$sor = $this->db->query($ver);
		if ($sor->num_rows() == 0) { 
			echo json_encode(array('yok'=>1));
			exit; 
		}
		
		/*$this->db->close();
		$this->load->database();*/
		
		$setb = array();
		foreach($sor->result() as $ass){
			
			$ass->orsay=$ass->orsayi-1;
			
			$ev_kazanc=$konuk_kazanc=$alt=$ust=$tsyaz=$hdksi1=$hdksi3=$hdksi8=$hdksi9='';
			if($ass->sonoran==''){continue;}
			$bol=explode(',',$ass->sonoran);			
			foreach($bol as $data){
				$bol1=explode('|',$data);
				$orval=$bol1[0];
				if($orval==1){$ev_kazanc=$bol1[1];$hdksi1=$bol1[3];}
				if($orval==2){$konuk_kazanc=$bol1[1];$hdksi3=$bol1[3];}
				if($orval==7){$alt=$bol1[1];$tsyaz=$bol1[3];$hdksi8=$bol1[3];}
				if($orval==8){$ust=$bol1[1];$hdksi9=$bol1[3];}
			}
			$ass->ev=oranana_temizle($ev_kazanc);
			$ass->knk=oranana_temizle($konuk_kazanc);
			$ass->alt=oranana_temizle($alt);
			$ass->ust=oranana_temizle($ust);
			
			if($ass->alt=="-" || $ass->ust=="-") { 
				$tssi = '-';
			} else {
				$tssi = $tsyaz; 
			}

			$ass->ts = $tssi;
			$ass->mbs = $ass->mbssi;
			$ass->zm = date("d.m",$ass->mac_time);
			$ass->gun = turkce_tarih_kisa($ass->mac_time);
			$ass->st = date("H:i",$ass->mac_time);
			$ligar=explode('|',$ass->lig);
			
			$encoded = $ass->id.'|'.$ass->mbs.'|basketbol';
			
			$ass->ev_takim=takimadikisalt($ass->ev_takim);
			$ass->konuk_takim=takimadikisalt($ass->konuk_takim);
			
			$ass->evk=codekupon($encoded.'|1|'.$ass->ev);
			$ass->kk=codekupon($encoded.'|2|'.$ass->knk);
			$ass->ak=codekupon($encoded.'|7|'.$ass->alt);
			$ass->uk=codekupon($encoded.'|8|'.$ass->ust);
			
			unset($ass->sonoran);
			unset($ass->mbssi);
			
			$setb[$ligar[0].'|'.$ligar[2]][]= $ass;
		}
		
		echo json_encode($setb);
		$sor->free_result();
		unset($setb,$sor);
	}
	
	public function tumoranb($id){
		
		ajaxvarmi();
		$ver="call bultenb (".kendi.",".ustu.",".patron.",' and a.id=$id',' a.id asc','')";
		$sor = $this->db->query($ver);
		if ($sor->num_rows() == 0) { 
			echo json_encode(array('yok'=>1));
			exit; 
		}
		$row=$sor->row();
		
		$bas['html']='';
		$bas['isim']='';
		$this->db->close();
		$this->load->database();
		$ligar=explode('|',$row->lig);
		?>
		<div class="extra-table-sports blueext">
	
		<?php
		
		$arr = array();
		
		$bol=explode(',',$row->sonoran);
		foreach($bol as $data){					
			$bol1=explode('|',$data);			
			$orval=$bol1[0];
			$oran_tip=$bol1[2];
			$arr[$oran_tip][]= $bol1;
		}
		foreach ($arr as $oran_tip => $veri) {
			
			$saybe=count($veri);
			$sqlek=$this->db->query("select tip_isim from oran_tipb where id='$oran_tip' order by id asc")->row();
			$tipbaslik=$sqlek->tip_isim;
			if($saybe==2){$cls= "2";}else{$cls= "3";}
			?>
		<div class="table-row-<?=$cls;?> zebra">
		<div class="lenotip-title"><p><?=$tipbaslik;?></p></div><ul>
		<?php	
		foreach($veri as $oranlari){
			
			$orvalid=$oranlari[0];	
			$oran_val_b=$oranlari[3];	
			if($oran_val_b!="") { $oran_val_b= "($oran_val_b)"; }
			
			$oran_bilgi = $this->db->query("select id,oran_val from oran_valb where id='$orvalid'")->row();
			$tahmin=$oran_bilgi->oran_val;
			
			$mbs = $row->mbssi;
			
			$buoran=oranana_temizle($oranlari[1]);
			
			if($buoran!='-'){
			
			$hdkyaz='';
			$favori='';
			
			$ev_takim=takimadikisalt($row->ev_takim);
			$konuk_takim=takimadikisalt($row->konuk_takim);
			
			$encoded = $row->id.'|'.$mbs.'|basketbol';
			
			$kupon=$encoded."|$orvalid|$buoran";
			?>
			<li><strong><?=$tahmin; ?> <?=$oran_val_b; ?></strong><a href="javascript:;" id="<?=$row->id.'-'.$orvalid.'-basketbol'; ?>" onClick="kupon('<?=codekupon("$kupon"); ?>');" class="ratio-box"><span><?if($buoran=='-'){echo'-';}else{echo nf($buoran);} ?></span></a></li>			
		<?php	
			}
		}
		?>
		</ul></div>
		<?php 
		}
		unset($row->sonoran);
		unset($row->mbssi);
		unset($arr,$row);
		?>
		</div>
	<?php 
	}
	
	public function tenis(){		
		//if(futbol == 0){redirect(base_url().'hata');}
		$this->smarty->view('bultent.tpl');		 
	}
	public function hentbol(){		
		//if(futbol == 0){redirect(base_url().'hata');}
		$this->smarty->view('bultenh.tpl');		 
	}
	public function buzhokeyi(){		
		//if(futbol == 0){redirect(base_url().'hata');}
		$this->smarty->view('bulteno.tpl');		 
	}
	
	public function bultenson(){
		
		ajaxvarmi();
		$t = $this->input->post('t');
		bultenisil($t);
		if($t=='t'){
			$hangi=3;
			$tip='tenis';
		}elseif($t=='h'){
			$hangi=4;
			$tip='hentbol';
		}elseif($t=='o'){
			$hangi=5;
			$tip='hokey';
		}
		$tarih = $this->input->post('tarih');
		$kod = $this->input->post('kod');
		$takim = $this->input->post('takim');
		$saat = $this->input->post('saat');
		$ligid = $this->input->post('ligid');
		
		$where_ekle = '';

		if(!empty($tarih) && (empty($kod) and empty($takim) and empty($ligid))) {
			$where_ekle.= " and mac_tarih='$tarih'";	
		}

		if(!empty($takim)) { 
			$where_ekle.= " and (ev_takim like '%$takim%' or konuk_takim like '%$takim%')";
		}

		if(!empty($kod)) {
			$where_ekle.= " and (mac_kodu like '%$kod%')";
		}

		if(!empty($saat)) { 
			$carp = ($saat*60); $eksi = time()+$carp; 
			$where_ekle.= " and mac_time<$eksi"; 
		} 

		if(!empty($ligid)) { 
			$where_ekle.= " and ulke='$ligid'"; 
		}
		
		$ver="select b.*,(select CONCAT(lig_adi,'|',lig_ulke,'|',lig_bayrak) from program_lig where id=b.kupa_id and hangi=$hangi) as lig,
		GROUP_CONCAT(o.oran_val_id,'|',
		   (CONCAT(ROUND(o.oran,2)))	
		  ,'|',o.oran_tip,'|',o.oldoran ORDER BY o.oran_tip,o.oran_val_id asc 
		) as sonoran
		from program$t b 
		left join oranlar$t o on o.mac_db_id=b.id
		where b.id!=0 $where_ekle 
		group by o.mac_db_id";
		
		$sor = $this->db->query($ver);
		if ($sor->num_rows() == 0) { 
			echo json_encode(array('yok'=>1));
			exit; 
		}
		
		/*$this->db->close();
		$this->load->database();*/
		
		$setb = array();
		foreach($sor->result() as $ass){
			
			$ass->orsay=$ass->orsayi;
			
			$ev_kazanc=$konuk_kazanc=$alt=$ust=$tssi=$beraberlik=$kgv=$kgo='';
			if($ass->sonoran==''){continue;}
			$bol=explode(',',$ass->sonoran);			
			foreach($bol as $data){
				$bol1=explode('|',$data);
				$orval=$bol1[0];
				if($hangi==3){
					if($orval==1){$ev_kazanc=$bol1[1];}
					if($orval==2){$konuk_kazanc=$bol1[1];}
					if($orval==3){$alt=$bol1[1];}
					if($orval==4){$ust=$bol1[1];}
				}elseif($hangi==5){
					if($orval==1){$ev_kazanc=$bol1[1];}
					if($orval==2){$beraberlik=$bol1[1];}
					if($orval==3){$konuk_kazanc=$bol1[1];}
					if($orval==4){$kgv=$bol1[1];}
					if($orval==5){$kgo=$bol1[1];}
				}elseif($hangi==4){
					if($orval==1){$ev_kazanc=$bol1[1];}
					if($orval==2){$beraberlik=$bol1[1];}
					if($orval==3){$konuk_kazanc=$bol1[1];}
					if($orval==4){$alt=$bol1[1];}
					if($orval==5){$ust=$bol1[1];}
				}
			}
			$ass->ev=oranana_temizle($ev_kazanc);
			if($hangi==5){
				$ass->brb=oranana_temizle($beraberlik);
				$ass->kgv=oranana_temizle($kgv);
				$ass->kgo=oranana_temizle($kgo);
			}elseif($hangi==4){
				$ass->brb=oranana_temizle($beraberlik);
			}
			$ass->knk=oranana_temizle($konuk_kazanc);
			$ass->alt=oranana_temizle($alt);
			$ass->ust=oranana_temizle($ust);			
			
			$ass->ts = $tssi;
			$ass->mbs = $ass->mbssi;
			$ass->zm = date("d.m",$ass->mac_time);
			$ass->gun = turkce_tarih_kisa($ass->mac_time);
			$ass->st = date("H:i",$ass->mac_time);
			$ligar=explode('|',$ass->lig);
			
			$encoded = $ass->id.'|'.$ass->mbs.'|'.$tip.'';
			
			$ass->ev_takim=takimadikisalt($ass->ev_takim);
			$ass->konuk_takim=takimadikisalt($ass->konuk_takim);
			
			$ass->evk=codekupon($encoded.'|1|'.$ass->ev);			
			if($hangi==5){
				$ass->kk=codekupon($encoded.'|3|'.$ass->knk);
				$ass->bk=codekupon($encoded.'|2|'.$ass->brb);
				$ass->kgv1=codekupon($encoded.'|4|'.$ass->kgv);
				$ass->kgo1=codekupon($encoded.'|5|'.$ass->kgo);
			}elseif($hangi==4){
				$ass->kk=codekupon($encoded.'|3|'.$ass->knk);
				$ass->bk=codekupon($encoded.'|2|'.$ass->brb);
				$ass->ak=codekupon($encoded.'|4|'.$ass->alt);
				$ass->uk=codekupon($encoded.'|5|'.$ass->ust);
			}elseif($hangi==3){
				$ass->kk=codekupon($encoded.'|2|'.$ass->knk);
				$ass->ak=codekupon($encoded.'|3|'.$ass->alt);
				$ass->uk=codekupon($encoded.'|4|'.$ass->ust);
			}
			
			unset($ass->sonoran);
			unset($ass->mbssi);
			
			$setb[$ligar[1].'|'.$ligar[0]][]= $ass;
		}
		
		echo json_encode($setb);
		$sor->free_result();
		unset($setb,$sor);
	}
	
	public function tumoranson($id){
		
		ajaxvarmi();
		$t = $this->input->post('t');
		$ver="select b.*,
		GROUP_CONCAT(o.oran_val_id,'|',
		   (CONCAT(ROUND(o.oran,2)))	
		  ,'|',o.oran_tip,'|',o.oldoran ORDER BY o.oran_tip,o.oran_val_id asc 
		) as sonoran
		from program$t b 
		left join oranlar$t o on o.mac_db_id=b.id
		where b.id=$id and o.oran_tip not in(1,2)
		group by o.mac_db_id";
		$sor = $this->db->query($ver);
		if ($sor->num_rows() == 0) { 
			echo json_encode(array('yok'=>1));
			exit; 
		}
		$row=$sor->row();
		
		$bas['html']='';
		$bas['isim']='';
		?>
		<div class="extra-table-sports blueext">
	
		<?php
		
		$arr = array();
		
		$bol=explode(',',$row->sonoran);
		foreach($bol as $data){					
			$bol1=explode('|',$data);			
			$orval=$bol1[0];
			$oran_tip=$bol1[2];
			$arr[$oran_tip][]= $bol1;
		}
		foreach ($arr as $oran_tip => $veri) {
			
			$saybe=count($veri);
			$sqlek=$this->db->query("select tip_isim from oran_tip$t where id='$oran_tip' order by id asc")->row();
			$tipbaslik=$sqlek->tip_isim;
			if($saybe==2){$cls= "2";}else{$cls= "3";}
			?>
		<div class="table-row-<?=$cls;?> zebra">
		<div class="lenotip-title"><p><?=$tipbaslik;?></p></div><ul>
		<?php	
		foreach($veri as $oranlari){
			
			$orvalid=$oranlari[0];	
			
			$oran_bilgi = $this->db->query("select id,oran_val from oran_val$t where id='$orvalid'")->row();
			$tahmin=$oran_bilgi->oran_val;
			
			$mbs = $row->mbssi;
			
			$buoran=oranana_temizle($oranlari[1]);
			
			if($buoran!='-'){
			
			$hdkyaz='';
			$favori='';
			
			$ev_takim=takimadikisalt($row->ev_takim);
			$konuk_takim=takimadikisalt($row->konuk_takim);
			if($t=='t'){
				$tip='tenis';
			}elseif($t=='h'){
				$tip='hentbol';
			}elseif($t=='o'){
				$tip='hokey';
			}
			$encoded = $row->id.'|'.$mbs.'|'.$tip.'';
			
			$kupon=$encoded."|$orvalid|$buoran";
			?>
			<li><strong><?=$tahmin; ?> </strong><a href="javascript:;" id="<?=$row->id.'-'.$orvalid.'-'.$tip.''; ?>" onClick="kupon('<?=codekupon("$kupon"); ?>');" class="ratio-box"><span><?if($buoran=='-'){echo'-';}else{echo nf($buoran);} ?></span></a></li>			
		<?php	
			}
		}
		?>
		</ul></div>
		<?php 
		}
		unset($row->sonoran);
		unset($row->mbssi);
		unset($arr,$row);
		?>
		</div>
	<?php 
	}
	
	public function gecis(){
		
		ajaxvarmi();
		$id = (int)$this->input->post('id');
		$this->db->select('id,yetki');
		$ubu = $this->db->get_where('kullanici', array('id' => $id));
		if($ubu->num_rows()>0) {
			$row=$ubu->row();
			//$_SESSION['gecis']=$ub['id'];
			$session_bilgileri = array(
					'gecis' =>id,
					'id' =>$row->id,
					'yetki' =>$row->yetki,
					'is_logged_Bet' =>true);
			$this->session->set_userdata($session_bilgileri);
			die('1');
		}
	}	
	
	public function newpass(){
		
		ajaxvarmi();
		$newpass = $this->input->post('newpass');
		$yazici = $this->input->post('yazici');
		$tc = $this->input->post('tc');
		$tel = $this->input->post('tel');
		$email = $this->input->post('email');
		
		$this->db->select('id,ayarlar');
		$sql = $this->db->get_where('kullanici', array('id' => id,'durum' => '1'));
		if($sql->num_rows >0){
			
			$rowu=$sql->row();
			$ayrv=unserialize($rowu->ayarlar);	
			$ayrv['yazici']=$yazici;
			$ayrv['tc']=$tc;
			$ayrv['tel']=$tel;
			$ayrv['email']=$email;
			$bayiAyari = $ayrv;
			
			$seti="ayarlar='".$this->db->escape_str(serialize($bayiAyari))."'";
			if($newpass !=''){
				$seti.=",password='".$newpass."'";
			}
			$sonuc = $this->db->query("update kullanici set $seti where id=".$rowu->id."");
			if($sonuc){
				die('1');
			}
		}else{
			die('2');
		}
	}
	
	public function gecisoff(){
		
		ajaxvarmi();
		$id = (int)$this->session->userdata('gecis');
		$this->db->select('id,yetki');
		$ubu = $this->db->get_where('kullanici', array('id' => $id));
		if($ubu->num_rows()>0) {
			$row=$ubu->row();
			$session_bilgileri = array(
					'id' =>$row->id,
					'yetki' =>$row->yetki,
					'is_logged_Bet' =>true);
			$this->session->set_userdata($session_bilgileri);
			$this->session->unset_userdata('gecis');
			die("1");
		}
	}
}
