<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class oranmerkezi extends CI_Controller {

	function __construct(){
		parent::__construct();
			logged_admin();
			if(yetki ==4 || oranduzenleme ==0 ){redirect(base_url().'hata');}
	}
	
	public function index(){
		
		$secim = $this->input->get('secim');
		
		if($secim==2){
			
			$gelen_lig = $this->input->get('lig');
			$ligar=array();
			$lig = $this->db->query("select lig_adi,id from program_lig where hangi in(1,3)");
			foreach($lig->result() as $row){
				$ligar[$row->lig_adi]= $row;
			}
			$this->smarty->assign('liglist',$lig->result());
			
			if($gelen_lig){
				$lig_bilgi = $this->db->query("select *,(if(EXISTS(SELECT gizliler FROM oranver WHERE oranvalid=0 and lig_mac=0 and uye=".ustu." and gizliler=program_lig.id and tip='gizlilig'),1,
				if(EXISTS(SELECT gizliler FROM oranver WHERE oranvalid=0 and lig_mac=0 and uye=".patron." and gizliler=program_lig.id and tip='gizlilig'),1,0))) as gizli from program_lig where id='$gelen_lig' and hangi in(1,3)")->row();
			
				//echo $this->db->last_query();	
				if($lig_bilgi->id=="") { 
					redirect(base_url()."oranmerkezi");
				}else{
					$this->smarty->assign('ligrow',$lig_bilgi);
				}
				$sorc = $this->db->query("select id from oranver where (lig_mac=$gelen_lig or gizliler=$gelen_lig ) and uye=".sesionlar('id')."");
				if($sorc->num_rows()>0) {
					$this->smarty->assign('lgdegisik',1);
				}
			}
			
		}else if($secim==3){
			
			$mac_id = $this->input->get('mac_id');
			
			if($mac_id){
				$mac_bilgi = $this->db->query("select *,(if(EXISTS(SELECT gizliler FROM oranver WHERE oranvalid=0 and lig_mac=0 and uye=".ustu." and gizliler=program.id and tip='gizlimac'),1,
				if(EXISTS(SELECT gizliler FROM oranver WHERE oranvalid=0 and lig_mac=0 and uye=".patron." and gizliler=program.id and tip='gizlimac'),1,0))) as gizli 
				from program where id='$mac_id'")->row();
			
				//echo $this->db->last_query();	
				if($mac_bilgi->id=="") { 
					redirect(base_url()."oranmerkezi");
				}else{
					$this->smarty->assign('macrow',$mac_bilgi);
				}
				$sorc = $this->db->query("select id from oranver where (lig_mac=$mac_id or gizliler=$mac_id) and uye=".sesionlar('id')."");
				if($sorc->num_rows()>0) {
					$this->smarty->assign('mcdegisik',1);
				}
				
				$orantip = $this->db->query("select * from oranlar where mac_db_id='$mac_id' order by oran_tip asc");
				$set1 = array();
				foreach($orantip->result() as $row){
					$ot = $this->db->query("select tip_isim from oran_tip where id='".$row->oran_tip."' order by id asc")->row();
					$row->oran_vali = $this->db->query("select oran_val from oran_val where id='".$row->oran_val_id."'")->row()->oran_val;
					$set1[$ot->tip_isim][]= $row;
				}
				//echo'<pre>';print_R($set1);
				$this->smarty->assign('orantip',$set1);
			}
			
		}else if($secim==14){
			
			$mac_id = $this->input->get('mac_id');
			
			if($mac_id){
				$mac_bilgi = $this->db->query("select *,(if(EXISTS(SELECT gizliler FROM coranver WHERE oranvalid=0 and lig_mac=0 and uye=".ustu." and gizliler=canli_maclar.eventid and tip='gizlimac'),1,
				if(EXISTS(SELECT gizliler FROM coranver WHERE oranvalid=0 and lig_mac=0 and uye=".patron." and gizliler=canli_maclar.eventid and tip='gizlimac'),1,0))) as gizli 
				from canli_maclar where eventid='$mac_id'")->row();
				if($mac_bilgi->id=="") { 
					redirect(base_url()."oranmerkezi");
				}else{
					$this->smarty->assign('macrow',$mac_bilgi);
				}
				
				$sorc = $this->db->query("select id from coranver where (lig_mac=$mac_id or gizliler=$mac_id) and uye=".sesionlar('id')."");
				if($sorc->num_rows()>0) {
					$this->smarty->assign('cdegisik',1);
				}else{
					$this->smarty->assign('cdegisik',0);
				}
				
				$orantip = $this->db->query("select * from canli_oran where mac_id='$mac_id' order by canli_tip asc,oran_adi asc");
				$set1 = array();
				foreach($orantip->result() as $row){
					$ot = $this->db->query("select * from canli_tip where id='".$row->canli_tip."' ")->row();
					$row->oran_val = $this->db->query("select oran_val from oran_valc where id='".$row->oran_adi."'")->row()->oran_val;
					$set1[$ot->tip_isim.'|'.$ot->id][]= $row;
				}
				if(empty($set1)){redirect(base_url()."oranmerkezi");}
				//echo'<pre>';print_R($set1);
				$this->smarty->assign('orantip',$set1);
			}
			
		}else if($secim==1){
			
			$sorv = $this->db->query("select id from oranver where lig_mac=0 and uye=".sesionlar('id')."");
			if($sorv->num_rows()>0) {
				$this->smarty->assign('alldegisik',1);
			}
		}else if($secim==13){
			
			$sorv = $this->db->query("select id from coranver where lig_mac=0 and uye=".sesionlar('id')."");
			if($sorv->num_rows()>0) {
				$this->smarty->assign('alldegisikc',1);
			}
			
		}
		
		if($secim){
			if($secim==1 || $secim==2){
				$orantip = $this->db->query("select * from oran_tip order by sira asc");
				$set = array();
				foreach($orantip->result() as $ass){
					$orantipv = $this->db->query("select * from oran_val where oran_tip='".$ass->id."' order by tus asc");
					$set[$ass->tip_isim]= $orantipv->result();
				}
				//echo'<pre>';print_R($set);
				$this->smarty->assign('orantip',$set);
			}else if($secim==13){
				$orantip = $this->db->query("select * from canli_tip where durum=1 order by id asc");
				$set = array();
				foreach($orantip->result() as $ass){
					$orantipv = $this->db->query("select * from oran_valc where oran_tip='".$ass->id."' order by sira asc");
					$set[$ass->tip_isim.'|'.$ass->id]= $orantipv->result();
				}
				$this->smarty->assign('orantip',$set);
			}
		}
		$this->smarty->view('oranmerkezi.tpl');
		 
	}
	
	public function allsil($secim,$id){
		
		if($secim=='1' && $id=='all'){
			$this->db->query("delete from oranver where lig_mac=0 and uye=".sesionlar('id')."");
			redirect(base_url()."oranmerkezi/?secim=1");
		}else if($secim=='2' && $id!=''){
			$this->db->query("delete from oranver where (lig_mac=$id or gizliler=$id) and uye=".sesionlar('id')."");
			redirect(base_url()."oranmerkezi/?secim=2&lig=".$id);
		}else if($secim=='3' && $id!=''){
			$this->db->query("delete from oranver where (lig_mac=$id or gizliler=$id) and uye=".sesionlar('id')."");
			redirect(base_url()."oranmerkezi/?secim=3&mac_id=".$id);
		}else if($secim=='14' && $id!=''){
			$this->db->query("delete from coranver where (lig_mac=$id or gizliler=$id) and uye=".sesionlar('id')."");
			redirect(base_url()."oranmerkezi/?secim=14&mac_id=".$id);
		}else if($secim=='13' && $id=='all'){
			$this->db->query("delete from coranver where lig_mac=0 and uye=".sesionlar('id')."");
			redirect(base_url()."oranmerkezi/?secim=13");
		}
	}
	
	public function macbul(){
		
		$aranan = $this->input->post('arama');

		if(empty($aranan)) { echo "<div class='bos'>Lütfen bir arama terimi giriniz.<br>(Maç kodu, iddaa kodu, ev sahibi takım adı ya da deplasman takım adı olabilir.)</div>"; } else {

		$sor = $this->db->query("select * from program where (mac_kodu like '%$aranan%' or d_kodu like '%$aranan%' or iddaa_kodu like '%$aranan%' or ev_takim like '%$aranan%' or konuk_takim like '%$aranan%')");
		if($sor->num_rows()==0) { echo "<div class='bos'>Herhangi bir sonuç bulunamadı</div>"; } else {
		?>
		<div class="duzentable">
		<ul class="head">
		<li class="zaman"><?=lang('trh');?></li>
		<li><?=lang('tkmadi');?></li>
		<li>&nbsp;</li>
		</ul>
		<?
		foreach($sor->result_array() as $row){
		?>
		<ul>
		<li><?=date("d.m.Y H:i",$row['mac_time']); ?></li>
		<li><?="$row[ev_takim] - $row[konuk_takim]"; ?></li>
		<li><a href="javascript:;" onClick="self.location.href='?secim=3&mac_id=<?=$row['id']; ?>';" class="d2"><?=lang('edit');?></a></li>
		</ul>
		<? } ?>
		</div>
		<? } }
	}
	
	public function all(){
		
		//echo'<pre>';print_R($_POST);
		$seciliuser=sesionlar('id');
		$sqlver=$olmayan_oran='';
		$secimi = $this->input->post("secimi");
		$sabitmbs = $this->input->post("sabitmbs");
		$kontrol = $this->input->post("kontrol");
		
		if($kontrol=='all' && $secimi==1){
			
		$this->db->query("delete from oranver where uye=$seciliuser and tip='futboltumligler'");
		$this->db->query("delete from oranver where uye=$seciliuser and tip='gizlioran' and lig_mac=0");
		$this->db->query("delete from oranver where uye=$seciliuser and tip='mbstum' and lig_mac=0");
		
		$sor = $this->db->query("select * from oran_val");
		
		foreach($sor->result_array() as $row){
			
			$tipisim=$this->db->query("select tip_isim from oran_tip where id=$row[oran_tip] limit 1")->row()->tip_isim;
			
			if(!isset($_POST['oranvals_'.$row['id'].''])) {
				$olmayan_oran .= "('$seciliuser','gizlioran','$row[id]','0'),";
				$kuponLogmaclig[] = array(
					'oran_adi' => $row['oran_val'],
					'oran_tip' => $tipisim	
				);
			}
			
			$gelen_oran = $this->input->post("oranval_".$row['id']."");
			if($gelen_oran!="0.00") {
				$degisimvar = 1;
				$sqlver.="('$seciliuser','futboltumligler','$row[id]','$gelen_oran','0'),";
				$kuponLogmaco[] = array(
					'oran_adi' => $row['oran_val'],
					'oran_tip' => $tipisim,
					'degisen_oran' => $gelen_oran
				);
			}
		}
			
		if($olmayan_oran) {		
			$olmayan_oran=substr($olmayan_oran,0,-1);
			$this->db->query("insert into oranver (uye,tip,oranvalid,lig_mac) values $olmayan_oran");
			loglama1(serialize($kuponLogmaclig), "Futbol Tüm Gizli Oran",'');
		}

		if($sabitmbs) {
			$this->db->query("insert into oranver (uye,tip,lig_mac,mbs) values ('$seciliuser','mbstum','0','$sabitmbs')");
			$kuponLogmacmbs[] = array(
				'yeni_mbs' => $sabitmbs
			);
			loglama1(serialize($kuponLogmacmbs),"Futbol Tüm Mbs",'');			
		}
		
		if($degisimvar) {
			$sqlver=substr($sqlver,0,-1);
			$this->db->query("insert into oranver (uye,tip,oranvalid,oran,lig_mac) values $sqlver");
			loglama1(serialize($kuponLogmaco), "Futbol Tüm Değişiklikler",'');
		}
		}
		redirect(base_url()."oranmerkezi/?secim=".$secimi);
	}
	
	public function lig(){
		
		$sqlver=$olmayan_oran='';
		
		$seciliuser=sesionlar('id');
		$secimi = $this->input->post("secimi");
		$sabitmbs = $this->input->post("sabitmbs");
		$gelenlig = $this->input->post("lig");
		$lig_goster = $this->input->post("lig_goster");
		$kontrol = $this->input->post("kontrol");
		
		if($kontrol=='lig' && $secimi==2 and $gelenlig){
			
		$this->db->query("delete from oranver where uye=$seciliuser and tip='futbollig' and lig_mac='$gelenlig'");
		$this->db->query("delete from oranver where uye=$seciliuser and tip='gizlilig' and gizliler='$gelenlig'");
		$this->db->query("delete from oranver where uye=$seciliuser and tip='gizlioran' and lig_mac='$gelenlig'");
		$this->db->query("delete from oranver where uye=$seciliuser and tip='mbslig' and lig_mac='$gelenlig'");
		
		$sor = $this->db->query("select * from oran_val");
		
		$ligibu=$this->db->query("select lig_adi from program_lig where id=$gelenlig and hangi=1 limit 1")->row()->lig_adi;
		
		foreach($sor->result_array() as $row){
			
			$adlar=$this->db->query("select tip_isim from oran_tip where id=$row[oran_tip] limit 1")->row();
			
			if(!isset($_POST['oranvals_'.$row['id'].''])) {
				$olmayan_oran .= "('$seciliuser','gizlioran','$row[id]','$gelenlig'),";
				$kuponLogmaclig[] = array(
					'oran_adi' => $row['oran_val'],
					'oran_tip' => $adlar->tip_isim,
					'lig_adi' => $ligibu
					
				);
			}
			$gelen_oran = $this->input->post("oranval_".$row['id']."");
			if($gelen_oran!="0.00") {
				$degisimvar = 1;
				$sqlver.="('$seciliuser','futbollig','$row[id]','$gelen_oran','$gelenlig'),";
				$kuponLogmaco[] = array(
					'oran_adi' => $row['oran_val'],
					'oran_tip' => $adlar->tip_isim,
					'degisen_oran' => $gelen_oran,
					'lig_adi' => $ligibu
				);
			}
		}
			
		if($olmayan_oran) {		
			$olmayan_oran=substr($olmayan_oran,0,-1);
			$this->db->query("insert into oranver (uye,tip,oranvalid,lig_mac) values $olmayan_oran");
			loglama1(serialize($kuponLogmaclig), "Futbol Lig Bazlı Gizli Oran",'');
		}

		if($sabitmbs) {
			$this->db->query("insert into oranver (uye,tip,lig_mac,mbs) values ('$seciliuser','mbslig','$gelenlig','$sabitmbs')");
			$kuponLogmacmbs[] = array(
					'yeni_mbs' => $sabitmbs,
					'lig_adi' => $ligibu				
				);
			loglama1(serialize($kuponLogmacmbs),"Futbol Lig Bazlı Mbs",'');			
		}
		
		if($lig_goster==1){
			$this->db->query("insert into oranver (uye,tip,gizliler) values ('$seciliuser','gizlilig','$gelenlig')");
			$kuponLogmacgizle[] = array(
				'lig_adi' => $ligibu
			);
			loglama1(serialize($kuponLogmacgizle), "Futbol Lig Gizleme",'');
		}
	
		if($degisimvar) {
			$sqlver=substr($sqlver,0,-1);
			$this->db->query("insert into oranver (uye,tip,oranvalid,oran,lig_mac) values $sqlver");
			loglama1(serialize($kuponLogmaco), "Futbol Lig Bazlı Değişiklikler",'');
		}
		}
		redirect(base_url()."oranmerkezi/?secim=".$secimi."&lig=".$gelenlig);
	}
	
	public function mac(){
		
		$sqlver=$olmayan_oran='';
		//echo'<pre>';print_R($_POST);
		$seciliuser=sesionlar('id');
		$kontrol = $this->input->post("kontrol");
		$secimi = $this->input->post("secimi");
		$sabitmbs = $this->input->post("sabitmbs");
		$gelenlig = $this->input->post("mac_id");
		$lig_goster = $this->input->post("lig_goster");
		
		if($kontrol=='mac' && $secimi==3 and $gelenlig){
		$this->db->query("delete from oranver where uye=$seciliuser and tip='macfutbol' and lig_mac='$gelenlig'");
		$this->db->query("delete from oranver where uye=$seciliuser and tip='gizlimac' and gizliler='$gelenlig'");
		$this->db->query("delete from oranver where uye=$seciliuser and tip='gizlioran' and lig_mac='$gelenlig'");
		$this->db->query("delete from oranver where uye=$seciliuser and tip='mbsmac' and lig_mac='$gelenlig'");
		
		$sor = $this->db->query("select id,oran_val_id,oran,oran_tip from oranlar where mac_db_id='$gelenlig'");
		$kodubu=$this->db->query("select mac_kodu,d_kodu,mbs from program where id=$gelenlig limit 1")->row();
		if($kodubu->mac_kodu==''){
			$mkodyaz=$kodubu->d_kodu;
			$detyaz='Duello';
		}else{
			$mkodyaz=$kodubu->mac_kodu;
			$detyaz='Futbol';
		}
		foreach($sor->result_array() as $row){
			
			$adlar=$this->db->query("select oran_val,(select tip_isim from oran_tip where id=oran_val.oran_tip) as tip_isim from oran_val where id=$row[oran_val_id] limit 1")->row();
			
			if(!isset($_POST['oranvals_'.$row['oran_val_id'].''])) {
				$olmayan_oran .= "('$seciliuser','gizlioran','$row[oran_val_id]','$gelenlig'),";
				$kuponLogmacg[] = array(
					'oran_adi' => $adlar->oran_val,
					'oran_tip' => $adlar->tip_isim,
					'bulten' => $detyaz,
					'mac_kodu' => $mkodyaz
				);
			}
			
			$gelen_oran = $this->input->post("oranval_".$row['id']."");
			if($gelen_oran && $gelen_oran!="0.00" && $gelen_oran!=$row['oran']) {
				$degisimvar = 1;
				$sqlver.="('$seciliuser','macfutbol','$row[oran_val_id]','$gelen_oran','$gelenlig'),";
				$kuponLogmac[] = array(
					'oran_adi' => $adlar->oran_val,
					'oran_tip' => $adlar->tip_isim,
					'orjinal_oran' => $row['oran'],
					'bulten' => $detyaz,
					'yeni_oran' => $gelen_oran,
					'mac_kodu' => $mkodyaz
				);
			}
		}
			
		if($olmayan_oran) {		
			$olmayan_oran=substr($olmayan_oran,0,-1);
			$this->db->query("insert into oranver (uye,tip,oranvalid,lig_mac) values $olmayan_oran");
			loglama1(serialize($kuponLogmacg), "Futbol Maç Bazlı Gizli Oran",$mkodyaz);
		}

		if($sabitmbs) {
			$this->db->query("insert into oranver (uye,tip,lig_mac,mbs) values ('$seciliuser','mbsmac','$gelenlig','$sabitmbs')");
			$kuponLogmacmbs[] = array(
					'orjinal_mbs' => $kodubu->mbs,
					'bulten' => $detyaz,
					'yeni_mbs' => $sabitmbs,
					'mac_kodu' => $mkodyaz
				);
			loglama1(serialize($kuponLogmacmbs),"Futbol Maç Bazlı Mbs",$mkodyaz);		
		}
		
		if($lig_goster==1){
			$this->db->query("insert into oranver (uye,tip,gizliler) values ('$seciliuser','gizlimac','$gelenlig')");
			$kuponLogmacgizle[] = array(
				'mac_kodu' => $mkodyaz,
				'bulten' => $detyaz
			);
			loglama1(serialize($kuponLogmacgizle), "Futbol Maç Gizleme",$mkodyaz);
		}
	
		if($degisimvar) {
			$sqlver=substr($sqlver,0,-1);
			$this->db->query("insert into oranver (uye,tip,oranvalid,oran,lig_mac) values $sqlver");
			loglama1(serialize($kuponLogmac), "Futbol Maç Bazlı Değişiklikler",$mkodyaz);
		}
		}
		redirect(base_url()."oranmerkezi/?secim=".$secimi."&mac_id=".$gelenlig);
	}
	
	public function kopya_edit($id){
		$sor = $this->db->query("select * from canli_maclar where id=$id");
		if($sor->num_rows()==0) { echo "<div class='bos'>Herhangi bir maç bulunamadı</div>"; } else {
		$row=$sor->row();
		echo'<form method="post">
		<table class="tftable">
		<tr>
		<th>Ev Sahibi</td>
		<th>Deplasman</td>
		<th>İlk Yarı</td>
		<th>Maç Sonucu</td>
		</tr>
		<tr>
		<td><input type="text" class="inputbet" id="ev_takim" value="'.$row->ev_takim.'"> </td>
		<td><input type="text" class="inputbet" id="konuk_takim" value="'.$row->konuk_takim.'"> </td>
		
		<td><input type="text" size="2" class="inputbet" id="iy_ev" value="'.$row->iy_ev.'">-<input type="text" size="2" class="inputbet" id="iy_konuk" value="'.$row->iy_konuk.'"></td>
		
		<td><input type="text" size="2" class="inputbet" id="ev_skor" value="'.$row->ev_skor.'">-<input type="text" size="2" class="inputbet" id="konuk_skor" value="'.$row->konuk_skor.'"></td>
		<td><input class="button" style="width:100%" value="Kaydet" type="button" onclick="kopyakaydet('.$id.',2);"></td>
		</tr>
		</table>';
		}
	}
	
	public function kopya($id,$tip){
		
		extract($_POST);
		if($tip==1){
			$this->db->query("INSERT INTO canli_maclar (adminid,ev_takim,konuk_takim,ev_skor,konuk_skor,dakika,sny,devre,aktif,eventid,songuncelleme,goster,devremi,iy_ev,iy_konuk,iybitti,ilkgiris,gol,sonoranguncelleme,betradar_id,isibitti,yer,orsayi,gorselkodu,finish,fms,lig_adi,olay,detay) 
			SELECT ".id.",ev_takim,konuk_takim,ev_skor,konuk_skor,dakika,sny,devre,aktif,eventid,songuncelleme,goster,devremi,iy_ev,iy_konuk,iybitti,ilkgiris,gol,sonoranguncelleme,betradar_id,isibitti,yer,orsayi,gorselkodu,finish,fms,'Dünya-Özel Maçlar-6',olay,detay
			FROM canli_maclar 
			WHERE id = $id");
			die("eklendi...");
		}else if($tip==2){
			$upbe="update canli_maclar set ev_takim='$ev_takim',konuk_takim='$konuk_takim',iy_ev='$iy_ev',iy_konuk='$iy_konuk',ev_skor='$ev_skor',konuk_skor='$konuk_skor' where id=".$id." ";
			$this->db->query($upbe);
			die("düzenlendi...");
		}else if($tip==3){
			$this->db->query("delete from canli_maclar where id=".$id."");
			die("silindi...");
		}
	}
	
	public function canli_b(){
		
		$fark = time()-360;
		$sor = $this->db->query("select * from canli_maclar where songuncelleme>$fark  and yer='Bwin' order by CAST(dakika AS UNSIGNED) asc");
		//where songuncelleme>$fark
		if($sor->num_rows()==0) { echo "<div class='bos'>Herhangi bir maç bulunamadı</div>"; } else {
		?>
		<div class="duzentable">
		<ul class="head">
		<li class="kodu"><?=lang('dk');?></li>
		<li class="zaman"><?=lang('dvre');?></li>
		<li><?=lang('tkmadi');?></li>
		<li>&nbsp;</li>
		</ul>
		<?
		foreach($sor->result_array() as $row){
		?>
		<ul>
		<li><? if($row['devremi']=="1") { echo "Devre"; } else { echo $row['dakika']; } ?></li>
		<li><?=$row['devre']; ?></li>
		<li><?="$row[ev_takim] - $row[konuk_takim]"; ?></li>
		<li>
		<? 
		$sor1 = $this->db->query("select * from canli_maclar where eventid=$row[eventid] and adminid>0 and yer='Bwin'")->num_rows();
		if($row['adminid']==0){?>
		<a href="javascript:;" onClick="self.location.href='?secim=14&mac_id=<?=$row['eventid']; ?>';" class="d2"><?=lang('edit');?></a>
		<? } ?>
		<? if($row['adminid']==0 && $sor1==0 ){?>
			 | <a href="javascript:;" onClick="kopya(<?=$row['id']; ?>,1)" class="d2">Bu Maçı Ekle</a>
		<? } ?>
		<? if($row['adminid']==id){?>
			 <a href="javascript:;" onClick="kopya_edit(<?=$row['id']; ?>)" class="d2">Maçı Düzenle</a> | 
			 <a href="javascript:;" onClick="if(!confirm('Maç Silinecektir. Emin misiniz?'))return;kopya(<?=$row['id']; ?>,3)" class="d3">Maçı Sil</a>
		<? } ?>	
		</li>
		</ul>
		<? } ?>
		</div>
		<? }
	}
	
	public function mac_c(){
		
		$sqlver=$olmayan_oran=$olmayan_oranic='';
		//echo'<pre>';print_R($_POST);
		$seciliuser=sesionlar('id');
		$kontrol = $this->input->post("kontrol");
		$secimi = $this->input->post("secimi");
		$gelenlig = $this->input->post("mac_id");
		$lig_goster = $this->input->post("lig_goster");
		$aski = $this->input->post("aski");
		
		if($kontrol=='mac_c' && $gelenlig){
		
		$this->db->query("delete from coranver where uye=$seciliuser and tip='maccanli' and lig_mac='$gelenlig'");
		$this->db->query("delete from coranver where uye=$seciliuser and tip='gizlimac' and gizliler='$gelenlig'");
		$this->db->query("delete from coranver where uye=$seciliuser and tip='aski' and gizliler='$gelenlig'");
		$this->db->query("delete from coranver where uye=$seciliuser and tip in('gizlioran','gizlioranic') and lig_mac='$gelenlig'");
		
		$vsql="select * from canli_oran where mac_id='$gelenlig' group by canli_tip";
		$sor1 = $this->db->query($vsql);
		foreach($sor1->result_array() as $row){
			
			$tipid = $row['canli_tip'];
			
			$tip_isim=$this->db->query("select tip_isim from canli_tip where id=$tipid limit 1")->row()->tip_isim;
			
			if(!isset($_POST['oranvaltip_'.$tipid.''])) {
				$olmayan_oran .= "('$seciliuser','gizlioran','$tipid','$gelenlig'),";
				$kuponLogmacg[] = array(
					'oran_tip' => $tip_isim,
					'mac_kodu' => $gelenlig
				);
			}			
		}
		
		$sor = $this->db->query("select * from canli_oran where mac_id='$gelenlig' ");
		$degisimvar = 0;
		
		foreach($sor->result_array() as $row){
			
			$icid = $row['oran_adi'];
			$adlar=$this->db->query("select tip_isim,(select oran_val from oran_valc where id=$icid) as oran_val from canli_tip where id=$row[canli_tip] limit 1")->row();
			
			if(!isset($_POST['oranvals_'.$icid.''])) {
				$olmayan_oranic .= "('$seciliuser','gizlioranic','$icid','$gelenlig'),";
				$kuponLogmacgi[] = array(
					'oran_adi' => $adlar->tip_isim,
					'oran_tip' => $adlar->oran_val,
					'mac_kodu' => $gelenlig
				);
			}
			
			$gelen_oran = $this->input->post("oranval_".$icid."");
			if($gelen_oran && $gelen_oran!="0.00") {
				$degisimvar = 1;
				$sqlver.="('$seciliuser','maccanli','$icid','$gelen_oran','$gelenlig'),";
				$kuponLogmacc[] = array(
					'oran_adi' => $adlar->tip_isim,
					'oran_tip' => $adlar->oran_val,
					'orjinal_oran' => $row['oran'],
					'yeni_oran' => $gelen_oran,
					'son_oran' => $row['oran']+$gelen_oran,
					'mac_kodu' => $gelenlig
				);
			}
		}
		
		if($olmayan_oran) {		
			$olmayan_oran=substr($olmayan_oran,0,-1);
			$this->db->query("insert into coranver (uye,tip,oranvalid,lig_mac) values $olmayan_oran");
			loglama1(serialize($kuponLogmacg), "Canli Maç Bazlı Gizli Oran",$gelenlig);
		}
		
		if($olmayan_oranic) {		
			$olmayan_oranic=substr($olmayan_oranic,0,-1);
			$this->db->query("insert into coranver (uye,tip,oranvalid,lig_mac) values $olmayan_oranic");
			loglama1(serialize($kuponLogmacgi), "Canli Maç Bazlı Gizli Oraniçi",$gelenlig);
		}

		if($lig_goster==1){
			$this->db->query("insert into coranver (uye,tip,gizliler) values ('$seciliuser','gizlimac','$gelenlig')");
			$kuponLogmacgizle[] = array(
				'mac_kodu' => $gelenlig
			);
			loglama1(serialize($kuponLogmacgizle), "Canli Maç Bazlı Gizleme",$gelenlig);
		}
		
		if($aski==1){
			$this->db->query("insert into coranver (uye,tip,gizliler) values ('$seciliuser','aski','$gelenlig')");
			$kuponLogmacask[] = array(
				'mac_kodu' => $gelenlig
			);
			loglama1(serialize($kuponLogmacask), "Canli Maç Bazlı Sürekli Askı",$gelenlig);
		}
	
		if($degisimvar) {
			$sqlver=substr($sqlver,0,-1);
			$this->db->query("insert into coranver (uye,tip,oranvalid,oran,lig_mac) values $sqlver");
			loglama1(serialize($kuponLogmacc), "Canli Maç Bazlı Oran Değişiklikleri",$gelenlig);
		}
		}
		redirect(base_url()."oranmerkezi/?secim=".$secimi."&mac_id=".$gelenlig);
	}
	
	
	public function mac_call(){
		
		$sqlver=$olmayan_oranic=$olmayan_oran='';
		//echo'<pre>';print_R($_POST);
		$seciliuser=sesionlar('id');
		$kontrol = $this->input->post("kontrol");
		$secimi = $this->input->post("secimi");
		
		if($kontrol=='mac_call' && $secimi==13){
		
		$this->db->query("delete from coranver where uye=$seciliuser and tip='tumcanli'");
		$this->db->query("delete from coranver where uye=$seciliuser and tip in('gizlioran','gizlioranic') and lig_mac=0");
		
		$sor1 = $this->db->query("select id,tip_isim from canli_tip where durum=1");
		
		foreach($sor1->result_array() as $row){
			
			$tipid = $row['id'];
									
			if(!isset($_POST['oranvaltip_'.$tipid.''])) {
				$olmayan_oran .= "('$seciliuser','gizlioran','$tipid','0'),";
				$kuponLogmacctum[] = array(
					'oran_adi' => $row['tip_isim']
				);
			}			
		}
		
		$sor = $this->db->query("select * from oran_valc ");
		$degisimvar = 0;
		
		foreach($sor->result_array() as $row){
			
			$icid = $row['id'];
			$tip_isim=$this->db->query("select tip_isim from canli_tip where id=$row[oran_tip] limit 1")->row()->tip_isim;
			if(!isset($_POST['oranvals_'.$icid.''])) {
				$olmayan_oranic.= "('$seciliuser','gizlioranic','$icid','0'),";
				$kuponLogmacgi[] = array(
					'oran_tip' => $tip_isim,
					'oran_adi' => $row['oran_val']
				);
			}
			
			$gelen_oran = $this->input->post("oranval_".$icid."");
			if($gelen_oran && $gelen_oran!="0.00") {
				$degisimvar = 1;
				$sqlver.="('$seciliuser','tumcanli','$icid','$gelen_oran','0'),";
				$kuponLogmacco[] = array(
					'oran_tip' => $tip_isim,
					'oran_adi' => $row['oran_val'],					
					'yeni_oran' => $gelen_oran
				);
			}
		}
			
		if($olmayan_oran) {		
			$olmayan_oran=substr($olmayan_oran,0,-1);
			$this->db->query("insert into coranver (uye,tip,oranvalid,lig_mac) values $olmayan_oran");
			loglama1(serialize($kuponLogmacctum), "Canli Tüm Gizli Oran",'');
		}
		
		if($olmayan_oranic) {		
			$olmayan_oranic=substr($olmayan_oranic,0,-1);
			$this->db->query("insert into coranver (uye,tip,oranvalid,lig_mac) values $olmayan_oranic");
			loglama1(serialize($kuponLogmacgi), "Canli Tüm Gizli Oraniçi",'');
		}

		if($degisimvar) {
			$sqlver=substr($sqlver,0,-1);
			$this->db->query("insert into coranver (uye,tip,oranvalid,oran,lig_mac) values $sqlver");
			loglama1(serialize($kuponLogmacco), "Canli Tüm Oran Değişiklikleri",'');
		}
		}
		redirect(base_url()."oranmerkezi/?secim=".$secimi);
	}

}
