<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class kupon extends CI_Controller {

	function __construct(){
		parent::__construct();
			logged_admin('mobil/');
			$this->userler=kendi.','.ustu.','.patron;
			//ajaxvarmi();
	}
	
	public function index(){	
		$this->smarty->view('mobil/kupon.tpl');
	}
		
	public function numaralar(){
		
		$yatan = $this->input->post('yatantutar');
		$oran = $this->input->post('oran');
		?>

		<div class="nume">
		<input type="text" class="inputnume" readonly id="yatan" value="<?=$yatan;?>">
		</div>
		<div class="baslik">Toplam Oran: <?=nf($oran);?><span style="float:right; color:#333;">Kazanç: <font id="kazanc"><?=nf($oran*$yatan);?> <?=para; ?></font></span></div>
		<div class="numpad">
		<input type="button" class="buttonnum" value="1" onClick="nums(1);">
		<input type="button" class="buttonnum" value="2" onClick="nums(2);">
		<input type="button" class="buttonnum" value="3" onClick="nums(3);">
		<br>
		<input type="button" class="buttonnum" value="4" onClick="nums(4);">
		<input type="button" class="buttonnum" value="5" onClick="nums(5);">
		<input type="button" class="buttonnum" value="6" onClick="nums(6);">
		<br>
		<input type="button" class="buttonnum" value="7" onClick="nums(7);">
		<input type="button" class="buttonnum" value="8" onClick="nums(8);">
		<input type="button" class="buttonnum" value="9" onClick="nums(9);">
		<br>
		<input type="button" class="buttonnum" value="0" onClick="nums(0);">
		<input type="button" class="buttonnum" value="&laquo;" onclick="deleteon();">
		</div>
		<div class="bos">Tuş takımını kullanarak yatırılan tutarı giriniz</div>

		<div align="center"><input type="button" class="buttonnum" onClick="numkapat();" value="TAMAM" style="background-color:#<?if (tema==1){echo'D38747';}else{echo'BC2121';}?>; color:#FFF; border:1px solid #900;"></div>
		<input type="hidden" id="toplamoranic" value="<?=$oran;?>">
		<script>
		function formatNumber(number)
		{
			var number = number.toFixed(2) + '';
			var x = number.split('.');
			var x1 = x[0];
			var x2 = x.length > 1 ? '.' + x[1] : '';
			var rgx = /(\d+)(\d{3})/;
			while (rgx.test(x1)) {
				x1 = x1.replace(rgx, '$1' + ',' + '$2');
			}
			return x1 + x2;
		}
		
		function nums(id) {
			var suan = $("#yatan").val();
			var varos = $("#yatan").val()+id;
			if(suan==0) {
				$("#yatan").val(id);
			} else {
				$("#yatan").val($("#yatan").val()+id);
			}
			var yansit = $("#yatan").val()*$("#toplamoranic").val();
			if(varos><?=maxodeme;?>) {
				hata('Maksimum ödeme tutarı <?=nf(maxodeme,2);?> <?=para;?>\'dir');
				$("#yatan").val('0');
				$("#kazanc").html('0.00');
			}  else { 
				var tutar = formatNumber(yansit); 
			}
			$("#kazanc").html(tutar);
		}

		function numkapat() {
			var tutar = $("#yatan").val();
			if(tutar<<?=minkupon;?> && tutar!="0") { 
				hata('Bu tutar minimum kupon tutarı altındadır. (<?=nf(minkupon); ?>)'); 
			} else {
				$("#yatantutar").text(tutar);
				$("#macd").fadeOut('fast');
				minimalhesapla();
			}
		}

		function deleteon() {
			
			var suan = $("#yatan").val();
			var toplam = suan.length;
			var res = suan.substr(0,(toplam-1));
			if(res=="") { 
				$("#yatan").val(0); 
			} else {
				$("#yatan").val(res);
			}
			var yansit = $("#yatan").val()*$("#toplamoranic").val();
			if(yansit><?=maxodeme;?>) { 
			var makstutarbul = <?=maxodeme;?>/$("#toplamoranic").val();
			var makstut = makstutarbul.toFixed(0);
			var tutar = formatNumber(<?=maxodeme;?>); 
			} else { var tutar = formatNumber(yansit); }
			$("#kazanc").html(''+tutar+' <?=para; ?>');
		}
		
		function minimalhesapla() {
			var bonusu = $("#bonusu").val();
			var yatan = $("#yatantutar").text();
			var toplamoran = $("#toplamoranic").val();
			var kazancilko = yatan*toplamoran;
			var kesintio=0;
			if(<?=kesinti;?> > 0){
				var kesintio = ((parseFloat(kazancilko) / 100) * <?=kesinti;?>);
			}
			var kazanc = kazancilko - kesintio;
			if(toplamoran><?=maxoran;?>) {
				hata('Maksimum oran sınırına bağlı olarak oran ayarlandı');
				$("#toporan").html('<?=nfss(maxoran,2);?>');
			}else if(yatan><?=maxodeme;?>) {
				hata('Maksimum ödeme tutarı <?=nf(maxodeme,2);?> <?=para;?>\'dir');
				$("#kesinti").html('0.00');
				$("#muhtemelkazanc").html('0.00');
			}else{	
				$("#muhtemelkazanc").html(formatNumber(kazanc));
				$("#kesinti").html(kesintio.toFixed(2));
				$("#bonusuhak").html( formatNumber(((parseFloat(kazanc) / 100) * bonusu) + kazanc));
			}
			$("#yatantutar").val(yatan);
		}
		</script>
<? }

	
	public function kuponok(){
		if(direk==1){die("403");}
		$kuponLog=array();
		$tutar = $this->input->post('tutar');
		$cd = $this->input->post('cd');
		//$toplammac = $this->input->post('toplammac');
		
		if(bakiye<$tutar) { die("402"); }
		
		if($cd=="1") {			
			$sor1 = $this->db->get_where('kupon', array('session_id' => id,'onlem' => sesid));
			foreach($sor1->result_array() as $rowc){
				if($rowc['spor_tip']=="canli") {
					canlida_oran($this->userler,$rowc['canli_event'],$rowc['id'],$rowc['coranid'],1);	
				} 
			}
		}		

		$zaman = time();
		$tarih = date("d.m.Y");

		$sonkontrol = $this->db->query("select aktif from kupon where session_id='".id."' and onlem='".sesid."' and spor_tip!='canli' and (aktif='0' or mac_time<$zaman)");
		if($sonkontrol->num_rows()>0) { die("404"); }
		
		$sonkontrolc = $this->db->query("select aktif from kupon where session_id='".id."' and onlem='".sesid."' and spor_tip='canli' and aktif='0'");		
		if($sonkontrolc->num_rows()>0) { die("404"); }
		
		$sor = $this->db->get_where('kupon', array('session_id' => id,'onlem' => sesid));
		$toplammac = $sor->num_rows();
		if($toplammac<1) { die("404"); }
		
		$toporan = 1;
		$mac_siralama='';
		foreach($sor->result_array() as $tveri){
			$toporan = $toporan*$tveri['oran'];
			@$mac_siralama .= '+'.$tveri['mac_db_id']."_".$tveri['oran_val_id']."_".$tveri['spor_tip'].", ";
		}
		
		$mac_siralama = substr($mac_siralama,0,-1);
		$sirasay=strlen($mac_siralama);
		if(yetki==5){
			$whr=" web_id=".id;
		}else{
			$whr=" user_id=".id." and web_id=0";
		}
		
		$kupa="select sum(yatan) as toplamyatan from kuponlar where $whr and durum=1 
		and LENGTH(mac_siralama)=$sirasay and match(mac_siralama) against('$mac_siralama' in boolean mode)";
		$aynikupon=$this->db->query($kupa);
		$aynikuponnum = $aynikupon->num_rows();
		if($aynikuponnum>0) {
			$ayrow=$aynikupon->row();
			$aynikupontoplam = $ayrow->toplamyatan + $tutar;
			if($aynikupontoplam > aynikuponmax && aynikuponmax > 0) {
				die("13");
			}
		}
		
		$toplamoran = $toporan;
		
		if(maxoran=="") { $maxoran = 1000; } else { $maxoran = maxoran; }
		if($toplamoran>$maxoran) { $toplamoran = $maxoran; }
		$kazanc = $toplamoran*$tutar;
		if($kazanc>maxodeme) { $kazanc = maxodeme; }
		$kesinti=0;
		if(kesinti>0) { $kesinti = nf(($kazanc * kesinti) / 100); }
		
		$ipadres = $_SERVER['REMOTE_ADDR'];
		if(bonus == 1){
			$bonus=bonus_hesapla($toplammac);		
			$bonus=nf(($kazanc / 100) * $bonus);
		}else{
			$bonus=0;
		}
		
		$futbol_durum = kupondavarmi('futbol',id);
		$basket_durum = kupondavarmi('basketbol',id);
		$duello_durum = kupondavarmi('duello',id);
		
		if(yetki==5){
			$usid=ustbayi;
			$webid=id;
		}else{
			$webid=0;
			$usid=id;
		}
		
		$this->db->query("insert into kuponlar (user_id,web_id,adm_id,sup_id,username,oran,yatan,tutar,kupon_time,basketbol,futbol,duello,canli,toplam_mac,durum,kupon_tarih,ipadres,bonus,telefon,mac_siralama,domain,kesinti) values
		('$usid','$webid','".kendi."','".ustu."','".username."','$toplamoran','$tutar','$kazanc','$zaman','$basket_durum','$futbol_durum','$duello_durum','$cd','$toplammac','1','$tarih','$ipadres','$bonus','1','$mac_siralama',14,'$kesinti')");

		$kupon_id = (int)$this->db->insert_id();
		if($kupon_id==0){die("505");}
		
		foreach($sor->result_array() as $row){
			
			$oran_val=$row['oran_val'];
			$oran_val2='';
					
			
		$buoran=$row['oran'];			
			
		$this->db->query("insert into kupon_ic (mbs,mac_kodu,ev_takim,konuk_takim,mac_db_id,mac_time,oran_val_id,oran_tip,oran_val,oran_val2,oran,spor_tip,kupon_id,user_id,username,canli_info,ilkgiris,betradar,hangicanli) 
		values ('$row[mbs]','$row[mac_kodu]','$row[ev_takim]','$row[konuk_takim]','$row[mac_db_id]','$row[mac_time]','$row[oran_val_id]','$row[oran_tip]','$oran_val','$oran_val2','$buoran','$row[spor_tip]','$kupon_id','".id."','".username."','$row[canli_info]','$row[ilkgiris]','$row[betradar]','$row[hangicanli]')");
		
		$kuponLog['kuponici'][] = array(
			'mac_time' => $row['mac_time'],
			'oran_val_id' => $row['oran_val_id'],
			'mac_db_id' => $row['mac_db_id'],
			'mac_kodu' => $row['mac_kodu'],
			'bayi' => username,
			'takimlar' => $row['ev_takim'].'-'.$row['konuk_takim'],
			'tahmin' => $row['oran_tip'],
			'oran' => $buoran,
			'spor_tip' => $row['spor_tip'],
			'canli_bilgi' => $row['canli_info']
		);
		
		}
		
		$this->db->query("update kullanici set bakiye=bakiye-$tutar where id=".id." ");
		$this->db->query("delete from kupon where session_id='".id."' and onlem='".sesid."'");		
		
		$kuponLog['kupon'] = array(
			'toplamoran' => nf($toplamoran),
			'yatan' => $tutar,
			'kazanc' => nf($kazanc),
			'bonus' => $bonus,
			'toplam_mac' => $toplammac,
			'kupon_tarihi' => date('Y-m-d H:i:s', time()),
			'bakiye' => nf(bakiye),
			'durum' => "$kupon_id no'lu Kupon Oynanmıştır"
		);
		$kuponLog = serialize($kuponLog);
		loglama($kuponLog, "Kupon Oynama",$kupon_id);
		die("$kupon_id");
		unset($kuponLog);
	}
	
	public function guncelbakiye(){
		echo nf(bakiye);
	}
	
	public function liveadd(){
		
		if(bahisyasak(yetki,kendi,2)){
			die("4");
		}
		$val = $this->input->post('warrior');
		
		$maxbul=$this->db->query("select id from kupon where session_id='".id."' and onlem='".sesid."'")->num_rows();
		if($maxbul==maxmac) { die("5"); }
		
		$encode = decodekupon($val);
		$war = explode("|",$encode);
		//print_R($war);
		$oran = $war[0];
		$mac_db_id = $war[1];
		$oran_id = $war[2];		
		$canli_kupon_sure = $war[3];		
		
		$simdi = time();
		
		if($canli_kupon_sure < $simdi){
			die("6");
		} 		
		$macbilgi = $this->db->query("select a.*,v.oran_val,t.tip_isim,
		(SELECT gizliler FROM coranver WHERE oranvalid=0 and lig_mac=0 and uye in(".$this->userler.") and gizliler=a.eventid and tip='aski') as surekliaski
		from canli_maclar a
		left join canli_oran b on b.mac_id=a.eventid
		left join canli_tip t on t.id=b.canli_tip
		left join oran_valc v on v.id=b.oran_adi
		where a.id=$mac_db_id AND b.oran_adi=$oran_id");
		
		if($macbilgi->num_rows()==0 && !is_numeric($mac_db_id) && !is_numeric($oran_id) && !empty($oran)) {die('3');}
		
		$mb=$macbilgi->row();
		$surekli_aski_durum = surekli_aski_durum($mb->gol,$mb->sonoranguncelleme,$mb->surekliaski);
		
		if($mb->aktif=="0" || $surekli_aski_durum==1 ) { die("2"); }
		
		$kontrolcv = $this->db->query("select id from kupon where session_id='".id."' and onlem='".sesid."' and hangicanli !='".$mb->yer."'");
		if($kontrolcv->num_rows()>0) {
			 die("5");
		}
		
		$kontrol = $this->db->query("select id from kupon where session_id='".id."' and onlem='".sesid."' and canli_event='".$mb->eventid."'");
		
		if($kontrol->num_rows()>0) {
			$obilgi = $kontrol->row();
			$this->db->query("delete from kupon where id='".$obilgi->id."'");
		}
		
		if($mb->devremi=="1") {
			$canliinfo = $mb->ev_skor.':'.$mb->konuk_skor.'|Devrede';
		} else {
			$canliinfo = $mb->ev_skor.':'.$mb->konuk_skor.'|'.$mb->dakika.'.dk';
		}
		
		$suan = time();
		$canlimbs = 1;//canli_mbs_ver($macbilgi['eventid']);
		
		$orantips = $mb->tip_isim.'|'.$mb->oran_val;
		if(!empty(canli_koruma) && canli_koruma!='0.00' && $oran >= canli_koruma){
			$oran=canli_koruma;
		}
		$this->db->query("insert into kupon (mbs,mac_kodu,ev_takim,konuk_takim,mac_db_id,mac_time,oran_tip,oran,session_id,spor_tip,ilkgiris,oldoran,canli_event,canli_info,betradar,coranid,hangicanli,onlem,canli_kupon_sure) 
		values ('$canlimbs','".$mb->eventid."','".$mb->ev_takim."','".$mb->konuk_takim."','$mac_db_id','$simdi','$orantips','$oran','".id."','canli','".$mb->ilkgiris."','$oran','".$mb->eventid."','$canliinfo','".$mb->betradar_id."','$oran_id','".$mb->yer."','".sesid."','".$canli_kupon_sure."')");
		die("1");
		
	}
	
	public function kuponsay(){
		$sori = $this->db->query("select mac_db_id,oran_val_id,spor_tip,id from kupon where session_id='".id."' and onlem='".sesid."' order by id desc");
		$toplammaci = $sori->num_rows();?>
		<script>
		$(".qbutton.dis").removeClass('selected');
		</script>
		<? if($toplammaci > 0) {
			foreach($sori->result_array() as $row){?>
			<div class="event_head" id="<?=$row['mac_db_id'].'-'.$row['oran_val_id'].'-'.$row['spor_tip'].'-'.$row['id']; ?>"></div> 
		<script>
		var cbet = $("#<?="$row[mac_db_id]-$row[oran_val_id]-$row[spor_tip]"; ?>");
		if(cbet.length>0) { 
			cbet.addClass('selected'); 
		}else{
			$(".all<?="$row[mac_db_id]-$row[spor_tip]"; ?>").addClass('selected');
		}
		</script>
		<? }}?>
		<script>
		$(".kuponsayi").html("<?=$toplammaci;?>");
		</script>
		<?
	}
	
	public function kuponekle(){
		
		if(bahisyasak(yetki,kendi,2)){
			die("4");
		}
		
		$val = $this->input->post('val');

		$maxbul=$this->db->query("select id from kupon where session_id='".id."' and onlem='".sesid."' ")->num_rows();
		if($maxbul==maxmac) { die("5"); }
		
		$encode = decodekupon($val);
		$kes = explode("|",$encode);
		//echo'<pre>';print_R($kes);
		$mac_db_id 		=	 	$kes[0];
		$mbs			=		$kes[1];
		$spor_tip 		=		$kes[2];
		$oran_val_id	=		$kes[3];
		$oran 			=		$kes[4];	
		
		if($oran=="-") { die('1'); }
		
		//if($spor_tip=="futbol" && futbol=="0") { die("no"); }
		
		if($spor_tip=="futbol" || $spor_tip=="duello") {			
			
			$mb = $this->db->query("select d_kodu,ev_takim,konuk_takim,mac_time,mac_kodu,iddaa_kodu from program where id='$mac_db_id'")->row();
			$oran_bilgi = $this->db->query("select oran_val,(select tip_isim from oran_tip where id=oran_val.oran_tip) as tip_isim from oran_val where id=$oran_val_id")->row();
			
			$oranval = "";
			$hdk = "";
			if($mb->d_kodu) { 
				$mb->mac_kodu = $mb->d_kodu; 
			} else { 
				$mb->mac_kodu = $mb->mac_kodu; 
			}
		} else if($spor_tip=="basketbol") {
			
			$mb = $this->db->query("select ev_takim,konuk_takim,mac_time,mac_kodu,iddaa_kodu from programb where id='$mac_db_id'")->row();
			
			$oran_bilgi = $this->db->query("select oran_val,(select tip_isim from oran_tipb where id=oran_valb.oran_tip) as tip_isim from oran_valb where id=$oran_val_id")->row();
			
			$ooran = $this->db->query("select oran_val_b,oran_val_id,mac_db_id,hdk from oranlarb where mac_db_id='$mac_db_id' and oran_val_id='$oran_val_id'")->row();
			
			$oranval = $ooran->oran_val_b;
			$hdk = $ooran->hdk;
			
			if($mb->iddaa_kodu) { 
				$mb->mac_kodu = $mb->iddaa_kodu; 
			} else { 
				$mb->mac_kodu = $mb->mac_kodu; 
			}

		}
		
		if(@$mb->ev_takim=='' || @$oran_bilgi->tip_isim=='') { die('1'); }
		
		if(sabitmbs!="0") { 
			$mbs = sabitmbs; 
		} else { 
			$mbs = $mbs; 
		}		
		

		$suan = time();
		$oran_tip = $oran_bilgi->tip_isim.'|'.$oran_bilgi->oran_val;
		
		$kontrol = $this->db->query("select id from kupon where session_id='".id."' and onlem='".sesid."' and spor_tip='$spor_tip' and mac_db_id='$mac_db_id'");
		if($kontrol->num_rows()<1) {
			$this->db->query("insert into kupon (mbs,mac_kodu,ev_takim,konuk_takim,mac_db_id,mac_time,oran_val_id,oran_tip,oran_val,oran,session_id,spor_tip,ilkgiris,hdk,oldoran,onlem) 
			values ('$mbs','".$mb->mac_kodu."','".$mb->ev_takim."','".$mb->konuk_takim."','$mac_db_id','".$mb->mac_time."','$oran_val_id','$oran_tip','$oranval','$oran','".id."','$spor_tip','$suan','$hdk','$oran','".sesid."')");
			die("201");
		} else {
			$kupondaki = $kontrol->row();
			$this->db->query("update kupon set oran_val_id='$oran_val_id',oran_tip='$oran_tip',oran='$oran',hdk='$hdk',oran_val='$oranval',oldoran='$oran' where id='".$kupondaki->id."' ");
			die("200");
		}	 
	}
	
	public function kuponsil(){
		$id = $this->input->post('id');
		$this->db->query("delete from kupon where id=$id and session_id='".id."' and onlem='".sesid."'");
		die("11");
	}
	
	public function kupontemizle(){
		$this->db->query("delete from kupon where session_id='".id."' and onlem='".sesid."'");
	}
	
	public function kuponguncelle(){
		
		$ysk=bahisyasak(yetki,kendi,2);
		if($ysk){
			echo'<script>$("#ticket_body").show();$(".kuponalt").hide();</script>';
			die("<div class='bos' style='color:#fff;font-size:14px;'><img src='/img/warn.png' style='float: left'><br>Şu an sistem bahislere kapalıdır.!!</div>");
		}
		
		$normal = $oynanamaz=$canlivar=$kombhata=$cv=0;
		$oran = 1;
		
		$sori = $this->db->query("select spor_tip,canli_event,id,coranid from kupon where session_id='".id."' and onlem='".sesid."' order by id desc");
		$toplammaci = $sori->num_rows();
		if($toplammaci > 0) {
			foreach($sori->result_array() as $rowi){
				if($rowi['spor_tip']=="canli") {
					$canlivar=1;
					canlida_oran($this->userler,$rowi['canli_event'],$rowi['id'],$rowi['coranid'],0);	
				}
			}
		}		
		
		$yaz="select * from kupon where session_id='".id."' and onlem='".sesid."' order by id desc";
		$sor = $this->db->query($yaz);
		$toplammac = $sor->num_rows();
		if($toplammac == 0) {
			echo'<script>$("#topsa , #toplamoran, #tutarhesap").text("0");</script>';
			echo'<script>$("#kuponyatan").val("");</script>';
			echo'<script>$("#tumsil , .kuponalt, #ticket_body").hide();</script>';
			
		?>
		<div class="msgtext msgtextbg scrollTo odd" style="color: #<?if (tema==1){echo'000';}else{echo'fff';}?>"> <div class="icons msg_warning"></div> <div class="hidden"></div><div class="hidden"></div><div class="text">Kuponunuz henüz boş.<br>Bahis ekleyebilirsiniz.</div></div> 
		
		
		<? } else {
		
		foreach($sor->result_array() as $row){

		$ob = explode("|",$row['oran_tip']); 
		$oran = $oran*$row['oran'];
				
		//$encoded = "$row[mac_db_id]|$row[mbs]|$row[spor_tip]";
		?>
		<div><div class="editem odd">
		<div class="text w100"><img src="<?=base_url().'img/'.$row['spor_tip'];?>.png" style="vertical-align:top;padding-left:3px"> <?=takimadikisaltkupon($row['ev_takim'])." - ".takimadikisaltkupon($row['konuk_takim']); ?></div>
		<div onclick="kuponsilic(<?=$row['id'];?>)" class="value sil"></div>
		</div>
		</div>

		<div class="edsubitem odd">
		<div class="text w100" style="padding-left:27px">
		<?=$ob[0];?> <b><?=$ob[1];?></b> <? if($row['oran_val']!="") { echo "($row[oran_val])"; } ?>
		</div>
		<div class="value <? if($row['oldoran'] != $row['oran'] && $row['oldoran']<$row['oran']){
			echo'tendup';
		}else if($row['oldoran'] != $row['oran'] && $row['oldoran']>$row['oran']){
			echo'tendown';
		}?>"><?=$row['oran'];?>
		</div>		
		
		<? 
		if($row['canli_event']=="") {
			$normal = 1;
		}
		if($row['canli_kupon_sure']<time() && $row['spor_tip']=="canli") { 
			$oynanamaz=1; 
			echo'<div style="padding-left:27px"> <img width="11" height="11" src="'.base_url().'img/warning_inline.gif" class="warning_inline"><span class="red"> Oran süresi doldu.</span></div>'; 
		}
		if($row['mac_time']<time() && $row['spor_tip']!="canli") { 
			$oynanamaz=1; 
			echo'<div style="padding-left:27px"> <img width="11" height="11" src="'.base_url().'img/warning_inline.gif" class="warning_inline"><span class="red"> Bu maç başladı</span></div>'; 
		}
		if($row['aktif']=="0") { 
			$oynanamaz = 1;
			echo'<div style="padding-left:27px"> <img width="11" height="11" src="'.base_url().'img/warning_inline.gif" class="warning_inline"><span class="red"> Bu maç/oran askıda.</span></div>';
		} ?>
		
		</div>
		<? }//döngü bitttii
		
		if($oran > maxoran) { $oran = maxoran; }
		echo'<script>$("#toplamoran").text("'.nfss($oran).'");</script>';
		echo'<script>$("#topsa").text("'.$toplammac.'");</script>';
		echo'<script>$("#tumsil , .kuponalt,#ticket_body").show();</script>';
		
				
		$maxmbs = $this->db->query("select MAX(mbs) as enmbs from kupon where session_id='".id."' and onlem='".sesid."'")->row()->enmbs;
		if($toplammac<$maxmbs) {
		$mbshata = 1;
		?>
		<script>$(".kuponalt,#ticket_body").hide();</script>	
		<div><div class="edsubitem red even" style="background: #<?if (tema==1){echo'ccc';}else{echo'000';}?>"><div style="padding-left:7px">Minimum bahis sayısına ulaşmadınız. <br><b>(<?=$maxmbs-$toplammac;?>)</b> maç daha ekleyin.</div></div></div>
		<? } else if($oran <= min_oran) {
		$oranhata = 1;
		?>
		<div><div class="edsubitem red even"><span style="padding-left:7px">En az <strong>(<?=min_oran;?>)</strong> oranda kupon yapılabilir.</span></div></div>
		<? } else if($toplammac != minmac && $toplammac < minmac) {$machata = 1;?>
		<div><div class="edsubitem red even"><div style="padding-left:7px">Minimum maç sayısına ulaşmadınız. <br><b>(<?=minmac-$toplammac;?>)</b> maç daha ekleyin.</div></div></div>		
		<? } else if(kombine == 0 && $normal==1 && $canlivar==1) {$kombhata=1;?>
		<div><div class="edsubitem red even"><span style="padding-left:7px">Canlı oyunlarla normal oyunlar kombine edilemezler. Lütfen seçimlerinizi gözden geçiriniz.</span></div></div><script>kombhata=1;</script>
		<? }
		
		if($toplammac==1) { if($canlivar==1) {echo"<input type='hidden' id='canlitekmacsayi' value='".canli_tekmac."'>";}else{echo"<input type='hidden' id='tekmacsayi' value='".tekmacmax."'>";} } else {echo"<input type='hidden' id='kuponmacmax' value='".maxkupon."'>";} ?>
		
		<? if(bonus == 1){
			$bonus=bonus_hesapla($toplammac);
			if($bonus >0){
		?>
		<div class="barbottom" style="width: 100%"><div class="text" style="text-align: center">Bonus</div></div>
		<div class="barbottom" style="width: 100%"><div class="text" style="text-align: center"><?=$toplammac;?> <span>Tahmin</span> %<?=$bonus;?> <span>Bonus</span><input type="hidden" id="bonusu" value="<?=$bonus;?>">
		</div>
		</div>
		<script>$("#bonsgiz").show();</script>
		<? }else{?>
		<input type="hidden" id="bonusu" value="0">	
		<script>$("#bonsgiz").hide();</script>
		<? }
		}else{?>
		<input type="hidden" id="bonusu" value="0">	
		<? }?>
		<input type="hidden" id="kombhata" value="<? if(@$kombhata) { echo "1"; } else { echo "0"; } ?>">
		<input type="hidden" id="oynanamaz" value="<? if(@$oynanamaz) { echo "1"; } else { echo "0"; } ?>">
		<input type="hidden" id="mbshata" value="<? if(@$mbshata) { echo "1"; } else { echo "0"; } ?>">
		<input type="hidden" id="machata" value="<? if(@$machata) { echo "1"; } else { echo "0"; } ?>">
		<input type="hidden" id="oranhata" value="<? if(@$oranhata) { echo "1"; } else { echo "0"; } ?>">		
		<input type="hidden" id="canlivar" value="<? if($canlivar) {$cv = 1; echo "1"; } else { $cv=0; echo "0"; } ?>">
		<?}//kupon var yok bitti?>
		<script>
		function otohesap() {  
		var bonuso = $("#bonusu").val(); var yatan = $("#yatantutar").val(); var toplamorano = $("#toplamoran").text(); var kazancilko = toplamorano*$("#yatantutar").val();  var kazanco = kazancilko; $("#muhtemelkazanc").html(formatNumber(kazanco)); $("#bonusuhak").html( formatNumber(((parseFloat(kazanco) / 100) * bonuso) + kazanco));  
		}
		otohesap();
		function kuponok() {
			
			var tekmacsayi = $("#tekmacsayi").val();
			var kuponmacmax = $("#kuponmacmax").val();
			var canlitekmacsayi = $("#canlitekmacsayi").val();
			$("#countgeri").val(<?=canli_sure;?>);
			var oynanamaz = $("#oynanamaz").val();
			var mbshata = $("#mbshata").val();
			var machata = $("#machata").val();
			var kuponyatan = $("#yatantutar").val();			
			var oranhata = $("#oranhata").val();
			var kombhata = $("#kombhata").val();
			
			if(kuponyatan=='' || kuponyatan<1) {
				hata('<?=lang('yatkont');?>');
			}else if(<?=direk;?>!=1 && <?=yetki;?>!=4 && <?=yetki;?>!=5) {
				hata('<?=lang('supolmaz');?>'); 
			}else if(<?=direk;?>==1 && kuponyatan><?=bakiye;?>) { 
				hata('<?=lang('uyeolmadanolmaz');?>');
			}else if(<?=direk;?>==0 && kuponyatan><?=bakiye;?>) { 
				hata('<?=lang('bakiolmaz');?>'); 
				kuponguncelle(0); 
			}else	if(kuponyatan<<?=minkupon;?>) { 
				hata('<?=lang('minbhs');?> <?=minkupon; ?> <?=para;?>');
				$("#yatantutar").val('<?=(minkupon);?>');	
				kuponguncelle(0); 
			}else if(tekmacsayi >0 && parseInt(kuponyatan) > tekmacsayi) {
				hata('<?=lang('tekmac');?> '+tekmacsayi+' <?=para;?>');
				return false;
			}else if(kuponmacmax >0 && parseInt(kuponyatan) > kuponmacmax) {
				hata('<?=lang('coklu');?> '+kuponmacmax+' <?=para;?>');
				return false;
			}else if(canlitekmacsayi >0 && parseInt(kuponyatan) > canlitekmacsayi) {
				hata('<?=lang('ctekmac');?> '+canlitekmacsayi+' <?=para;?>');
				return false;
			} else	if(oynanamaz==1) { 
				hata('<?=lang('oynanamaz');?>'); 
				kuponguncelle(0); 
			} else	if(mbshata==1) { 
				hata('<?=lang('mbshta',array($maxmbs-$toplammac));?>'); 
				kuponguncelle(0); 
			} else	if(machata==1) { 
				hata('<?=lang('minmac',array(minmac-$toplammac));?>'); 
				kuponguncelle(0); 
			} else 	if(oranhata==1) { 
				hata('<?=lang('minorhata',array(min_oran));?>'); 
				kuponguncelle(0); 
			}else if(kombhata==1) { 
				hata('<?=lang('kombinehta');?>'); 
				kuponguncelle(0); 
			} else	{	
				$(".kuponalt").hide(); 
				$(".kuponalt").addClass('bekle'); 
				$(".kuponalt").removeClass('kuponalt'); 
				var rand = Math.random();
				
				var toplamoran = $("#toplamoran").val();
				var canlidurum = $("#canlivar").val();
				if(canlidurum=="1") {
					hata('<?=lang('kc2');?>',2); 
					$(".countdown").show();
					var kontrol = setInterval(function() { 
					var suancount = $("#countgeri").val();
					var yenicount = suancount-1;
					if(yenicount>-1) {
						$("#countgeri").val(yenicount);
					} else {
						$(".kuponalt").hide(); 
						$(".countdown").show();
						clearInterval(kontrol);
						$(".kuponalt").hide(); 
						$(".countdown").show();
						var kontrolt = setInterval(function() {					
							$("#countgeri").val(0);
							$(".kuponalt").hide(); 
							$(".countdown").show();
							var suancountt = $("#songeri").val();
							var yenicountt = suancountt-1;
							$('#sonbe').html('<?=lang('kupguncelyat');?>');					
							if(yenicountt>-1) {
								$(".kuponalt").hide(); 
								$(".countdown").show();
								$("#songeri").val(yenicountt);
							} else {
								clearInterval(kontrolt);
								if($("#oynanamaz").val()==1) {
									hata('<?=lang('oynanamaz');?>'); 
									kuponguncelle(0); 
								}else{
									kuponokson(kuponyatan,canlidurum,toplamoran);
								}
							}
						},1000);
					}
					},1200);
				} else {
					kuponokson(kuponyatan,canlidurum,toplamoran);
				}
				
			}
		}

		function kuponokson(tutar,canlidurum,toplamoran) {
			
			var baseurl1 = "<?=base_url();?>mobil/";
			var rand = Math.random();
			$.post(baseurl1+'kupon/kuponok',{
				tutar:tutar,cd:canlidurum,toplamoran:toplamoran,toplammac:<?=$toplammac;?>,cv:<?=$cv;?>},function(data) {
			
			if(data=="403") { 
				hata('<?=lang('uyeolmadanolmaz');?>');
			} else	
			if(data=="402") { 
				hata('<?=lang('bakiolmaz');?>'); 
				kuponguncelle(0); 
			} else	if(data=="404") { 
				hata('<?=lang('oynanamaz');?>'); 
				kuponguncelle(0); 
			} else	if(data=="13") { 
				hata('<?=lang('aynikupon',array(nf(aynikuponmax)));?>'); 
				kuponguncelle(0); 
			}else if(data=="505") { 
				hata('<?=lang('hataolustu');?>'); 
				kuponguncelle(0); 
			} else{
				kuponguncelle(0);
				kuponsay();
				limitupdate();				 
				$(".afteredkupon").slideDown();				
				
				hata('<?=lang('ktamam');?>');
			}			
			});
			$(".countdown").hide();
			$(".bekle").addClass('kuponalt'); 
			$(".kuponalt").removeClass('bekle'); 
		}
		</script>
		<? if($cv==1) { ?>
		<input type="hidden" id="caola" value="1">
		<? }
	}
	
}