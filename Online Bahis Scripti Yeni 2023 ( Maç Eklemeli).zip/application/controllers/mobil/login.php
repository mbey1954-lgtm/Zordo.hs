<?php class login extends CI_Controller{

    function __construct() {       
		   parent::__construct();
		   $this->load->model('membership_model');
		   //$this->session->sess_destroy();
	  }
	  
	   
	function index(){   
			if(!detect_mobile()){
				redirect(base_url()."login");
			}
			$this->smarty->view('mobil/anagiris.tpl');
	}
	
	function home(){   
			$this->smarty->assign('yok', $this->session->flashdata('hata')); 
			$this->smarty->view('mobil/login.tpl');
	}
					
   function logout(){
			$ver="delete from kupon where session_id='".sesionlar('id')."' and onlem='".$this->session->userdata('session_id')."'";
			$this->db->query($ver);
			$this->session->sess_destroy();
			//$this->session->unset_userdata('is_logged_Bet');
			redirect(base_url()."mobil/login");  
	}
					
	function giris(){
		
			$username = $this->input->post('username');
			$sifre = $this->input->post('password');
			$yer = $this->input->post('yer');
			if(empty($yer)){
				$this->session->set_flashdata('hata', 'Form bilgileri hataldır.');
			}
			if($yer=='mobil'){
				$nereye='mobil/login/home/?direct=mobil';
				$direct='mobil';
			}else{
				$nereye='mobil/login/home/?direct=masaustu';
				$direct='';
			}
			
			$sql = $this->db->get_where('kullanici', array('username' => addslashes($username),'password' => addslashes($sifre)));
			
			if($sql->num_rows() > 0 ){				
				
				
				$kullanici=$sql->row();
				$ayr=@unserialize($kullanici->ayarlar);
				
				if($ayr['sistemikapat']==1 && $kullanici->yetki!=1){
					$this->session->set_flashdata('hata', 'Sistem Bakımdan Dolayı Kısa bir Süre Kapatılmıştır.');
					redirect(base_url($nereye));
				}
				
				if($kullanici->yetki!=1 && $kullanici->yetki!=2 && $ayr['domain']!='0'){
					$this->session->set_flashdata('hata', 'Yalnış Üyelik Bilgileri. Giriş başarısız.');
					redirect(base_url($nereye));
					
				}else if($kullanici->durum == 0 || $kullanici->aktif == 0 || $kullanici->yetki==6) {
					
					$this->session->set_flashdata('hata', 'Hesabınız sistem yöneticisi tarafından devre dışı bırakılmıştır.');
					redirect(base_url($nereye));
					
				}else if($kullanici->yetki==4 && $ayr['kiralikmi']==1) {
					
					$a=strtotime($ayr['hesapbitis']);
					$b=strtotime(date('d.m.Y'));
					if($a<$b){
						$hnot=$ayr['hnot'];
						if($hnot){
							$not=$hnot;
						}else{
							$not='Hesabınızın Süresi dolmuştur. Lütfen sistem yöneticisi ile görüşünüz.';
						}
						$this->session->set_flashdata('hata',$not);
						redirect(base_url($nereye)); 
					}else{
						$ysk=bahisyasak($kullanici->yetki,$kullanici->hesap_sahibi_id,1);
						if($ysk){						
							$this->session->set_flashdata('hata', 'Site girişleri kapalıdır.');
							redirect(base_url($nereye));
						}
						$session_bilgileri = array(
						'id' =>$kullanici->id,
						'yetki' =>$kullanici->yetki,
						'is_logged_Bet' =>true);
						$this->session->set_userdata($session_bilgileri);
						redirect(base_url($direct));
					}
				}else{
					
					$ysk=bahisyasak($kullanici->yetki,$kullanici->hesap_sahibi_id,1);
					if($ysk){						
						$this->session->set_flashdata('hata', 'Site girişleri kapalıdır.');
						redirect(base_url($nereye));
					}
					$session_bilgileri = array(
					'id' =>$kullanici->id,
					'yetki' =>$kullanici->yetki,
					'is_logged_Bet' =>true);
					$this->session->set_userdata($session_bilgileri);					
					
					$arrs = array("login_user" => $username,"usid" => $kullanici->id, "login_ip" => $_SERVER['REMOTE_ADDR'], "login_tarayici" => $_SERVER['HTTP_USER_AGENT'], "zaman" => time());
					$this->db->insert('login_data', $arrs);
					
					redirect(base_url($direct));
				}
				
				
				
			}else{
				$this->session->set_flashdata('hata', 'Giriş başarısız');
				redirect(base_url($nereye));
			}
			
			$this->session->set_flashdata('hata', 'Bilgileri eksiksiz giriniz.');
			redirect(base_url($nereye));
    }
	
}