<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class home extends CI_Controller {

	function __construct(){
		parent::__construct();
			logged_admin('mobil/');
	}
	
	public function index(){
		
		if(futbol == 0){redirect(base_url().'mobil/hata');}
		$this->smarty->view('mobil/ana.tpl');
		 
	}
	
	public function duello(){		
		if(duello == 0 || dukapat==1){redirect(base_url().'mobil/hata');}
		$this->smarty->view('mobil/duello.tpl');		 
	}
	
	public function bulten(){
	
		ajaxvarmi();
		bultenisil();
		
		$tarih = $this->input->post('tarih');
		$kod = $this->input->post('kod');
		$takim = $this->input->post('takim');
		$saat = $this->input->post('saat');
		$ligid = $this->input->post('ulke');
		$duelmi = (int)$this->input->post('duelmi');
		
		$where_ekle = "";
		
		if($duelmi==1){
			$kodne='a.d_kodu';
			$tipyaz='duello';
			$oran_val_id = "1,2,3,31,32,33";
			$where_ekle.= " and a.program_tip='duello'";
		}else{
			$kodne='a.mac_kodu';
			$tipyaz='futbol';
			$oran_val_id = "1,2,3,6,7,13,14";
			$where_ekle.= " and a.program_tip='futbol'";
		}
		
		$where_ekle.= " and (a.d_kodu !='' or a.mac_kodu !='')";
		
		if(!empty($tarih) && (empty($kod) and empty($takim))) {
			$where_ekle.= " and a.mac_tarih='$tarih'";	
		}

		if(!empty($takim)) { 
			$where_ekle.= " and (a.ev_takim like '%$takim%' or a.konuk_takim like '%$takim%')";
		}

		if(!empty($kod)) {
			$where_ekle.= " and ($kodne like '%$kod%')";
		}

		if(!empty($saat)) { 
			$carp = ($saat*60); $eksi = time()+$carp; 
			$where_ekle.= " and a.mac_time<$eksi"; 
		} 

		if(!empty($ligid)) { 
			$where_ekle.= " and a.kupa_id='$ligid'"; 
		}
		
		$where_ekle= '"'.$where_ekle.'"';
		$ver="call bulten (".kendi.",".ustu.",".patron.",$where_ekle,'$kodne asc','and b.oran_val_id in($oran_val_id)')";
		
		$sor = $this->db->query($ver);
		if ($sor->num_rows() == 0) { 
			echo '<div class="bonusSloganBox"> <span>Seçimlerinize uygun müsabaka bulunamadı</span><br><span></span> </div><button onclick="goBack()" class="bigbutton"><div class="text">Geri</div></button>';
			exit; 
		}		
		
		$start = microtime(true);
		$set = array();
		
		//$this->db->close();
		
		foreach($sor->result() as $assr){
			$ligar=explode('|',$assr->lig);
			$set[$ligar[0].'|'.$ligar[2]][]= $assr;
		}
		$k=0;
		foreach($set as $lig=>$rowlar){			
			$arlig=explode('|',$lig);
			echo'<div class="navtitle">
				<div class="text"><img src="/img/ico-23_w.png" style="vertical-align: middle; width: 18px"> '.$arlig[0].'</div>
			</div>';
		
		foreach($rowlar as $ass){
			
			$ev_kazanc=$beraberlik=$konuk_kazanc=$a25=$u25=$a15=$u15=$kgv=$kgy=$cs1=$cs0=$cs2='';
			if($ass->sonoran==''){continue;}
			$bol=explode(',',$ass->sonoran);
			foreach($bol as $data){
				$bol1=explode('|',$data);
				$orval=$bol1[0];
				if($orval==1){$ev_kazanc=$bol1[1];}
				if($orval==2){$beraberlik=$bol1[1];}
				if($orval==3){$konuk_kazanc=$bol1[1];}
				if($duelmi==1){
					if($orval==31){$cs1=$bol1[1];}
					if($orval==32){$cs0=$bol1[1];}
					if($orval==33){$cs2=$bol1[1];}
				}else{
					if($orval==6){$a25=$bol1[1];}
					if($orval==7){$u25=$bol1[1];}
					if($orval==13){$kgv=$bol1[1];}
					if($orval==14){$kgy=$bol1[1];}
				}
			}
			$ass->orsayi=$ass->orsayi-1;
			$ass->ev=oranana_temizle($ev_kazanc);
			$ass->brb=oranana_temizle($beraberlik);
			$ass->knk=oranana_temizle($konuk_kazanc);
			if($duelmi==1){
				$ass->cs1=oranana_temizle($cs1);
				$ass->cs0=oranana_temizle($cs0);
				$ass->cs2=oranana_temizle($cs2);
			}else{
				$ass->a25=oranana_temizle($a25);
				$ass->u25=oranana_temizle($u25);
				$ass->kgv=oranana_temizle($kgv);
				$ass->kgy=oranana_temizle($kgy);
			}
			
			$ass->mbs = $ass->mbssi;
			$ass->zm = date("d.m",$ass->mac_time);
			$ass->gun = turkce_tarih_kisa($ass->mac_time);
			$ass->st = date("H:i",$ass->mac_time);
			
			$ligar=explode('|',$ass->lig);
			$ass->ev_takim=takimadikisalt($ass->ev_takim);
			$ass->konuk_takim=takimadikisalt($ass->konuk_takim);
			$ass->tipi=$tipyaz;
			
			$encoded = $ass->id.'|'.$ass->mbs.'|'.$tipyaz;
			
			$ass->evk=codekupon($encoded.'|1|'.$ass->ev);
			$ass->bk=codekupon($encoded.'|2|'.$ass->brb);
			$ass->kk=codekupon($encoded.'|3|'.$ass->knk);
			if($duelmi==1){
				$ass->cs1k=codekupon($encoded.'|31|'.$ass->cs1);
				$ass->cs0k=codekupon($encoded.'|32|'.$ass->cs0);
				$ass->cs2k=codekupon($encoded.'|33|'.$ass->cs2);
			}else{
				$ass->a25k=codekupon($encoded.'|6|'.$ass->a25);
				$ass->u25k=codekupon($encoded.'|7|'.$ass->u25);
				$ass->kgvk=codekupon($encoded.'|13|'.$ass->kgv);
				$ass->kgyk=codekupon($encoded.'|14|'.$ass->kgy);
			}			
			
			if($k % 2 == 0){$even='even';}else{$even='odd';}
			if($duelmi==1){
				echo'
			<div class="'.$even.' ">  
				<table class="event  ">
				<tbody>
				<tr><td class="date small " rowspan="2"> '.$ass->gun.' '.$ass->st.'</td><td class="sportsIcon hidden" rowspan="2"><div class="icon">  </div></td><td class="team"><img src="/img/mbs_'.$ass->mbs.'.png"> <b>'.$ass->d_kodu.'</b> '.$ass->ev_takim.' v '.$ass->konuk_takim.'</td><td class="hidden"><span class=""></span></td><td class="hidden"><span class=""></span></td><td class="hidden"><span class=""></span></td><td class="hidden"><span class=""></span></td><td class="hidden"><span class=""></span></td><td class="hidden"><span class=""></span></td><td class="hidden"><span class=""></span></td><td rowspan="2"><div class="hidden"></div></td><td class="" rowspan="2" ></td></tr></tbody></table>
			</div>

			<div style="" class="navitem noborder w100 '.$even.'">
				<div class="cell rsDesc w15">Maç Sonucu</div>
				<div class="cell w25 rsBut">
					<div onclick="kupon(\''.$ass->evk.'\');" class="qbutton dis all'.$ass->id.'-'.$ass->tipi.'" id="'.$ass->id.'-1-'.$ass->tipi.'">
						<div class="caption">1 </div>
						<div class="quote"> '.$ass->ev.'</div>
					</div>
					<div onclick="kupon(\''.$ass->bk.'\');" class="qbutton dis all'.$ass->id.'-'.$ass->tipi.'" id="'.$ass->id.'-2-'.$ass->tipi.'">
						<div class="caption">X </div>
						<div class="quote"> '.$ass->brb.'</div>
					</div>
					<div onclick="kupon(\''.$ass->kk.'\');" class="qbutton dis all'.$ass->id.'-'.$ass->tipi.'" id="'.$ass->id.'-3-'.$ass->tipi.'">
						<div class="caption">2 </div>
						<div class="quote"> '.$ass->knk.'</div>
					</div>
				</div>			
			</div>			
			<div style="" class="navitem noborder w100 '.$even.'">
				<div class="cell rsDesc w15">Çifte Şans</div>	
				<div class="cell w25 rsBut">
					<div onclick="kupon(\''.$ass->cs1k.'\');" class="qbutton dis all'.$ass->id.'-'.$ass->tipi.'" id="'.$ass->id.'-31-'.$ass->tipi.'">
						<div class="caption">1-0</div>
						<div class="quote"> '.$ass->cs1.'</div>
					</div>
					<div onclick="kupon(\''.$ass->cs0k.'\');" class="qbutton dis all'.$ass->id.'-'.$ass->tipi.'" id="'.$ass->id.'-32-'.$ass->tipi.'">
						<div class="caption">1-2</div>
						<div class="quote"> '.$ass->cs0.'</div>
					</div>
					<div onclick="kupon(\''.$ass->cs2k.'\');" class="qbutton dis all'.$ass->id.'-'.$ass->tipi.'" id="'.$ass->id.'-33-'.$ass->tipi.'">
						<div class="caption">0-2</div>
						<div class="quote"> '.$ass->cs2.'</div>
					</div>
				</div>
			</div>			
			
				<div class=""></div>
			</div>';
			}else{
			echo'
			<div class="'.$even.' ">  
				<table class="event  " onclick="mdf(\''.$ass->id.'\',\'\');">
				<tbody>
				<tr><td class="date small " rowspan="2"> '.$ass->gun.' '.$ass->st.'</td><td class="sportsIcon hidden" rowspan="2"><div class="icon">  </div></td><td class="team"><img src="/img/mbs_'.$ass->mbs.'.png"> <b>'.$ass->mac_kodu.'</b> '.$ass->ev_takim.' v '.$ass->konuk_takim.'</td><td class="hidden"><span class=""></span></td><td class="hidden"><span class=""></span></td><td class="hidden"><span class=""></span></td><td class="hidden"><span class=""></span></td><td class="hidden"><span class=""></span></td><td class="hidden"><span class=""></span></td><td class="hidden"><span class=""></span></td><td rowspan="2"><div class="hidden"></div></td><td class="arrow" rowspan="2" ></td></tr></tbody></table>
			</div>

			<div style="" class="navitem noborder w100 '.$even.'">
				<div class="cell rsDesc w15">Maç Sonucu</div>
				<div class="cell w25 rsBut">
					<div onclick="kupon(\''.$ass->evk.'\');" class="qbutton dis all'.$ass->id.'-'.$ass->tipi.'" id="'.$ass->id.'-1-'.$ass->tipi.'">
						<div class="caption">1 </div>
						<div class="quote"> '.$ass->ev.'</div>
					</div>
					<div onclick="kupon(\''.$ass->bk.'\');" class="qbutton dis all'.$ass->id.'-'.$ass->tipi.'" id="'.$ass->id.'-2-'.$ass->tipi.'">
						<div class="caption">X </div>
						<div class="quote"> '.$ass->brb.'</div>
					</div>
					<div onclick="kupon(\''.$ass->kk.'\');" class="qbutton dis all'.$ass->id.'-'.$ass->tipi.'" id="'.$ass->id.'-3-'.$ass->tipi.'">
						<div class="caption">2 </div>
						<div class="quote"> '.$ass->knk.'</div>
					</div>
				</div>			
			</div>			
			<div style="" class="navitem noborder w100 '.$even.'">
				<div class="cell rsDesc w15">Alt/Üst (2.5)</div>	
				<div class="cell w25 rsBut">
					<div onclick="kupon(\''.$ass->a25k.'\');" class="qbutton dis w45 all'.$ass->id.'-'.$ass->tipi.'" id="'.$ass->id.'-6-'.$ass->tipi.'">
						<div class="caption">Alt</div>
						<div class="quote"> '.$ass->a25.'</div>
					</div>
					<div onclick="kupon(\''.$ass->u25k.'\');" class="qbutton dis w45 all'.$ass->id.'-'.$ass->tipi.'" id="'.$ass->id.'-7-'.$ass->tipi.'">
						<div class="caption">Üst</div>
						<div class="quote"> '.$ass->u25.'</div>
					</div>
				</div>
			</div>			
			<div style="" class="navitem noborder w100 '.$even.'">
				<div class="cell rsDesc w15">Karşılıklı Gol</div>		
				<div class="cell w25 rsBut">
					<div onclick="kupon(\''.$ass->kgvk.'\');" class="qbutton dis w45 all'.$ass->id.'-'.$ass->tipi.'" id="'.$ass->id.'-13-'.$ass->tipi.'">
						<div class="caption">Var </div>
						<div class="quote"> '.$ass->kgv.'</div>
					</div>
					<div onclick="kupon(\''.$ass->kgyk.'\');" class="qbutton dis w45 all'.$ass->id.'-'.$ass->tipi.'" id="'.$ass->id.'-14-'.$ass->tipi.'">
						<div class="caption">Yok </div>
						<div class="quote"> '.$ass->kgy.'</div>
					</div>
				</div>
			</div>	
				
				<div class=""></div>
			</div>';
			}
		$k++;
		}
		}
		unset($ass->sonoran);
		unset($ass->mbssi);	
		$sor->free_result();unset($sor,$set);
		//printf(" %.6fs\n", microtime(true) - $start);
		//echo json_encode($set);		
		//$this->load->database();
	}
	
	public function iddaa_bulten(){		
		//if(duello == 0){redirect(base_url().'hata');}
		$this->smarty->view('mobil/iddaa.tpl');		 
	}
	
	public function iddaa_bulten_data(){
	
		ajaxvarmi();
		bultenisil();
		
		$tarih = $this->input->post('tarih');
		$kod = $this->input->post('kod');
		$takim = $this->input->post('takim');
		$saat = $this->input->post('saat');
		$ligid = $this->input->post('ulke');
		$tipyaz='futbol';
		$where_ekle = " and a.iddaa_kodu !=''";
		
		if(!empty($tarih) && (empty($kod) and empty($takim))) {
			$where_ekle.= " and a.mac_tarih='$tarih'";	
		}

		if(!empty($takim)) { 
			$where_ekle.= " and (a.ev_takim like '%$takim%' or a.konuk_takim like '%$takim%')";
		}

		if(!empty($kod)) {
			$where_ekle.= " and (a.iddaa_kodu like '%$kod%')";
		}

		if(!empty($saat)) { 
			$carp = ($saat*60); $eksi = time()+$carp; 
			$where_ekle.= " and a.mac_time<$eksi"; 
		} 

		if(!empty($ligid)) { 
			$where_ekle.= " and a.kupa_id='$ligid'"; 
		}
		
		$where_ekle= '"'.$where_ekle.'"';
		$ver="call bulten (".kendi.",".ustu.",".patron.",$where_ekle,'a.iddaa_kodu asc','and b.oran_val_id in(1,2,3,6,7,4,5,13,14)')";
		
		$sor = $this->db->query($ver);
		if ($sor->num_rows() == 0) { 
			echo '<div class="bonusSloganBox"> <span>Seçimlerinize uygun müsabaka bulunamadı</span><br><span></span> </div><button onclick="goBack()" class="bigbutton"><div class="text">Geri</div></button>';
			exit; 
		}		
		
		$start = microtime(true);
		$set = array();
		
		//$this->db->close();
		
		foreach($sor->result() as $assr){
			$ligar=explode('|',$assr->lig);
			$set[$ligar[0].'|'.$ligar[2]][]= $assr;
		}
		$k=0;
		foreach($set as $lig=>$rowlar){			
			$arlig=explode('|',$lig);
			echo'<div class="navtitle">
				<div class="text"><img src="/img/ico-23_w.png" style="vertical-align: middle; width: 18px"> '.$arlig[0].'</div>
			</div>';
		
		foreach($rowlar as $ass){
			
			$ev_kazanc=$beraberlik=$konuk_kazanc=$a25=$u25=$a15=$u15=$kgv=$kgy=$cs1=$cs0=$cs2='';
			if($ass->sonoran==''){continue;}
			$bol=explode(',',$ass->sonoran);
			foreach($bol as $data){
				$bol1=explode('|',$data);
				$orval=$bol1[0];
				if($orval==1){$ev_kazanc=$bol1[1];}
				if($orval==2){$beraberlik=$bol1[1];}
				if($orval==3){$konuk_kazanc=$bol1[1];}
				
				if($orval==6){$a25=$bol1[1];}
				if($orval==7){$u25=$bol1[1];}
				if($orval==13){$kgv=$bol1[1];}
				if($orval==14){$kgy=$bol1[1];}
			}
			$ass->orsayi=$ass->orsayi-1;
			$ass->ev=oranana_temizle($ev_kazanc);
			$ass->brb=oranana_temizle($beraberlik);
			$ass->knk=oranana_temizle($konuk_kazanc);
			
			$ass->a25=oranana_temizle($a25);
			$ass->u25=oranana_temizle($u25);
			$ass->kgv=oranana_temizle($kgv);
			$ass->kgy=oranana_temizle($kgy);
			
			$ass->mbs = $ass->mbssi;
			$ass->zm = date("d.m",$ass->mac_time);
			$ass->gun = turkce_tarih_kisa($ass->mac_time);
			$ass->st = date("H:i",$ass->mac_time);
			
			$ligar=explode('|',$ass->lig);
			$ass->ev_takim=takimadikisalt($ass->ev_takim);
			$ass->konuk_takim=takimadikisalt($ass->konuk_takim);
			$ass->tipi=$tipyaz;
			
			$encoded = $ass->id.'|'.$ass->mbs.'|'.$tipyaz;
			
			$ass->evk=codekupon($encoded.'|1|'.$ass->ev);
			$ass->bk=codekupon($encoded.'|2|'.$ass->brb);
			$ass->kk=codekupon($encoded.'|3|'.$ass->knk);
			
			$ass->a25k=codekupon($encoded.'|6|'.$ass->a25);
			$ass->u25k=codekupon($encoded.'|7|'.$ass->u25);
			$ass->kgvk=codekupon($encoded.'|13|'.$ass->kgv);
			$ass->kgyk=codekupon($encoded.'|14|'.$ass->kgy);
			
			if($k % 2 == 0){$even='even';}else{$even='odd';}
			
			echo'
			<div class="'.$even.' ">  
				<table class="event  " onclick="mdf(\''.$ass->id.'\',\'\');">
				<tbody>
				<tr><td class="date small " rowspan="2"> '.$ass->gun.' '.$ass->st.'</td><td class="sportsIcon hidden" rowspan="2"><div class="icon">  </div></td><td class="team"><img src="/img/mbs_'.$ass->mbs.'.png"> <b>'.$ass->iddaa_kodu.'</b> '.$ass->ev_takim.' v '.$ass->konuk_takim.'</td><td class="hidden"><span class=""></span></td><td class="hidden"><span class=""></span></td><td class="hidden"><span class=""></span></td><td class="hidden"><span class=""></span></td><td class="hidden"><span class=""></span></td><td class="hidden"><span class=""></span></td><td class="hidden"><span class=""></span></td><td rowspan="2"><div class="hidden"></div></td><td class="arrow" rowspan="2" ></td></tr></tbody></table>
			</div>

			<div style="" class="navitem noborder w100 '.$even.'">
				<div class="cell rsDesc w15">Maç Sonucu</div>
				<div class="cell w25 rsBut">
					<div onclick="kupon(\''.$ass->evk.'\');" class="qbutton dis all'.$ass->id.'-'.$ass->tipi.'" id="'.$ass->id.'-1-'.$ass->tipi.'">
						<div class="caption">1 </div>
						<div class="quote"> '.$ass->ev.'</div>
					</div>
					<div onclick="kupon(\''.$ass->bk.'\');" class="qbutton dis all'.$ass->id.'-'.$ass->tipi.'" id="'.$ass->id.'-2-'.$ass->tipi.'">
						<div class="caption">X </div>
						<div class="quote"> '.$ass->brb.'</div>
					</div>
					<div onclick="kupon(\''.$ass->kk.'\');" class="qbutton dis all'.$ass->id.'-'.$ass->tipi.'" id="'.$ass->id.'-3-'.$ass->tipi.'">
						<div class="caption">2 </div>
						<div class="quote"> '.$ass->knk.'</div>
					</div>
				</div>			
			</div>			
			<div style="" class="navitem noborder w100 '.$even.'">
				<div class="cell rsDesc w15">Alt/Üst (2.5)</div>	
				<div class="cell w25 rsBut">
					<div onclick="kupon(\''.$ass->a25k.'\');" class="qbutton dis w45 all'.$ass->id.'-'.$ass->tipi.'" id="'.$ass->id.'-6-'.$ass->tipi.'">
						<div class="caption">Alt</div>
						<div class="quote"> '.$ass->a25.'</div>
					</div>
					<div onclick="kupon(\''.$ass->u25k.'\');" class="qbutton dis w45 all'.$ass->id.'-'.$ass->tipi.'" id="'.$ass->id.'-7-'.$ass->tipi.'">
						<div class="caption">Üst</div>
						<div class="quote"> '.$ass->u25.'</div>
					</div>
				</div>
			</div>			
			<div style="" class="navitem noborder w100 '.$even.'">
				<div class="cell rsDesc w15">Karşılıklı Gol</div>		
				<div class="cell w25 rsBut">
					<div onclick="kupon(\''.$ass->kgvk.'\');" class="qbutton dis w45 all'.$ass->id.'-'.$ass->tipi.'" id="'.$ass->id.'-13-'.$ass->tipi.'">
						<div class="caption">Var </div>
						<div class="quote"> '.$ass->kgv.'</div>
					</div>
					<div onclick="kupon(\''.$ass->kgyk.'\');" class="qbutton dis w45 all'.$ass->id.'-'.$ass->tipi.'" id="'.$ass->id.'-14-'.$ass->tipi.'">
						<div class="caption">Yok </div>
						<div class="quote"> '.$ass->kgy.'</div>
					</div>
				</div>
			</div>	
				
				<div class=""></div>
			</div>';
		$k++;
		}
		}
		unset($ass->sonoran);
		unset($ass->mbssi);	
		$sor->free_result();unset($sor,$set);
		//printf(" %.6fs\n", microtime(true) - $start);
		//echo json_encode($set);
		//$this->load->database();
	}
	
	public function tumoran($id){
		
		ajaxvarmi();
		$id=(int)$id;
		$ver="call bulten (".kendi.",".ustu.",".patron.",' and a.id=$id',' a.id asc','')";
		$sor = $this->db->query($ver);
		if ($sor->num_rows() == 0) { 
			echo '<div class="bos">Seçimlerinize uygun oran bulunamadı</div>';
			exit; 
		}
		$row=$sor->row();
		
		$bas['html']='';
		$bas['isim']='';
		$this->db->close();
		$this->load->database();
		$ligar=explode('|',$row->lig);
		if($ligar[1]=='Duello'){$tipyaz='duello';}else{$tipyaz='futbol';}
		echo'
			<div style="left: 0px; right: 0px; z-index: 100; position: fixed; top: 0px;" class="appheader" onclick="macdkapat()"><div>  <div class="header"><div class="text title noselect">Kapat </div><div onclick="" style="padding-left:20px" class="icon logo noselect"></div></div></div></div>
			
			<div class="page slide top in" id="page1">
			<div class="scroll_container" style="">
			<div class="scroll_wrapper" style="overflow: hidden">
			<div class="appcontent">
			<div>  </div>
			<div class="odd " style="text-align: center">'.kupa_isim_temizle($ligar[0]).'<br>'.turkce_tarih($row->mac_time).' '.date("H:i",$row->mac_time).'<br><b style="font-size=14px">'.$row->ev_takim.'</b> v <b style="font-size=14px">'.$row->konuk_takim.'</b><br>Maç Kodu : <b>'.$row->mac_kodu.'</b>
			</div>';
		
		$arr = array();
		
		$bol=explode(',',$row->sonoran);
		foreach($bol as $data){					
			$bol1=explode('|',$data);			
			$orval=$bol1[0];
			$oran_tip=$bol1[2];
			$arr[$oran_tip][]= $bol1;
		}
		foreach ($arr as $oran_tip => $veri) {
			
			$saybe=count($veri);
			$sqlek=$this->db->query("select tip_isim from oran_tip where id='$oran_tip' order by id asc")->row();
			?>
		<?php
		echo'<div style="" class="navitem noborder w100 odd">
				<div class="even">&nbsp;'.$tipbaslik=$sqlek->tip_isim.'<br>';		
		foreach($veri as $oranlari){
			
			$orvalid=$oranlari[0];	
			
			$oran_bilgi = $this->db->query("select id,oran_val from oran_val where id='$orvalid'")->row();
			$tahmin=$oran_bilgi->oran_val;
			
			$mbs = $row->mbssi;
			
			$buoran=oranana_temizle($oranlari[1]);
			
			if($buoran!='-'){
			
			$encoded = $row->id.'|'.$mbs.'|'.$tipyaz;			
			$kupon=$encoded."|$orvalid|$buoran";
			
			if($buoran=='-'){$buoran='-';}else{$buoran= nf($buoran);}
			
			echo'<div onclick="kupon(\''.codekupon($kupon).'\');$(\'.qbutton.ic\').removeClass(\'selected\');$(this).addClass(\'selected\');" class="qbutton ic" style="width:100%;" id="ic'.$row->id.'-'.$orvalid.'-'.$tipyaz.'">
						<div class="caption">'.$tahmin.'</div>
						<div class="quote"> '.$buoran.'</div>
					</div>
				';?>
		<?php	
			}
		}
		?>
		</div>
			</div>
		<?php 
		}
		unset($row->sonoran);
		unset($row->mbssi);
		unset($arr);
		?>
		</div></div></div></div>
		<? $ver="select mac_db_id,oran_val_id,spor_tip from kupon where mac_kodu='".$row->mac_kodu."' and session_id='".id."' and onlem='".sesid."' and spor_tip='futbol'";
		$sori = $this->db->query($ver);
		$toplammaci = $sori->num_rows();?>
		<script>
		$(".qbutton.ic").removeClass('selected');
		</script>
		<? if($toplammaci > 0) {
			foreach($sori->result_array() as $row){?>
			
		<script>
		var cbetic = $("#ic<?="$row[mac_db_id]-$row[oran_val_id]-$row[spor_tip]"; ?>");
		if(cbetic.length>0) { 
			cbetic.addClass('selected'); 
		}
		</script>
		<? }}?>
	<?php 
	}
	
	public function basketbol(){
		
		if(basketbol == 0 || baskapat==1){redirect(base_url().'mobil/hata');}
		$this->smarty->view('mobil/bultenb.tpl');
		 
	}
	
	public function bultenb(){
		
		ajaxvarmi();
		bultenisil('b');
		
		$tarih = $this->input->post('tarih');
		$kod = $this->input->post('kod');
		$takim = $this->input->post('takim');
		$saat = $this->input->post('saat');
		$ligid = $this->input->post('ulke');
		
		$where_ekle = " and a.mac_kodu !=''";

		if(!empty($tarih) && (empty($kod) and empty($takim))) {
			$where_ekle.= " and mac_tarih='$tarih'";	
		}

		if(!empty($takim)) { 
			$where_ekle.= " and (ev_takim like '%$takim%' or konuk_takim like '%$takim%')";
		}

		if(!empty($kod)) {
			$where_ekle.= " and (mac_kodu like '%$kod%')";
		}

		if(!empty($saat)) { 
			$carp = ($saat*60); $eksi = time()+$carp; 
			$where_ekle.= " and mac_time<$eksi"; 
		} 

		if(!empty($ligid)) { 
			$where_ekle.= " and kupa_id='$ligid'"; 
		}
		
		$where_ekle= '"'.$where_ekle.'"';
		$ver="call bultenb (".kendi.",".ustu.",".patron.",$where_ekle,'a.mac_time asc','and b.oran_val_id in(1,2,7,8)')";
		
		$sor = $this->db->query($ver);
		if ($sor->num_rows() == 0) { 
			echo '<div class="bonusSloganBox"> <span>Seçimlerinize uygun müsabaka bulunamadı</span><br><span></span> </div><button onclick="goBack()" class="bigbutton"><div class="text">Geri</div></button>';
			exit; 
		}
		
		/*$this->db->close();
		$this->load->database();*/
		
		$setb = array();
		foreach($sor->result() as $assr){
			$ligar=explode('|',$assr->lig);
			$setb[$ligar[0].'|'.$ligar[2]][]= $assr;
		}
		$k=0;
		foreach($setb as $lig=>$rowlar){			
			$arlig=explode('|',$lig);
			echo'<div class="navtitle">
				<div class="text"><img src="/img/ico-23_w.png" style="vertical-align: middle; width: 18px"> '.$arlig[0].'</div>
			</div>';
		foreach($rowlar as $ass){
			
			$ass->orsay=$ass->orsayi-1;
			
			$ev_kazanc=$konuk_kazanc=$alt=$ust=$tsyaz=$hdksi1=$hdksi3=$hdksi8=$hdksi9='';
			if($ass->sonoran==''){continue;}
			$bol=explode(',',$ass->sonoran);			
			foreach($bol as $data){
				$bol1=explode('|',$data);
				$orval=$bol1[0];
				if($orval==1){$ev_kazanc=$bol1[1];$hdksi1=$bol1[3];}
				if($orval==2){$konuk_kazanc=$bol1[1];$hdksi3=$bol1[3];}
				if($orval==7){$alt=$bol1[1];$tsyaz=$bol1[3];$hdksi8=$bol1[3];}
				if($orval==8){$ust=$bol1[1];$hdksi9=$bol1[3];}
			}
			$ass->ev=oranana_temizle($ev_kazanc);
			$ass->knk=oranana_temizle($konuk_kazanc);
			$ass->alt=oranana_temizle($alt);
			$ass->ust=oranana_temizle($ust);
			
			if($ass->alt=="-" || $ass->ust=="-") { 
				$tssi = '-';
			} else {
				$tssi = $tsyaz; 
			}

			$ass->ts = $tssi;
			$ass->mbs = $ass->mbssi;
			$ass->zm = date("d.m",$ass->mac_time);
			$ass->gun = turkce_tarih_kisa($ass->mac_time);
			$ass->st = date("H:i",$ass->mac_time);
			$ligar=explode('|',$ass->lig);
			
			$encoded = $ass->id.'|'.$ass->mbs.'|basketbol';
			
			$ass->ev_takim=takimadikisalt($ass->ev_takim);
			$ass->konuk_takim=takimadikisalt($ass->konuk_takim);
			
			$ass->evk=codekupon($encoded.'|1|'.$ass->ev);
			$ass->kk=codekupon($encoded.'|2|'.$ass->knk);
			$ass->ak=codekupon($encoded.'|7|'.$ass->alt);
			$ass->uk=codekupon($encoded.'|8|'.$ass->ust);			
			
			if($k % 2 == 0){$even='even';}else{$even='odd';}
			echo'
			<div class="'.$even.' ">  
				<table class="event  ">
				<tbody>
				<tr><td class="date small " rowspan="2"> '.$ass->gun.' '.$ass->st.'</td><td class="sportsIcon hidden" rowspan="2"><div class="icon">  </div></td><td class="team"><img src="/img/mbs_'.$ass->mbs.'.png"> <b>'.$ass->mac_kodu.'</b> '.$ass->ev_takim.' v '.$ass->konuk_takim.'</td><td class="hidden"><span class=""></span></td><td class="hidden"><span class=""></span></td><td class="hidden"><span class=""></span></td><td class="hidden"><span class=""></span></td><td class="hidden"><span class=""></span></td><td class="hidden"><span class=""></span></td><td class="hidden"><span class=""></span></td><td rowspan="2"><div class="hidden"></div></td><td class="arrow" rowspan="2" onclick="mdf(\''.$ass->id.'\',\'b\');"></td></tr></tbody></table>
			</div>

			<div style="" class="navitem noborder w100 '.$even.'">
				<div class="cell rsDesc w15">Maç Sonucu</div>
				<div class="cell w25 rsBut">
					<div onclick="kupon(\''.$ass->evk.'\');" class="qbutton dis all'.$ass->id.'-basketbol" id="'.$ass->id.'-1-basketbol">
						<div class="caption">1 </div>
						<div class="quote"> '.$ass->ev.'</div>
					</div>
					<div onclick="kupon(\''.$ass->kk.'\');" class="qbutton dis all'.$ass->id.'-basketbol" id="'.$ass->id.'-2-basketbol">
						<div class="caption">2 </div>
						<div class="quote"> '.$ass->knk.'</div>
					</div>
				</div>			
			</div>
			<div style="" class="navitem noborder w100 '.$even.'">
				<div class="cell rsDesc w15">Puan</div>
				<div class="cell w25 rsBut">
					<div class=" dis ">
						<div class="quote"> '.$ass->ts.'</div>
					</div>
					
				</div>			
			</div>			
			<div style="" class="navitem noborder w100 '.$even.'">
				<div class="cell rsDesc w15">Toplam Sayi Alt/Üst</div>	
				<div class="cell w25 rsBut">
					<div onclick="kupon(\''.$ass->ak.'\');" class="qbutton dis all'.$ass->id.'-basketbol" id="'.$ass->id.'-7-basketbol">
						<div class="caption">Alt</div>
						<div class="quote"> '.$ass->alt.'</div>
					</div>
					<div onclick="kupon(\''.$ass->uk.'\');" class="qbutton dis all'.$ass->id.'-basketbol" id="'.$ass->id.'-8-basketbol">
						<div class="caption">Üst</div>
						<div class="quote"> '.$ass->ust.'</div>
					</div>
				</div>
			</div><div class=""></div>
			</div>';
		$k++;
		}
		}
		unset($ass->sonoran);
		unset($ass->mbssi);	
		$sor->free_result();unset($sor,$setb);
		//printf(" %.6fs\n", microtime(true) - $start);
		//echo json_encode($set);
	}
	
	public function tumoranb($id){
		
		ajaxvarmi();
		$ver="call bultenb (".kendi.",".ustu.",".patron.",' and a.id=$id',' a.id asc','')";
		$sor = $this->db->query($ver);
		if ($sor->num_rows() == 0) { 
			echo '<div class="bos">Seçimlerinize uygun oran bulunamadı</div>';
			exit; 
		}
		$row=$sor->row();
		
		$bas['html']='';
		$bas['isim']='';
		$this->db->close();
		$this->load->database();
		$ligar=explode('|',$row->lig);
		echo'
			<div style="left: 0px; right: 0px; z-index: 100; position: fixed; top: 0px;" class="appheader" onclick="macdkapat()"><div>  <div class="header"><div class="text title noselect">Kapat </div><div onclick="" style="padding-left:20px" class="icon logo noselect"></div></div></div></div>
			
			<div class="page slide top in" id="page1">
			<div class="scroll_container" style="">
			<div class="scroll_wrapper" style="overflow: hidden">
			<div class="appcontent">
			<div>  </div>
			<div class="odd " style="text-align: center">'.kupa_isim_temizle($ligar[0]).' '.turkce_tarih($row->mac_time).' '.date("H:i",$row->mac_time).'<br><b style="font-size=14px">'.$row->ev_takim.'</b> v <b style="font-size=14px">'.$row->konuk_takim.'</b><br>Maç Kodu : <b>'.$row->mac_kodu.'</b>
			</div>';
	
		$arr = array();
		
		$bol=explode(',',$row->sonoran);
		foreach($bol as $data){					
			$bol1=explode('|',$data);			
			$orval=$bol1[0];
			$oran_tip=$bol1[2];
			$arr[$oran_tip][]= $bol1;
		}
		foreach ($arr as $oran_tip => $veri) {
			
			$saybe=count($veri);
			$sqlek=$this->db->query("select tip_isim from oran_tipb where id='$oran_tip' order by id asc")->row();
			echo'<div style="" class="navitem noborder w100 odd">
				<div class="even">&nbsp;'.$tipbaslik=$sqlek->tip_isim.'<br>';
				
		foreach($veri as $oranlari){
			
			$orvalid=$oranlari[0];	
			$oran_val_b=$oranlari[3];	
			if($oran_val_b!="") { $oran_val_b= "($oran_val_b)"; }
			
			$oran_bilgi = $this->db->query("select id,oran_val from oran_valb where id='$orvalid'")->row();
			$tahmin=$oran_bilgi->oran_val;
			
			$mbs = $row->mbssi;
			
			$buoran=oranana_temizle($oranlari[1]);
			
			if($buoran!='-'){
			
			$hdkyaz='';
			$favori='';
			
			$ev_takim=takimadikisalt($row->ev_takim);
			$konuk_takim=takimadikisalt($row->konuk_takim);
			
			$encoded = $row->id.'|'.$mbs.'|basketbol';
			
			$kupon=$encoded."|$orvalid|$buoran";
			
			echo'<div onclick="kupon(\''.codekupon($kupon).'\');$(\'.qbutton.ic\').removeClass(\'selected\');$(this).addClass(\'selected\');" class="qbutton ic" style="width:100%;" id="ic'.$row->id.'-'.$orvalid.'-basketbol">
						<div class="caption">'.$tahmin.' '.$oran_val_b.'</div>
						<div class="quote"> '.$buoran.'</div>
					</div>
				';?>
		<?php	
			}
		}
		?>
		</div>
			</div>
		<?php 
		}
		unset($row->sonoran);
		unset($row->mbssi);
		unset($arr);
		?>
		</div></div></div></div>
		<? $ver="select mac_db_id,oran_val_id,spor_tip from kupon where (mac_kodu='".$row->mac_kodu."' or mac_kodu='".$row->iddaa_kodu."') and session_id='".id."' and onlem='".sesid."' and spor_tip='basketbol'";
		$sori = $this->db->query($ver);
		$toplammaci = $sori->num_rows();?>
		<script>
		$(".qbutton.ic").removeClass('selected');
		</script>
		<? if($toplammaci > 0) {
			foreach($sori->result_array() as $row){?>
			
		<script>
		var cbetic = $("#ic<?="$row[mac_db_id]-$row[oran_val_id]-$row[spor_tip]"; ?>");
		if(cbetic.length>0) { 
			cbetic.addClass('selected'); 
		}
		</script>
		<? }}?>
	<?php 
	}
	
	
	public function newpass(){
		
		ajaxvarmi();
		$newpass = $this->input->post('newpass');
		$sql = $this->db->get_where('kullanici', array('id' => id,'durum' => '1'));
		if($sql->num_rows >0 && $newpass !=''){
			$sonuc = $this->db->update('kullanici', array('password' =>$newpass), array('id' =>$sql->row()->id));
			if($sonuc){
				die('1');
			}
		}else{
			die('2');
		}
	}
}
