<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class canlibahis extends CI_Controller {

	function __construct(){
		parent::__construct();
			logged_admin('mobil/');			
			$this->userler=kendi.','.ustu.','.patron;
			//canlisil('');
			$kelimeler = explode(',', ckelime);
			$this->notLike = "";
			if(!empty(ckelime)){
				foreach($kelimeler as $keyword){
					if(trim($keyword)=="")
						continue;
					$this->notLike .= " AND a.ev_takim NOT LIKE '%".$this->db->escape_str($keyword)."%'";
					$this->notLike .= " AND a.konuk_takim NOT LIKE '%".$this->db->escape_str($keyword)."%'";
				}
			}
			$this->fark = time()-80;
	}
	
	public function index(){		
		
		if(canliyasak >0 || canlibahis==0){redirect(base_url().'mobil/hata');}
		$this->smarty->view('mobil/canli.tpl');
		/*if(soket){
			$this->smarty->view('mobil/socket.tpl');		 
		}else{
			$this->smarty->view('mobil/canli.tpl');
		}*/
	}
	
	public function socket(){		
		
		$this->smarty->view('mobil/socket.tpl'); 
	}
	
	public function livelist(){
	
		ajaxvarmi();
		$bas['ust']='';
		if(canliyasak >0 || canlibahis==0){
			$bas['ust'].='yok';
			echo json_encode($bas);
			exit;
		}
		
		$tip = (int)$this->input->post('tip');
		if($tip){
			$tipver=$tip;
		}else{
			$tipver='1';
		}
		$yeni='SELECT a.lig_adi,k.coranid,a.orsayi,a.eventid,a.gol,a.gorselkodu,a.id,a.ev_takim,a.konuk_takim,a.aktif,a.dakika,a.devre,a.ev_skor,a.konuk_skor,a.sonoranguncelleme,
		(SELECT gizliler FROM coranver WHERE oranvalid=0 and lig_mac=0 and uye in('.$this->userler.') and gizliler=a.eventid and tip="aski") as surekliaski,
		(SELECT count(oranvalid) FROM coranver WHERE lig_mac in(0,a.eventid) and uye in('.$this->userler.') and tip="gizlioranic") as gizlioranic,
		GROUP_CONCAT(
		ct.tip_isim,"|",
		b.oran_adi,"|",
		   (		
			case				
			when c.tip="tumcanli" then CONCAT(ROUND(oranyuzdehesapla(b.oran,(c.oran+IFNULL(m.oran,0))),2))		
			when m.tip="maccanli" then CONCAT(ROUND(oranyuzdehesapla(b.oran,m.oran),2))		
			else CONCAT(ROUND(b.oran,2))
			end
			)	
		  ,"|",b.yukselis,"|",b.dusus,"|",b.canli_tip,"|",b.askida,"|",cv.oran_val ORDER BY b.canli_tip asc,cv.sira asc
		) as sonoran

		FROM canli_maclar a
		left join kupon k on k.mac_kodu=a.eventid and session_id='.id.' and onlem="'.sesid.'"
		left join canli_oran b on b.mac_id=a.eventid and b.canli_tip not in((SELECT oranvalid FROM coranver WHERE lig_mac in(0,a.eventid) and uye in('.$this->userler.') and tip="gizlioran")) and b.canli_tip ='.$tipver.'
		
		left join oran_valc cv on cv.id=b.oran_adi
		left join canli_tip ct on ct.id=b.canli_tip and ct.durum=1
		left join coranver c on c.oranvalid=b.oran_adi and c.lig_mac = 0 and c.uye =(
		if(EXISTS(SELECT uye FROM coranver WHERE oranvalid=b.oran_adi and lig_mac = 0 and uye='.kendi.' and tip="tumcanli")
		,'.kendi.',if(EXISTS(SELECT uye FROM coranver WHERE oranvalid=b.oran_adi and lig_mac = 0 and uye='.ustu.' and tip="tumcanli"),'.ustu.','.patron.'))
		) and c.tip="tumcanli"

		left join coranver m on m.oranvalid=b.oran_adi and m.lig_mac = a.eventid and m.uye=(
		if(EXISTS(SELECT uye FROM coranver WHERE oranvalid=b.oran_adi and lig_mac = a.eventid and uye='.kendi.' and tip="maccanli")
		,'.kendi.',if(EXISTS(SELECT uye FROM coranver WHERE oranvalid=b.oran_adi and lig_mac = a.eventid and uye='.ustu.' and tip="maccanli"),'.ustu.','.patron.'))
		) and m.tip="maccanli"
	
		where
		a.eventid not in((SELECT gizliler FROM coranver WHERE oranvalid=0 and lig_mac=0 and uye in('.$this->userler.') and gizliler=a.eventid and tip="gizlimac"))
		
		and a.sonoranguncelleme>'.$this->fark.'
		and a.dakika <='.canli_dk_kes1.'
		and a.lig_adi!=""
		and a.yer="'.aktifcanli.'"
		'.$this->notLike.'
		group by b.mac_id order by a.id desc';
		$sor = $this->db->query($yeni);
		
		$toplam=$sor->num_rows();
		if ($toplam == 0) { 
			$bas['ust'].='yok';
			echo json_encode($bas);
			exit; 
		}		
		
		$oddeve=0;
				
		$set = array();
		foreach($sor->result() as $mb1){
			$lg=explode('-',$mb1->lig_adi);
			$set[$lg[0].' '.$lg[1]][]= $mb1;
		}
		
		foreach ($set as $ligadi => $data) {
			$bas['ust'].='<div>	<div class="sports-caption">
					<div class="liveicon-left licon-1"></div>
					<div class="navtitle1"><span class="ng-binding">'.$ligadi.'</span></div>
				</div>';
			foreach($data as $mb){
			
			$surekli_aski_durumo =surekli_aski_durum($mb->gol,$mb->sonoranguncelleme,$mb->surekliaski);
			if($surekli_aski_durumo==1 || $mb->aktif=="0") { $aktif = 0; } else { $aktif = 1; }				
							
			$arr = array();
			$oranlar = array();			
				
			$bol=explode(',',$mb->sonoran);
			//echo'<pre>';print_R($bol);
			foreach($bol as $data){
				$bol1=explode('|',$data);				
				$arr[$bol1[0]][]= $bol1;
				
			}//exit;
			$altust=$iyaltustyaz=$altustyaz=$iyaltust=$sgol=$iygk1=$ms1=$iysira=$iyms1=$kv=$ky=$sd=$s0=$ms0=$s1=$cs2=$cs0=$ms2=$cs1=$gk1=$gk0=$gk2=$acoran=$orver=$bslk='';
			$tmp=$iyal=0;
			
			foreach ($arr as $tipbaslik => $veri1) {
				$bslk=$tipbaslik;
				$saybe=count($veri1);
				if($saybe==2 || strstr($tipbaslik,'Alt/Üst')){
					$cls= 3;
				}elseif($saybe==3){
					$cls= 2;
				}elseif($saybe==4){
					$cls= 2;
				}
				
				foreach($veri1 as $k=>$veri){
					
					
					$oran_id=$veri[1];
					$oran=$veri[2];
					$yukselis=$veri[3];
					$dusus=$veri[4];
					$canli_tip=$veri[5];
					$oran_adi=$veri[7];
					
					//if ($canli_tip==2 && $tmp++ > 2) {continue;}
					if(!empty(canli_koruma) && canli_koruma!='0.00' && $oran >= canli_koruma){
						$oran=canli_koruma;
					}
					$canli_kupon_sure = time()+(canli_kupon_sure * 60);
					$kupverr = codekupon("$oran|".$mb->id."|".$oran_id."|".$canli_kupon_sure);
					$cekle='onClick="canliekle(\''.$kupverr.'\');$(this).addClass(\'active\');"';
					
					if($oran_id==$mb->coranid){
						$seciliclass='active';
						$ydus=yukdurumsec($yukselis,$dusus);
					}else{
						$ydus=yukdurum($yukselis,$dusus);
						$seciliclass='';
					}
					
					if($aktif==0 || $veri[6]==0 || $mb->gizlioranic==$oran_id) {
						$askclass='ldisabled';
						$kupver='';
					}else{
						$askclass='';
						$kupver=$cekle;
					}
					if($askclass == 'ldisabled'){
						$oran='';
					}
					//$oranlar[$canli_tip][$oran_id]=array($ydus,$kupver,$oran);
					if($canli_tip==24){
						$orver.='<li><a class="ratio-box '.$askclass.' '.$seciliclass.' '.$ydus.'" id="" href="javascript:;"  '.$kupver.'><span class="row-span">'.str_replace(array('Ev Sahibi','Gol Olmayacak','Deplasman'),array('1','X','2'),$oran_adi).'</span><strong class="row-strong">'.$oran.'</strong></a></li>';
					}else
					if($canli_tip==1){
						$orver.='<li><a class="ratio-box '.$askclass.' '.$seciliclass.' '.$ydus.'" href="javascript:;" id="" '.$kupver.'><span class="row-span">'.str_replace(array('Ev Sahibi','Beraberlik','Deplasman'),array('1','X','2'),$oran_adi).'</span><strong class="row-strong">'.$oran.'</strong></a></li>';
					}else
					if($canli_tip==2){
						if ($tmp++ > 1) {continue;}
						$altustyaz=str_replace(array('Alt','Üst',' '),'',$oran_adi);
						$orver.='<li><a class="ratio-box '.$askclass.' '.$seciliclass.' '.$ydus.'" href="javascript:;" id="" '.$kupver.'><span class="row-span">'.$oran_adi.'</span><strong class="row-strong">'.$oran.'</strong></a></li>';
					}else
					if($canli_tip==28){
						$orver.='<li><a class="ratio-box '.$askclass.' '.$seciliclass.' '.$ydus.'" href="javascript:;" id="" '.$kupver.'><span class="row-span">'.$oran_adi.'</span><strong class="row-strong">'.$oran.'</strong></a></li>';
					}
				}
			}
			
			$golsesi = time()-60;
			$golhtml='<span style="background-color:red;color:#fff;width:40px"><img src="'.base_url().'img/golvar.GIF" style="" height="10"> <ibrahim>Gooooll !</ibrahim></span>';
			if(!empty($mb->gol) && $mb->gol>$golsesi) {
				$golvar=$golhtml;
			}else{
				$golvar='';
			}
			
			if($mb->devre!='2. Yarı') { $devreyaz= $mb->devre; }else { $devreyaz= '';}
			if($mb->dakika<45) { $iyari= 'big-';$orsayidusur=23; }else { $iyari= '';$orsayidusur=14;}
			if($mb->devre=="Devre arası") { $dkyaz= lang('dvre');}else 
			if($mb->dakika=="") { $dkyaz= "-"; }else 
			if(is_numeric($mb->dakika)) {$dkyaz=$mb->dakika." '";}
			
			if($mb->gorselkodu){
				$tvvarmi='';
			}else{
				$tvvarmi='';
			}			
			$linkver='onclick="go(\'canlibahis/liveevents/'.$mb->eventid.'\');"';
			$bas['ust'].='<div class="live-match">
				<div class="sports-tip" > 
					<a '.$linkver.'>
						<div class="datetime-caption"><span>'.$dkyaz.'<br>'.$mb->ev_skor.':'.$mb->konuk_skor.'</span></div>
						<div class="team-caption"><span class="ng-binding">'.$mb->ev_takim.'<br>'.$mb->konuk_takim.'</span></div>
						<div class="rg2"></div>
						<div class="icon-right"><i class="fa fa-caret-right fa-lg"></i></div>
					</a> 
				
				<div style="background: #ccc; padding-left: 5px;"><img src="/images/live.gif" style="width: 30px"></div>
				</div>
				<div class="table-row-'.$cls.' ">
					<div class="row_'.$cls.'-caption"><span>'.$bslk.'
						<text >&nbsp;'.$altustyaz.'</text>
						</span>
					</div>
					<ul>
						'.$orver.'
					</ul>
				</div></div>';
				
			$oddeve++;
		}
		$bas['ust'].='</div>';
		}
		echo json_encode($bas);
	}
	
	public function liveevents($event){
		
		if(canliyasak >0 || canlibahis==0){redirect(base_url().'mobil/hata');}
		$this->smarty->assign('event',$event);
		$this->smarty->view('mobil/canlievent.tpl');
	}
	
	public function liveevents_socket($event){
		exit;
		$event=(int)$event;
		if(canliyasak >0 || canlibahis==0){redirect(base_url().'mobil/hata');}
		if($event==0){redirect(base_url().'mobil/canlibahis/');exit;}
		$this->smarty->assign('event',$event);
		$this->smarty->view('mobil/socket_event.tpl');
	}
	
	public function liveodds(){
		
		ajaxvarmi();
		
		$bas['ust']='';
		$bas['odds']='';
			
		if(canliyasak >0 || canlibahis==0){
			$bas['ust'].='yok';
			echo json_encode($bas);
			exit; 
		}
		
		$mac_id = (int)$this->input->post('event');
		//$tip = $this->input->post('tip');
		
		if($mac_id){			
			
			
			$yeni='SELECT a.betradar_id,a.gorselkodu,a.id,a.ev_takim,a.konuk_takim,a.aktif,a.dakika,a.devre,a.ev_skor,a.konuk_skor,a.gol,a.sonoranguncelleme,
			(SELECT gizliler FROM coranver WHERE oranvalid=0 and lig_mac=0 and uye in('.$this->userler.') and gizliler=a.eventid and tip="aski") as surekliaski,
			if(a.devre = "1. Yarı" and a.dakika >= '.canli_dk_kes.',1,0) as ilkyarigizle,
			GROUP_CONCAT(
			ct.tip_isim,"|",
			b.oran_adi,"|",
			   (		
				case				
				when c.tip="tumcanli" then CONCAT(ROUND(oranyuzdehesapla(b.oran,(c.oran+IFNULL(m.oran,0))),2))		
				when m.tip="maccanli" then CONCAT(ROUND(oranyuzdehesapla(b.oran,m.oran),2))		
				else CONCAT(ROUND(b.oran,2))
				end
				)	
			  ,"|",cv.oran_val,"|",b.yukselis,"|",b.dusus,"|",b.askida ORDER BY ct.sira asc,cv.sira asc
			) as sonoran

			FROM canli_maclar a
			left join canli_oran b on b.mac_id=a.eventid and b.canli_tip not in((SELECT oranvalid FROM coranver WHERE lig_mac in(0,a.eventid) and uye in('.$this->userler.') and tip="gizlioran")) and b.oran_adi not in((SELECT oranvalid FROM coranver WHERE lig_mac in(0,a.eventid) and uye in('.$this->userler.') and tip="gizlioranic"))
			
			left join canli_tip ct on ct.id=b.canli_tip and ct.durum=1
			left join oran_valc cv on cv.id=b.oran_adi
			
			left join coranver c on c.oranvalid=b.oran_adi and c.lig_mac = 0 and c.uye =(
			if(EXISTS(SELECT uye FROM coranver WHERE oranvalid=b.oran_adi and lig_mac = 0 and uye='.kendi.' and tip="tumcanli")
			,'.kendi.',if(EXISTS(SELECT uye FROM coranver WHERE oranvalid=b.oran_adi and lig_mac = 0 and uye='.ustu.' and tip="tumcanli"),'.ustu.','.patron.'))
			) and c.tip="tumcanli"

			left join coranver m on m.oranvalid=b.oran_adi and m.lig_mac = a.eventid and m.uye=(
			if(EXISTS(SELECT uye FROM coranver WHERE oranvalid=b.oran_adi and lig_mac = a.eventid and uye='.kendi.' and tip="maccanli")
			,'.kendi.',if(EXISTS(SELECT uye FROM coranver WHERE oranvalid=b.oran_adi and lig_mac = a.eventid and uye='.ustu.' and tip="maccanli"),'.ustu.','.patron.'))
			) and m.tip="maccanli"
		
			where
			a.eventid not in((SELECT gizliler FROM coranver WHERE oranvalid=0 and lig_mac=0 and uye in('.$this->userler.') and gizliler=a.eventid and tip="gizlimac"))
			and a.eventid='.$mac_id.'
			and a.yer=(select aktifcanli from kullanici where id=1)
			and a.sonoranguncelleme>'.$this->fark.'
			and a.dakika <='.canli_dk_kes1.'
			'.$this->notLike.'
			group by b.mac_id ';
		
			$sor = $this->db->query($yeni);
			$toplam=$sor->num_rows();
			$mb=$sor->row();
			
			if ($toplam == 0 || count($mb->sonoran)==0) { 
				$bas['ust'].='yok';
				echo json_encode($bas);
				exit; 
			}
			
			if($mb->devre=="Devre arası") { $dkyaz= "45"; }else 
			if($mb->dakika=="") { $dkyaz= "-"; }else 
			if(is_numeric($mb->dakika)) {$dkyaz=$mb->dakika;}
			
			$bas['ust'].='<div class="matchscores"><div class="scorebox headline scrollTo2"><div class="eventpointDG"><div class="top time ">'.$dkyaz.' \'</div><div class="top right">'.$mb->ev_takim.'</div><div class="top center noBG"><span class="">'.$mb->ev_skor.'</span>:<span class="">'.$mb->konuk_skor.'</span></div><div class="top left">'.$mb->konuk_takim.'</div></div></div><div class="eventPointInfo"><div class="eventInfo"><div class="score"><span class="">'.$mb->devre.'</span><span class=""></span></div><div class="icon"><div class="scIcon goal-kick"></div></div></div></div></div><div class="t_head cf"><div class="livescoreboard-title">
			';
		
			$surekli_aski_durum = surekli_aski_durum($mb->gol,$mb->sonoranguncelleme,$mb->surekliaski);
			if($surekli_aski_durum==1 || $mb->aktif=="0") { $aktif = 0; } else { $aktif = 1; }
	
			$arr = array();
			
			$bol=explode(',',$mb->sonoran);
			//echo'<pre>';print_R($bol);
			foreach($bol as $data){					
				$bol1=explode('|',$data);
				//$bol1[3]=($bol1[3].'d');	
				$arr[$bol1[0]][]= $bol1;
			}
						
			foreach ($arr as $tipbaslik => $veri) {
				if($mb->ilkyarigizle){
					if(strstr($tipbaslik,'İlk')){
						continue;
					}
				}
				$saybe=count($veri);
				$bas['odds'].='<div style="" class="navitem noborder w100 odd">
				<div class="even">&nbsp;'.$tipbaslik.'<br>';
				
				foreach($veri as $ass1){
					
					if($tipbaslik=='Ev Sahibi İlk Yarı Alt/Üst' || $tipbaslik=='Maç Sonucu Alt/Üst' || $tipbaslik=='İkinci Yarı Toplam Gol Alt/Üst' || $tipbaslik=='İlk Yarı Toplam Gol Alt/Üst' || $tipbaslik=='İlk Yarı Sonucu Alt/Üst' || $tipbaslik=='İlk Yarı Sonucu Alt/Üst' || $tipbaslik=='Ev Sahibi Maç Sonucu Alt/Üst' || $tipbaslik=='Deplasman İlk Yarı Alt/Üst'|| $tipbaslik=='Deplasman Maç Sonucu Alt/Üst' || $tipbaslik=='MS ve İki Takım da Gol Atar' || $saybe==2){$cls= "md50";}else{$cls= "md33";}
					//if($saybe==2) { $cls= "md50"; } else { $cls= "md33"; }
					$oran_id=$ass1[1];
					$oran_adi=$ass1[3];
					$oran=$ass1[2];
					$yukselis=$ass1[4];
					$dusus=$ass1[5];
					if(!empty(canli_koruma) && canli_koruma!='0.00' && $oran >= canli_koruma){
						$oran=canli_koruma;
					}
					$canli_kupon_sure = time()+(canli_kupon_sure * 60);
					$kuponekle = codekupon("$oran|".$mb->id."|".$oran_id."|".$canli_kupon_sure);
					
					if($aktif==0 || $ass1[6]==0) {
						$askclass='askioran';
						$kupver='';
					}else{
						$askclass='';
						$kupver='onClick="canliekle(\''.$kuponekle.'\');$(\'.qbutton.ic\').removeClass(\'selected\');$(this).addClass(\'selected\');"';
					}					
					
					if($oran<=1.00){
						$kupver='';
						$oran='-';
					}
					if($askclass == 'askioran'){
						$oran='<img src="'.base_url().'img/lock.png" height="14" style="vertical-align:middle; margin-bottom:2px;" title="Oran Askıda">';
					}
					$bas['odds'].='<div '.$kupver.' class="qbutton ic '.$askclass.'" style="width:99.7%;" id="'.$oran_id.'-0-canli">
						<div class="caption">'.$oran_adi.'</div>
							<div class="quote '.yukdurum($yukselis,$dusus).'">'.$oran.'</div>
						</div>';
					
				}				
				$bas['odds'].='</div></div>';
			}
		}
		echo json_encode($bas);
		$sor->free_result();unset($arr,$bas,$sor);
	}
}
