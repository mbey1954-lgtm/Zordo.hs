<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class kuponlar extends CI_Controller {

	function __construct(){
		parent::__construct();
			logged_admin('mobil/');
	}
	
	public function index(){
		$bver=bayioption();	
		$this->smarty->assign('bayilist',bayioption());
		$bver='';
		$this->smarty->view('mobil/kuponlar.tpl');
	}
	
	public function data(){
		
		ajaxvarmi();
		$kuponno = (int)$this->input->post('kupon_no');
		$tarih1 = basla_time($this->input->post('tarih1'));
		$tarih2 = bitir_time($this->input->post('tarih2'));
		$satir = $this->input->post('satir');
		$durum = $this->input->post('durum');
		$tip = $this->input->post('tip');
		$order = $this->input->post('order');
		$ascdesc = $this->input->post('ascdesc');
		$pi = $this->input->post('pi');
		$userid = $this->input->post('userid');
		$oyun = $this->input->post('oyun');
		
		if($ascdesc=="asc") { $yenidesk = "desc"; } else { $yenidesk = "asc"; }

		$limitayar = 50;
		$limit = $pi*$limitayar;

		if($userid){
			if(yetki == 4) {
				$user_ekle = " a.web_id='$userid'";
			}else{
				$user_ekle = " (a.user_id='$userid' or a.web_id='$userid')";
			}
		}else{
			if(yetki == 1) {
				$user_ekle = "a.id!=''";
			}else if(yetki == 2) {
				$user_ekle = " a.sup_id='".id."'";
			}else if(yetki == 3) {
				$user_ekle = " a.adm_id='".id."'";
			}else if(yetki == 4) {
				$user_ekle = " a.user_id='".id."'";
			}else if(yetki == 5) {
				$user_ekle = " a.web_id='".id."'";
			}
		}
		
		$tarihkle="and a.kupon_time between '$tarih1' and '$tarih2'";
		
		if(!empty($kuponno)) { $kupon_ekle = "and a.id='$kuponno'";$tarihkle='';} else { $kupon_ekle = ""; }
		
		if(!empty($satir)) {
			if($satir=="kombine") { $satir_ekle = "and a.toplam_mac>1"; } else
			if($satir==3) { $satir_ekle = "and a.toplam_mac>2"; } else
			if($satir==1 || $satir==2) { $satir_ekle = "and a.toplam_mac='$satir'"; }	
		} else {
			$satir_ekle = "";	
		}
		if(!empty($durum)) { $durum_ekle = "and a.durum='$durum'"; } else { $durum_ekle = ""; }
		if(!empty($tip)) {
			if($tip=="1") { $tip_ekle = "and a.canli='0'"; } else
			if($tip=="2") { $tip_ekle = "and a.canli='1'"; }	
		} else {
			$tip_ekle = "";	
		}
		
		$oyunekle='';
		$group='';
		$join='';
		$alan='';		

		$sqladder = "$user_ekle $durum_ekle $tarihkle $kupon_ekle $satir_ekle $tip_ekle ";
		$bak="select a.*,
		(select count(kupon_id) from kupon_ic where kupon_id=a.id and kazanma='2') as toplamtutan,
		(select count(kupon_id) from kupon_ic where kupon_id=a.id and mac_time<".time().") as macbaslamismi,
		(select count(id) from kuponlar where user_id='".id."' and kupon_tarih='".date('d.m.Y')."' and durum=4) as gunsay
		$alan
		from kuponlar a
		$join
		where $sqladder $oyunekle
		$group
		order by $order $ascdesc limit 0,$limit";//order by $order $ascdesc limit 0,$limit
 
		if($ascdesc=="asc") { $yenidesk = "desc"; } else { $yenidesk = "asc"; }

		$sor = $this->db->query($bak);
		$toplam_kuponi=$sor->num_rows();
		
		if($toplam_kuponi<1) { 
			echo "<div class='bos'>Herhangi bir sonuç bulunamadı</div>";exit;
		} else {
		
		$yenihesap = $this->db->query("select 
		count(a.id) AS toplam_kupon,
		SUM(a.yatan) AS toplam_kupon_tutar,

		coalesce(sum(a.durum=1), 0) AS toplam_devam,
		SUM(IF(a.durum=1, a.yatan, 0)) AS toplam_devam_tutar,

		coalesce(sum(a.durum=2), 0) AS toplam_kazanan,
		SUM(IF(a.durum=2, (a.tutar + a.bonus), 0)) AS toplam_kazanan_tutar,

		coalesce(sum(a.durum=3), 0) AS toplam_kaybeden,
		SUM(IF(a.durum=3, a.yatan, 0)) AS toplam_kaybeden_tutar,

		coalesce(sum(a.durum=4), 0) AS toplam_iptal,
		SUM(IF(a.durum=4, a.yatan, 0)) AS toplam_iptal_tutar

		from kuponlar a where $sqladder")->row();
		$kazanan_yuzde = '';//yuzde($toplam_kupon,$toplam_kazanan);
		$kaybeden_yuzde = '';//yuzde($toplam_kupon,$toplam_kaybeden);
		$devameden_yuzde = '';//yuzde($toplam_kupon,$toplam_devam);
		$iptal_yuzde = '';//yuzde($toplam_kupon,$toplam_iptal);
		?>
		<table>
		<tr style="background:#fff">
		<td style="color:#000;" data-label="Yatırılan Kupon">
		(<?=n($yenihesap->toplam_kupon - $yenihesap->toplam_iptal);?>) 
		<?=nf($yenihesap->toplam_kupon_tutar - $yenihesap->toplam_iptal_tutar); ?> TL
		</td>
		<td style="color:#0C0;" data-label="Kazanan">
		(<?=n($yenihesap->toplam_kazanan);?>) 
		<?=$kazanan_yuzde;?> <?=nf($yenihesap->toplam_kazanan_tutar); ?> TL
		</td>
		<td style="color:#F00;" data-label="Kaybeden">
		(<?=n($yenihesap->toplam_kaybeden);?>) 
		<?=$kaybeden_yuzde;?> <?=nf($yenihesap->toplam_kaybeden_tutar); ?> TL
		</td>
		<td data-label="Bahis Açık">
		(<?=n($yenihesap->toplam_devam);?>) 
		<?=$devameden_yuzde;?> <?=nf($yenihesap->toplam_devam_tutar); ?> TL
		</td>
		<td style="color:#006699;" data-label="İptal Edilen">
		(<?=n($yenihesap->toplam_iptal);?>) 
		<?=$iptal_yuzde;?> <?=nf($yenihesap->toplam_iptal_tutar); ?> TL
		</td>
		</tr>
		
		<thead>
		<tr>
		<th><a href="javascript:;" >No</a></th>
		<th><a href="javascript:;" >Bayi</a></th>
		<th style="width:8%"><a href="javascript:;">Tarih</a></th>
		<th><a href="javascript:;" >Maç</a></th>
		<th ><a href="javascript:;" >Yatırılan</a></th>
		<th ><a href="javascript:;" >Toplam Oran</a></th>
		<th ><a href="javascript:;" >Bonus</a></th>
		<th ><a href="javascript:;" >Olası Kazanç</a></th>
		<th ><a href="javascript:;">Durum</a></th>
		<th><a href="javascript:;">Tip</a></th>
		<th style="width:6%">İptal</th>
		</tr>
		</thead><tbody>
		<? foreach($sor->result_array() as $row){ ?>

			<tr class="kdurum_<?=$row['durum']; ?>">
			<td style="cursor:pointer;" data-label="Kupon No">
			<img src="/img/gordum.png" style="height:10px; display:none; vertical-align:middle; margin-bottom:2px;" id="gordum_<?=$row['id']; ?>"> 
			<a href="javascript:;" onclick="kupond('<?=$row['id']; ?>');event.stopImmediatePropagation();" title="Kupon Detayı için tıklayınız."><?=$row['id']; ?></a>
			</td>
			<td data-label="Bayi"><?=$row['username']; ?></td>
			
			<td data-label="Tarih"><?=date("d.m.Y H:i:s",$row['kupon_time']); ?></td>
			<td data-label="Maç"><?=$row['toplam_mac']; ?> <? echo "($row[toplamtutan])";?></td>
			<td data-label="Yatırılan"><?=nf($row['yatan']); ?></td>
			<td data-label="Toplam Oran"><?=nf($row['oran']); ?></td>
			<td data-label="Bonus"><?=nf($row['bonus']); ?></td>
			<td data-label="Olası Kazanç"><?=nf($row['tutar']+$row['bonus']); ?></td>
			<td data-label="Durum"><?=durumnedir($row['durum']); ?> <? if($row['odendi']=="1") { ?>, Ödendi.<? } ?></td>
			<td data-label="Tip"><? if($row['canli']=="1") { ?><img src="/img/canli.png" title="Canlı Bahis"><? } ?><? if($row['basketbol']=="1") { ?><img src="/img/basketbol.png" title="Basketbol"><? } ?><? if($row['futbol']=="1") { ?><img src="/img/futbol.png" title="Futbol"><? } ?><? if($row['duello']=="1" ) { ?><img src="/img/duello.png" title="duello"><? } ?></td>
			<td style="width:5%" data-label="İptal">
			<? 
			$aradafark = time()-$row['kupon_time'];
			$suann=time();
			
			if($row['gunsay'] > iptal_limit){$gunlimit=1;}else{$gunlimit=0;}
			//echo $ub['iptal_yetki'].'/'.$silme_sure.'/'.$aradafark.'/'.$gunlimit.'/'.$macbaslamismi;

			if((yetki == 1 || yetki == 2) && $row['durum']!="4"){
			?>
				<a href="javascript:;" onclick="kupon_iptal('<?=$row['id']; ?>');event.stopImmediatePropagation();">
					<img src="/img/sil.png" >
				</a>
			<? }else if(iptal_yetki==1 && yetki == 3 && $row['durum']!="4"){?>
				<a href="javascript:;" onclick="kupon_iptal('<?=$row['id']; ?>');event.stopImmediatePropagation();">
					<img src="/img/sil.png" >
				</a>
			<? }else if($row['durum']=="1" && $row['canli']=="0" && $row['macbaslamismi']==0 && iptal_yetki=="1" && iptal_sure!=0 && ((iptal_sure*60)>$aradafark) && $gunlimit==0){?>
				<a href="javascript:;" onclick="kupon_iptal('<?=$row['id']; ?>');event.stopImmediatePropagation();">
					<img src="/img/sil.png" >
				</a>
			<?}else if($row['durum']=="1" && $row['canli']=="0" && $row['iptalzaman']=='' && $row['macbaslamismi']==0){?>
				<a href="javascript:;" onclick="kupon_iptal_bildir_div('<?=$row['id']; ?>');event.stopImmediatePropagation();">
					<img src="/img/sil.png" >
				</a>
			<? }
			echo $row['iptalzaman']; 
			if($row['durum']=="2" && $row['odendi']=="0") { ?>
			<a href="javascript:;" onClick="kupon_odendi('<?=$row['id']; ?>');event.stopImmediatePropagation();"><img src="/img/odendi.png"></a>
			<? }?>&nbsp;
			</td>
			</tr>
		<? } ?>
		</tbody>
		</table>
		
		<? } ?>
		<input type="hidden" id="footcontrol" value="<? if($yenihesap->toplam_kupon>$limit) { echo "1"; } else { echo "0"; } ?>">
		
	<?php 	$bak='';
	$sor->free_result();
	unset($sor,$yenihesap);		 
	}	
	
	public function kuponiptal(){		
		
		ajaxvarmi();
		if(iptal_yetki==0 && iptal_sure==0){die('1');}
		
		$id = (int)$this->input->post('id');
		$this->db->select('kupon_time,durum,id,canli,username,user_id,yatan');
		$row = $this->db->get_where('kuponlar', array('id' => $id))->row_array();
		
		$suan = time();
		$aradafark = $suan - $row['kupon_time'];		
		$ipadres = $_SERVER['REMOTE_ADDR'];
		
		if($row['durum']=="4") {die("2");}
		
		if(yetki ==4){
			$macbaslamismi = $this->db->query("select id from kupon_ic where kupon_id='$row[id]' and mac_time<'$suan'")->num_rows();
		
			$ver="select count(id) as say from kuponlar where user_id='".id."' and kupon_tarih='".date('d.m.Y')."' and durum=4";
			$gunsay = $this->db->query($ver)->row()->say;
			if($gunsay >= iptal_limit){die('3');}
			
			if( $aradafark>(iptal_sure*60) && $row['canli']=="0" && $macbaslamismi==0){die('3');}
					
		}
		
		if($row['web_id']) {
			$user_ekle = $row['web_id'];
		}else{
			$user_ekle = $row['user_id']; 
		}
		
		if(iptal_yetki==1) {
			
			if($row['durum']=='2'){
				$yenitutar=$row['oran'] * $row['yatan'];
				$kaztut=$yenitutar - $row['yatan'];
				hesap_hareket('cikar',$row['username'],$user_ekle,$kaztut,"".$row['id']." numaralı kupon düzenlemesi",$row['id']);
			}else{
				hesap_hareket('ekle',$row['username'],$user_ekle,$row['yatan'],"".$row['id']." numaralı kupon iptal iadesi",$row['id']);
			}
			
			$this->db->query("update kuponlar set durum='4',iptalzaman='".date('H:i:s d.m.Y')."' where id='$id'");
			
			$kuponLog=array();
			$don = $this->db->query("select * from kupon_ic where kupon_id='$row[id]'");
			foreach($don->result_array() as $rowic){
				$kuponLog['kuponici'][] = array(
					'durum' => durumnedir($rowic['kazanma']),
					'mac_kodu' => $rowic['mac_kodu'],
					'bayi' => $row['username'],
					'takimlar' => $rowic['ev_takim'].'-'.$rowic['konuk_takim'],
					'tahmin' => $rowic['oran_tip'],
					'oran' => $rowic['oran'],
					'spor_tip' => $rowic['spor_tip'],
					'canli_bilgi' => $rowic['canli_info']
				);
			}
			
			$this->db->query("update kupon_ic set kazanma='4' where kupon_id='$id'");
			
			$kuponLog['kupon'] = array(
				'durum' => $row['id']." no'lu Kupon İptal Edilmiştir"
			);
			$kuponLog = serialize($kuponLog);
			loglama($kuponLog, "Kupon İptal",$row['id']);
			$kupic=$this->db->escape_str($kuponLog);
			unset($kuponLog);
			$kay="insert into iptal_listesi (kupon_id,iptal_zaman,iptal_user_id,iptal_username,iptal_ip,kupon_user_id,ic) values
			('$row[id]','$suan','".id."','".username."','$ipadres','$user_ekle','$kupic')";
			$this->db->query($kay);
		}
	}
	
	public function kuponiptalbildirim(){		
		
		ajaxvarmi();
		$id = (int)$this->input->post('id');
		$iptmsg = $this->input->post('iptmsg');
		$varmi = $this->db->query("select id from iptaltalep where kuponid='$id'")->num_rows();
		if($varmi>0){die('1');}
		$this->db->query("insert into iptaltalep (kuponid,bayiid,ustid,mesaj,okundu) values
		('$id','".id."','".kendi."','".$iptmsg."','0')");
	}
	
	public function talepmesaj(){
		
		ajaxvarmi();
		if(yetki==3){
			$responce=array();
			$responce['iptalvar'] = 0;
			$sqlyaz="select * from iptaltalep where ustid=".id." and okundu=0";
			$sql = $this->db->query($sqlyaz);
			if($sql->num_rows() >0){
				//$row=$sql->row();
				$responce['iptalvar'] = 1;
				$sonuc = $this->db->update('iptaltalep', array('okundu' =>1), array('ustid' =>id));
			}
			echo json_encode($responce);
		}
	}
	
	public function kuponyazdir(){
		
		$id = (int)$this->input->get('kupid');
		$this->db->select('kupon_time,id,yatan,bonus,tutar,oran');
		$kb = $this->db->get_where('kuponlar', array('id' => $id))->row();
		
		$this->smarty->assign('kb',$kb);
	
		$sor = $this->db->order_by('mac_kodu', 'ASC')->get_where('kupon_ic', array('kupon_id' => $id));
		$this->smarty->assign('liste',$sor->result());
		//echo 'yazdir'.yazici.'.tpl';
		$this->smarty->view('yazdir'.yazici.'.tpl');
	}
	
	public function kupond(){
		
		ajaxvarmi();
		$id = (int)$this->input->post('id');
		$this->db->select('toplam_mac,kupon_time,kesinti,durum,id,canli,username,user_id,yatan,ipadres,bonus,tutar,oran');
		$kb = $this->db->get_where('kuponlar', array('id' => $id))->row_array();
		
	?>
<div style="left: 0px; right: 0px; z-index: 100; position: fixed; top: 0px;" class="appheader" onclick="macdkapat()"><div>  <div class="header"><div class="text title noselect" onclick="macdkapat()">Kapat </div><div  style="padding-left:20px" class="icon logo noselect"></div></div></div></div>

	<div class="kuponlar" style="margin-top:48px;">
	<ul >
	<li class="h">Zaman</li>
	<li class="h">Müsabaka</li>
	<li class="h">Seçim</li>
	<li class="h">Oran</li>
	<li class="h">İY/MS</li>
	<li class="h">Durum</li>
	</ul>
	
	<?
	
	$sor = $this->db->order_by('mac_kodu', 'ASC')->get_where('kupon_ic', array('kupon_id' => $id));

	foreach($sor->result_array() as $row){
		
	$ob = explode("|",$row['oran_tip']);
	if($row['spor_tip']=="canli") {
		
		$infobol = explode("|",$row['canli_info']);
		$zaman = "$infobol[0] <strong>($infobol[1])</strong>";
		$fark = time()-180;
		$canlibilgi = $this->db->query("select iy_ev,iy_konuk,ev_skor,konuk_skor,songuncelleme,devremi,dakika from canli_maclar where id='$row[mac_db_id]' and songuncelleme>$fark ");
		
		if($canlibilgi->num_rows()>0) {
			
			$bilgisi = $canlibilgi->row_array();	
			$iy = "$bilgisi[iy_ev]-$bilgisi[iy_konuk]*";
			$ms = "$bilgisi[ev_skor]-$bilgisi[konuk_skor]*";
			$farki = time()-60;
			if($bilgisi['songuncelleme'] < $farki) {
				$macsonucu = "Sonuç bekleniyor"; 
			} else if($bilgisi['devremi']=="1") {
				$macsonucu = "Devrede"; 
			} else{
				$macsonucu = "Devam Ediyor <strong>($bilgisi[dakika].dk)</strong>";
			}
		} else {
			$iy = $row['iy'];
			$ms = $row['ms'];
			$macsonucu = "Sona Erdi";
		}
	} else {
		if($row['mac_time']<time()) { 
			$macsonucu = "Başladı <strong>(".date("H:i",$row['mac_time']).")</strong>"; 
		} else if($row['ertelendi']=="2") {
			$macsonucu = "<strong>Ertelendi</strong>"; 	
		} else {
			$macsonucu = "Başlamadı <strong>".date("d.m H:i",$row['mac_time'])."</strong>"; 
		}
		
		$zaman = date("d.m H:i",$row['mac_time']);	
		$iy = $row['iy'];
		$ms = $row['ms'];
	}
	if($row['kazanma']!="1") { $macsonucu = "Sonuçlandı"; }
	if($iy=="") { $iy= "-"; }
	if($ms=="") { $ms= "-"; }
	$tahmin=$ob[0];
	$tercih=$ob[1];
	?>
	<ul class="kdurum_<?=$row['kazanma'];?>" >
	<li><?=$zaman;?></li>
	<li><?=$row['ev_takim']; ?><br><?=$row['konuk_takim']; ?></li>
	<li><?=$tahmin;?> <?
	if(strstr($tahmin,"Sıradaki Gol") && $tercih=='Gol Olmaz'){
		$skorver=' ('.str_replace(':','-',$infobol[0]).')';
		echo$tercih=$tercih.$skorver;
	}else{
		echo$tercih;
	}
	?> <? if(!empty($row['oran_val'])) { 
			if($row['spor_tip']=='basketbol'){echo "($row[oran_val])";}else{echo "$row[oran_val]";}
	}?></li>
	<li><strong><? $oranes = nf($row['oran']); echo $oranes; ?></strong></li>
	<li><?=$iy;?><br><?=$ms;?></li>
	<li><?=durumnedir($row['kazanma']); ?></li>
	</ul>
	<? } ?>
	</div>
	
	<div class="kuponalt kdurum_<?=$kb['durum'];?>">
	<ul >
	<li><strong>Kupon Tarihi</strong></li>
	<li><strong><?=date("d.m.Y H:i:s",$kb['kupon_time']); ?></strong></li>
	</ul>
	<ul >
	<li><strong>Kupon Numarası</strong></li>
	<li><strong><?=$kb['id']; ?></strong></li>
	</ul>
	<ul>
	<li><strong>Durum</strong></li>
	<li><strong><?=durumnedir($kb['durum']); ?></strong></li>
	</ul>
	<ul>
	<li><strong>Toplam Maç</strong></li>
	<li><?=$kb['toplam_mac']; ?></li>
	</ul>
	<ul>
	<li><strong>Toplam Oran</strong></li>
	<li><?=nf($kb['oran']); ?></li>
	</ul>
	<ul>
	<li><strong>Yatırılan Tutar</strong></li>
	<li><?=nf($kb['yatan']); ?></li>
	</ul>
	<ul>
	<li><strong>Bonus</strong></li>
	<li><?=nf($kb['bonus']); ?></li>
	</ul>
	<ul>
	<li><strong>Komisyon</strong></li>
	<li><?=nf($kb['kesinti']); ?></li>
	</ul><ul>
	<li><strong>Muhtemel Kazanç</strong></li>
	<li><?=nf(($kb['tutar']+$kb['bonus'])-$kb['kesinti']); ?></li>
	</ul>
	</div>
	
	<? $sor->free_result();
	unset($sor);
	}
		
	public function kuponodendi(){
		
		ajaxvarmi();
		$id = $this->input->post('id');
		$this->db->select('id');
		$row = $this->db->get_where('kuponlar', array('id' => $id))->num_rows();
		if($row >0){
			$this->db->update('kuponlar', array('odendi' => '1'), array('id' =>$id));
		}
		
	}
	
	
}