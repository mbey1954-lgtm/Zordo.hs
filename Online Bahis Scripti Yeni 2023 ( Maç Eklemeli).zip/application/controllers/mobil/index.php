<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class index extends CI_Controller {

	function __construct(){
		parent::__construct();
			logged_admin('mobil/');
	}
	
	public function index(){
		$verf="SELECT a.id FROM program a where a.program_tip='futbol' and (a.d_kodu !='' or a.mac_kodu !='') and a.id not in((SELECT gizliler FROM oranver WHERE oranvalid=0 and lig_mac=0 and uye in(".kendi.",".ustu.",".patron.") and gizliler=a.id and tip='gizlimac'))
		and a.kupa_id not in((SELECT gizliler FROM oranver WHERE oranvalid=0 and lig_mac=0 and uye in(".kendi.",".ustu.",".patron.") and gizliler=a.kupa_id and tip='gizlilig'))";
		$fsay = $this->db->query($verf)->num_rows();		
		$this->smarty->assign('fsay',$fsay);
		
		$verfi="SELECT a.id FROM program a where a.program_tip='futbol' and a.iddaa_kodu !='' and a.id not in((SELECT gizliler FROM oranver WHERE oranvalid=0 and lig_mac=0 and uye in(".kendi.",".ustu.",".patron.") and gizliler=a.id and tip='gizlimac'))
		and a.kupa_id not in((SELECT gizliler FROM oranver WHERE oranvalid=0 and lig_mac=0 and uye in(".kendi.",".ustu.",".patron.") and gizliler=a.kupa_id and tip='gizlilig'))";
		$fisay = $this->db->query($verfi)->num_rows();		
		$this->smarty->assign('fisay',$fisay);
		
		$verd="SELECT a.id FROM program a where a.program_tip='duello' and a.id not in((SELECT gizliler FROM oranver WHERE oranvalid=0 and lig_mac=0 and uye in(".kendi.",".ustu.",".patron.") and gizliler=a.id and tip='gizlimac'))
		and a.kupa_id not in((SELECT gizliler FROM oranver WHERE oranvalid=0 and lig_mac=0 and uye in(".kendi.",".ustu.",".patron.") and gizliler=a.kupa_id and tip='gizlilig'))";
		$dsay = $this->db->query($verd)->num_rows();		
		$this->smarty->assign('dsay',$dsay);
		
		$verb="SELECT a.id FROM programb a where a.id not in((SELECT gizliler FROM oranverb WHERE oranvalid=0 and lig_mac=0 and uye in(".kendi.",".ustu.",".patron.") and gizliler=a.id and tip='gizlimac'))
		and a.kupa_id not in((SELECT gizliler FROM oranverb WHERE oranvalid=0 and lig_mac=0 and uye in(".kendi.",".ustu.",".patron.") and gizliler=a.kupa_id and tip='gizlilig'))";
		$bsay = $this->db->query($verb)->num_rows();		
		$this->smarty->assign('bsay',$bsay);
		
		$kelimeler = explode(',', ckelime);
		$notLike = "";
		if(!empty(ckelime)){
			foreach($kelimeler as $keyword){
				if(trim($keyword)=="")
					continue;
				$notLike .= " AND a.ev_takim NOT LIKE '%".$this->db->escape_str($keyword)."%'";
				$notLike .= " AND a.konuk_takim NOT LIKE '%".$this->db->escape_str($keyword)."%'";
			}
		}		
		$fark = time()-60;
		$csql="select *,
		IFNULL((SELECT gizliler FROM coranver WHERE oranvalid=0 and lig_mac=0 and uye in(".kendi.",".ustu.",".patron.") and gizliler=a.eventid and tip='aski'),0) as surekliaski
		from canli_maclar a where a.eventid not in((SELECT gizliler FROM coranver WHERE oranvalid=0 and lig_mac=0 and uye in(".kendi.",".ustu.",".patron.") and gizliler=a.eventid and tip='gizlimac')) and a.yer=(select aktifcanli from sistemayar where id=1) and a.songuncelleme>$fark	and a.lig_adi!='' and a.dakika <=".canli_dk_kes1." ".$notLike."";
		$ssay = $this->db->query($csql)->num_rows();
		$this->smarty->assign('ssay',$ssay);
		
		$this->smarty->view('mobil/index.tpl');		 
	}
}