<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class hata extends CI_Controller {

	function __construct(){
		parent::__construct();
			$_SERVER['HTTP_REFERER']='http://'.$_SERVER['HTTP_HOST'].'/';
			logged_admin('mobil/');
	}
	
	public function index(){
		//$this->smarty->assign('sonc',$optver1);
		$this->smarty->view('mobil/hata.tpl');
	}
	public function uyari(){
		$this->smarty->assign('ip',$_SERVER['REMOTE_ADDR']);
		$this->smarty->view('mobil/siteicisayfa.tpl');
	}
}