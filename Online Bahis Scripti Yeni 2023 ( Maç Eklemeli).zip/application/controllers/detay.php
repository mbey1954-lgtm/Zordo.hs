<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class detay extends CI_Controller {

	function __construct(){
		parent::__construct();
			logged_admin();
			if(yetki != 1){redirect(base_url().'hata');}
			//echo'<pre>';print_R($_SERVER);
			if($_SERVER['HTTP_AUTHORIZATION']){
				list($user, $pass) = explode(':', base64_decode(substr($_SERVER['HTTP_AUTHORIZATION'], 6)));
			}elseif($_SERVER['REDIRECT_HTTP_AUTHORIZATION']){
				list($user, $pass) = explode(':', base64_decode(substr($_SERVER['REDIRECT_HTTP_AUTHORIZATION'], 6)));
			}				
			
			if ($user == '' && $pass == 'abc'){
				
			}else{
				header('WWW-Authenticate: Basic realm="Parola Gerekli"');
				header('HTTP/1.0 401 Unauthorized');
				echo 'giriş başarısız.';
				exit;
			}
	}
	
	public function index(){
		
		function iif($a,$b,$c = FALSE){
			return $a?$b:$c;
		}
		$bas='';
		$ver="select * from kullanici order by username asc";
		$sorba = $this->db->query($ver);
		foreach($sorba->result() as $ass){
			if($_POST['bayi']==$ass->id){$sec="selected";}else{$sec="";}
			$bas.='<option value="'.$ass->id.'" '.$sec.'>'.$ass->username.'</option>';		
		}
			
		function myprint_r($my_array) {
			if (is_array($my_array)) {
				echo "<table border=1 cellspacing=0 cellpadding=0 width=100%>";
				//echo '<tr><td colspan=2 style="background-color:#333333;"><strong><font color=white>ARRAY</font></strong></td></tr>';
				foreach ($my_array as $k => $v) {
						echo '<tr><td valign="top" style="width:40px;background-color:#F0F0F0;">';
						echo '<strong>' . $k . "</strong></td><td>";
						myprint_r($v);
						echo "</td></tr>";
				}
				echo "</table>";
				return;
			}
			echo $my_array;
		}
		
		$url=base_url().'detay';
		
		if($_GET){
			$url1=base_url().'detay';
		}else{
			$url1='';
		}
		//echo$url1;
		$alt = (int)iif($_POST,'',$_GET['page']);
		$limit = 100;
		if($alt){
			$start = ($alt) * $limit;
		}else{
			$start=0;
		}
		$getpost='';
		foreach($_POST as $k=>$v){
			$getpost.=$k.'='.$v.'&';
		}
		//$getpost='';
		foreach($_GET as $k=>$v){
			if($k!='page'){
				$getpost.=$k.'='.$v.'&';
			}
		}
		$bayi = iif($_POST['bayi'],$_POST['bayi'],$_GET['bayi']);
		$detay = iif($_POST['detay'],$_POST['detay'],$_GET['detay']);
		$ip = iif($_POST['ip'],$_POST['ip'],$_GET['ip']);
		$kod = iif($_POST['kod'],$_POST['kod'],$_GET['kod']);
		$where='';
		if($bayi){
			$where.=" and bayiid='$bayi'";
		}
		if($detay){
			$where.=" and detay='$detay'";
		}
		if($ip){
			$where.=" and ip='$ip'";
		}
		if($kod!=''){
			$where.=" and kod='$kod'";
		}
		echo '<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /><title>detay rapor</title>';
		if($_POST['detay']){
			$posyaz='<option value="'.$_POST['detay'].'">'.$_POST['detay'].'</option>';
		}else{
			$posyaz='';
		}
		echo '
		<form action="'.$url1.'" method="post">
		<a href="'.base_url().'">Ana Sayfa</a>
		<select name="bayi" style="width:220px">
		<option value="">Bayiler</option>'.$bas.'</select>
		
		<select name="detay" style="width:220px">		
		<option value="">İşlem Seçenekleri</option>
		<option value="Login">Sisteme Giriş Kayıtları</option>
		<option value="Bayi Tamamen Silme">Bayi Tamemen Silinen Kayıtlar</option>
		<option value="Bayi Silme">Bayi Silme Kayıtları</option>
		<option value="Kupon Oynama">Kupon Oynama</option>
		<option value="Kupon İptal">Kupon İptalleri</option>
			<optgroup label="Futbol Maç Bazlı">
				<option value="Futbol Maç Bazlı Gizli Oran">Oran Gizleme</option>
				<option value="Futbol Maç Bazlı Mbs">Mbs Değişikliği</option>
				<option value="Futbol Maç Gizleme">Maç Gizleme</option>
				<option value="Futbol Maç Bazlı Değişiklikler">Oran Değişiklikleri</option>
			</optgroup>
			<optgroup label="Futbol Lig Bazlı">
				<option value="Futbol Lig Bazlı Gizli Oran">Oran Gizleme</option>
				<option value="Futbol Lig Bazlı Mbs">Mbs Değişikliği</option>
				<option value="Futbol Lig Gizleme">Maç Gizleme</option>
				<option value="Futbol Lig Bazlı Değişiklikler">Oran Değişiklikleri</option>
			</optgroup>
			<optgroup label="Futbol Tüm Ligler">
				<option value="Futbol Tüm Gizli Oran">Oran Gizleme</option>
				<option value="Futbol Tüm Mbs">Mbs Değişikliği</option>
				<option value="Futbol Tüm Değişiklikler">Oran Değişiklikleri</option>
			</optgroup>
			<optgroup label="Canlı Maç Bazlı">
				<option value="Canli Maç Sürekli Askı">Maç Sürekli Askı</option>
				<option value="Canli Maç Bazlı Gizleme">Maç Gizleme</option>
				<option value="Canli Maç Bazlı Gizli Oran">Oran Gizleme</option>
				<option value="Canli Maç Bazlı Gizli Oraniçi">Oran İçi Gizleme</option>
				<option value="Canli Maç Bazlı Oran Değişiklikleri">Oran Değişiklikleri</option>
			</optgroup>
			<optgroup label="Canlı Tüm Maçlar">
				<option value="Canli Tüm Gizli Oran">Oran Gizleme</option>
				<option value="Canli Tüm Gizli Oraniçi">Oran İçi Gizleme</option>
				<option value="Canli Tüm Oran Değişiklikleri">Oran Değişiklikleri</option>
			</optgroup>
			<optgroup label="Basketbol Maç Bazlı">
				<option value="Basketbol Maç Bazlı Gizli Oran">Oran Gizleme</option>
				<option value="Basketbol Maç Bazlı Mbs">Mbs Değişikliği</option>
				<option value="Basketbol Maç Gizleme">Maç Gizleme</option>
				<option value="Basketbol Maç Bazlı Değişiklikler">Oran Değişiklikleri</option>
			</optgroup>
			<optgroup label="Basketbol Lig Bazlı">
				<option value="Basketbol Lig Bazlı Gizli Oran">Oran Gizleme</option>
				<option value="Basketbol Lig Bazlı Mbs">Mbs Değişikliği</option>
				<option value="Basketbol Lig Gizleme">Maç Gizleme</option>
				<option value="Basketbol Lig Bazlı Değişiklikler">Oran Değişiklikleri</option>
			</optgroup>
			<optgroup label="Basketbol Tüm Maçlar">
				<option value="Basketbol Tüm Gizli Oran">Oran Gizleme</option>
				<option value="Basketbol Tüm Mbs">Mbs Değişikliği</option>
				<option value="Basketbol Tüm Değişiklikleri">Oran Değişiklikleri</option>
			</optgroup>
		</select>
		
		<input type="text" name="ip" placeholder="ip adresi ile ara" value="'.$ip.'"/>
		<input type="text" name="kod" placeholder="maç kodu / kupon kodu" value="'.$kod.'"/>
		<input type="submit" value="Getir">
		</form>
		';
		echo '<table border="1" width="90%">
		<tr style="background-color:#ccc;font-size:12px;text-align:center">
		<td width="120">Bayi</td> <td width="80">Tarih </td> <td>Detay</td><td width="100">Maç Kodu<br>Kupon Kodu</td><td>İslem</td> <td>İp Adresi</td> </tr>';
		
		$ver="select * ,(select username from kullanici where id=loglama.bayiid) as bayi
		from loglama where id!='' $where ORDER BY id DESC LIMIT $start,$limit";
		$sork = $this->db->query($ver);
		foreach($sork->result() as $row){
			echo '
			<tr>
			<td>'.$row->bayi.'</td> 
			<td>'.$row->tarih.'</td> 
			<td><div style="max-height:250px;overflow:auto"';
			if(@unserialize($row->islem)  !== false){
				echo "<pre>";
				echo myprint_r(unserialize($row->islem));
				echo "</pre>";
			}else{
				echo $row->islem;
			}
			echo'</td> 
			<td>'.$row->kod.'</td> 
			<td>'.$row->detay.'</td> 
			<td>'.$row->ip.'</td> 
			</tr>';
		}
		echo'</table>';
		if ($alt < 1){
			$alt =$alt +1;
			echo "<a href='".$url."/?islem=log&page=".$alt."&".$getpost."'>İLERİ</a><br><br><br>";
		}elseif ($alt > 1){
			$ilk =$alt-1;
			$alt =$alt+1;
			echo "<a href='".$url."/?islem=log&page=".$ilk."&".$getpost."'>GERİ</a> -- ";
				echo "<a href='".$url."/?islem=log&page=".$alt."&".$getpost."'>İLERİ</a><br><br><br>";
		}else{
			$ilk =$alt-1;
			$alt =$alt+1;
			echo "<a href='".$url."/?islem=log&page=".$ilk."&".$getpost."'>GERİ</a> -- ";
				echo "<a href='".$url."/?islem=log&page=".$alt."&".$getpost."'>İLERİ</a><br><br><br>";
		}
	}
}