<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class info extends CI_Controller {

	function __construct(){
		parent::__construct();
			logged_admin();
	}
	
	public function bahiskurallari(){
		$sqlyaz="select * from kurallar ";
		$sql = $this->db->query($sqlyaz)->row()->kural;
		
		$this->smarty->assign('liste',nl2br($sql));
		$this->smarty->view('kurallar.tpl');
	}
	
	public function sifrehatirlat($nereye){
		
		$nereye='info/sifremi_unuttum';
		
		//echo$nereye;exit;
		$email = $this->input->post('email');
		if(strstr($email,'@')){
			$buldum=$this->db->query('SELECT ayarlar,username,password FROM `kullanici` WHERE yetki=4 and ayarlar REGEXP \'.*"email";s:[0-9]+:"'.$email.'".*\'');
			if($buldum->num_rows>0){
				
				$row = $buldum->row();
				$ayrv=unserialize($row->ayarlar);
				$eposta = trim($ayrv['email']);
				
				$headers  = 'MIME-Version: 1.0' . "\r\n";
				$headers .= 'Content-type: text/html; charset=utf-8' . "\r\n";
				$headers .= 'From: Yollayan <xfirarx@hotmail.com>' . "\r\n";
				$headers .= 'Reply-To: Yanit <xfirarx@hotmail.com>' . "\r\n";
				$headers .= 'X-Mailer: PHP/' . phpversion() . "\r\n";				 
				
				$konu = 'EuroBetFull Şifre Hatırlatma Servisi';
				$mesaj = 'Kullanıcı Adınız : '.$row->username.'<br>Şifreniz : '.$row->password.'<br><a href="http://www.'.domainver(1,domain).'">Sisteme giriş yapmak için tıklayınız.</a><br><br>İyi çalışmalar dileriz.';
				$okmu=mail($eposta, $konu, $mesaj, $headers);
				if($okmu){
					
					$this->session->set_flashdata('sifhata', 'Şifreniz E-Mail Adresinize Gönderildi..');
					redirect(base_url($nereye));
				}else{
					$this->session->set_flashdata('sifhata', 'HATA Oluştu yeniden deneyiniz..');
					redirect(base_url($nereye));
				}
			}else{
				$this->session->set_flashdata('sifhata', 'E-Mail Adresi Bulunamadı');
				redirect(base_url($nereye));
			}
		}else{
			$this->session->set_flashdata('sifhata', 'E-Mail Adresi Hatalı..');
			redirect(base_url($nereye));
		}
		
	}	
	
	public function banka_hesap(){
		//if(yetki != 4){redirect(base_url().'hata');}
		$ouser = $this->db->query("select * from bankalar where admin=".kendi." ");
		$this->smarty->assign('liste', $ouser->result());
		$this->smarty->view('banka_hesap.tpl');
	}
	
	public function sifremi_unuttum(){
		$this->smarty->assign('yok', $this->session->flashdata('sifhata'));
		$this->smarty->view('sifremi_unuttum.tpl');
	}
	public function hakkimizda(){
		$this->smarty->view('hakkimizda.tpl');
	}
	public function yardim(){
		$this->smarty->view('yardim.tpl');
	}
	public function gizlilik(){
		$this->smarty->view('gizlilik.tpl');
	}
	public function sozluk(){
		$this->smarty->view('sozluk.tpl');
	}
}