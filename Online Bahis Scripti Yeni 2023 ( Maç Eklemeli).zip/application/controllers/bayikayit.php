<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class bayikayit extends CI_Controller {

	function __construct(){
		parent::__construct();
			logged_admin();
			if((yetki == 4 && wyetki==0) || yetki ==5){redirect(base_url().'hata');}
	}
	
	public function index(){
		
		if(yetki == 2 || yetki == 3 || (yetki == 4 && wyetki==1)){
			$hakdurum=0;
			$toplam_kullanici = $this->db->query("select hesap_sahibi_id from kullanici where hesap_sahibi_id='".id."' and durum='1'")->num_rows;
			$acabildigi = alt_sinir;
			if($toplam_kullanici>=$acabildigi) {
				$hakdurum=$acabildigi;
			}
			$this->smarty->assign('hakkac',$hakdurum);
		}
		$bas=$bas1='';
		for($i=1; $i<46; $i++) {
			$bas.='<option value="'.$i.'"'; if($i==44) { $bas.= "selected"; }$bas.='>'.$i.'.dk</option>';
		}
		for($i=45; $i<96; $i++) {
			$bas1.='<option value="'.$i.'"'; if($i==88) { $bas1.= "selected"; }$bas1.='>'.$i.'.dk</option>';
		}
		$this->smarty->assign('bakiyehata', $this->session->flashdata('bakiyehata')); 
		$this->smarty->assign('cdk',$bas);
		$this->smarty->assign('cdk1',$bas1);
		$this->smarty->view('bayikayit.tpl');
		$bas=$bas1='';
	}
	
	public function edit(){
		
		$id = (int)$this->input->get('id');
		
		if(yetki != 5 && $id >0 ){//|| (yetki == 4 && wyetki==1)
			$sql = $this->db->get_where('kullanici', array('id' => $id,'durum' => '1'));
			if($sql->num_rows >0){
				if($sql->row()->hesap_sahibi_id != id){
					redirect(base_url().'hata');
				}
				$this->smarty->assign('yok',0);
				$this->smarty->assign('veri',$sql->row());
				$ayrv=unserialize($sql->row()->ayarlar);
				
				$this->smarty->assign('ayr',(object)$ayrv);
			}else{
				$this->smarty->assign('yok',1);
			}			
		}else{
			redirect(base_url().'hata');
		}
		$bas=$bas1='';
		for($i=1; $i<46; $i++) {
			$bas.='<option value="'.$i.'"'; if($i==$ayrv['canli_dk_kes']) { $bas.= "selected"; }$bas.='>'.$i.'.dk</option>';
		}
		for($i=45; $i<96; $i++) {
			$bas1.='<option value="'.$i.'"'; if($i==$ayrv['canli_dk_kes1']) { $bas1.= "selected"; }$bas1.='>'.$i.'.dk</option>';
		}
		$this->smarty->assign('cdk',$bas);
		$this->smarty->assign('cdk1',$bas1);
		$this->smarty->view('bayiedit.tpl');
		$bas=$bas1='';
	}
	
	public function editform(){		
		
		$id = (int)$this->input->post('userid');
		$this->db->select('ayarlar');
		$sql = $this->db->get_where('kullanici', array('id' => $id,'durum' => '1','hesap_sahibi_id' => id));
		if($sql->num_rows >0 && $id >0){		
		
		$ayrv=unserialize($sql->row()->ayarlar);		
		$olusver=$ayrv['olusturma_zaman'];
		
		foreach(array_keys($_POST) as $key){
			$ver[$key] = addslashes($_POST[$key]);//$ver[$key] = $this->input->post($key);
		}
		
		if(yetki==1){
			
			$domain='';
			foreach($_POST['domain'] as $site){
				$domain.=$site.'|';
				//echo'<pre>';print_R($site);
			}
			
			$domain=substr($domain,0,-1);
			
			$bayiAyar = array(
				"baskapat"=> baskapat,				
				"dukapat"=> dukapat,				
				"canlibahis"=> canlibahis,		
				"canlibahisb"=> canlibahisb,		
				"sistemikapat"=> sistemikapat,				
				"canli_kupon_sure"=> '3',				
				"canli_koruma"=> '0.00',				
				"sanalbahis"=> '1',
				"email"=> '',				
				"kesinti"=> '0',				
				"ckelime"=> '',				
				"kombine"=> '1',				
				"domain"=> $domain,				
				"yazici"=> 'normal',				
				"canli_dk_kes"=> 44,				
				"canli_dk_kes1"=> 90,				
				"calisma_sekli"=> 0,				
				"komisyon"=> 0,
				"ccalisma_sekli"=> 0,
				"ckomisyon"=> 0,
				"futbol"=> 1,
				"duello"=> 1,
				"bonus"=> 1,
				"basketbol"=> 1,
				"iptal_sure"=> 5,
				"iptal_limit"=> 10,
				"maxodeme"=> 15000,
				"aynikuponmax"=> 5000,
				"sabitmbs"=> 0,
				"maxmac"=> 15,
				"minmac"=> 1,
				"tekmacmax"=> 1000,
				"canli_tekmac"=> 1000,
				"min_oran"=> '1.50',
				"maxoran"=> 1000,
				"minkupon"=> 1,
				"maxkupon"=> 1000,
				"canli_sure"=> 15,
				"iptal_yetki"=> 1,
				"oranduzenleme"=> 1,
				"wyetki"=> 0,
				"alt_sinir"=> $ver['alt_sinir'] == '' ? '10' : $ver['alt_sinir'],
				"silme_yetki"=> 1,
				"olusturma_zaman"=> $olusver
			);
			if($ver['sifre']){
				$arrs = array("password" => $ver['sifre'],"firma" => $ver['firma'],"ayarlar" => serialize($bayiAyar));
			}else{
				$arrs = array("firma" => $ver['firma'],"ayarlar" => serialize($bayiAyar));
			}
			
			$sonuc = $this->db->update('kullanici', $arrs, array('id' =>$id));
			unset($bayiAyar);
			
			$ouser = $this->db->query("select ayarlar,id from kullanici where (hesap_root_root_id=$id or hesap_root_id=$id or hesap_sahibi_id=$id)");
			foreach($ouser->result() as $row){
				$ayrvk=unserialize($row->ayarlar);	
				$ayrvk['domain']=$domain;
				$this->db->query("update kullanici set ayarlar='".$this->db->escape_str(serialize($ayrvk))."' where id=".$row->id."");
			}
			//echo$this->db->last_query();exit;
		}else if(yetki==2){
			
			$domain='';
			foreach($_POST['domain'] as $site){
				$domain.=$site.'|';
			}			
			$domain=substr($domain,0,-1);
			$bayiAyar = array(
				"canli_kupon_sure"=> '3',
				"canli_koruma"=> '0.00',
				"baskapat"=> baskapat,				
				"dukapat"=> dukapat,				
				"canlibahis"=> canlibahis,		
				"canlibahisb"=> canlibahisb,		
				"sistemikapat"=> sistemikapat,
				"sanalbahis"=> '1',
				"yazici"=> 'normal',
				"kesinti"=> '0',
				"kombine"=> '1',
				"email"=> '',
				"ckelime"=> '',
				"canli_dk_kes"=> 44,				
				"canli_dk_kes1"=> 90,
				"calisma_sekli"=> 0,				
				"komisyon"=> 0,
				"ccalisma_sekli"=> 0,
				"ckomisyon"=> 0,
				"futbol"=> 1,
				"duello"=> 1,
				"bonus"=> 1,
				"basketbol"=> 1,
				"iptal_sure"=> 5,
				"iptal_limit"=> 10,
				"maxodeme"=> 15000,
				"aynikuponmax"=> 5000,
				"sabitmbs"=> 0,
				"maxmac"=> 15,
				"minmac"=> 1,
				"tekmacmax"=> 1000,
				"canli_tekmac"=> 1000,
				"min_oran"=> '1.50',
				"maxoran"=> 1000,
				"minkupon"=> 1,
				"maxkupon"=> 1000,
				"canli_sure"=> 15,
				"wyetki"=> 0,
				"domain"=> $domain,
				"kupon_degistirme"=> $ver['kupon_degistirme'] == '' ? '0' : $ver['kupon_degistirme'],
				"tema"=> $ver['tema'] ,
				"email_yetki"=> $ver['email_yetki'] == '' ? '' : $ver['email_yetki'],
				"iptal_yetki"=> $ver['iptal_yetki'] == '' ? '0' : $ver['iptal_yetki'],
				"oranduzenleme"=> $ver['oranduzenleme'] == '' ? '0' : $ver['oranduzenleme'],
				"alt_sinir"=> $ver['alt_sinir'] == '' ? '10' : $ver['alt_sinir'],
				"silme_yetki"=> $ver['silme_yetki'] == '' ? '0' : $ver['silme_yetki'],
				"olusturma_zaman"=> $olusver,
				"tel"=> $ver['tel'] == '' ? '0' : $ver['tel'],
			);
			
			if($ver['sifre']){
				$arrad = array("password" => $ver['sifre'],"firma" => $ver['firma'],"ayarlar" => serialize($bayiAyar));
			}else{
				$arrad = array("firma" => $ver['firma'],"ayarlar" => serialize($bayiAyar));
			}
			
			$sonuc = $this->db->update('kullanici', $arrad, array('id' =>$id));
			unset($bayiAyar);
			$ouser = $this->db->query("select ayarlar,id from kullanici where (hesap_root_root_id=$id or hesap_root_id=$id or hesap_sahibi_id=$id)");
			foreach($ouser->result() as $row){
				$ayrvk=unserialize($row->ayarlar);	
				$ayrvk['domain']=$domain;
				$ayrvk['tema']=$ver['tema'];
				$this->db->query("update kullanici set ayarlar='".$this->db->escape_str(serialize($ayrvk))."' where id=".$row->id."");
			}
		}else if(yetki==3){
			
			$bayiAyar = array(
				"tema"=> tema,				
				"baskapat"=> baskapat,				
				"dukapat"=> dukapat,	
				"sistemikapat"=> sistemikapat,
				"domain"=> domain,
				"ckelime"=> ckelime,
				"canli_kupon_sure"=> $ver['canli_kupon_sure'] == '' ? '3' : $ver['canli_kupon_sure'],
				"sanalbahis"=> $ver['sanalbahis'] == '' ? '1' : $ver['sanalbahis'],
				"kesinti"=> $ver['kesinti'] == '' ? '0' : $ver['kesinti'],
				"kombine"=> $ver['kombine'] == '' ? '1' : $ver['kombine'],
				"email"=> $ver['email'] == '' ? '' : $ver['email'],
				"yazici"=> $ver['yazici'] == '' ? 'normal' : $ver['yazici'],				
				"canli_dk_kes"=> $ver['canli_dk_kes'] == '' ? '44' : $ver['canli_dk_kes'],				
				"canli_dk_kes1"=> $ver['canli_dk_kes1'] == '' ? '88' : $ver['canli_dk_kes1'],				
				"kiralikmi"=> $ver['kiralikmi'] == '' ? '0' : $ver['kiralikmi'],				
				"hesapbaslangic"=> $ver['hesapbaslangic'] == '' ? '0' : $ver['hesapbaslangic'],				
				"hesapbitis"=> $ver['hesapbitis'] == '' ? '0' : $ver['hesapbitis'],				
				"hnot"=> $ver['hnot'] == '' ? '' : $ver['hnot'],
				"calisma_sekli"=> $ver['calisma_sekli'] == '' ? '0' : $ver['calisma_sekli'],				
				"komisyon"=> $ver['komisyon'] == '' ? '0' : $ver['komisyon'],
				"ccalisma_sekli"=> $ver['ccalisma_sekli'] == '' ? '0' : $ver['ccalisma_sekli'],
				"ckomisyon"=> $ver['ckomisyon'] == '' ? '0' : $ver['ckomisyon'],
				"canlibahis"=> $ver['canlibahis'] == '' ? '0' : $ver['canlibahis'],
				"canlibahisb"=> $ver['canlibahisb'] == '' ? '0' : $ver['canlibahisb'],
				"futbol"=> $ver['futbol'] == '' ? '0' : $ver['futbol'],
				"duello"=> $ver['duello'] == '' ? '0' : $ver['duello'],
				"basketbol"=> $ver['basketbol'] == '' ? '0' : $ver['basketbol'],
				"iptal_yetki"=> $ver['iptal_yetki'] == '' ? '0' : $ver['iptal_yetki'],
				"iptal_sure"=> $ver['iptal_sure'] == '' ? '0' : $ver['iptal_sure'],
				"iptal_limit"=> $ver['iptal_limit'] == '' ? '0' : $ver['iptal_limit'],
				"maxodeme"=> $ver['maxodeme'] == '' ? '15000' : $ver['maxodeme'],
				"aynikuponmax"=> $ver['aynikuponmax'] == '' ? '5000' : $ver['aynikuponmax'],
				"sabitmbs"=> $ver['sabitmbs'] == '' ? '0' : $ver['sabitmbs'],
				"maxmac"=> $ver['maxmac'] == '' ? '15' : $ver['maxmac'],
				"minmac"=> $ver['minmac'] == '' ? '1' : $ver['minmac'],
				"tekmacmax"=> $ver['tekmacmax'] == '' ? '1000' : $ver['tekmacmax'],
				"canli_tekmac"=> $ver['canli_tekmac'] == '' ? '1000' : $ver['canli_tekmac'],
				"min_oran"=> $ver['min_oran'] == '' ? '1.50' : $ver['min_oran'],
				"maxoran"=> $ver['maxoran'] == '' ? '1000' : $ver['maxoran'],
				"minkupon"=> $ver['minkupon'] == '' ? '1' : $ver['minkupon'],
				"maxkupon"=> $ver['maxkupon'] == '' ? '1000' : $ver['maxkupon'],
				"canli_sure"=> $ver['canli_sure'] == '' ? '15' : $ver['canli_sure'],
				"silme_yetki"=> $ver['silme_yetki'] == '' ? '0' : $ver['silme_yetki'],
				"alt_sinir"=> $ver['alt_sinir'] == '' ? '0' : $ver['alt_sinir'],
				"wyetki"=> $ver['wyetki'] == '' ? '0' : $ver['wyetki'],
				"canli_koruma"=> $ver['canli_koruma'] == '' ? '0.00' : $ver['canli_koruma'],
				"bonus"=> $ver['bonus'] == '' ? '0' : $ver['bonus'],
				"olusturma_zaman"=> $olusver,
				"sehir"=> $ver['sehir'] == '' ? '0' : $ver['sehir'],
				"adres"=> $ver['adres'] == '' ? '0' : $ver['adres'],
				"tc"=> $ver['tc'] == '' ? '0' : $ver['tc'],
				"cins"=> $ver['cins'] == '' ? '0' : $ver['cins'],
				"ad"=> $ver['ad'] == '' ? '0' : $ver['ad'],
				"dogum"=> $ver['dogum'] == '' ? '0' : $ver['dogum'],
				"pkod"=> $ver['pkod'] == '' ? '0' : $ver['pkod'],
				"ulke"=> $ver['ulke'] == '' ? '0' : $ver['ulke'],
				"para"=> $ver['para'] == '' ? '0' : $ver['para'],
				"tel"=> $ver['tel'] == '' ? '0' : $ver['tel'],
			);
			
			$arrab = array("password" => $ver['sifre'],"firma" => $ver['firma'],"ayarlar" => serialize($bayiAyar));
			$sonuc = $this->db->update('kullanici', $arrab, array('id' =>$id));
			
			unset($bayiAyar);
			
		}
		redirect(base_url()."bayiler");
		}else{
			redirect(base_url()."hata");
		}
	}
	
	public function kayit(){
		
		$ver=array();
		foreach(array_keys($_POST) as $key){
			$ver[$key] = addslashes($_POST[$key]);//$ver[$key] = $this->input->post($key);
		}
		
		if(count($ver) >0 ){
			
		if(yetki==1){
			$domain='';
			foreach($_POST['domain'] as $site){
				$domain.=$site.'|';
				//echo'<pre>';print_R($site);
			}
			
			$domain=substr($domain,0,-1);
			
			$bayiAyar = array(
				"canli_kupon_sure"=> '3',
				"canli_koruma"=> '0.00',
				"baskapat"=> baskapat,				
				"dukapat"=> dukapat,				
				"canlibahis"=> canlibahis,		
				"canlibahisb"=> canlibahisb,		
				"sistemikapat"=> sistemikapat,
				"email"=> '',
				"sanalbahis"=> '1',
				"kesinti"=> '0',
				"ckelime"=> '',
				"kombine"=> '1',
				"domain"=> $domain,
				"yazici"=> 'normal',	
				"canli_dk_kes"=> 44,				
				"canli_dk_kes1"=> 90,
				"calisma_sekli"=> 0,				
				"komisyon"=> 0,
				"ccalisma_sekli"=> 0,
				"ckomisyon"=> 0,
				"futbol"=> 1,
				"duello"=> 1,
				"bonus"=> 1,
				"basketbol"=> 1,
				"iptal_sure"=> 5,
				"iptal_limit"=> 10,
				"maxodeme"=> 15000,
				"aynikuponmax"=> 5000,
				"sabitmbs"=> 0,
				"maxmac"=> 15,
				"minmac"=> 1,
				"tekmacmax"=> 1000,
				"canli_tekmac"=> 1000,
				"min_oran"=> '1.50',
				"maxoran"=> 1000,
				"minkupon"=> 1,
				"maxkupon"=> 1000,
				"canli_sure"=> 15,
				"iptal_yetki"=> 1,
				"oranduzenleme"=> 1,
				"wyetki"=> 0,
				"alt_sinir"=> $ver['alt_sinir'] == '' ? '10' : $ver['alt_sinir'],
				"silme_yetki"=> 1,
				"olusturma_zaman"=> date('d.m.Y H:i:s')
			);
			$arrs = array("username" => $ver['user'],"firma" => $ver['firma'], "password" => $ver['sifre'],"hesap_sahibi_user" => username,"hesap_sahibi_id" => id,"hesap_root_id" => id,"tip" => 'Süper Admin','yetki'=>2,"ayarlar" => serialize($bayiAyar));
			//$_sonuc = $this->db->update('kullanici', $ver, array('id' =>sesionlar('id')));
			$this->db->insert('kullanici', $arrs); 
			unset($bayiAyar);
			
		}else if(yetki==2){
			$domain='';
			foreach($_POST['domain'] as $site){
				$domain.=$site.'|';
			}			
			$domain=substr($domain,0,-1);
			$bayiAyar = array(
				"canli_kupon_sure"=> '3',
				"canli_koruma"=> '0.00',
				"baskapat"=> baskapat,				
				"dukapat"=> dukapat,				
				"canlibahis"=> canlibahis,		
				"canlibahisb"=> canlibahisb,		
				"sistemikapat"=> sistemikapat,
				"sanalbahis"=> '1',
				"yazici"=> 'normal',
				"kesinti"=> '0',
				"kombine"=> '1',
				"email"=> '',
				"ckelime"=> '',
				"canli_dk_kes"=> 44,				
				"canli_dk_kes1"=> 90,				
				"calisma_sekli"=> 0,				
				"komisyon"=> 0,
				"ccalisma_sekli"=> 0,
				"ckomisyon"=> 0,
				"futbol"=> 1,
				"duello"=> 1,
				"bonus"=> 1,
				"basketbol"=> 1,
				"iptal_sure"=> 5,
				"iptal_limit"=> 10,
				"maxodeme"=> 15000,
				"aynikuponmax"=> 5000,
				"sabitmbs"=> 0,
				"maxmac"=> 15,
				"minmac"=> 1,
				"tekmacmax"=> 1000,
				"canli_tekmac"=> 1000,
				"min_oran"=> '1.50',
				"maxoran"=> 1000,
				"minkupon"=> 1,
				"maxkupon"=> 1000,
				"canli_sure"=> 15,
				"wyetki"=> 0,
				"domain"=> $domain,
				"kupon_degistirme"=> $ver['kupon_degistirme'] == '' ? '0' : $ver['kupon_degistirme'],
				"tema"=> $ver['tema'] ,
				"email_yetki"=> $ver['email_yetki'] == '' ? '' : $ver['email_yetki'],
				"iptal_yetki"=> $ver['iptal_yetki'] == '' ? '0' : $ver['iptal_yetki'],
				"oranduzenleme"=> $ver['oranduzenleme'] == '' ? '0' : $ver['oranduzenleme'],
				"alt_sinir"=> $ver['alt_sinir'] == '' ? '10' : $ver['alt_sinir'],
				"silme_yetki"=> $ver['silme_yetki'] == '' ? '0' : $ver['silme_yetki'],
				"tel"=> $ver['tel'] == '' ? '0' : $ver['tel'],
				"olusturma_zaman"=> date('d.m.Y H:i:s')
			);
			
			$arra = array("username" => $ver['user'],"firma" => $ver['firma'], "password" => $ver['sifre'],"hesap_sahibi_user" => username,"hesap_sahibi_id" => id,"hesap_root_id" => hesap_root_id,"tip" => 'Admin','yetki'=>3,"ayarlar" => serialize($bayiAyar));
			//$_sonuc = $this->db->update('kullanici', $ver, array('id' =>sesionlar('id')));
			$this->db->insert('kullanici', $arra);
			unset($bayiAyar);
			
		}else if(yetki==3){
			
			$bayiAyar = array(
				"tema"=> tema,				
				"baskapat"=> baskapat,				
				"dukapat"=> dukapat,			
				"sistemikapat"=> sistemikapat,
				"domain"=> domain,
				"ckelime"=> ckelime,
				"canli_kupon_sure"=> $ver['canli_kupon_sure'] == '' ? '3' : $ver['canli_kupon_sure'],
				"sanalbahis"=> $ver['sanalbahis'] == '' ? '1' : $ver['sanalbahis'],
				"kombine"=> $ver['kombine'] == '' ? '1' : $ver['kombine'],
				"kesinti"=> $ver['kesinti'] == '' ? '0' : $ver['kesinti'],
				"email"=> $ver['email'] == '' ? '' : $ver['email'],
				"yazici"=> $ver['yazici'] == '' ? 'normal' : $ver['yazici'],				
				"canli_dk_kes"=> $ver['canli_dk_kes'] == '' ? '44' : $ver['canli_dk_kes'],				
				"canli_dk_kes1"=> $ver['canli_dk_kes1'] == '' ? '88' : $ver['canli_dk_kes1'],	
				"kiralikmi"=> $ver['kiralikmi'] == '' ? '0' : $ver['kiralikmi'],				
				"hesapbaslangic"=> $ver['hesapbaslangic'] == '' ? '0' : $ver['hesapbaslangic'],				
				"hesapbitis"=> $ver['hesapbitis'] == '' ? '0' : $ver['hesapbitis'],				
				"hnot"=> $ver['hnot'] == '' ? '' : $ver['hnot'],				
				"calisma_sekli"=> $ver['calisma_sekli'] == '' ? '0' : $ver['calisma_sekli'],				
				"komisyon"=> $ver['komisyon'] == '' ? '0' : $ver['komisyon'],
				"ccalisma_sekli"=> $ver['ccalisma_sekli'] == '' ? '0' : $ver['ccalisma_sekli'],
				"ckomisyon"=> $ver['ckomisyon'] == '' ? '0' : $ver['ckomisyon'],
				"canlibahis"=> $ver['canlibahis'] == '' ? '0' : $ver['canlibahis'],
				"canlibahisb"=> $ver['canlibahisb'] == '' ? '0' : $ver['canlibahisb'],
				"futbol"=> $ver['futbol'] == '' ? '0' : $ver['futbol'],
				"duello"=> $ver['duello'] == '' ? '0' : $ver['duello'],
				"basketbol"=> $ver['basketbol'] == '' ? '0' : $ver['basketbol'],
				"iptal_yetki"=> $ver['iptal_yetki'] == '' ? '0' : $ver['iptal_yetki'],
				"iptal_sure"=> $ver['iptal_sure'] == '' ? '0' : $ver['iptal_sure'],
				"iptal_limit"=> $ver['iptal_limit'] == '' ? '0' : $ver['iptal_limit'],
				"maxodeme"=> $ver['maxodeme'] == '' ? '15000' : $ver['maxodeme'],
				"aynikuponmax"=> $ver['aynikuponmax'] == '' ? '5000' : $ver['aynikuponmax'],
				"sabitmbs"=> $ver['sabitmbs'] == '' ? '0' : $ver['sabitmbs'],
				"maxmac"=> $ver['maxmac'] == '' ? '15' : $ver['maxmac'],
				"minmac"=> $ver['minmac'] == '' ? '1' : $ver['minmac'],
				"tekmacmax"=> $ver['tekmacmax'] == '' ? '1000' : $ver['tekmacmax'],
				"canli_tekmac"=> $ver['canli_tekmac'] == '' ? '1000' : $ver['canli_tekmac'],
				"min_oran"=> $ver['min_oran'] == '' ? '1.50' : $ver['min_oran'],
				"maxoran"=> $ver['maxoran'] == '' ? '1000' : $ver['maxoran'],
				"minkupon"=> $ver['minkupon'] == '' ? '1' : $ver['minkupon'],
				"maxkupon"=> $ver['maxkupon'] == '' ? '1000' : $ver['maxkupon'],
				"canli_sure"=> $ver['canli_sure'] == '' ? '15' : $ver['canli_sure'],
				"silme_yetki"=> $ver['silme_yetki'] == '' ? '0' : $ver['silme_yetki'],
				"bonus"=> $ver['bonus'] == '' ? '0' : $ver['bonus'],
				"tel"=> $ver['tel'] == '' ? '0' : $ver['tel'],
				"canli_koruma"=> $ver['canli_koruma'] == '' ? '0.00' : $ver['canli_koruma'],
				"alt_sinir"=> $ver['alt_sinir'] == '' ? '0' : $ver['alt_sinir'],
				"sehir"=> $ver['sehir'] == '' ? '0' : $ver['sehir'],
				"adres"=> $ver['adres'] == '' ? '0' : $ver['adres'],
				"tc"=> $ver['tc'] == '' ? '0' : $ver['tc'],
				"cins"=> $ver['cins'] == '' ? '0' : $ver['cins'],
				"ad"=> $ver['ad'] == '' ? '0' : $ver['ad'],
				"dogum"=> $ver['dogum'] == '' ? '0' : $ver['dogum'],
				"pkod"=> $ver['pkod'] == '' ? '0' : $ver['pkod'],
				"ulke"=> $ver['ulke'] == '' ? '0' : $ver['ulke'],
				"para"=> $ver['para'] == '' ? '0' : $ver['para'],
				"wyetki"=> $ver['wyetki'] == '' ? '0' : $ver['wyetki'],
				"olusturma_zaman"=> date('d.m.Y H:i:s')
			);
			
			$arra = array("username" => $ver['user'],"firma" => $ver['firma'], "password" => $ver['sifre'],"hesap_sahibi_user" => username,"hesap_sahibi_id" => id,"hesap_root_id" => hesap_sahibi_id,"tip" => 'Bayi','yetki'=>4,"ayarlar" => serialize($bayiAyar));
			//$_sonuc = $this->db->update('kullanici', $ver, array('id' =>sesionlar('id')));
			$this->db->insert('kullanici', $arra);
			$kulid = $this->db->insert_id();
			if($ver['bakiye']>0){
				hesap_hareket('ekle',$ver['user'],$kulid,$ver['bakiye'],"ilk giriş bakiyesi.",0);
			}
			unset($bayiAyar);
			
		}
		redirect(base_url()."bayiler");
		}else{
			redirect(base_url()."hata");
		}
		
	}
	
}