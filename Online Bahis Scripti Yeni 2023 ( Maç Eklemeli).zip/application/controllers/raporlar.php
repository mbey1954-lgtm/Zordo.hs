<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class raporlar extends CI_Controller {

	function __construct(){
		parent::__construct();
			logged_admin();
	}
	
	public function index(){
		
		$bas='';
		$uyelerim='';
		
		if(yetki !=5) {
			$verme=1;	
			if(yetki ==2) {
				$uyelerim=' and (hesap_sahibi_id='.id.' or hesap_root_id='.id.' or hesap_root_root_id='.id.') and yetki !=5';//super
			}else if(yetki ==3) {
				$uyelerim=' and (hesap_sahibi_id='.id.' or hesap_root_id='.id.') and yetki !=5';//admin
			}else if(yetki ==4 && wyetki == 1) {
				$uyelerim=' and hesap_sahibi_id='.id;//bayi
			}else if(yetki ==1) {
				$uyelerim='';
			}else{
				$verme=0;
			}
			if($verme){
				$ver="select id,username,yetki from kullanici where id!=1 and durum=1 and yetki !=6 $uyelerim order by yetki,username asc";
				$sor = $this->db->query($ver);
				$set = array();
				foreach($sor->result() as $ass){
					$set[$ass->yetki][]= $ass;
				}
				$sor->free_result();
				foreach($set as $y=>$by){
					//$wyaz=0;
					if($y==2){$bas.='<optgroup label="'.lang('suadmler').'">';$tire='-s';}
					if($y==3){$bas.='<optgroup label="'.lang('admler').'">';$tire='-a';}
					if($y==4){$bas.='<optgroup label="'.lang('byler').'">';$tire='';}
					if($y==5){$bas.='<optgroup label="'.lang('webler').'">';$tire='-w';}
					foreach($by as $y1=>$v){
						$bas.='<option value="'.$v->id.$tire.'">'.$v->username.'</option>';
					}
					$bas.='</optgroup>';
				}
			}
			//echo'<pre>';print_R($bas);			
		}
		$this->smarty->assign('bayilist',$bas);		
		$this->smarty->view('raporlar.tpl');
		$bas=$uyelerim='';unset($set);
	}
	
	function komisyon_hesap($ayrv,$yatan,$kazanan,$tip) {
	
		//$ub = $this->db->query("select ayarlar from kullanici where id='$user'")->row_array();
		//$ayrv=unserialize(@$ub['ayarlar']);
		
		if($tip=="canli") {
			$komisyon = carpan($ayrv['ckomisyon']);
			$cs = $ayrv['ccalisma_sekli'];
		} else
		if($tip=="normal") {
			$komisyon = carpan($ayrv['komisyon']);
			$cs = $ayrv['calisma_sekli'];
		}
		$donen = "0";
		if($cs=="0") {
			$donen = "0";
		} else
		if($cs=="1") {
			$donen = $yatan*$komisyon;
		} else
		if($cs=="2") {
			$donen = ($yatan - $kazanan) * $komisyon;
		}
		return $donen;		
	}

	public function data(){
		
		ajaxvarmi();
		$tarih1 = basla_time($this->input->post("tarih1"));
		$tarih2 = bitir_time($this->input->post("tarih2"));
		$satir = $this->input->post("satir");
		$tip = $this->input->post("tip");		
		$userid = $this->input->post("userid");		
		
		if(!empty($satir)) {
		if($satir=="kombine") { $satir_ekle = "and a.toplam_mac>1"; } else
		if($satir==3) { $satir_ekle = "and a.toplam_mac>2"; } else
		if($satir==1 || $satir==2) { $satir_ekle = "and a.toplam_mac='$satir'"; }	
		} else {
		$satir_ekle = "";	
		}
		if(!empty($durum)) { $durum_ekle = "and a.durum='$durum'"; } else { $durum_ekle = ""; }

		if($tip==2) {
			$tip_ekle = "and a.canli='1'"; 
		} else if($tip==1) {
			$tip_ekle = "and a.canli='0'";
		}else{			
			$tip_ekle = "";
		}
		
		$teklibayi = 0;
		$user_ekle='';
		if(!empty($userid) && is_numeric($userid)) {
			$user_ekle = " a.user_id='$userid'"; 
		}else if(!empty($userid) && strstr($userid,"-a")){
			$userid=str_replace('-a','',$userid);
			$user_ekle = " a.adm_id='$userid'"; 
		}else if(!empty($userid) && strstr($userid,"-s")){
			$userid=str_replace('-s','',$userid);
			$user_ekle = " a.sup_id='$userid'"; 
		}else if(!empty($userid) && strstr($userid,"-w")){
			$userid=str_replace('-w','',$userid);
			$user_ekle = " a.web_id='$userid'"; 
		}
		
		$webusugizle=0;
		$group='';
		$wbuseluisim="user_id";
		
		if(yetki == 1) {
			$webusugizle=1;
			$user_ekleu = " a.id!=''";
		}else if(yetki == 2) {
			$webusugizle=1;
			$user_ekleu = " a.sup_id='".id."'";
		}else if(yetki == 3) {
			$webusugizle=1;
			$user_ekleu = " a.adm_id='".id."' ";
		}else if(yetki == 4) {
			if(wyetki == 1) {
				$user_ekleu = "  a.user_id='".id."' ";
				$group=',a.web_id';
			}else{
				$user_ekleu = " a.user_id='".id."'";
			}
			$teklibayi = 1;
		}else if(yetki == 5) {
			$user_ekleu = " a.web_id='".id."'";
			$teklibayi = 1;
		}
		
		if($user_ekle){
			$user_ekleu = "";
		}
		
		$sqladderf = " and a.kupon_time between '$tarih1' and '$tarih2' $tip_ekle $satir_ekle and a.hesap_kesim_zaman=''";
		
		$yaz="select SUM(IF(a.durum = 2, a.bonus, 0)) as bonuslar,a.web_id,a.username,a.user_id,a.canli,k.ayarlar,k.id as uyid,k.firma,w.hesap_sahibi_user as badi
		from kuponlar a 
		left join kullanici k on k.id=a.user_id
		left join kullanici w on w.id=a.web_id
		where $user_ekleu $user_ekle $sqladderf group by a.user_id $group order by k.firma asc";
		$responce = array();
		$sor = $this->db->query($yaz);
		
		$responce['govde'] = '';
		$responce['msg'] = '';
		
		if($sor->num_rows() <1) { 
			$responce['govde'].= '<div class="bos">'.lang('bos').'</div>';
			$responce['msg'].= '';
			echo json_encode($responce);
			exit;
		}

		$responce['govde'].= '
		<table style="width:100%" class="tftable" cellspacing="0" cellpadding="0">
		<thead>
		<tr >
		<th>'.lang('firma').'</li>
		<th>'.lang('byler').'</li>
		<th >'.lang('ytrlan').'</li>
		<th >'.lang('kaz').'</li>
		<th >'.lang('kay').'</li>
		<th >'.lang('bacik').'</li>
		<th >'.lang('ipt').'</li>
		<th>'.lang('komskl').'</li>
		<th >'.lang('kom').'</li>
		<th >'.lang('snclar').'</li>
		<th >'.lang('netkaz').'</li>
		</tr></thead><tbody>';
		
		$top_iptal=$top_devam=$top_kaybeden=$top_odenen=$top_kazanan_adet=$top_kaybeden_adet=$top_devam_adet=$top_iptal_adet=$top_odenen_adet=$toplam_komisyon=$top_kazanan=$calist=$tipt=0;
		
		foreach($sor->result_array() as $row){ 

		$ayrv=unserialize($row['ayarlar']);
		
		if($webusugizle){
			if($row['web_id']){
				$usyaz=$row['badi'];
			}else{
				$usyaz=$row['username'];
			}
			$wbuselu="a.user_id='$row[user_id]'";
		}else{
			$usyaz=$row['username'];
			if($row['web_id']){
			$wbuselu="a.web_id='$row[web_id]'";
			}else{
				$wbuselu="a.user_id='$row[user_id]' and a.web_id=0";
			}
		}
		$toplam_odenen = $this->db->query("select SUM(a.yatan) as toplam ,
		count(a.id) AS toplam_odenen_adet,
		coalesce(sum(a.durum=2), 0) AS toplam_kazanan_adet,
		SUM(IF(a.durum=2, a.tutar, 0)) AS toplam_kazanan_tutar,
		
		coalesce(sum(a.durum=3), 0) AS toplam_kaybeden_adet,
		SUM(IF(a.durum=3, a.yatan, 0)) AS toplam_kaybeden_tutar,
		
		coalesce(sum(a.durum=1), 0) AS toplam_devam_adet,
		SUM(IF(a.durum=1, a.yatan, 0)) AS toplam_devam_tutar,
		
		coalesce(sum(a.durum in(4,5)), 0) AS toplam_iptal_adet,
		SUM(IF(a.durum in(4,5), a.yatan, 0)) AS toplam_iptal_tutar
		
		from kuponlar a where $wbuselu $sqladderf")->row_array();
		
		$toplam_odenen_adet = $toplam_odenen['toplam_odenen_adet'];
		$top_odenen = $top_odenen+$toplam_odenen['toplam'];
		$top_odenen_adet = $top_odenen_adet+$toplam_odenen_adet;
		
		// toplam kazanan		
		$toplam_kazanan_adet = $toplam_odenen['toplam_kazanan_adet'];
		$top_kazanan = $top_kazanan+$toplam_odenen['toplam_kazanan_tutar'] + $row['bonuslar'];
		$top_kazanan_adet = $top_kazanan_adet+$toplam_kazanan_adet;
		
		// toplam kaybeden		
		$toplam_kaybeden_adet = $toplam_odenen['toplam_kaybeden_adet'];
		$top_kaybeden = $top_kaybeden+$toplam_odenen['toplam_kaybeden_tutar'];
		$top_kaybeden_adet = $top_kaybeden_adet+$toplam_kaybeden_adet;
		
		// toplam devam
		$toplam_devam_adet = $toplam_odenen['toplam_devam_adet'];
		$top_devam = $top_devam+$toplam_odenen['toplam_devam_tutar'];
		$top_devam_adet = $top_devam_adet+$toplam_devam_adet;
		
		// toplam iptal
		$toplam_iptal_adet = $toplam_odenen['toplam_iptal_adet'];
		$top_iptal = $top_iptal+$toplam_odenen['toplam_iptal_tutar'];
		$top_iptal_adet = $top_iptal_adet+$toplam_iptal_adet;
		
		if($row['canli']==1){
			$calis = $ayrv['ccalisma_sekli'];
			$calist = $calist+$calis;
			$kom = $ayrv['ckomisyon'];	
			$tipo="canli";
			$jvyaz=2;
			$tipt = $tipt+$jvyaz;
		}else{
			$calis = $ayrv['calisma_sekli'];
			$calist = $calist+$calis;
			$kom = $ayrv['komisyon'];	
			$tipo="normal";
			$jvyaz=1;
			$tipt = $tipt+$jvyaz;
		}

		//if($row['canli']==1){$tip=2;}else{$tip=1;}
		$kazantop=$toplam_odenen['toplam_kazanan_tutar'] + $row['bonuslar'];

		$komisyon = $this->komisyon_hesap($ayrv,($toplam_odenen['toplam']-$toplam_odenen['toplam_iptal_tutar']-$toplam_odenen['toplam_devam_tutar']),$kazantop,$tipo);

		$satirtoplam = $toplam_odenen['toplam']-$kazantop-$toplam_odenen['toplam_iptal_tutar']-$toplam_odenen['toplam_devam_tutar'];

		if($satirtoplam>0) { 
			$classyaz= "kazanan"; 
			$kom_yaz=($komisyon);
		} else if($satirtoplam<=0) { 
			$classyaz= "kaybeden";
			//$toplam_komisyon = $toplam_komisyon+0;	
			/*if($jvyaz==2){$kom_yaz='0.00';}else{
				$kom_yaz=($komisyon);
			}*/
			$kom_yaz='0.00';
		}
		
		/*if($toplam_kaybeden_adet==0 && $toplam_kazanan_adet==0){
			$kom_yaz=0;
			$genelsonucsatir=0;
		}else{*/
			$kom_yaz=$kom_yaz;
			$genelsonucsatir = $toplam_odenen['toplam']-$kazantop-$toplam_odenen['toplam_iptal_tutar']-$kom_yaz-$toplam_odenen['toplam_devam_tutar'];
		//}
		
		$toplam_komisyon = $toplam_komisyon+$kom_yaz;

		if($row['firma'] && yetki!=5) { $firmayaz= '<font color="red">'.$row['firma'].'</font>'; } else { $firmayaz =""; }
		if($genelsonucsatir<0) { $kaver= "kay"; } else { $kaver ="kaz"; }
		/*if($row['byetki']==5) { 
			$bbas= $row['username'].' ('.$row['ustbayisi'].')';
		} else { 
			$bbas= $row['username'];
		}*/
		//if($row['user_id']==443){continue;}
		$responce['govde'].= '
		<tr>
		<td >'.$firmayaz.'</td>
		<td >'.$usyaz.'</td>
		<td class="od">'.nf($toplam_odenen['toplam']).' ['.n($toplam_odenen_adet-$toplam_iptal_adet).']</td>
		<td class="kaz">'.nf($kazantop).' ['.n($toplam_kazanan_adet).']</td>
		<td class="kay">'.nf($toplam_odenen['toplam_kaybeden_tutar']).' ['.n($toplam_kaybeden_adet).']</td>
		<td >'.nf($toplam_odenen['toplam_devam_tutar']).' ['.n($toplam_devam_adet).']</td>
		<td class="ipt">'.nf($toplam_odenen['toplam_iptal_tutar']).' ['.n($toplam_iptal_adet).']</td>
		<td >'.anlasma_turs($calis,$jvyaz).' (%'.$kom.')</td>
		<td>'.nf($kom_yaz).'</td>
		<td class="'.$kaver.'">'.nf($genelsonucsatir+$kom_yaz).'</td>
		<td class="'.$kaver.'">'.nf($genelsonucsatir).'</td>
		</tr><tr></tr>';
		}
		$responce['govde'].= '</tbody></table>';
		$tekcal1='';
		
		if($teklibayi) {
			$tekcal1='<li style="color:#777;"><span>('.anlasma_turs($calist,$tipt).')</span><font><br>('.'%'.$kom.')</font></li>';
		}

		$bir=$top_odenen_adet-$top_iptal_adet;

		$iki=$top_odenen-$top_iptal;

		$uc=$top_kazanan_adet;

		$dort=$top_kazanan;

		$bes=$top_kaybeden_adet;

		$alti=$top_kaybeden;

		$yedi=$top_devam_adet;

		$sekiz=$top_devam;

		$dokuz=$top_iptal_adet;

		$on=$top_iptal;

		$onbir=$toplam_komisyon;

		$yenisatirhesap=$iki-$dort-$onbir-$sekiz;

		if($yenisatirhesap<0) {	
			//if($tip=='1'){$yenisatirhesap=$iki-$dort-$onbir;}else{$yenisatirhesap=$iki-$dort-$onbir;}
			//if($tip==2){$onbir=0;}
			$kver= "kay"; 
		} else { 
			$kver= "kaz"; 
		}

		$responce['msg'].='
		<div class="istabox">
		<ul>
		<li style="color:#2A7394;">
		<span>'.lang('tpl').'</span>
		</li>
		<li style="color:#000;">
		<span>'.lang('ytrlan').'</span>
		('.n($bir).')
		<font><br>('.nf($iki).')</font>
		</li>
		<li style="color:#0C0;">
		<span>'.lang('kaz').'</span>
		('.n($uc).')
		<font><br>('.nf($dort).')</font>
		</li>
		<li style="color:#F00;">
		<span>'.lang('kay').'</span>
		('.n($bes).')
		<font><br>('.nf($alti).')</font>
		</li>
		<li>
		<span>'.lang('bacik').'</span>
		('.n($yedi).')
		<font><br>('.nf($sekiz).')</font>
		</li>
		<li style="color:#006699;">
		<span>'.lang('ipt').'</span>
		('.n($dokuz).')
		<font><br>('.$on.')</font>
		</li>
		'.$tekcal1.'
		<li style="color:#777;">
		<span>'.lang('kom').'</span>
		<font><br>('.nf($onbir).')</font>
		</li>
		<li style="color:#000;">
		<span>'.lang('snclar').'</span>
		<font><br>('.nf($yenisatirhesap+$onbir).')</font>
		</li>
		<li class="'.$kver.'">
		<span>'.lang('netkaz').'</span>
		<font><br>('.nf($yenisatirhesap).')</font>
		</li>
		</ul>
		</div>';
		echo json_encode($responce);
		$sqladderf='';$sor->free_result();unset($responce,$sor);
	}
	
	public function gunlukrapor(){
		$bver=bayioption();	
		$this->smarty->assign('bayilist',bayioption());
		$bver='';
		$this->smarty->view('gunlukrapor.tpl');
	}
	
	public function gunlukrapordata(){
		
		ajaxvarmi();
		$tarih1 = basla_time($this->input->post("tarih1"));
		$tarih2 = bitir_time($this->input->post("tarih2"));
		$satir = $this->input->post("satir");
		$tip = $this->input->post("tip");		
		$hesapdurum = $this->input->post("k_hkesim");		
		$userid = $this->input->post('k_user');
		
		if($userid){
			if(yetki == 4) {
				$user_ekle = " a.web_id='$userid'";
			}else{
				$user_ekle = " a.user_id='$userid'"; 
			}
		}else if(yetki == 4) {
			$user_ekle = " a.user_id='".id."'"; 
		}else if(yetki == 5) {
			$user_ekle = " a.web_id='".id."'";
		}else{
			$user_ekle = " a.user_id in(".bayilerim().")";
		}
		
		if(!empty($satir)) {
		if($satir=="kombine") { $satir_ekle = "and a.toplam_mac>1"; } else
		if($satir==3) { $satir_ekle = "and a.toplam_mac>2"; } else
		if($satir==1 || $satir==2) { $satir_ekle = "and a.toplam_mac='$satir'"; }	
		} else {
		$satir_ekle = "";	
		}
		if(!empty($durum)) { $durum_ekle = "and durum='$durum'"; } else { $durum_ekle = ""; }

		if($tip==2) {
			$tip_ekle = "and a.canli=1"; 
		} else if($tip==1) {
			$tip_ekle = "and a.canli=0";
		}else{
			$tip_ekle = "";
		}
		
		if($hesapdurum=="1") { $hesap_ekle = "and a.hesap_kesim_zaman=''"; } else { $hesap_ekle = ""; }
		
		$sqladderf = " $user_ekle and a.kupon_time between '$tarih1' and '$tarih2' $tip_ekle $satir_ekle $hesap_ekle";
		
		$yaz="select SUM(IF(a.durum = 2, a.bonus, 0)) as bonuslar,a.*,k.ayarlar,k.id as uyid from kuponlar a
		left join kullanici k on k.id=a.user_id
		where $sqladderf group by a.kupon_tarih order by a.kupon_time asc";
		$responce = array();
		$sor = $this->db->query($yaz);
		
		$responce['govde'] = '';
		
		if($sor->num_rows() <1) { 
			$responce['govde'].= '<div class="bos">'.lang('bos').'</div>';
			echo json_encode($responce);
			exit;
		}

		$responce['govde'].= '
		<table style="width:100%" class="tftable" cellspacing="0" cellpadding="0">
		<thead>
		<tr >
		<th>'.lang('trh').'</th>
		<th >'.lang('ytrlan').'</th>
		<th >'.lang('kaz').'</th>
		<th >'.lang('kay').'</th>
		<th >'.lang('bacik').'</th>
		<th >'.lang('ipt').'</th>
		<th >'.lang('kom').'</th>
		<th >'.lang('netkaz').'</th>
		</tr></thead><tbody>';
		$geneltoplam=$top_iptal=$top_devam=$top_kaybeden=$top_odenen=$top_kazanan_adet=$top_kaybeden_adet=$top_devam_adet=$top_iptal_adet=$top_odenen_adet=$toplam_komisyon=$top_kazanan=0;
		foreach($sor->result_array() as $row){ 

		//$userim = $this->db->query("select id,ayarlar from kullanici where id='$row[user_id]'")->row_array();
		$ayrv=unserialize($row['ayarlar']);
		
		$sqladder = "$user_ekle and a.kupon_time between '$tarih1' and '$tarih2' $hesap_ekle $satir_ekle $tip_ekle and a.kupon_tarih='$row[kupon_tarih]'";
		
		$toplam_odenen = $this->db->query("select SUM(yatan) as toplam from kuponlar a where $sqladder")->row_array();
		$toplam_odenen_adet = $this->db->query("select id from kuponlar a where $sqladder")->num_rows();
		$top_odenen = $top_odenen+$toplam_odenen['toplam'];
		$top_odenen_adet = $top_odenen_adet+$toplam_odenen_adet;
		// toplam kazanan
		$toplam_kazanan = $this->db->query("select SUM(tutar) as toplam from kuponlar a where $sqladder and a.durum='2'")->row_array();
		$toplam_kazanan_adet = $this->db->query("select id from kuponlar a where $sqladder and a.durum='2'")->num_rows();
		$top_kazanan = $top_kazanan+$toplam_kazanan['toplam'] + $row['bonuslar'];
		$top_kazanan_adet = $top_kazanan_adet+$toplam_kazanan_adet;
		// toplam kaybeden
		$toplam_kaybeden = $this->db->query("select SUM(yatan) as toplam from kuponlar a where $sqladder and a.durum='3'")->row_array();
		$toplam_kaybeden_adet = $this->db->query("select id from kuponlar a where $sqladder and a.durum='3'")->num_rows();
		$top_kaybeden = $top_kaybeden+$toplam_kaybeden['toplam'];
		$top_kaybeden_adet = $top_kaybeden_adet+$toplam_kaybeden_adet;
		// toplam devam
		$toplam_devam = $this->db->query("select SUM(yatan) as toplam from kuponlar a where $sqladder and a.durum='1'")->row_array();
		$toplam_devam_adet = $this->db->query("select id from kuponlar a where $sqladder and a.durum='1'")->num_rows();
		$top_devam = $top_devam+$toplam_devam['toplam'];
		$top_devam_adet = $top_devam_adet+$toplam_devam_adet;
		// toplam iptal
		$toplam_iptal = $this->db->query("select SUM(yatan) as toplam from kuponlar a where $sqladder and a.durum='4'")->row_array();
		$toplam_iptal_adet = $this->db->query("select id from kuponlar a where $sqladder and a.durum='4'")->num_rows();
		$top_iptal = $top_iptal+$toplam_iptal['toplam'];
		$top_iptal_adet = $top_iptal_adet+$toplam_iptal_adet;
		
		$satirtoplam = $toplam_odenen['toplam']-$toplam_iptal['toplam']-$toplam_kazanan['toplam'];
		
		if($row['canli']==1){
			$calis = $ayrv['ccalisma_sekli'];
			$kom = $ayrv['ckomisyon'];	
			$tipo="canli";
			$jvyaz=2;
		}else{
			$calis = $ayrv['calisma_sekli'];
			$kom = $ayrv['komisyon'];	
			$tipo="normal";
			$jvyaz=1;
		}
		
		$komisyon = $this->komisyon_hesap($ayrv,($toplam_odenen['toplam']-$toplam_iptal['toplam']),$toplam_kazanan['toplam'],$tipo);
		
		if($satirtoplam>0) { 
			$classyaz= "kazanan"; 
			$kom_yaz=$komisyon;
		} else if($satirtoplam<=0) { 
			$classyaz= "kaybeden";
			$toplam_komisyon = $toplam_komisyon+0;	
			if($tip==2){$kom_yaz='0.00';}else{$kom_yaz=$komisyon; }
		}		
	
		if($tip==1){
			$toplam_komisyon = $toplam_komisyon+$kom_yaz;
		}else if($classyaz!='kaybeden'){
			$toplam_komisyon = $toplam_komisyon+$kom_yaz;
		}
		
		$kazantop=$toplam_kazanan['toplam'] + $row['bonuslar'];
		$genelsonucsatir = $toplam_odenen['toplam']-$kazantop-$toplam_iptal['toplam']-$kom_yaz;

		$geneltoplam = $geneltoplam+$genelsonucsatir;
		if($genelsonucsatir<0) { $kaver= "kay"; } else { $kaver ="kaz"; }
		
		$responce['govde'].= '
		<tr>
		<td >'.$row['kupon_tarih'].'</td>
		<td >'.nf($toplam_odenen['toplam']-$toplam_iptal['toplam']).' ['.n($toplam_odenen_adet-$toplam_iptal_adet).']</td>
		<td >'.nf($kazantop).' ['.n($toplam_kazanan_adet).']</td>
		<td >'.nf($toplam_kaybeden['toplam']).' ['.n($toplam_kaybeden_adet).']</td>
		<td >'.nf($toplam_devam['toplam']).' ['.n($toplam_devam_adet).']</td>
		<td >'.nf($toplam_iptal['toplam']).' ['.n($toplam_iptal_adet).']</td>
		<td title="'.$satirtoplam.'">'.nf($kom_yaz).'</td>
		<td class="'.$kaver.'">'.nf($genelsonucsatir).'</td>
		</tr>';
		
		}
		//$responce['govde'].= '</table></div>';
		
		if($geneltoplam<0) { $kavert= "kay"; } else { $kavert ="kaz"; }
		if(tema==1){$rnkver='<tr style="background: #ccc;color: #fff">';}else{$rnkver='<tr style="background: #000;color: #fff">';}
		$responce['govde'].= $rnkver.'
		<td width="100">Toplamlar</td>
		<td width="100">'.nf($top_odenen-$top_iptal).' ['.n($top_odenen_adet-$top_iptal_adet).']</td>
		<td >'.nf($top_kazanan).' ['.n($top_kazanan_adet).']</td>
		<td class="kay alr">'.nf($top_kaybeden).' ['.n($top_kaybeden_adet).']</td>
		<td >'.nf($top_devam).' ['.n($top_devam_adet).']</td>
		<td >'.nf($top_iptal).' ['.n($top_iptal_adet).']</td>
		<td>'.nf($toplam_komisyon).'</td>
		<td class="'.$kavert.'">'.nf($geneltoplam).'</td>
		</tr><tr></tr>';
		$responce['govde'].= '</tbody></table>';
		
		echo json_encode($responce);
		$sqladderf=$sqladder='';$sor->free_result();unset($responce,$sor);
	}
	
	public function hesaphareket(){
		$bver=bayioption();	
		$this->smarty->assign('bayilist',bayioption());
		$bver='';
		$this->smarty->view('hesaphareket.tpl');
	}
	
	public function hesaphareketdata(){		
		
		ajaxvarmi();
		$tarih1 = basla_time($this->input->post('tarih1'));
		$tarih2 = bitir_time($this->input->post('tarih2'));
		$islemtip = $this->input->post('islemtip');
		$userid = $this->input->post('k_user');
		$ascdesc = $this->input->post('ascdesc');
		$order = $this->input->post('order');
		$ciftler = $this->input->post('ciftler');		
		
		/*if($userid){
			$ustler=1;
			$user_ekle = " user_id='$userid'"; 
		}else if(yetki != 5){
			$ustler=1;
			$user_ekle = " user_id in(".bayilerim().")"; 			
		}else{
			$ustler=0;
			$user_ekle = " user_id='".id."'"; 
		}*/
		if($userid){
			$ustler=1;
			$user_ekle = " user_id='$userid'"; 
		}else if(yetki == 4) {
			if(wyetki == 1) {
				$ustler=1;
				$user_ekle = " user_id in(".wbayilerim(id).")";
			}else{
				$ustler=0;
				$user_ekle = " user_id='".id."'"; 
			}			
		}else if(yetki == 5) {
			$ustler=0;
			$user_ekle = " user_id='".id."'";
		}else{
			$ustler=1;
			$user_ekle = " user_id in(".bayilerim().")";
		}
		
		if(!empty($islemtip)) { $islemtip_ekle = "and tip='$islemtip'"; } else { $islemtip_ekle = ""; }
		
		if($ascdesc=="asc") { 
			$neworder = "desc";
		} else { 
			$neworder = "asc";
		}		
		
		if($ciftler){
			$ver="select * from hesap_hareket where kuponid!=0 group by kuponid having count(1)>1 ";
		}else{
			$ver="select * from hesap_hareket where $user_ekle and zaman between '$tarih1' and '$tarih2' $islemtip_ekle and detay='0' order by $order $ascdesc   limit 300";	
		}
		$sor = $this->db->query($ver);
		if($sor->num_rows()==0) { echo "<div class='bos'>".lang('bos')."</div>";exit; } else {
		?>
		<table class="tftable" cellspacing="0" cellpadding="0" style="width:100%">
		<thead><tr>
		<? if ($ustler){?><th width="150"><?=lang('byler');?></li><? }?>
		<th width="180"><?=lang('zmn');?></li>
		<th width="80"><?=lang('ttr');?></li>
		<th width="110"><?=lang('ottr');?></li>
		<th width="110"><?=lang('sttr');?></li>
		<th><?=lang('isyapan');?></li>
		<th><?=lang('acikla');?></li>
		</thead><tbody>
		<? foreach($sor->result_array() as $row){
		if($row['tip']=="ekle") { $sonraki_tutar = $row['onceki_tutar']+$row['tutar']; } else
		if($row['tip']=="cikar") { $sonraki_tutar = $row['onceki_tutar']-$row['tutar']; }
		?>
		<tr>
		<? if ($ustler){?><td><?=$row['username']; ?></td><? }?>
		<td><?=turkce_tarih($row['zaman']); ?> <?=date("H:i",$row['zaman']); ?></li>
		<td ><?=nf($row['tutar']); ?></li>
		<td ><?=nf($row['onceki_tutar']); ?></li>
		<td ><?=nf($sonraki_tutar);?></li>
		<td><?=$row['islemi_yapan']; ?></li>
		<td class="<? if($row['tip']=="ekle") {echo "d2"; } else if($row['tip']=="cikar") { echo "d3"; } ?>"><?=$row['aciklama']; ?></li>
		</tr><tr></tr>
		<? } ?>
		</tbody></table>
		<? }
		$sor->free_result();unset($sor);
	}
}