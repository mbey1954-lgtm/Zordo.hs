<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class kupon extends CI_Controller {

	function __construct(){
		parent::__construct();
			logged_admin();
			$this->userler=kendi.','.ustu.','.patron;
			ajaxvarmi();
	}
	
	public function index(){	
		redirect(base_url()."login");	 
	}
	
	public function oncekikupon(){
		
		if(bahisyasak(yetki,kendi,2)){
			die("4");
		}
		if(yetki==5){
			$whr="web_id=".id;
		}else{
			$whr="user_id=".id." and web_id=0";
		}
		$sor = $this->db->query("select id from kuponlar where $whr order by id desc");
		$say = $sor->num_rows();
		if($say==0){die('0');}
		$bilgisi = $sor->row();
		
		$sork = $this->db->get_where('kupon_ic', array('kupon_id' => $bilgisi->id));
		$saybe=0;
		foreach($sork->result_array() as $row){

			$suan = time();
			if($row['mac_time']>$suan && $row['spor_tip']!="canli") {
				
				/*if($row['spor_tip']=="canli") { 
					$canli=$this->db->get_where('canli_maclar', array('id' => $row['mac_db_id']))->row();
					$mac_kodu=$canli->eventid;
				}else{*/
					$mac_kodu=$row['mac_kodu'];
				//}				
				$kontrol = $this->db->query("select id from kupon where session_id='".id."' and onlem='".sesid."' and spor_tip='$row[spor_tip]' and mac_db_id='$row[mac_db_id]'");
				if($kontrol->num_rows()>0) {die('2');}
				$okmu=$this->db->query("insert into kupon (mbs,mac_kodu,ev_takim,konuk_takim,mac_db_id,mac_time,oran_val_id,oran_tip,oran_val,oran,oldoran,session_id,spor_tip,canli_event,canli_info,betradar,coranid,onlem) values 
				('$row[mbs]','$mac_kodu','$row[ev_takim]','$row[konuk_takim]','$row[mac_db_id]','$row[mac_time]','$row[oran_val_id]','$row[oran_tip]','$row[oran_val]','$row[oran]','$row[oran]','".id."','$row[spor_tip]','$mac_kodu','$row[canli_info]','$row[betradar]','$row[id]','".sesid."')");
				$saybe++;
			}
		}
		if($saybe==0){die('2');}
	}
	
	public function kodilegetir(){
		
		if(bahisyasak(yetki,kendi,2)){
			die("4");
		}
		
		$kuponid = $this->input->post('kuponid');
		if(yetki==5){
			$whr=" and web_id=".id;
		}else{
			$whr=" and user_id=".id." and web_id=0";
		}
		$sor = $this->db->query("select id from kuponlar where id=$kuponid $whr ");
		$say = $sor->num_rows();
		if($say==0){die('0');}
		$bilgisi = $sor->row();
		
		$sork = $this->db->get_where('kupon_ic', array('kupon_id' => $bilgisi->id));
		$saybe=0;
		foreach($sork->result_array() as $row){

			$suan = time();
			if($row['mac_time']>$suan && $row['spor_tip']!="canli") {
				
				/*if($row['spor_tip']=="canli") { 
					$canli=$this->db->get_where('canli_maclar', array('id' => $row['mac_db_id']))->row();
					$mac_kodu=$canli->eventid;
				}else{*/
					$mac_kodu=$row['mac_kodu'];
				//}				
				$kontrol = $this->db->query("select id from kupon where session_id='".id."' and onlem='".sesid."' and spor_tip='$row[spor_tip]' and mac_db_id='$row[mac_db_id]'");
				if($kontrol->num_rows()>0) {die('2');}
				$okmu=$this->db->query("insert into kupon (mbs,mac_kodu,ev_takim,konuk_takim,mac_db_id,mac_time,oran_val_id,oran_tip,oran_val,oran,oldoran,session_id,spor_tip,canli_event,canli_info,betradar,coranid,onlem) values 
				('$row[mbs]','$mac_kodu','$row[ev_takim]','$row[konuk_takim]','$row[mac_db_id]','$row[mac_time]','$row[oran_val_id]','$row[oran_tip]','$row[oran_val]','$row[oran]','$row[oran]','".id."','$row[spor_tip]','$mac_kodu','$row[canli_info]','$row[betradar]','$row[id]','".sesid."')");
				$saybe++;
			}
		}
		if($saybe==0){die('2');}
	}
	
	
	public function kuponok(){
		if(direk==1){die("403");}
		$kuponLog=array();
		$tutar = $this->input->post('tutar');
		$cd = $this->input->post('cd');
		//$toplammac = $this->input->post('toplammac');
		
		if(bakiye<$tutar) { die("402"); }		
		
		$futbol_durum=$basket_durum =$duello_durum =$tenis_durum =$hentbol_durum =$hokey_durum =0;
		
		if($cd=="1") {
			$this->db->select('id,spor_tip,canli_event,coranid');	
			$sor1 = $this->db->get_where('kupon', array('session_id' => id,'onlem' => sesid));
			foreach($sor1->result_array() as $rowc){
				if($rowc['spor_tip']=="canli") {
					canlida_oran($this->userler,$rowc['canli_event'],$rowc['id'],$rowc['coranid'],1);	
				}
				if($rowc['spor_tip']=="canlib") {
					canlida_oranb($this->userler,$rowc['canli_event'],$rowc['id'],$rowc['coranid'],1);	
				}  
			}
		}
		
		$zaman = time();
		$tarih = date("d.m.Y");

		$sonkontrol = $this->db->query("select aktif from kupon where session_id='".id."' and onlem='".sesid."' and spor_tip not in('canli','canlib') and (aktif='0' or mac_time<$zaman)");
		if($sonkontrol->num_rows()>0) { die("404"); }
		
		$sonkontrolc = $this->db->query("select aktif from kupon where session_id='".id."' and onlem='".sesid."' and spor_tip in('canli','canlib') and aktif='0'");		
		if($sonkontrolc->num_rows()>0) { die("404"); }
		
		
		$sor = $this->db->get_where('kupon', array('session_id' => id,'onlem' => sesid));
		$toplammac = $sor->num_rows();
		if($toplammac<1) { die("404"); }		
			
		$toporan = 1;
		$mac_siralama='';
		foreach($sor->result_array() as $tveri){
			if($tveri['spor_tip']=="futbol") {$futbol_durum=1;}
			if($tveri['spor_tip']=="basketbol") {$basket_durum=1;}
			if($tveri['spor_tip']=="duello") {$duello_durum=1;}
			if($tveri['spor_tip']=="tenis") {$tenis_durum=1;}
			if($tveri['spor_tip']=="hentbol") {$hentbol_durum=1;}
			if($tveri['spor_tip']=="hokey") {$hokey_durum=1;}
			$toporan = $toporan*$tveri['oran'];
			@$mac_siralama .= '+'.$tveri['mac_db_id']."_".$tveri['oran_val_id']."_".$tveri['spor_tip'].", ";
		}
		
		$mac_siralama = substr($mac_siralama,0,-1);
		$sirasay=strlen($mac_siralama);
		
		if(yetki==5){
			$whr=" web_id=".id;
		}else{
			$whr=" user_id=".id." and web_id=0";
		}
		
		$kupa="select sum(yatan) as toplamyatan from kuponlar where $whr and durum=1 
		and LENGTH(mac_siralama)=$sirasay and match(mac_siralama) against('$mac_siralama' in boolean mode)";
		$aynikupon=$this->db->query($kupa);
		$aynikuponnum = $aynikupon->num_rows();
		if($aynikuponnum>0) {
			$ayrow=$aynikupon->row();
			$aynikupontoplam = $ayrow->toplamyatan + $tutar;
			if($aynikupontoplam > aynikuponmax && aynikuponmax > 0) {
				die("13");
			}
		}
		
		$toplamoran = $toporan;
		
		if(maxoran=="") { $maxoran = 1000; } else { $maxoran = maxoran; }
		if($toplamoran>$maxoran) { $toplamoran = $maxoran; }
		$kazanc = $toplamoran*$tutar;
		if($kazanc>maxodeme) { $kazanc = maxodeme; }
		$kesinti=0;
		//if(kesinti>0) { $kesinti = nf(($kazanc * kesinti) / 100); }
		
		$ipadres = $_SERVER['REMOTE_ADDR'];
		if(bonus == 1){
			$bonus=bonus_hesapla($toplammac);		
			$bonus=nf(($kazanc / 100) * $bonus);
		}else{
			$bonus=0;
		}
		/*$futbol_durum = kupondavarmi('futbol',id);
		$basket_durum = kupondavarmi('basketbol',id);
		$duello_durum = kupondavarmi('duello',id);*/
		$web=0;
		if(yetki==5){
			$usid=ustbayi;
			$webid=id;
		}else{
			$webid=0;
			$usid=id;
		}		
		$this->db->query("insert into kuponlar (user_id,web_id,adm_id,sup_id,username,oran,yatan,tutar,kupon_time,basketbol,futbol,duello,canli,tenis,hentbol,hokey,toplam_mac,durum,kupon_tarih,ipadres,bonus,mac_siralama,domain,kesinti) values
		('$usid','".$webid."','".kendi."','".ustu."','".username."','$toplamoran','$tutar','$kazanc','$zaman','$basket_durum','$futbol_durum','$duello_durum','$cd','$tenis_durum','$hentbol_durum','$hokey_durum','$toplammac','1','$tarih','$ipadres','$bonus','$mac_siralama',".domain.",'$kesinti')");

		$kupon_id = $this->db->insert_id();
		if($kupon_id){
		foreach($sor->result_array() as $row){
			
			$oran_val=$row['oran_val'];
			$oran_val2='';
						
			
		$buoran=$row['oran'];			
			
		$this->db->query("insert into kupon_ic (mbs,mac_kodu,ev_takim,konuk_takim,mac_db_id,mac_time,oran_val_id,oran_tip,oran_val,oran_val2,oran,spor_tip,kupon_id,user_id,username,canli_info,ilkgiris,betradar,hangicanli) 
		values ('$row[mbs]','$row[mac_kodu]','$row[ev_takim]','$row[konuk_takim]','$row[mac_db_id]','$row[mac_time]','$row[oran_val_id]','$row[oran_tip]','$oran_val','$oran_val2','$buoran','$row[spor_tip]','$kupon_id','".id."','".username."','$row[canli_info]','$row[ilkgiris]','$row[betradar]','$row[hangicanli]')");
		
		$kuponLog['kuponici'][] = array(
			'mac_time' => $row['mac_time'],
			'oran_val_id' => $row['oran_val_id'],
			'mac_db_id' => $row['mac_db_id'],
			'mac_kodu' => $row['mac_kodu'],
			'bayi' => username,
			'takimlar' => $row['ev_takim'].'-'.$row['konuk_takim'],
			'tahmin' => $row['oran_tip'],
			'oran' => $buoran,
			'spor_tip' => $row['spor_tip'],
			'canli_bilgi' => $row['canli_info']
		);
		
		}
		
		$this->db->query("update kullanici set bakiye=bakiye-$tutar where id=".id." ");
		$this->db->query("delete from kupon where session_id='".id."' and onlem='".sesid."'");		
		
		$kuponLog['kupon'] = array(
			'toplamoran' => nf($toplamoran),
			'yatan' => $tutar,
			'kazanc' => nf($kazanc),
			'bonus' => $bonus,
			'toplam_mac' => $toplammac,
			'kupon_tarihi' => date('Y-m-d H:i:s', time()),
			'bakiye' => nf(bakiye),
			'durum' => "$kupon_id no'lu Kupon Oynanmıştır"
		);
		$kuponLog = serialize($kuponLog);
		loglama($kuponLog, "Kupon Oynama",$kupon_id);
		die("$kupon_id");
		unset($kuponLog);
		}else{
			die("405");
		}
	}
	
	public function guncelbakiye(){
		echo nf(bakiye);
	}
	
	public function liveadd(){
		
		if(bahisyasak(yetki,kendi,2)){
			die("4");
		}
		
		$val = $this->input->post('warrior');
		
		$maxbul=$this->db->query("select id from kupon where session_id='".id."' and onlem='".sesid."'")->num_rows();
		if($maxbul==maxmac) { die("5"); }
		
		$encode = decodekupon($val);
		$war = explode("|",$encode);
		//print_R($war);
		$oran = $war[0];
		$mac_db_id = $war[1];
		$oran_id = $war[2];		
		$canli_kupon_sure = $war[3];		
		
		$simdi = time();
		
		if($canli_kupon_sure < $simdi){
			die("6");
		} 		
		$macbilgi = $this->db->query("select a.*,v.oran_val,t.tip_isim,
		(SELECT gizliler FROM coranver WHERE oranvalid=0 and lig_mac=0 and uye in(".$this->userler.") and gizliler=a.eventid and tip='aski') as surekliaski
		from canli_maclar a
		left join canli_oran b on b.mac_id=a.eventid
		left join canli_tip t on t.id=b.canli_tip
		left join oran_valc v on v.id=b.oran_adi
		where a.id=$mac_db_id AND b.oran_adi=$oran_id");
		
		if($macbilgi->num_rows()==0 && !is_numeric($mac_db_id) && !is_numeric($oran_id) && !empty($oran)) {die('3');}
		
		$mb=$macbilgi->row();
		$surekli_aski_durum = surekli_aski_durum($mb->gol,$mb->sonoranguncelleme,$mb->surekliaski);
		
		if($mb->aktif=="0" || $surekli_aski_durum==1 ) { die("2"); }
		
		$kontrolcv = $this->db->query("select id from kupon where session_id='".id."' and onlem='".sesid."' and hangicanli !='".$mb->yer."'");
		if($kontrolcv->num_rows()>0) {
			 die("5");
		}
		
		$hop="select id from kupon where session_id='".id."' and onlem='".sesid."' and mac_db_id='".$mb->id."'";
		$kontrol = $this->db->query($hop);
		
		if($kontrol->num_rows()>0) {
			$obilgi = $kontrol->row();
			$this->db->query("delete from kupon where id='".$obilgi->id."'");
		}
		
		if($mb->devremi=="1") {
			$canliinfo = $mb->ev_skor.':'.$mb->konuk_skor.'|Devrede';
		} else {
			$canliinfo = $mb->ev_skor.':'.$mb->konuk_skor.'|'.$mb->dakika.'.dk';
		}
		
		$suan = time();
		$canlimbs = 1;//canli_mbs_ver($macbilgi['eventid']);
		
		$orantips = $mb->tip_isim.'|'.$mb->oran_val;
		if(!empty(canli_koruma) && canli_koruma!='0.00' && $oran >= canli_koruma){
			$oran=canli_koruma;
		}
		$ekle="insert into kupon (mbs,mac_kodu,ev_takim,konuk_takim,mac_db_id,mac_time,oran_tip,oran,session_id,spor_tip,ilkgiris,oldoran,canli_event,canli_info,betradar,coranid,hangicanli,onlem,canli_kupon_sure) 
		values ('$canlimbs','".$mb->eventid."','".$mb->ev_takim."','".$mb->konuk_takim."','$mac_db_id','$simdi','$orantips','$oran','".id."','canli','".$mb->ilkgiris."','$oran','".$mb->eventid."','$canliinfo','".$mb->betradar_id."','$oran_id','".$mb->yer."','".sesid."','".$canli_kupon_sure."')";
		$this->db->query($ekle);
		die("1");
		
	}
	
	public function liveaddb(){
		
		if(bahisyasak(yetki,kendi,2)){
			die("4");
		}
		if(canliyasakb >0 || canlibahisb==0){
			die("4");
		}
		$val = $this->input->post('warrior');
		
		$maxbul=$this->db->query("select id from kupon where session_id='".id."' and onlem='".sesid."'")->num_rows();
		if($maxbul==maxmac) { die("5"); }
		
		$encode = decodekupon($val);
		$war = explode("|",$encode);
		//print_R($war);
		$oran = $war[0];
		$mac_db_id = $war[1];
		$canli_tip = $war[2];		
		$oran_adi = $war[3];		
		$canli_kupon_sure = $war[4];		
		
		$simdi = time();
		
		if($canli_kupon_sure < $simdi){
			die("6");
		} 		
		$ver="select a.*,b.oran_adi,t.tip_isim,t.id as canli_tip,
		(SELECT gizliler FROM coranverb WHERE oranvalid=0 and lig_mac=0 and uye in(".$this->userler.") and gizliler=a.eventid and tip='aski') as surekliaski
		from canli_maclarb a
		left join canli_oranb b on b.mac_id=a.eventid
		left join canli_tipb t on t.id=b.canli_tip
		where a.id=$mac_db_id AND b.canli_tip='$canli_tip' AND b.oran_adi='$oran_adi'";
		$macbilgi = $this->db->query($ver);
		
		if($macbilgi->num_rows()==0 && !is_numeric($mac_db_id) && !empty($oran_adi) && !empty($oran)) {die('3');}
		
		$mb=$macbilgi->row();
		$surekli_aski_durum = surekli_aski_durumb($mb->sonoranguncelleme,$mb->surekliaski);
		
		if($mb->aktif=="0" || $surekli_aski_durum==1 ) { die("2"); }
		
		//if(id == 1033){
		$kontrolcv = $this->db->query("select id from kupon where session_id='".id."' and onlem='".sesid."' and hangicanli !='".$mb->yer."'");
		if($kontrolcv->num_rows()>0) {
			 die("5");
		}
		//}
		$kontrol = $this->db->query("select id from kupon where session_id='".id."' and onlem='".sesid."' and canli_event='".$mb->eventid."'");
		
		if($kontrol->num_rows()>0) {
			$obilgi = $kontrol->row();
			$this->db->query("delete from kupon where id='".$obilgi->id."'");
		}
		
		$canliinfo = $mb->ev_skor.':'.$mb->konuk_skor.'|'.$mb->devre;
		
		$orantips = $mb->tip_isim.'|'.$mb->oran_adi;
		$coranid = $mb->canli_tip.'|'.$mb->oran_adi;
		if(!empty(canli_koruma) && canli_koruma!='0.00' && $oran >= canli_koruma){
			$oran=canli_koruma;
		}
		$ver1="insert into kupon (mbs,mac_kodu,ev_takim,konuk_takim,mac_db_id,mac_time,oran_tip,oran,session_id,spor_tip,ilkgiris,oldoran,canli_event,canli_info,betradar,coranid,hangicanli,onlem,canli_kupon_sure) 
		values ('1','".$mb->eventid."','".$mb->ev_takim."','".$mb->konuk_takim."','$mac_db_id','$simdi','$orantips','$oran','".id."','canlib','".$mb->ilkgiris."','$oran','".$mb->eventid."','$canliinfo','".$mb->betradar_id."','$coranid','".$mb->yer."','".sesid."','".$canli_kupon_sure."')";
		$this->db->query($ver1);
		die("1");
		
	}
	
	public function kuponekle(){
		
		if(bahisyasak(yetki,kendi,2)){
			die("4");
		}
		
		$val = $this->input->post('val');

		$maxbul=$this->db->query("select id from kupon where session_id='".id."' and onlem='".sesid."' ")->num_rows();
		if($maxbul==maxmac) { die("5"); }
		
		$encode = decodekupon($val);
		$kes = explode("|",$encode);
		//echo'<pre>';print_R($kes);
		$mac_db_id 		=	 	$kes[0];
		$mbs			=		$kes[1];
		$spor_tip 		=		$kes[2];
		$oran_val_id	=		$kes[3];
		$oran 			=		$kes[4];	
		
		if($oran=="-") { die('1'); }
		
		//if($spor_tip=="futbol" && futbol=="0") { die("no"); }
		
		if($spor_tip=="futbol" || $spor_tip=="duello") {			
			
			$mb = $this->db->query("select d_kodu,ev_takim,konuk_takim,mac_time,mac_kodu,iddaa_kodu from program where id='$mac_db_id'")->row();
			$oran_bilgi = $this->db->query("select oran_val,(select tip_isim from oran_tip where id=oran_val.oran_tip) as tip_isim from oran_val where id=$oran_val_id")->row();
			
			$oranval = "";
			$hdk = "";
			if($mb->d_kodu) { 
				$mb->mac_kodu = $mb->d_kodu; 
			} else { 
				$mb->mac_kodu = $mb->mac_kodu; 
			}
		} else if($spor_tip=="basketbol") {
			
			$mb = $this->db->query("select ev_takim,konuk_takim,mac_time,mac_kodu,iddaa_kodu from programb where id='$mac_db_id'")->row();
			
			$oran_bilgi = $this->db->query("select oran_val,(select tip_isim from oran_tipb where id=oran_valb.oran_tip) as tip_isim from oran_valb where id=$oran_val_id")->row();
			
			$ooran = $this->db->query("select oran_val_b,oran_val_id,mac_db_id,hdk from oranlarb where mac_db_id='$mac_db_id' and oran_val_id='$oran_val_id'")->row();
			
			$oranval = $ooran->oran_val_b;
			$hdk = $ooran->hdk;
			
			if($mb->iddaa_kodu) { 
				$mb->mac_kodu = $mb->iddaa_kodu; 
			} else { 
				$mb->mac_kodu = $mb->mac_kodu; 
			}

		}else if($spor_tip=="tenis" || $spor_tip=="hentbol" || $spor_tip=="hokey") {
			if($spor_tip=='tenis'){
				$t='t';
			}elseif($spor_tip=='hentbol'){
				$t='h';
			}elseif($spor_tip=='hokey'){
				$t='o';
			}
			$mb = $this->db->query("select ev_takim,konuk_takim,mac_time,mac_kodu from program$t where id='$mac_db_id'")->row();
			
			$oran_bilgi = $this->db->query("select oran_val,(select tip_isim from oran_tip$t where id=oran_val$t.oran_tip) as tip_isim from oran_val$t where id=$oran_val_id")->row();
			
			$oranval = $hdk = "";
			$mb->mac_kodu = $mb->mac_kodu;
		}
		
		if(@$mb->ev_takim=='' || @$oran_bilgi->tip_isim=='') { die('1'); }
		
		if(sabitmbs!="0") { 
			$mbs = sabitmbs; 
		} else { 
			$mbs = $mbs; 
		}		
		

		$suan = time();
		$oran_tip = $oran_bilgi->tip_isim.'|'.$oran_bilgi->oran_val;
		
		$kontrol = $this->db->query("select id from kupon where session_id='".id."' and onlem='".sesid."' and spor_tip='$spor_tip' and mac_db_id='$mac_db_id'");
		if($kontrol->num_rows()<1) {
			$this->db->query("insert into kupon (mbs,mac_kodu,ev_takim,konuk_takim,mac_db_id,mac_time,oran_val_id,oran_tip,oran_val,oran,session_id,spor_tip,ilkgiris,hdk,oldoran,onlem) 
			values ('$mbs','".$mb->mac_kodu."','".$mb->ev_takim."','".$mb->konuk_takim."','$mac_db_id','".$mb->mac_time."','$oran_val_id','$oran_tip','$oranval','$oran','".id."','$spor_tip','$suan','$hdk','$oran','".sesid."')");
			die("201");
		} else {
			$kupondaki = $kontrol->row();
			$this->db->query("update kupon set oran_val_id='$oran_val_id',oran_tip='$oran_tip',oran='$oran',hdk='$hdk',oran_val='$oranval',oldoran='$oran' where id='".$kupondaki->id."' ");
			die("200");
		}	 
	}
	
	public function kuponsil(){
		$id = $this->input->post('id');
		$this->db->query("delete from kupon where id=$id and session_id='".id."' and onlem='".sesid."'");
		die("11");
	}
	
	public function kupontemizle(){
		$this->db->query("delete from kupon where session_id='".id."' and onlem='".sesid."'");
	}
	
	public function kuponguncelle(){		
		?><script>var kombhata=0;$(".bulten .ratio-box").removeClass('active');</script><?
		$normal = $oynanamaz=$canlivar=$cdurum=$cv=0;
		$oran = 1;
		$sor = $this->db->query("select * from kupon where session_id='".id."' and onlem='".sesid."' order by id desc");
		$toplammac = $sor->num_rows();
		if($toplammac == 0) {
			echo'<script>$("#sidebarbox").show();$("#toplammac , #topsa , #toplamoran, #tutarhesap").text("0");</script>';echo'<script>$("#kuponyatan").val("");</script>';echo'<script>$(".kuponalt").hide();$(".blank-coupon").show();</script>';			
		?>
		
		<? } else {
		foreach($sor->result_array() as $row){
			$mbsler[]=$row['mbs']; 
			
			$ob = explode("|",$row['oran_tip']); 
			$ob1=temizle($ob[0]);
			$ob2=temizle($ob[1]);
			$ob1=lang($ob1);
			$ob2=lang($ob2);
			if(!$ob2){
				$ob2=$ob[1];
			}
			if($row['spor_tip']=="canli") { 
				$canlivar=1; $cdurum=canlida_oran($this->userler,$row['canli_event'],$row['id'],$row['coranid'],0); 
			} 
			if($row['spor_tip']=="canlib") {
				$canlivar=1; $cdurum=canlida_oranb($this->userler,$row['canli_event'],$rowi['id'],$row['coranid'],0);
				$cob = explode("|",$row['coranid']); 
				if($cob[0]==3 || $cob[0]==14){
					$sy=preg_replace('/[^0-9.]*/', "",$cob[1]);
					$sy1=preg_replace('/[^a-z]*/', "",$cob[1]);
					$oadi=temizle($sy1);
					$ob2=lang($oadi,array($sy));
				}else if($cob[0]==11){ 
					$sy=preg_replace('/[^0-9-+.]*/', "",$cob[1]);
					$sy1=preg_replace('/[^a-zA-Z]*/', "",$cob[1]);
					$oadi=temizle($sy1);
					$ob2=lang($oadi.'11',array($sy));
				}
			}
			
			$oran = $oran*$row['oran'];?>
			<ul class="matches event_head" id="<?=$row['mac_db_id'].'-'.$row['oran_val_id'].'-'.$row['spor_tip'].'-'.$row['id'].'-'.$row['coranid']; ?>">
				<li><div class="left"> <span class="team-full"><?=takimadikisaltkupon($row['ev_takim']).":".takimadikisaltkupon($row['konuk_takim']); ?></span><span class="info"><?=$ob1;?><span style="float: left; margin: 1px 0px 0px 5px;"><? if($row['oran_val']!="") { echo "($row[oran_val])&nbsp;"; } ?><?=$ob2;?></span></span> <span class="ratio"><?=$row['oran'];?></span> <? if($row['canli_event']=="") { $normal = 1; } if($row['canli_kupon_sure']<time() && ($row['spor_tip']=="canli" || $row['spor_tip']=="canlib")) { $oynanamaz=1; echo'<div class="info" style="border: 1px solid #FF2829;margin: 2px;"><i class="fa fa-exclamation-triangle"></i> '.lang('orsure').'</div>'; } if($row['mac_time']<time() && ($row['spor_tip']!="canli" && $row['spor_tip']!="canlib")) { $oynanamaz=1; echo'<div class="info" style="border: 1px solid #FF2829;margin: 2px;"><i class="fa fa-exclamation-triangle"></i> '.lang('bubasladi').'</div>'; } if($cdurum==1 && ($row['spor_tip']=="canli" || $row['spor_tip']=="canlib")) { $oynanamaz = 1; echo'<div class="info" style="border: 1px solid #FF2829;margin: 2px;"><i class="fa fa-exclamation-triangle"></i> '.lang('buaski').'</div>'; } ?></div>
				<a class="close" href="#" onclick="kuponsil(<?=$row['id'];?>)"><i class="fa fa-times"></i></a></li>
			</ul>
			<script> var cbet = $("#<?="$row[mac_db_id]-$row[oran_val_id]-$row[spor_tip]"; ?>"); if(cbet.length>0) { cbet.addClass('active'); }else{$(".all<?="$row[mac_db_id]-$row[spor_tip]"; ?>").addClass('active');} </script><? }//döngü bitttii
		if($oran > maxoran) { $oran = maxoran; }
		echo'<script>$("#sidebarbox").hide();$("#toplamoran").text("'.nfss($oran).'");</script>';echo'<script>$("#toplammac , #topsa").text("'.$toplammac.'");</script>';echo'<script>$(".kuponalt").show();$(".blank-coupon").hide();</script>';		
		$maxmbs = max($mbsler);
		if($toplammac<$maxmbs) {
		$mbshata = 1;
		?>
		<div class="mbshata"><?=lang('mbshta',array($maxmbs-$toplammac));?> </div> <? } else if($oran <= min_oran) { $oranhata = 1; ?> <div class="mbshata">
		<?=lang('enaz',array(min_oran));?></div> 
		<? } else if($toplammac != minmac && $toplammac < minmac) {$machata = 1;?> <div class="mbshata"><?=lang('mbshta',array(minmac-$toplammac));?></div> <? } else if(kombine == 0 && $normal==1 && $canlivar==1) {?> <div class="mbshata"><?=lang('kombinehta');?></div><script>kombhata=1;</script> <? }  if($toplammac==1) { if($canlivar==1) {echo"<input type='hidden' id='canlitekmacsayi' value='".canli_tekmac."'>";}else{echo"<input type='hidden' id='tekmacsayi' value='".tekmacmax."'>";} } else {echo"<input type='hidden' id='kuponmacmax' value='".maxkupon."'>";} ?>  <? if(bonus == 1){ $bonus=bonus_hesapla($toplammac); if($bonus >0){ ?> <div class="mbshata"> <script>$("#bonsgiz").show();</script><?=$toplammac;?> <span><?=lang('thm');?></span><br>% <?=$bonus;?> <span><?=lang('bns');?></span> <input type="hidden" id="bonusu" value="<?=$bonus;?>"></div> <? }else{?> <input type="hidden" id="bonusu" value="0"> <script>$("#bonsgiz").hide();</script> <? } }else{?> <input type="hidden" id="bonusu" value="0"> <? }?>  <input type="hidden" id="oynanamaz" value="<? if(@$oynanamaz) { echo "1"; } else { echo "0"; } ?>"> <input type="hidden" id="mbshata" value="<? if(@$mbshata) { echo "1"; } else { echo "0"; } ?>"> <input type="hidden" id="machata" value="<? if(@$machata) { echo "1"; } else { echo "0"; } ?>"> <input type="hidden" id="oranhata" value="<? if(@$oranhata) { echo "1"; } else { echo "0"; } ?>"> <input type="hidden" id="canlivar" value="<? if($canlivar) {$cv = 1; echo "1"; } else { $cv=0; echo "0"; } ?>"> <?}//kupon var yok bitti?>
		
		<script>  $(document).ready(function(e) {  $("#kuponyatan").keyup(function(e) {var bonusu = $("#bonusu").val(); var tekmacsayi = $("#tekmacsayi").val(); var kuponmacmax = $("#kuponmacmax").val(); var canlitekmacsayi = $("#canlitekmacsayi").val(); var yatantutar = $("#kuponyatan").val(); var toplamoran = $("#toplamoran").text();  var kazancilk = toplamoran*$("#kuponyatan").val(); var kazanc = kazancilk;  if(tekmacsayi >0 && parseInt(yatantutar) > tekmacsayi) { failcont('<?=lang('tekmac');?> '+tekmacsayi+' <?=para;?>'); $("#kuponyatan").val('2'); $("#tutarhesap").html(kazanc.toFixed(2)); }else if(kuponmacmax >0 && parseInt(yatantutar) > kuponmacmax) { failcont('<?=lang('coklu');?> '+kuponmacmax+' <?=para;?>'); $("#kuponyatan").val('2'); $("#tutarhesap").html(kazanc.toFixed(2)); }else if(canlitekmacsayi >0 && parseInt(yatantutar) > canlitekmacsayi) { failcont('<?=lang('ctekmac');?> '+canlitekmacsayi+' <?=para;?>'); $("#kuponyatan").val('2'); $("#tutarhesap").html(kazanc.toFixed(2)); }else if(toplamoran><?=maxoran;?>) { failcont('<?=lang('maxorayar');?>'); $("#kuponyatan").val('2'); $("#toporan").html('<?=nfss(maxoran,2);?>'); }else if(kazanc><?=maxodeme;?>) { failcont('<?=lang('maxode');?> <?=nfss(maxodeme,2);?> <?=para;?>'); $("#kuponyatan").val('0'); $("#tutarhesap").html('0.00'); }else { $("#tutarhesap").html(kazanc.toFixed(2)); $("#bonusuhak").html( (((parseFloat(kazanc) / 100) * bonusu) + kazanc).toFixed(2));} });  });  function otohesap() {  var bonuso = $("#bonusu").val(); var yatan = $("#kuponyatan").val(); var toplamorano = $("#toplamoran").text(); var kazancilko = toplamorano*$("#kuponyatan").val();  var kazanco = kazancilko; $("#tutarhesap").html(kazanco.toFixed(2)); $("#bonusuhak").html( (((parseFloat(kazanco) / 100) * bonuso) + kazanco).toFixed(2));  } otohesap(); function kuponok() {  var tekmacsayi = $("#tekmacsayi").val(); var kuponmacmax = $("#kuponmacmax").val(); var canlitekmacsayi = $("#canlitekmacsayi").val(); $("#countgeri").val(<?=canli_sure;?>); var oynanamaz = $("#oynanamaz").val(); var mbshata = $("#mbshata").val(); var machata = $("#machata").val(); var kuponyatan = $("#kuponyatan").val(); var oranhata = $("#oranhata").val();  if(kuponyatan=='' || kuponyatan<1) { failcont('<?=lang('yatkont');?>'); }else if(<?=direk;?>!=1 && <?=yetki;?>!=4 && <?=yetki;?>!=5) { failcont("<?=lang('supolmaz');?>"); } else if(<?=direk;?>==1 && kuponyatan><?=bakiye;?>) { failcont('<?=lang('uyeolmadanolmaz');?>');}else if(<?=direk;?>==0 && kuponyatan><?=bakiye;?>) { failcont('<?=lang('bakiolmaz');?>'); kuponguncelle(0); } else	if(kuponyatan<<?=minkupon;?>) { failcont('<?=lang('minbhs');?> <?=minkupon; ?> <?=para;?>'); $("#kuponyatan").val('<?=(minkupon);?>'); kuponguncelle(0); }else if(tekmacsayi >0 && parseInt(kuponyatan) > tekmacsayi) { failcont('<?=lang('tekmac');?> '+tekmacsayi+' <?=para;?>'); return false; }else if(kuponmacmax >0 && parseInt(kuponyatan) > kuponmacmax) { failcont('<?=lang('coklu');?> '+kuponmacmax+' <?=para;?>'); return false; }else if(canlitekmacsayi >0 && parseInt(kuponyatan) > canlitekmacsayi) { failcont('<?=lang('ctekmac');?> '+canlitekmacsayi+' <?=para;?>'); return false; } else	if(oynanamaz==1) { failcont('<?=lang('oynanamaz');?>'); kuponguncelle(0); } else	if(mbshata==1) { failcont('<?=lang('mbshta',array($maxmbs-$toplammac));?>'); kuponguncelle(0); } else	if(machata==1) { failcont('<?=lang('minmac',array(minmac-$toplammac));?>'); kuponguncelle(0); } else 	if(oranhata==1) { failcont('<?=lang('minorhata',array(min_oran));?>'); kuponguncelle(0); } else 	if(kombhata==1) { failcont('<?=lang('kombinehta');?>'); kuponguncelle(0); } else	{ $(".kuponalt").hide(); $(".kuponalt").addClass('bekle'); $(".kuponalt").removeClass('kuponalt'); $(".afteredkupon").slideUp(); var rand = Math.random(); var toplamoran = $("#toplamoran").val(); var canlidurum = $("#canlivar").val(); if(canlidurum=="1") { $("#livelock").fadeIn('fast'); $(".countdown").show(); var kontrol = setInterval(function() { var suancount = $("#countgeri").val(); var yenicount = suancount-1; if(yenicount>-1) { $("#countgeri").val(yenicount); } else { $(".kuponalt").hide(); $(".countdown").show(); clearInterval(kontrol); $(".kuponalt").hide(); $(".countdown").show(); var kontrolt = setInterval(function() { $("#countgeri").val(0); $(".kuponalt").hide(); $(".countdown").show(); var suancountt = $("#songeri").val(); var yenicountt = suancountt-1; $('#sonbe').html('<?=lang('kupguncelyat');?>'); if(yenicountt>-1) { $(".kuponalt").hide(); $(".countdown").show(); $("#songeri").val(yenicountt); } else { clearInterval(kontrolt); if($("#oynanamaz").val()==1) { failcont('<?=lang('oynanamaz');?>'); $(".countdown").hide(); $(".bekle").addClass('kuponalt'); $(".kuponalt").removeClass('bekle'); $("#livelock").fadeOut('slow'); kuponguncelle(0); }else{ kuponokson(kuponyatan,canlidurum,toplamoran); } } },1000); } },1200); } else { kuponokson(kuponyatan,canlidurum,toplamoran); }  } }  function kuponokson(tutar,canlidurum,toplamoran) {  var baseurl1 = "<?=base_url();?>"; var rand = Math.random(); $.post(baseurl1+'kupon/kuponok',{ tutar:tutar,cd:canlidurum,toplamoran:toplamoran,toplammac:<?=$toplammac;?>,cv:<?=$cv;?>},function(data) {  if(data=="403") { failcont('<?=lang('uyeolmadanolmaz');?>'); } else if(data=="402") { failcont('<?=lang('bakiolmaz');?>'); kuponguncelle(0); } else if(data=="404") { failcont('<?=lang('oynanamaz');?>'); kuponguncelle(0); } else	if(data=="13") { failcont('<?=lang('aynikupon',array(nf(aynikuponmax)));?>'); kuponguncelle(0); } else	if(data=="505") { failcont('<?=lang('hataolustu');?>'); kuponguncelle(0); } else{ kuponguncelle(); limitupdate(); $(".afteredkupon").slideDown(); failcont('<i class="fa fa-check"></i> <?=lang('ktamam');?>'); } }); $(".countdown").hide(); $(".bekle").addClass('kuponalt'); $(".kuponalt").removeClass('bekle'); $("#livelock").fadeOut('slow'); } </script> </div> <? if($cv==1) { ?> <input type="hidden" id="caola" value="1"> <? }
	}
	
}