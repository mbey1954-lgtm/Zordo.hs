<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class ayar extends CI_Controller {

	function __construct(){
		parent::__construct();
			logged_admin();
			
	}
	
	public function bankahesaplari(){		
		if(yetki != 3){redirect(base_url().'hata');}
		$ouser = $this->db->query("select * from bankalar where admin=".kendi." ");
		$this->smarty->assign('liste', $ouser->result());
		$this->smarty->view('bankahesaplari.tpl');
	}
	
	public function orankaydet(){
		//echo'<pre>';print_R($_POST);exit;
		$id=$_POST['id'];
		$tb=$_POST['tb'];
		unset($_POST['id']);
		unset($_POST['tb']);
		$sonuc=0;
		foreach($_POST as $oran_val_id=>$p){
			if($p['oran']){
				$yenikayit.="($oran_val_id,".$p['oran_tip'].",'".$p['oran']."','$id',1),";
			}
		}
		
		$or=explode('),',$yenikayit);
		$orsayi= count($or);
		$yenikayit=substr($yenikayit,0,-1);
		$sonveri="insert into oranlar$tb (oran_val_id,oran_tip,oran,mac_db_id,gunceldestek)
		values $yenikayit
		on duplicate key update
		oldoran=IF(oran != values(oran), oran,0),
		oran_val_id=values(oran_val_id),
		oran_tip=values(oran_tip),
		oran=values(oran),
		mac_db_id=values(mac_db_id),
		gunceldestek=values(gunceldestek)";
		$sonuc=$this->db->query($sonveri);
		$this->db->query("update program$tb set orsayi='$orsayi' where id='$id'");
		echo$sonuc;exit;
	}
	
	public function macoran(){
		
		//ajaxvarmi();
		extract($_POST);
		if($tb=='Futbol'){
			$tb1='';
		}else if($tb=='Basketbol'){
			$tb1='b';
		}else if($tb=='Tenis'){
			$tb1='t';
		}else if($tb=='Hentbol'){
			$tb1='h';
		}else if($tb=='Hokey'){
			$tb1='o';
		}else if($tb==''){
			$tb1='';
		}
		//<input type="hidden" name="'.$id.'[oran_val_id]" value="'.$vtip->id.'">
		//<input type="hidden" name="'.$id.'[oran_tip]" value="'.$vtip->oran_tip.'">
		$ver="select * from oran_tip$tb1 order by id asc";
		$sor = $this->db->query($ver);
		$bas='<form method="post" id="siraform"><div style="float:left;width:100%"><input type="hidden" name="id" value="'.$id.'"><input type="hidden" name="tb" value="'.$tb1.'"><input class="button" style="width:100%" value="Kaydet" type="button" onclick="orankaydet();"></div><table style="background:#ccc;color: #fff;float:left;margin-right: 10px;" cellspacing="0" cellpadding="0" border="1"><tr style="background-color: #000;"></tr>';
		$say=0;
		foreach ($sor->result() as $otip) {
			$say++;
			$tipbaslik=$otip->tip_isim;
			$bas.='<tr style="background-color: #000;"><th colspan="3">'.$tipbaslik.'</th></tr>
			<tr style="background: #4d302f">
			<th>Tahmin</th>
			<th>Oran</th>
			</tr>';
			$val=$this->db->query("select * from oran_val$tb1 where oran_tip='".$otip->id."' order by id asc");
			
			foreach ($val->result() as $vtip) {
				$orne = $this->db->query("select oran from oranlar$tb1 where mac_db_id=$id and oran_val_id=".$vtip->id." ")->row();
				$bas.='<tr style="background: #3F3F3F">
				<td style="width:250px;">
				<input type="hidden" name="'.$vtip->id.'[oran_tip]" value="'.$vtip->oran_tip.'">
				'.$vtip->oran_val.'</td>
				<td style=""><input size="4" class="inputbet" name="'.$vtip->id.'[oran]" value="'.$orne->oran.'" maxlength="6" type="text"></td>
				</tr>';
			}
			if($say>6){
				$say=0;
				$bas.='</table><table style="background:#ccc;color: #fff;float:left;margin-right: 10px;" cellspacing="0" cellpadding="0" border="1">';
			}
		}
		$bas.='</table></form>';
		echo$bas;
			
	}
	
	public function macekle(){
		extract($_POST);
		$program_tip='';
		if($tb=='Futbol'){
			$tb1='';
			$program_tip1=',program_tip';
			$program_tip=",'futbol'";
		}else if($tb=='Basketbol'){
			$tb1='b';
		}else if($tb=='Tenis'){
			$tb1='t';
		}else if($tb=='Hentbol'){
			$tb1='h';
		}else if($tb=='Hokey'){
			$tb1='o';
		}else if($tb==''){
			$tb1='';
		}
		$ligar = explode('-',$kupa_id);
		$kupa_id = $ligar[0];
		$ulke = $ligar[1];
		$tarihkes = explode('.',$trh);
		$saatkes  = explode(':',$saat);
		$mac_time = mktime($saatkes[0],$saatkes[1],0,$tarihkes[1],$tarihkes[0],$tarihkes[2]);
		$ver="insert into program$tb1 (ev_takim,konuk_takim,mac_kodu,mac_tarih,mac_time,adminid $program_tip1,kupa_id,ulke) 
		values ('$ev','$kt','$kod','$trh','$mac_time','".id."'$program_tip,'$kupa_id','$ulke')";
		$this->db->query($ver);
		redirect(base_url().'ayar/hizliduzenle?tablo='.$tb);
	}
	
	public function macgizlemedurum(){
		
		extract($_POST);
		if($tb=='Futbol'){
			$tb='';
		}else if($tb=='Basketbol'){
			$tb='b';
		}else if($tb==''){
			$tb='';
		}
		if($durum=='1'){
			$this->db->query("insert into oranver$tb (uye,tip,gizliler) values ('".id."','gizlimac','$id')");
		}else{
			$this->db->query("delete from oranver$tb where uye=".id." and tip='gizlimac' and gizliler='$id'");
		}	
	}
	
	public function mackaydet(){
		extract($_POST);
		if($kod && is_numeric($kod)){
			$mkodyaz=",$p='$kod'";
		}		
		if($tb=='Futbol'){
			$tb='';
		}else if($tb=='Basketbol'){
			$tb='b';
		}else if($tb=='Tenis'){
			$tb='t';
		}else if($tb=='Hentbol'){
			$tb='h';
		}else if($tb=='Hokey'){
			$tb='o';
		}else if($tb==''){
			$tb='';
		}
		if($trh){
			$tarihkes = explode('.',$trh);
			$saatkes  = explode(':',$saat);
			$mac_time = mktime($saatkes[0],$saatkes[1],0,$tarihkes[1],$tarihkes[0],$tarihkes[2]);
			$trhyaz=",mac_time='$mac_time',mac_tarih='$trh'";
		}
		$ver="update program$tb set ev_takim='$ev_takim',konuk_takim='$konuk_takim'$trhyaz $mkodyaz where id=$id";
		$this->db->query($ver);
	}
	
	public function hizliduzenle(){		
		if(yetki != 3 && yetki != 1){redirect(base_url().'hata');}
		$tb = $this->input->get('tablo');
		$this->smarty->assign('tipyok', 0);
		if($tb){		
			if($tb=='Futbol'){
				$gizver=",(select count(id) from oranver where uye=".id." and tip='gizlimac' and gizliler=a.id) as gizlimi";
				$tb='';
				$hangi='1';
			}else if($tb=='Basketbol'){
				$gizver=",(select count(id) from oranverb where uye=".id." and tip='gizlimac' and gizliler=a.id) as gizlimi";
				$tb='b';
				$hangi='2';
			}else if($tb=='Tenis'){
				$gizver='';
				$tb='t';
				$hangi='3';
			}else if($tb=='Hentbol'){
				$gizver='';
				$tb='h';
				$hangi='4';
			}else if($tb=='Hokey'){
				$gizver='';
				$tb='o';
				$hangi='5';
			}else if($tb==''){
				$gizver=",(select count(id) from oranver where uye=".id." and tip='gizlimac' and gizliler=a.id) as gizlimi";
				$tb='';
				$hangi='1';
			}
			$ver="select a.* $gizver
			from program$tb a order by a.mac_kodu asc ";
			$ouser = $this->db->query($ver);
			$this->smarty->assign('liste', $ouser->result());
			$sor = $this->db->query("select * from program_lig where hangi=$hangi");
			$bas='';
			foreach($sor->result() as $ass){
				$bas.="<option value='".$ass->id.'-'.$ass->lig_ulke."'>".$ass->lig_adi."</option>";
			}
			$this->smarty->assign('ligler', $bas);
		}else{
			$this->smarty->assign('tipyok', 1);
		}
		
		$this->smarty->view('hizli_duzenle.tpl');
	}
	
	public function taleplerdata(){
		ajaxvarmi();
		$tarih1 = basla_time($this->input->post('tarih1'));
		$tarih2 = bitir_time($this->input->post('tarih2'));
		$islemtip = $this->input->post('islemtip');
		if($userid){
			$user_ekle = " and user='$userid'"; 
		}
		
		if(!empty($islemtip)) { $islemtip_ekle = "and tip='$islemtip'"; } else { $islemtip_ekle = ""; }
		$ver="select pcek.*,(select username from kullanici where id=pcek.user) as bayi from pcek where admin=".id." $user_ekle and trh between '$tarih1' and '$tarih2' $islemtip_ekle order by id desc ";
		$sor = $this->db->query($ver);
		if($sor->num_rows()==0) { echo "<div class='bos'>".lang('bos')."</div>";exit; }?>
		<table class="tftable" cellspacing="0" cellpadding="0" style="width:100%">
		<thead><tr>
		<th width="150"><?=lang('byler');?></li>
		<th width="180"><?=lang('zmn');?></li>
		<th width="80">İsim</li>
		<th width="110"><?=lang('tc');?></li>
		<th width="110"><?=lang('bnk');?></li>
		<th><?=lang('iban');?></li>
		<th><?=lang('sube');?></li>
		<th><?=lang('hspno');?></li>
		<th><?=lang('ttr');?></li>
		</thead><tbody>
		<? foreach($sor->result_array() as $row){?>
		<tr>
		<td><?=$row['bayi']; ?></td>
		<td><?=date("d-m-Y H:i:s",$row['trh']); ?></li>
		<td ><?=$row['isim']; ?></li>
		<td ><?=$row['tc']; ?></li>
		<td ><?=$row['banka']; ?></li>
		<td ><?=$row['iban']; ?></li>
		<td ><?=$row['sube']; ?></li>
		<td ><?=$row['hesap']; ?></li>
		<td ><?=nf($row['tutar']); ?></li>
		<? } ?>
		</tbody></table>
		<?
		$sor->free_result();unset($sor);
	}
	
	public function talepler(){		
		if(yetki != 3){redirect(base_url().'hata');}
		$this->smarty->assign('bayilist',bayioption());
		$this->smarty->view('talepler.tpl');
	}
	
	public function bankadata(){
		
		if(yetki != 3){redirect(base_url().'hata');}
		$edit = $this->input->post('edit');
		$insert = $this->input->post('insert');
		
		if($edit==1){
	
			$sqlyaz="select * from bankalar order by id asc";
			$sql = $this->db->query($sqlyaz);
			foreach($sql->result_array() as $row){
				
				$banka = $_POST['banka_'.$row['id'].''];
				$isim = $_POST['isim_'.$row['id'].''];
				$sube = $_POST['sube_'.$row['id'].''];				
				$hesap = $_POST['hesap_'.$row['id'].''];				
				$iban = $_POST['iban_'.$row['id'].''];				
				if($banka=='Garanti'){
					$img='garantibank';
				}elseif($banka=='İşbank'){
					$img='isbank';
				}elseif($banka=='Vakıfbank'){
					$img='vakifbank';
				}elseif($banka=='Akbank'){
					$img='akbank';
				}elseif($banka=='Yapı Kredi'){
					$img='yapikredi';
				}elseif($banka=='Finansbank'){
					$img='finansbank';
				}elseif($banka=='Ziraat Bankası'){
					$img='ziraatbank';
				}elseif($banka=='Ptt Bank'){
					$img='pttbank';
				}elseif($banka=='TEB'){
					$img='tebbank';
				}
				//if($banka!=$row['banka'] || $isim!=$row['isim'] || $sube!=$row['sube']){
					$ver="update bankalar set img='$img',hesap='$hesap',iban='$iban',banka='$banka',isim='$isim',admin='".id."',sube='$sube' where id=$row[id]";
					$this->db->query($ver);
				//}
			}
			redirect(base_url().'ayar/bankahesaplari');
		}

		if($insert==1){	
			
				$banka = $this->input->post("banka");
				$isim = $this->input->post("isim");
				$sube = $this->input->post("sube");
				$hesap = $this->input->post("hesap");
				$iban = $this->input->post("iban");
				if($banka=='Garanti'){
					$img='garantibank';
				}elseif($banka=='İşbank'){
					$img='isbank';
				}elseif($banka=='Vakıfbank'){
					$img='vakifbank';
				}elseif($banka=='Akbank'){
					$img='akbank';
				}elseif($banka=='Yapı Kredi'){
					$img='yapikredi';
				}elseif($banka=='Finansbank'){
					$img='finansbank';
				}elseif($banka=='Ziraat Bankası'){
					$img='ziraatbank';
				}elseif($banka=='Ptt Bank'){
					$img='pttbank';
				}elseif($banka=='TEB'){
					$img='tebbank';
				}
				if(isset($banka,$isim,$sube,$hesap,$iban)){
					$ver="insert into bankalar (img,iban,hesap,banka,isim,admin,sube) values ('$img','$iban','$hesap','$banka','$isim','".id."','$sube')";
					$this->db->query($ver);
				}	
			redirect(base_url().'ayar/bankahesaplari');
		}
		
		if(isset($_GET['sil'])){	
	
			$silid = $this->input->get("sil");
			$ver="delete from bankalar where id=$silid";
			$this->db->query($ver);			
			redirect(base_url().'ayar/bankahesaplari');
		}
	}
	
	public function sistemikapat(){
		
		ajaxvarmi();
		if(yetki == 2 || yetki == 4){redirect(base_url().'hata');}
		$ver = $this->input->post('ver');	
		$ouser = $this->db->query("select ayarlar,id from kullanici ");
		foreach($ouser->result() as $row){
			$ayrv=unserialize($row->ayarlar);	
			$ayrv['sistemikapat']=$ver;
			$bayiAyari = $ayrv;
			$this->db->query("update kullanici set ayarlar='".$this->db->escape_str(serialize($bayiAyari))."' where id=".$row->id."");
		}
	}
	
	public function sistemayar(){
		
		ajaxvarmi();
		if(yetki != 1){redirect(base_url().'hata');}
		$ver = (int)$this->input->post('ne');	
		$h = (int)$this->input->post('h');	
		if($h=='1'){$skt="soket=".$ver."";}else{$skt='';}
		if($h=='2'){$ref="ref=".$ver."";}else{$ref='';}
		
		$this->db->query("update sistemayar set $skt $ref where id=1");
	}
	
	public function yasakla($yer){
		
		ajaxvarmi();
		if(yetki == 2 || yetki == 4){redirect(base_url().'hata');}
		$ne = $this->input->post('ne');
		
		$verb=$verd=$vers=$verw=0;
		if($yer=='Basket'){$verb=$ne;}else{$verb=baskapat;}
		if($yer=='Duello'){$verd=$ne;}else{$verd=dukapat;}
		/*if($yer=='Super'){$vers=$ne;}else{$vers=supkapat;}
		if($yer=='Bwin'){$verw=$ne;}else{$verw=bwinkapat;}*/
		
		$ouser = $this->db->query("select ayarlar,id from kullanici ");
		foreach($ouser->result() as $row){
			$ayrv=unserialize($row->ayarlar);	
			$ayrv['baskapat']=$verb;
			$ayrv['dukapat']=$verd;
			/*$ayrv['supkapat']=$vers;
			$ayrv['bwinkapat']=$verw;*/
			$bayiAyari = $ayrv;
			$this->db->query("update kullanici set ayarlar='".$this->db->escape_str(serialize($bayiAyari))."' where id=".$row->id."");
		}
	}
	
	public function aktifcanli($yer){
		
		ajaxvarmi();
		if(yetki == 2 || yetki == 4){redirect(base_url().'hata');}	
		$this->db->query("update sistemayar set aktifcanli='".$this->db->escape_str($yer)."' where id=1");
	}
		
	public function patron(){
		//echo CI_VERSION;exit;
		//echo $this->input->server('HTTP_HOST');exit;
		if(yetki != 1){redirect(base_url().'hata');}
		$ouser = $this->db->query("select ayarlar,id from kullanici ");
		foreach($ouser->result() as $row){
			$ayrv=unserialize($row->ayarlar);	
			$ayrv['tema']='0';
			$bayiAyari = $ayrv;
			$this->db->query("update kullanici set ayarlar='".$this->db->escape_str(serialize($bayiAyari))."' where id=".$row->id."");
		}
		exit;
		$bayiAyar = array(
				"tema"=> 0,				
				"baskapat"=> 0,				
				"dukapat"=> 0,			
				"sistemikapat"=> 0,
				"canli_koruma"=> '0.00',
				"ckelime"=> '',
				"kombine"=> '1',
				"kesinti"=> '0',
				"domain"=> '',
				"yazici"=> 'normal',
				"canli_dk_kes"=> '44',
				"canli_dk_kes1"=> '90',				
				"calisma_sekli"=> 0,				
				"komisyon"=> 0,
				"ccalisma_sekli"=> 0,
				"ckomisyon"=> 0,
				"canlibahis"=> 1,
				"futbol"=> 1,
				"duello"=> 1,
				"bonus"=> 1,
				"basketbol"=> 1,
				"iptal_sure"=> 0,
				"iptal_limit"=> 1,
				"maxodeme"=> 15000,
				"aynikuponmax"=> 5000,
				"sabitmbs"=> 0,
				"maxmac"=> 15,
				"tekmacmax"=> 1000,
				"canli_tekmac"=> 1000,
				"min_oran"=> '1.50',
				"maxoran"=> 1000,
				"minkupon"=> 2,
				"canli_kupon_sure"=> 2,
				"canli_sure"=> 15,
				"iptal_yetki"=> 1,
				"oranduzenleme"=> 1,
				"wyetki"=> 0,
				"alt_sinir"=> 100000,
				"silme_yetki"=> 1,
				"olusturma_zaman"=> date('d.m.Y H:i:s')
			);
		$this->db->query("update kullanici set ayarlar='".$this->db->escape_str(serialize($bayiAyar))."' where id=1");
		print_R($bayiAyar);
	}
	
	public function hesabim(){
		
		$this->smarty->view('hesabim.tpl');
	}
	public function yogunlukb(){
		
		if(yetki != 4 && yetki != 5){redirect(base_url().'hata');}
		$ver="SELECT ki.mac_kodu, ki.ev_takim, ki.konuk_takim, count( * ) AS totali, sum( k.yatan ) AS toplamyatan, sum( k.tutar ) AS toplamtutar, sum( k.toplam_mac ) AS toplammac
		FROM kuponlar k
		left join kupon_ic ki on k.id = ki.kupon_id		
		WHERE ki.spor_tip = 'futbol'
		AND k.durum = '1'
		GROUP BY ki.mac_kodu
		ORDER BY totali DESC limit 10";
		$ouser = $this->db->query($ver);
		
		$bas='<table border="0" cellpadding="0" cellspacing="1" style="width: 98%; margin-top: 50px;">
			<tr>
				<td style="width: 391px;" valign="top">
				<table border="0" cellpadding="0" cellspacing="1" style="border: 1px solid rgb(204, 204, 204);    border-radius: 6px;box-shadow: 0 1px 1px rgb(204, 204, 204);width: 97%;">
						<tr>
							<th colspan="4" class="thbaslik">EN ÇOK KUPON YAPILAN KARŞILAŞMALAR</th>
						</tr>
						<tr>
							<th class="thsi">Karşılaşma</th>
							<th class="thsi" width="40">Adet</th>
							<th class="thsi" width="40">Yüzde</th>
						</tr>';
		$topl=0;
		foreach($ouser->result() as $row){
			if(empty($row->toplammac) || empty($row->totali)) { $donecek = $yuzde = "0"; } else { 
				$c = $row->toplammac / 100; 
				$donecek = nf($row->totali/$c);
				$yuzde="%".nf($row->totali/$c)."";
			}
			$topl=$topl+$donecek;
			$bas.='<tr >	
				<td class="ictd">'.$row->mac_kodu.' - '.$row->ev_takim.' - '.$row->konuk_takim.'</td>	
				<td class="ictd">'.$row->totali.'</td>
				<td class="ictd">'.$yuzde.'</td>
				</tr>';
		}
		$bas.='<tr>	
		<td colspan="2" style="text-align: right !important" class="ictd">	Toplam Oynanma Yüzdeleri: </td>	
		<td style="text-align: center !important" class="ictd">% '.$topl.'</td></tr></table></td>';
		
		$bas.='<td valign="top" style="width: 390px;">
				<table border="0" cellpadding="0" cellspacing="1" style="border: 1px solid rgb(204, 204, 204);    border-radius: 6px;box-shadow: 0 1px 1px rgb(204, 204, 204);width: 100%;">
						<tr>
							<th class="thbaslik" colspan="4">EN ÇOK KUPON YAPTIĞIN KARŞILAŞMALAR</th>
						</tr>
						<tr>
							<th class="thsi">Karşılaşma</th>
							<th class="thsi" width="40">Adet</th>
							<th class="thsi" width="40">Yatırılan</th>
						</tr>';
						
		$ver="SELECT ki.mac_kodu, ki.ev_takim, ki.konuk_takim, count( * ) AS totali, sum( k.yatan ) AS toplamyatan, sum( k.tutar ) AS toplamtutar, sum( k.toplam_mac ) AS toplammac
		FROM kuponlar k
		left join kupon_ic ki on k.id = ki.kupon_id		
		WHERE k.user_id=".id."
		and ki.spor_tip = 'futbol'
		AND k.durum = '1'
		GROUP BY ki.mac_kodu
		ORDER BY toplamyatan DESC limit 10";
		$ouser = $this->db->query($ver);

		$topy=0;
		foreach($ouser->result() as $row){
			
			$topy=$topy + nf($row->toplamyatan);
			$bas.='<tr>	
				<td class="ictd">'.$row->mac_kodu.' - '.$row->ev_takim.' - '.$row->konuk_takim.'</td>	
				<td class="ictd">'.$row->totali.'</td>
				<td class="ictd">'.nf($row->toplamyatan).'</td></tr>';
		}
		$bas.='<tr>	
		<td colspan="2" style="text-align: right !important" class="ictd">	Toplam Yatırılan Miktar: </td>	
		<td style="text-align: right !important" class="ictd"> '.nf($topy).'</td></tr></table></td>';	
		$bas.='</tbody></table>
				</td>
				</tr></table>';
		$this->smarty->assign('bas',$bas);
		$this->smarty->view('yogunluk.tpl');
	}
	
	public function yogunluk(){
		
		if(yetki == 4 || yetki == 5){redirect(base_url().'hata');}
		if(yetki==3){$whr=" and k.adm_id=".id."";}else if(yetki==2){$whr=" and k.sup_id=".id."";}
		$ver="SELECT k.toplam_mac,ki.oran_tip,ki.mac_kodu, ki.ev_takim, ki.konuk_takim, count( * ) AS totali, sum( k.yatan ) AS toplamyatan, sum( k.tutar ) AS toplamtutar, sum( k.toplam_mac ) AS toplammac
		FROM kuponlar k
		left join kupon_ic ki on k.id = ki.kupon_id		
		WHERE ki.spor_tip = 'futbol'
		AND k.durum = '1'
		".$whr."
		GROUP BY ki.mac_kodu,ki.oran_val_id
		ORDER BY k.toplam_mac DESC limit 15";
		$ouser = $this->db->query($ver);
		
		$bas='<table border="0" cellpadding="0" cellspacing="1" style="width: 98%; margin-top: 50px;">
			<tr>
				<td style="width: 391px;" valign="top">
				<table border="0" cellpadding="0" cellspacing="1" style="border: 1px solid rgb(204, 204, 204);    border-radius: 6px;box-shadow: 0 1px 1px rgb(204, 204, 204);width: 97%;">
						<tr>
							<th colspan="4" class="thbaslik">
							EN ÇOK KUPON YAPILAN KARŞILAŞMALAR</th>
						</tr>
						<tr>
							<th class="thsi">Karşılaşma</th>
							<th class="thsi" width="40">Adet</th>
							<th class="thsi" width="80">Seçim</th>
							<th class="thsi" width="40">Yüzde</th>
						</tr>';
		$topl=0;
		foreach($ouser->result() as $row){
			if(empty($row->toplammac) || empty($row->totali)) { $donecek = $yuzde = "0"; } else { 
				$c = $row->toplammac / 100; 
				$donecek = nf($row->totali/$c);
				$yuzde="%".nf($row->totali/$c)."";
			}
			$or=explode('|',$row->oran_tip);
			$topl=$topl+$donecek;
			$bas.='<tr>	
				<td class="ictd"><b>'.$row->mac_kodu.'</b> - '.$row->ev_takim.' - '.$row->konuk_takim.'</td>	
				<td class="ictd">'.$row->toplam_mac.'</td>
				<td class="ictd"><b style="color:#FF0020;font-size:10px">'.$or[0].'</b><hr><b style="color:#000;font-size:9px">'.$or[1].'</b></td>
				<td class="ictd">'.$yuzde.'</td>
				</tr>';
		}
		$bas.='<tr>	
		<td style="text-align: right !important" class="ictd" colspan="3">Toplam Oynanma Yüzdeleri: </td>	
		<td style="text-align: center !important" class="ictd">% '.$topl.'</td></tr></table></td>';
		
		$bas.='<td valign="top" style="width: 390px;">
				<table border="0" cellpadding="0" cellspacing="1" style="border: 1px solid rgb(204, 204, 204);    border-radius: 6px;box-shadow: 0 1px 1px rgb(204, 204, 204);width: 100%;">
						<tr>
							<th class="thbaslik" colspan="4">EN ÇOK KUPON YATIRILAN KARŞILAŞMALAR</th>
						</tr>
						<tr>
							<th class="thsi">Karşılaşma</th>
							<th class="thsi" width="40">Adet</th>
							<th class="thsi" width="80">Seçim</th>
							<th class="thsi" width="40">Yatırılan</th>
						</tr>';
		
		$ver="SELECT ki.oran_tip,ki.mac_kodu, ki.ev_takim, ki.konuk_takim, count( * ) AS totali, sum( k.yatan ) AS toplamyatan, sum( k.tutar ) AS toplamtutar, sum( k.toplam_mac ) AS toplammac
		FROM kuponlar k
		left join kupon_ic ki on k.id = ki.kupon_id		
		WHERE ki.spor_tip = 'futbol'
		AND k.durum = '1'
		".$whr."
		GROUP BY ki.mac_kodu,ki.oran_val_id
		ORDER BY toplamyatan DESC limit 15";
		$ouser = $this->db->query($ver);
		
		$topy=0;
		foreach($ouser->result() as $row){
			
			$or=explode('|',$row->oran_tip);
			$topy=$topy + $row->toplamyatan;
			$bas.='<tr >	
				<td class="ictd"><b>'.$row->mac_kodu.'</b> - '.$row->ev_takim.' - '.$row->konuk_takim.'</td>	
				<td class="ictd">'.$row->totali.'</td>
				<td class="ictd"><b style="color:#FF0020;font-size:10px">'.$or[0].'</b><hr><b style="color:#000;font-size:9px">'.$or[1].'</b></td>
				<td class="ictd">'.nf($row->toplamyatan).'</td></tr>';
		}
		$bas.='<tr>	
		<td colspan="3" style="text-align: right !important" class="ictd">	Toplam Yatırılan Miktar: </td>	
		<td style="text-align: center !important" class="ictd"> '.nf($topy).'</td></tr></table></td>';	
		$bas.='</tbody></table>
				</td>
				</tr></table>';
		$this->smarty->assign('bas',$bas);
		$this->smarty->view('yogunluk.tpl');
	}
	
	public function bultenindir(){
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, 'http://eurosportt.net/bulten/bulten.pdf');
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		$data = curl_exec ($ch);
		
		$file = 'bulten.pdf';
		$fileName = 'fileName.pdf';
		file_put_contents($file, $data);
		
		header("Cache-Control: public");
		header("Content-Description: File Transfer");
		header("Content-Disposition: attachment; filename=$file");
		header("Content-Type: application/pdf");
		header("Content-Transfer-Encoding: binary");
		readfile($file);
	}
	
	public function index(){
		
		if(yetki != 1 && yetki != 3){redirect(base_url().'hata');}
		$sqlyaz="select * from bonus  ORDER BY `minm` ASC";
		$sql = $this->db->query($sqlyaz);
		/*$arr=array();
		foreach($sql->result() as $row){
			$arr[$row->mac][]= $row;
		}*/
		$this->smarty->assign('liste',$sql->result());
		$this->smarty->view('bonus.tpl');
	}
	
	public function macistatistikleri(){
		
		$this->smarty->view('macistatistikleri.tpl');
	}
	
	public function poker(){
		
		$this->smarty->view('poker.tpl');

	}
	
	public function rulet(){
		
		$this->smarty->view('rulet.tpl');

	}
	
	public function tombala(){
		
		$this->smarty->view('tombala.tpl');
	}
	public function takimistatistikleri(){
		
		$this->smarty->view('takimistatistikleri.tpl');
	}
	
	public function duyurular(){
		
		if(yetki == 4 || yetki == 5){redirect(base_url().'hata');}
		//if(yetki == 4){$user=patron.",".kendi.",".ustu;}else{$user=patron.",".id.",".ustu;}
		$sqlyaz="select * from duyurular  where user_id =".id." ORDER BY id desc";
		$sql = $this->db->query($sqlyaz);
		
		$this->smarty->assign('liste',$sql->result());
		$this->smarty->view('duyurular.tpl');
	}
	
	public function duyurudata(){
		
		if(yetki == 4 || yetki == 5){redirect(base_url().'hata');}
				
		if(isset($_GET['sil'])){	
			$silid = $this->input->get("sil");
			$ver="delete from duyurular where id=$silid";
			$this->db->query($ver);			
		}else{
			$duyuru = $this->input->post('duyuru');
			$this->db->query("insert into duyurular (user_id,username,mesaj) values ('".id."','".username."','$duyuru')");
		}
		redirect(base_url().'ayar/duyurular');
	}
	
	public function parayatir(){		
		$this->smarty->view('para_yatir.tpl');
	}
	public function paracekme(){		
		$this->smarty->view('para_cekme.tpl');
	}
	public function pcetir(){
		extract($_POST);	
		$arra = array("admin" => kendi,"user" => id,"isim" => $isim,"tc" => $tc,"banka" => $banka,"hesap" => $hesap,"sube" => $sube,"tutar" => $tutar,"iban" => $iban,"trh" => time(),"tip" => 1);
		$this->db->insert('pcek', $arra);
		//echo$this->db->last_query();
		if($this->db->affected_rows()){
			echo 'Talebiniz alındı';exit;
		}else{
			echo 'HATA Oluştu. Lütfen yeniden deneyiniz.';exit;
		}
	}
		
	public function pcetir_yatir(){
		extract($_POST);	
		$arra = array("admin" => kendi,"user" => id,"isim" => $isim,"mnot" => $not,"banka" => $banka,"hesap" => $hesap,"sube" => $sube,"tutar" => $tutar,"iban" => $iban,"trh" => time(),"tip" => 2);
		$this->db->insert('pcek', $arra);
		//echo$this->db->last_query();
		if($this->db->affected_rows()){
			echo 'Talebiniz alındı';exit;
		}else{
			echo 'HATA Oluştu. Lütfen yeniden deneyiniz.';exit;
		}
	}
		
	public function iptaltalepleri(){
		
		if(yetki == 4 || yetki == 5){redirect(base_url().'hata');}
		$ipid = (int)$this->input->get('ipid');
		$this->db->update('iptaltalep', array('okundu' =>1), array('ustid' =>id));
		if($ipid){
			$this->db->query("delete from iptaltalep where id=$ipid");
			redirect(base_url()."ayar/iptaltalepleri");
		}
		$bas='';
		$uyelerim='';
		if(yetki ==3) {
			$ver="select id,username from kullanici where durum=1 and yetki=4 and hesap_sahibi_id=".id." order by username asc";
			$sor = $this->db->query($ver);
			foreach($sor->result() as $ass){
				$bas.='<option value="'.$ass->id.'">'.$ass->username.'</option>';		
			}
		} 
		$this->smarty->assign('bayilist',$bas);
		$bas='';
		$tarih = $this->input->post('tarih');
		$tarih1 = $this->input->post('tarih1');
		$where='';
		if($tarih && $tarih1){
			
			$this->smarty->assign('ilkt',$tarih);
			$this->smarty->assign('ikit',$tarih1);
			$where.=" and tarih 
			BETWEEN ('$tarih 00:00:01') AND ('$tarih1 23:59:59')";
		}else{
			$this->smarty->assign('ilkt',date('Y-m-d'));
			$this->smarty->assign('ikit',date('Y-m-d'));
		}
		
		$sqlyaz="select *,
		(select username from kullanici where id=iptaltalep.bayiid) as useri,
		(select durum from kuponlar where id=iptaltalep.kuponid) as kupdurum
		from iptaltalep where ustid=".id."  $where ORDER BY `id` desc";
		$sql = $this->db->query($sqlyaz);
		
		$this->smarty->assign('liste',$sql->result());
		$this->smarty->view('iptal_talepleri.tpl');
	}
	
	public function iptallistesi(){
		
		if(yetki == 4 || yetki == 5){redirect(base_url().'hata');}
		$bver=bayioption();	
		$this->smarty->assign('bayilist',bayioption());
		$bver='';
		$this->smarty->view('iptallistesi.tpl');
	}
	public function iptallistesidata(){		
		
		ajaxvarmi();
		$tarih1 = basla_time($this->input->post('tarih1'));
		$tarih2 = bitir_time($this->input->post('tarih2'));
		$userid = $this->input->post('k_user');		
		$k_kuponno = $this->input->post('k_kuponno');
		
		$kupid='';
		if($k_kuponno){
			$kupid=" and kupon_id='$k_kuponno'";
		}
		
		if($userid){
			$ustler=1;
			$user_ekle = " kupon_user_id='$userid'"; 
		}else if(yetki != 4){
			$ustler=1;
			$user_ekle = " kupon_user_id in(".bayilerim(yetki,id).")"; 			
		}else{
			$ustler=0;
			$user_ekle = " kupon_user_id='".id."'"; 
		}
		if(yetki == 1){$user_ekle='id!=0';}
		$ver="select *,(select username from kullanici where id=iptal_listesi.kupon_user_id) as bayisi from iptal_listesi where $user_ekle and iptal_zaman between '$tarih1' and '$tarih2' $kupid order by `id` desc limit 100";	
		
		$sor = $this->db->query($ver);
		if($sor->num_rows()==0) { echo "<div class='bos'>".lang('bos')."</div>"; } else {			
		?>
		<table style="width:100%" class="tftable" cellspacing="0" cellpadding="0">
		<thead>
		<tr >
		<th class="t"><?=lang('kpno');?></td>
		<th class="t"><?=lang('trh');?></td>
		<th class="t"><?=lang('iptedn');?></td>
		<th class="t"><?=lang('byler');?></td>
		<th class="t">IP</td>
		</tr></thead><tbody>
		<? foreach($sor->result_array() as $row){
		
		?>
		<tr id="dac" style="display:none">
			<td>
				<div id="dialog<?=$row['id']; ?>" title="<?=lang('kupdetay'); ?>" style="display:none">
				  <? 
				  $don=unserialize($row['ic']);
				  echo "<table class='share-list1'><tr>
					<th>".lang('byler')."</th>
					<th>".lang('spr')."</th>
					<th>".lang('tkmadi')."</th>
					<th>".lang('trch')."</th>
					<th>".lang('oran')."</th>
					<th>".lang('odrm')."</th>
					</tr>";
				  foreach($don['kuponici'] as $k=>$verbe){
						echo '<tr>
						<td>'.$verbe['bayi'].'</td>
						<td>'.sporyaz($verbe['spor_tip']).'</td>
						<td>'.$verbe['takimlar'].'</td>
						<td>'.$verbe['tahmin'].'</td>
						<td>'.$verbe['oran'].'</td>
						<td>'.$verbe['durum'].'</td>						
						</tr>';
				  }
				  echo '</table>
				  <table class="share-list1">
				  <tr><th style="text-align:center">'.$don['kupon']['durum'].'</th></tr></table>';
				  ?>
				</div>
			</td>
		</tr>
		<tr>
		<td><a href="javascript:;" style="color:blue" onclick="detay('<?=$row['id']; ?>')">
		<abbr title="detay"><?=$row['kupon_id']; ?></abbr></a></td>
		<td><?=turkce_tarih($row['iptal_zaman']); ?> <?=date("H:i",$row['iptal_zaman']); ?></td>
		<td ><?=$row['iptal_username']; ?></td>
		<td ><?=$row['bayisi']; ?></td>
		<td ><?=$row['iptal_ip']; ?></td>
		</tr>
		<? } ?>
		</tbody>
		</table>
		<? }
		$sor->free_result();unset($sor);	
	}
	
	public function konusmalar(){
		
		if(yetki != 1){redirect(base_url().'hata');}
		$sor = $this->db->query("select id,username from kullanici where durum=1 order by username asc");
		$bas='';
		foreach($sor->result() as $ass){						
			$bas.='<option value="'.$ass->id.'">'.$ass->username.'</option>';	
		}
		
		$userler = $this->input->post('userler');
		$where='';
		if($userler){$where='where kim='.$userler.' or kime='.$userler.' ';}
		$sqlyaz="select mesaj.*,
		(select username from kullanici where id=mesaj.kim) as kim,
		(select username from kullanici where id=mesaj.kime) as kime
		from mesaj  $where ORDER BY `id` desc";
		$sql = $this->db->query($sqlyaz);
		
		$this->smarty->assign('liste',$sql->result());
		$this->smarty->assign('bayilist',$bas);
		$bas='';
		$this->smarty->view('destekhatti.tpl');
	}
	
	public function sistemdekiler(){
		
		if(yetki == 4 || yetki == 5){redirect(base_url().'hata');}
		
		$fark = time()-300;
		if(yetki!=1){
			$usu=" and (a.hesap_sahibi_id=".id." or a.hesap_root_id=".id.")";
		}else{
			$usu='';
		}
		$sqlyaz="SELECT a.username,a.tip,a.hesap_sahibi_user,a.sayfa,b.login_ip,b.login_tarayici,a.sonislem
		FROM kullanici a
		LEFT JOIN login_data b ON b.login_user = a.username
		WHERE a.sonislem>$fark and a.durum = '1'
		$usu
		GROUP BY a.username
		ORDER BY a.username ASC ";
		$sql = $this->db->query($sqlyaz);		
		$this->smarty->assign('liste',$sql->result());
		$this->smarty->assign('sayi',$sql->num_rows());
		$this->smarty->view('sistemdekiler.tpl');
	}
	
	public function hizlikodlar(){
		
		if(yetki != 1){redirect(base_url().'hata');}
		$orantip = $this->db->query("select * from oran_tip order by id asc");		
		$bas=$basb='';
		foreach($orantip->result() as $ass){
			$bas.='<div class="odorantip">'.$ass->tip_isim.'</div>
			<div class="duzentable">
				<ul class="head">
				<li>Tercih</li>
				<li>Tuş Adı</li>
				<li>Bağlı Tuş</li>
				</ul>';
			$orantipv = $this->db->query("select * from oran_val where oran_tip='".$ass->id."'");
			foreach($orantipv->result() as $ass1){
				
				$hgr = $this->db->query("select yenitus from hizligiris where oranvalid='".$ass1->id."' and tablo=''")->row();
				$bas.='<ul>				
				<li style="width:250px;">'.$ass1->oran_val.'</li>
				<li>
					<input type="text" size="4" class="inputbet" name="tus_'.$ass1->id.'" value="'.@$hgr->yenitus.'" maxlength="6"> 
				</li>
				<li style="width:250px;">'.@$hgr->yenitus.'</li>
				</ul>';
			}
			$bas.='</div><input type="hidden" name="fvarmi" value="2">';
		}
		
		$orantipb = $this->db->query("select * from oran_tipb order by id asc");		
		foreach($orantipb->result() as $ass){
			$basb.='<div class="odorantip">'.$ass->tip_isim.'</div>
			<div class="duzentable">
				<ul class="head">
				<li>Tercih</li>
				<li>Tuş Adı</li>
				<li>Bağlı Tuş</li>
				</ul>';
			$orantipvb = $this->db->query("select * from oran_valb where oran_tip='".$ass->id."'");
			foreach($orantipvb->result() as $ass1){
				
				$hgrb = $this->db->query("select yenitus from hizligiris where oranvalid='".$ass1->id."' and tablo='b'")->row();
				$basb.='<ul>				
				<li style="width:250px;">'.$ass1->oran_val.'</li>
				<li>
					<input type="text" size="4" class="inputbet" name="tusb_'.$ass1->id.'" value="'.@$hgrb->yenitus.'" maxlength="6"> 
				</li>
				<li style="width:250px;">'.@$hgrb->yenitus.'</li>
				</ul>';
			}
			$basb.='</div><input type="hidden" name="bvarmi" value="2">';
		}
		
		$this->smarty->assign('orantip',$bas);
		$this->smarty->assign('orantipb',$basb);
		$bas=$basb='';
		$this->smarty->view('hizlikod.tpl');
	}
	
	public function hizlikodtuslari(){

		$orantip = $this->db->query("select * from oran_tip order by id asc");		
		$bas=$basb='';
		foreach($orantip->result() as $ass){
			$bas.='<div class="odorantip">'.$ass->tip_isim.'</div>
			<div class="duzentable">
				<ul class="head">
				<li>Tercih</li>
				<li>Tuş Adı</li>
				</ul>';
			$orantipv = $this->db->query("select * from oran_val where oran_tip='".$ass->id."'");
			foreach($orantipv->result() as $ass1){
				
				$hgr = $this->db->query("select yenitus from hizligiris where oranvalid='".$ass1->id."' and tablo=''")->row();
				$bas.='<ul>				
				<li style="width:250px;">'.$ass1->oran_val.'</li>
				
				<li style="width:250px;">'.@$hgr->yenitus.'</li>
				</ul>';
			}
			$bas.='</div>';
		}
		
		$orantipb = $this->db->query("select * from oran_tipb order by id asc");		
		foreach($orantipb->result() as $ass){
			$basb.='<div class="odorantip">'.$ass->tip_isim.'</div>
			<div class="duzentable">
				<ul class="head">
				<li>Tercih</li>
				<li>Tuş Adı</li>
				</ul>';
			$orantipvb = $this->db->query("select * from oran_valb where oran_tip='".$ass->id."'");
			foreach($orantipvb->result() as $ass1){
				
				$hgrb = $this->db->query("select yenitus from hizligiris where oranvalid='".$ass1->id."' and tablo='b'")->row();
				$basb.='<ul>				
				<li style="width:250px;">'.$ass1->oran_val.'</li>
				
				<li style="width:250px;">'.@$hgrb->yenitus.'</li>
				</ul>';
			}
			$basb.='</div>';
		}
		
		$this->smarty->assign('orantip',$bas);
		$this->smarty->assign('orantipb',$basb);
		$bas=$basb='';
		$this->smarty->view('hizlikodtuslari.tpl');
	}
	
	public function hizligirisdata(){
		
		if(yetki != 1){redirect(base_url().'hata');}
		if(isset($_POST['fvarmi']) && isset($_POST['bvarmi'])) {$this->db->query("delete from hizligiris");}
		
		if(isset($_POST['fvarmi'])) {

			$s = $this->db->query("select * from oran_val");
			foreach($s->result_array() as $ass){
				$tus = $_POST['tus_'.$ass['id']];
				if($tus!="") {
					$this->db->query("insert into hizligiris (oranvalid,yenitus,tablo) values ('$ass[id]','$tus','')");	
				}
			}			
		}
		if(isset($_POST['bvarmi'])) {

			$s = $this->db->query("select * from oran_valb");
			foreach($s->result_array() as $ass){
				$tus = $_POST['tusb_'.$ass['id']];
				if($tus!="") {
					$this->db->query("insert into hizligiris (oranvalid,yenitus,tablo) values ('$ass[id]','$tus','b')");	
				}
			}
		}
		redirect(base_url().'ayar/hizlikodlar');
	}
	
	public function bonusdata(){
		
		if(yetki != 1 && yetki != 3){redirect(base_url().'hata');}
		$edit = $this->input->post('edit');
		$insert = $this->input->post('insert');
		
		if($edit==1){
	
			$sqlyaz="select * from bonus order by id asc";
			$sql = $this->db->query($sqlyaz);
			foreach($sql->result_array() as $row){
				
				$minm = $_POST['minm_'.$row['id'].''];
				$maxm = $_POST['maxm_'.$row['id'].''];
				$bonus = $_POST['bonus_'.$row['id'].''];				
				
				if($minm!=$row['minm'] || $maxm!=$row['maxm'] || $bonus!=$row['bonus']){
					$ver="update bonus set minm='$minm',maxm='$maxm',user='".id."',bonus='$bonus' where id=$row[id]";
					$this->db->query($ver);
					//echo $mac,$min,$max,$bonus;
				}
			}
			redirect(base_url().'ayar');
		}

		if($insert==1){	
			
				$minm = $this->input->post("minm");
				$maxm = $this->input->post("maxm");
				$bonusy = $this->input->post("bonusy");
				
				if(isset($minm,$maxm,$bonusy)){
					$ver="insert into bonus (minm,maxm,user,bonus) values ('$minm','$maxm','".id."','$bonusy')";
					$this->db->query($ver);
				}	
			redirect(base_url().'ayar');
		}
		
		if(isset($_GET['sil'])){	
	
			$silid = $this->input->get("sil");
			$ver="delete from bonus where id=$silid";
			$this->db->query($ver);			
			redirect(base_url().'ayar');
		}
	}
	
	public function hizligiris(){
		
		$mackodu = $this->input->post('mackodu');
		$secim = $this->input->post('secim');
		$bulten = $this->input->post('bulten');		
		$tablo = $this->input->post('tablo');		
		
		$ver="select oranvalid from hizligiris where yenitus='$secim' and tablo='$tablo'";
		$sorgu = $this->db->query($ver);
		if ($sorgu->num_rows() == 0) {die("5");}
		
			$bilgisi = $sorgu->row();
			$oran_val_id = $bilgisi->oranvalid;
			
			
			if($bulten=='hitit'){$kodver='a.mac_kodu';}else if($bulten=='iddaa'){$kodver='a.iddaa_kodu';}else{die("5");}
		
			$ver="call bulten$tablo (".kendi.",".ustu.",".patron.",' and $kodver=$mackodu',' a.id asc',' and b.oran_val_id in($oran_val_id)')";	
			$sor = $this->db->query($ver);
		
			if ($sor->num_rows() == 0) {die("5");}	
			
			$macbilgi = $sor->row();
			
			$this->db->close();
			$this->load->database();
			
			$mbs = $macbilgi->mbssi;
			$bol=explode('|',$macbilgi->sonoran);
			$orani = oranana_temizle($bol[1]);
			
			if($tablo=='b'){							
				$tipyaz='basketbol';
			}else{				
				$ligar=explode('|',$macbilgi->lig);
				if($ligar[1]=='Duello'){$tipyaz='duello';}else{$tipyaz='futbol';}				
			}		
			$encoded = $macbilgi->id.'|'.$macbilgi->mbs.'|'.$tipyaz;
			$kupon=$encoded."|$oran_val_id|$orani";
			
			$ici = "kupon('".codekupon("".$kupon."")."');";
			
			$donen = "
			<script>
			$(document).ready(function() {
			".$ici."
			});
			</script>
			";
			echo $donen;		
	}
	
}