<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class oranmerkezib extends CI_Controller {

	function __construct(){
		parent::__construct();
			logged_admin();
			if(yetki ==4 || oranduzenleme ==0 ){redirect(base_url().'hata');}
	}
	
	public function index(){
		
		$secim = $this->input->get('secim');
		
		if($secim==2){
			
			$gelen_lig = $this->input->get('lig');
			$ligar=array();
			$lig = $this->db->query("select lig_adi,id from program_lig where hangi=2");
			foreach($lig->result() as $row){
				$ligar[$row->lig_adi]= $row;
			}
			$this->smarty->assign('liglist',$lig->result());
			
			if($gelen_lig){
				$lig_bilgi = $this->db->query("select *,(if(EXISTS(SELECT gizliler FROM oranverb WHERE oranvalid=0 and lig_mac=0 and uye=".ustu." and gizliler=program_lig.id and tip='gizlilig'),1,
				if(EXISTS(SELECT gizliler FROM oranverb WHERE oranvalid=0 and lig_mac=0 and uye=".patron." and gizliler=program_lig.id and tip='gizlilig'),1,0))) as gizli from program_lig where id='$gelen_lig' and hangi=2")->row();
			
				//echo $this->db->last_query();	
				if($lig_bilgi->id=="") { 
					redirect(base_url()."oranmerkezib");
				}else{
					$this->smarty->assign('ligrow',$lig_bilgi);
				}
				$sorc = $this->db->query("select id from oranverb where (lig_mac=$gelen_lig or gizliler=$gelen_lig ) and uye=".sesionlar('id')."");
				if($sorc->num_rows()>0) {
					$this->smarty->assign('lgdegisik',1);
				}
			}
			
		}else if($secim==3){
			
			$mac_id = $this->input->get('mac_id');
			
			if($mac_id){
				$mac_bilgi = $this->db->query("select *,(if(EXISTS(SELECT gizliler FROM oranverb WHERE oranvalid=0 and lig_mac=0 and uye=".ustu." and gizliler=programb.id and tip='gizlimac'),1,
				if(EXISTS(SELECT gizliler FROM oranverb WHERE oranvalid=0 and lig_mac=0 and uye=".patron." and gizliler=programb.id and tip='gizlimac'),1,0))) as gizli 
				from programb where id='$mac_id'")->row();
			
				//echo $this->db->last_query();	
				if($mac_bilgi->id=="") { 
					redirect(base_url()."oranmerkezib");
				}else{
					$this->smarty->assign('macrow',$mac_bilgi);
				}
				$sorc = $this->db->query("select id from oranverb where (lig_mac=$mac_id or gizliler=$mac_id) and uye=".sesionlar('id')."");
				if($sorc->num_rows()>0) {
					$this->smarty->assign('mcdegisik',1);
				}
				$orantip = $this->db->query("select * from oranlarb where mac_db_id='$mac_id' order by oran_tip asc");
				$set1 = array();
				foreach($orantip->result() as $row){
					$ot = $this->db->query("select tip_isim from oran_tipb where id='".$row->oran_tip."' order by id asc")->row();
					$row->oran_vali = $this->db->query("select oran_val from oran_valb where id='".$row->oran_val_id."'")->row()->oran_val;
					$set1[$ot->tip_isim][]= $row;
				}
				//echo'<pre>';print_R($set1);
				$this->smarty->assign('orantip',$set1);
			}
			
		}else if($secim==14){
			
			$mac_id = $this->input->get('mac_id');
			
			if($mac_id){
				$mac_bilgi = $this->db->query("select *,(if(EXISTS(SELECT gizliler FROM coranverb WHERE oranvalid=0 and lig_mac=0 and uye=".ustu." and gizliler=canli_maclarb.eventid and tip='gizlimac'),1,
				if(EXISTS(SELECT gizliler FROM coranverb WHERE oranvalid=0 and lig_mac=0 and uye=".patron." and gizliler=canli_maclarb.eventid and tip='gizlimac'),1,0))) as gizli 
				from canli_maclarb where eventid='$mac_id'")->row();
				if($mac_bilgi->id=="") { 
					redirect(base_url()."oranmerkezib");
				}else{
					$this->smarty->assign('macrow',$mac_bilgi);
				}
				
				$sorc = $this->db->query("select id from coranverb where (lig_mac=$mac_id or gizliler=$mac_id) and uye=".sesionlar('id')."");
				if($sorc->num_rows()>0) {
					$this->smarty->assign('cdegisik',1);
				}else{
					$this->smarty->assign('cdegisik',0);
				}	
			}
			
		}else if($secim==1){
			
			$sorv = $this->db->query("select id from oranverb where lig_mac=0 and uye=".sesionlar('id')."");
			if($sorv->num_rows()>0) {
				$this->smarty->assign('alldegisik',1);
			}
		}else if($secim==13){
			
			$sorv = $this->db->query("select id from coranverb where lig_mac=0 and uye=".sesionlar('id')."");
			if($sorv->num_rows()>0) {
				$this->smarty->assign('alldegisikc',1);
			}
			
		}
		
		if($secim){
			if($secim==1 || $secim==2){
				$orantip = $this->db->query("select * from oran_tipb order by id asc");
				$set = array();
				foreach($orantip->result() as $ass){
					$orantipv = $this->db->query("select * from oran_valb where oran_tip='".$ass->id."'");
					$set[$ass->tip_isim]= $orantipv->result();
				}
				//echo'<pre>';print_R($set);
				$this->smarty->assign('orantip',$set);
			}else if($secim==13 || $secim==14){
				$orantipc = $this->db->query("select * from canli_tipb where durum=1 order by id asc");
				$this->smarty->assign('orantip',$orantipc->result());
			}
		}
		$this->smarty->view('oranmerkezib.tpl');
		 
	}
	
	public function allsil($secim,$id){
		
		if($secim=='1' && $id=='all'){
			$this->db->query("delete from oranverb where lig_mac=0 and uye=".sesionlar('id')."");
			redirect(base_url()."oranmerkezib/?secim=1");
		}else if($secim=='2' && $id!=''){
			$this->db->query("delete from oranverb where (lig_mac=$id or gizliler=$id) and uye=".sesionlar('id')."");
			redirect(base_url()."oranmerkezib/?secim=2&lig=".$id);
		}else if($secim=='3' && $id!=''){
			$this->db->query("delete from oranverb where (lig_mac=$id or gizliler=$id) and uye=".sesionlar('id')."");
			redirect(base_url()."oranmerkezib/?secim=3&mac_id=".$id);
		}else if($secim=='14' && $id!=''){
			$this->db->query("delete from coranverb where (lig_mac=$id or gizliler=$id) and uye=".sesionlar('id')."");
			redirect(base_url()."oranmerkezib/?secim=14&mac_id=".$id);
		}else if($secim=='13' && $id=='all'){
			$this->db->query("delete from coranverb where lig_mac=0 and uye=".sesionlar('id')."");
			redirect(base_url()."oranmerkezib/?secim=13");
		}
	}
	
	public function macbul(){
		
		$aranan = $this->input->post('arama');

		if(empty($aranan)) { echo "<div class='bos'>Lütfen bir arama terimi giriniz.<br>(Maç kodu, iddaa kodu, ev sahibi takım adı ya da deplasman takım adı olabilir.)</div>"; } else {

		$sor = $this->db->query("select * from programb where (mac_kodu like '%$aranan%' or iddaa_kodu like '%$aranan%' or ev_takim like '%$aranan%' or konuk_takim like '%$aranan%')");
		if($sor->num_rows()==0) { echo "<div class='bos'>Herhangi bir sonuç bulunamadı</div>"; } else {
		?>
		<div class="duzentable">
		<ul class="head">
		<li class="zaman"><?=lang('trh');?></li>
		<li><?=lang('tkmadi');?></li>
		<li>&nbsp;</li>
		</ul>
		<?
		foreach($sor->result_array() as $row){
		?>
		<ul>
		<li><?=date("d.m.Y H:i",$row['mac_time']); ?></li>
		<li><?="$row[ev_takim] - $row[konuk_takim]"; ?></li>
		<li><a href="javascript:;" onClick="self.location.href='?secim=3&mac_id=<?=$row['id']; ?>';" class="d2"><?=lang('edit');?></a></li>
		</ul>
		<? } ?>
		</div>
		<? } }
	}
	
	public function all(){
		
		//echo'<pre>';print_R($_POST);
		$seciliuser=sesionlar('id');
		$sqlver=$olmayan_oran='';
		$secimi = $this->input->post("secimi");
		$sabitmbs = $this->input->post("sabitmbs");
		$kontrol = $this->input->post("kontrol");
		
		if($kontrol=='all' && $secimi==1){
			
		$this->db->query("delete from oranverb where uye=$seciliuser and tip='baskettumligler'");
		$this->db->query("delete from oranverb where uye=$seciliuser and tip='gizlioran' and lig_mac=0");
		$this->db->query("delete from oranverb where uye=$seciliuser and tip='mbstum' and lig_mac=0");
		
		$sor = $this->db->query("select * from oran_valb");
		
		foreach($sor->result_array() as $row){
			
			$tipisim=$this->db->query("select tip_isim from oran_tipb where id=$row[oran_tip] limit 1")->row()->tip_isim;
			
			if(!isset($_POST['oranvals_'.$row['id'].''])) {
				$olmayan_oran .= "('$seciliuser','gizlioran','$row[id]','0'),";
				$kuponLogmaclig[] = array(
					'oran_adi' => $row['oran_val'],
					'oran_tip' => $tipisim	
				);
			}
			
			$gelen_oran = $this->input->post("oranval_".$row['id']."");
			if($gelen_oran!="0.00") {
				$degisimvar = 1;
				$sqlver.="('$seciliuser','baskettumligler','$row[id]','$gelen_oran','0'),";
				$kuponLogmaco[] = array(
					'oran_adi' => $row['oran_val'],
					'oran_tip' => $tipisim,
					'degisen_oran' => $gelen_oran
				);
			}
		}
			
		if($olmayan_oran) {		
			$olmayan_oran=substr($olmayan_oran,0,-1);
			$this->db->query("insert into oranverb (uye,tip,oranvalid,lig_mac) values $olmayan_oran");
			loglama1(serialize($kuponLogmaclig), "Basketbol Tüm Gizli Oran",'');
		}

		if($sabitmbs) {
			$this->db->query("insert into oranverb (uye,tip,lig_mac,mbs) values ('$seciliuser','mbstum','0','$sabitmbs')");
			$kuponLogmacmbs[] = array(
				'yeni_mbs' => $sabitmbs
			);
			loglama1(serialize($kuponLogmacmbs),"Basketbol Tüm Mbs",'');
		}
		
		if($degisimvar) {
			$sqlver=substr($sqlver,0,-1);
			$this->db->query("insert into oranverb (uye,tip,oranvalid,oran,lig_mac) values $sqlver");
			loglama1(serialize($kuponLogmaco), "Basketbol Tüm Değişiklikler",'');
		}
		}
		redirect(base_url()."oranmerkezib/?secim=".$secimi);
	}
	
	public function lig(){
		
		$sqlver=$olmayan_oran='';
		
		$seciliuser=sesionlar('id');
		$secimi = $this->input->post("secimi");
		$sabitmbs = $this->input->post("sabitmbs");
		$gelenlig = $this->input->post("lig");
		$lig_goster = $this->input->post("lig_goster");
		$kontrol = $this->input->post("kontrol");
		
		if($kontrol=='lig' && $secimi==2 and $gelenlig){
			
		$this->db->query("delete from oranverb where uye=$seciliuser and tip='basketlig' and lig_mac='$gelenlig'");
		$this->db->query("delete from oranverb where uye=$seciliuser and tip='gizlilig' and gizliler='$gelenlig'");
		$this->db->query("delete from oranverb where uye=$seciliuser and tip='gizlioran' and lig_mac='$gelenlig'");
		$this->db->query("delete from oranverb where uye=$seciliuser and tip='mbslig' and lig_mac='$gelenlig'");
		
		$sor = $this->db->query("select * from oran_valb");
		$ligibu=$this->db->query("select lig_adi from program_lig where id=$gelenlig and hangi=2 limit 1")->row()->lig_adi;
		
		foreach($sor->result_array() as $row){
			
			$adlar=$this->db->query("select tip_isim from oran_tipb where id=$row[oran_tip] limit 1")->row();
			
			if(!isset($_POST['oranvals_'.$row['id'].''])) {
				$olmayan_oran .= "('$seciliuser','gizlioran','$row[id]','$gelenlig'),";
				$kuponLogmaclig[] = array(
					'oran_adi' => $row['oran_val'],
					'oran_tip' => $adlar->tip_isim,
					'lig_adi' => $ligibu
					
				);
			}
			$gelen_oran = $this->input->post("oranval_".$row['id']."");
			if($gelen_oran!="0.00") {
				$degisimvar = 1;
				$sqlver.="('$seciliuser','basketlig','$row[id]','$gelen_oran','$gelenlig'),";
				$kuponLogmaco[] = array(
					'oran_adi' => $row['oran_val'],
					'oran_tip' => $adlar->tip_isim,
					'degisen_oran' => $gelen_oran,
					'lig_adi' => $ligibu
				);
			}
		}
			
		if($olmayan_oran) {		
			$olmayan_oran=substr($olmayan_oran,0,-1);
			$this->db->query("insert into oranverb (uye,tip,oranvalid,lig_mac) values $olmayan_oran");
			loglama1(serialize($kuponLogmaclig), "Basketbol Lig Bazlı Gizli Oran",'');
		}

		if($sabitmbs) {
			$this->db->query("insert into oranverb (uye,tip,lig_mac,mbs) values ('$seciliuser','mbslig','$gelenlig','$sabitmbs')");
			$kuponLogmacmbs[] = array(
					'yeni_mbs' => $sabitmbs,
					'lig_adi' => $ligibu				
				);
			loglama1(serialize($kuponLogmacmbs),"Basketbol Lig Bazlı Mbs",'');
		}
		
		if($lig_goster==1){
			$this->db->query("insert into oranverb (uye,tip,gizliler) values ('$seciliuser','gizlilig','$gelenlig')");
			$kuponLogmacgizle[] = array(
				'lig_adi' => $ligibu
			);
			loglama1(serialize($kuponLogmacgizle), "Basketbol Lig Gizleme",'');
		}
	
		if($degisimvar) {
			$sqlver=substr($sqlver,0,-1);
			$this->db->query("insert into oranverb (uye,tip,oranvalid,oran,lig_mac) values $sqlver");
			loglama1(serialize($kuponLogmaco), "Basketbol Lig Bazlı Değişiklikler",'');
		}
		}
		redirect(base_url()."oranmerkezib/?secim=".$secimi."&lig=".$gelenlig);
	}
	
	public function mac(){
		
		$sqlver=$olmayan_oran='';
		//echo'<pre>';print_R($_POST);
		$seciliuser=sesionlar('id');
		$kontrol = $this->input->post("kontrol");
		$secimi = $this->input->post("secimi");
		$sabitmbs = $this->input->post("sabitmbs");
		$gelenlig = $this->input->post("mac_id");
		$lig_goster = $this->input->post("lig_goster");
		
		if($kontrol=='mac' && $secimi==3 and $gelenlig){
		$this->db->query("delete from oranverb where uye=$seciliuser and tip='macbasket' and lig_mac='$gelenlig'");
		$this->db->query("delete from oranverb where uye=$seciliuser and tip='gizlimac' and gizliler='$gelenlig'");
		$this->db->query("delete from oranverb where uye=$seciliuser and tip='gizlioran' and lig_mac='$gelenlig'");
		$this->db->query("delete from oranverb where uye=$seciliuser and tip='mbsmac' and lig_mac='$gelenlig'");
		
		$sor = $this->db->query("select id,oran_val_id from oranlarb where mac_db_id='$gelenlig'");
		$kodubu=$this->db->query("select mac_kodu,mbs from programb where id=$gelenlig limit 1")->row();
		$mkodyaz=$kodubu->mac_kodu;
		
		foreach($sor->result_array() as $row){
			
			$adlar=$this->db->query("select oran_val,(select tip_isim from oran_tipb where id=oran_valb.oran_tip) as tip_isim from oran_valb where id=$row[oran_val_id] limit 1")->row();
			
			if(!isset($_POST['oranvals_'.$row['oran_val_id'].''])) {
				$olmayan_oran .= "('$seciliuser','gizlioran','$row[oran_val_id]','$gelenlig'),";
				$kuponLogmacg[] = array(
					'oran_adi' => $adlar->oran_val,
					'oran_tip' => $adlar->tip_isim,
					'mac_kodu' => $mkodyaz
				);
			}
			$gelen_oran = $this->input->post("oranval_".$row['id']."");
			if($gelen_oran && $gelen_oran!="0.00") {
				$degisimvar = 1;
				$sqlver.="('$seciliuser','macbasket','$row[oran_val_id]','$gelen_oran','$gelenlig'),";
				$kuponLogmac[] = array(
					'oran_adi' => $adlar->oran_val,
					'oran_tip' => $adlar->tip_isim,
					'orjinal_oran' => $row['oran'],
					'yeni_oran' => $gelen_oran,
					'mac_kodu' => $mkodyaz
				);
			}
		}
			
		if($olmayan_oran) {		
			$olmayan_oran=substr($olmayan_oran,0,-1);
			$this->db->query("insert into oranverb (uye,tip,oranvalid,lig_mac) values $olmayan_oran");
			loglama1(serialize($kuponLogmacg), "Basketbol Maç Bazlı Gizli Oran",$mkodyaz);
		}

		if($sabitmbs) {
			$this->db->query("insert into oranverb (uye,tip,lig_mac,mbs) values ('$seciliuser','mbsmac','$gelenlig','$sabitmbs')");
			$kuponLogmacmbs[] = array(
					'orjinal_mbs' => $kodubu->mbs,
					'yeni_mbs' => $sabitmbs,
					'mac_kodu' => $mkodyaz
				);
			loglama1(serialize($kuponLogmacmbs),"Basketbol Maç Bazlı Mbs",$mkodyaz);
		}
		
		if($lig_goster==1){
			$this->db->query("insert into oranverb (uye,tip,gizliler) values ('$seciliuser','gizlimac','$gelenlig')");
			$kuponLogmacgizle[] = array(
				'mac_kodu' => $mkodyaz
			);
			loglama1(serialize($kuponLogmacgizle), "Basketbol Maç Gizleme",$mkodyaz);
		}
	
		if($degisimvar) {
			$sqlver=substr($sqlver,0,-1);
			$this->db->query("insert into oranverb (uye,tip,oranvalid,oran,lig_mac) values $sqlver");
			loglama1(serialize($kuponLogmac), "Basketbol Maç Bazlı Değişiklikler",$mkodyaz);
		}
		}
		redirect(base_url()."oranmerkezib/?secim=".$secimi."&mac_id=".$gelenlig);
	}
	
	public function canli_b(){
		
		$fark = time()-360;
		$sor = $this->db->query("select * from canli_maclarb where songuncelleme>$fark and yer='Bwin' order by CAST(dakika AS UNSIGNED) asc");
		//where songuncelleme>$fark
		if($sor->num_rows()==0) { echo "<div class='bos'>Herhangi bir maç bulunamadı</div>"; } else {
		?>
		<div class="duzentable">
		<ul class="head">
		<li class="kodu"><?=lang('dk');?></li>
		<li class="zaman"><?=lang('dvre');?></li>
		<li><?=lang('tkmadi');?></li>
		<li>&nbsp;</li>
		</ul>
		<?
		foreach($sor->result_array() as $row){
		?>
		<ul>
		<li><? if($row['devremi']=="1") { echo "Devre"; } else { echo $row['dakika']; } ?></li>
		<li><?=$row['devre']; ?></li>
		<li><?="$row[ev_takim] - $row[konuk_takim]"; ?></li>
		<li><a href="javascript:;" onClick="self.location.href='?secim=14&mac_id=<?=$row['eventid']; ?>';" class="d2"><?=lang('edit');?></a></li>
		</ul>
		<? } ?>
		</div>
		<? }
	}
	
	public function mac_c(){
		
		$sqlver=$olmayan_oran='';
		//echo'<pre>';print_R($_POST);
		$seciliuser=sesionlar('id');
		$kontrol = $this->input->post("kontrol");
		$secimi = $this->input->post("secimi");
		$gelenlig = $this->input->post("mac_id");
		$lig_goster = $this->input->post("lig_goster");
		$aski = $this->input->post("aski");
		
		if($kontrol=='mac_c' && $gelenlig){
		
		$this->db->query("delete from coranverb where uye=$seciliuser and tip='macbasket' and lig_mac='$gelenlig'");
		$this->db->query("delete from coranverb where uye=$seciliuser and tip='gizlimac' and gizliler='$gelenlig'");
		$this->db->query("delete from coranverb where uye=$seciliuser and tip='aski' and gizliler='$gelenlig'");
		$this->db->query("delete from coranverb where uye=$seciliuser and tip='gizlioran' and lig_mac='$gelenlig'");
		
		$sor = $this->db->query("select * from canli_oranb where mac_id='$gelenlig' group by canli_tip");
		$degisimvar = 0;
		
		foreach($sor->result_array() as $row){
			
			if(!isset($_POST['oranvals_'.$row['canli_tip'].''])) {
				$olmayan_oran .= "('$seciliuser','gizlioran','$row[canli_tip]','$gelenlig'),";
			}
			$gelen_oran = $this->input->post("oranval_".$row['canli_tip']."");
			if($gelen_oran && $gelen_oran!="0.00") {
				$degisimvar = 1;
				$sqlver.="('$seciliuser','macbasket','$row[canli_tip]','$gelen_oran','$gelenlig'),";
			}
		}
			
		if($olmayan_oran) {		
			echo$olmayan_oran=substr($olmayan_oran,0,-1);
			$this->db->query("insert into coranverb (uye,tip,oranvalid,lig_mac) values $olmayan_oran");
		}

		if($lig_goster==1){
			$this->db->query("insert into coranverb (uye,tip,gizliler) values ('$seciliuser','gizlimac','$gelenlig')");
		}
		
		if($aski==1){
			$this->db->query("insert into coranverb (uye,tip,gizliler) values ('$seciliuser','aski','$gelenlig')");
		}
	
		if($degisimvar) {
			$sqlver=substr($sqlver,0,-1);
			$this->db->query("insert into coranverb (uye,tip,oranvalid,oran,lig_mac) values $sqlver");
		}
		}
		redirect(base_url()."oranmerkezib/?secim=".$secimi."&mac_id=".$gelenlig);
	}
	
	public function mac_call(){
		
		$sqlver=$olmayan_oran='';
		//echo'<pre>';print_R($_POST);
		$seciliuser=sesionlar('id');
		$kontrol = $this->input->post("kontrol");
		$secimi = $this->input->post("secimi");
		
		if($kontrol=='mac_call' && $secimi==13){
		
		$this->db->query("delete from coranverb where uye=$seciliuser and tip='tumcanli'");
		$this->db->query("delete from coranverb where uye=$seciliuser and tip='gizlioran' and lig_mac=0");
		
		$sor = $this->db->query("select id from canli_tipb where durum=1");
		$degisimvar = 0;
		
		foreach($sor->result_array() as $row){
			
			$tipver = $row['id'];
			
			if(!isset($_POST['oranvals_'.$tipver.''])) {
				$olmayan_oran .= "('$seciliuser','gizlioran','$tipver','0'),";
			}
			$gelen_oran = $this->input->post("oranval_".$tipver."");
			if($gelen_oran && $gelen_oran!="0.00") {
				$degisimvar = 1;
				$sqlver.="('$seciliuser','tumcanli','$tipver','$gelen_oran','0'),";
			}
		}
			
		if($olmayan_oran) {		
			$olmayan_oran=substr($olmayan_oran,0,-1);
			$this->db->query("insert into coranverb (uye,tip,oranvalid,lig_mac) values $olmayan_oran");
		}

		if($degisimvar) {
			$sqlver=substr($sqlver,0,-1);
			$this->db->query("insert into coranverb (uye,tip,oranvalid,oran,lig_mac) values $sqlver");
		}
		}
		redirect(base_url()."oranmerkezib/?secim=".$secimi);
	}

}
