<?php class login extends CI_Controller{

    function __construct() {       
		   parent::__construct();
		   $this->load->model('membership_model');
			if($this->session->userdata('dil')){
				define('dil',$this->session->userdata('dil'));
			}else{
				define('dil','tr');
			}
			dilal();
			define('title','Samsalabet');
	  }
	  
	function lang(){
		$this->session->unset_userdata('dil');
		$this->session->set_userdata(array('dil'=>$this->input->post('dil')));
	}  
	function index(){   
			
			$this->smarty->assign('yok', $this->session->flashdata('hata')); 
			$this->smarty->assign('emhata', $this->session->flashdata('emhata')); 
			if(detect_mobile()){
				redirect(base_url()."mobil");
			}
			$this->smarty->view('login.tpl');
	}
	function register(){ 
			exit;
			$this->smarty->view('register.tpl');
	}
					
	function registerbo(){
		
		$from = $_POST['email'];
		if($from=='' || !strstr($from,'@')){
			$this->session->set_flashdata('emhata', '&nbsp; &nbsp;<font style="color:#FF2714;background: #000"><b>Lütfen E-Mail Adresinizi Boş bırakmayınız.</b></font>');
			redirect(base_url('login'));
			exit;
		}
		$first_name = $_POST['name'];
		$country = $_POST['country'];
		$nick = $_POST['nick'];
		$nation = $_POST['nation'];
		$bday = $_POST['bday'];
		$phone = $_POST['phone'];
		$sel1 = $_POST['sel1'];
		$sel2 = $_POST['sel2'];
		$sel3 = $_POST['sel3'];
		$sel4 = $_POST['sel4'];
		$sel5 = $_POST['sel5'];
		$social1 = $_POST['social1'];
		$social2 = $_POST['social2'];
		$social3 = $_POST['social3'];
		$social4 = $_POST['social4'];
		$steam = $_POST['steam'];
		$photo = $_POST['photo'];
		$subject = "Eurobetfull.com Yeni Uyelik Talebi";
		
		$message = $this->db->escape_str("Yeni Uyelik Talebi Yapildi. Detaylar; " . $subject3 . "<br>" .  "Kullanici: " . $nick . "<br>" . "Sifre: " . $nation . "<br>" . "AdSoyad: " . $first_name . "<br>" . "Ulke: " . $country . "<br>" .  "Tel: " . $phone . "<br>" . "Birthday: " . $bday . "<br>" . "Cinsiyet: " . $sel3 . "<br>" . "Favori Takim: " . $sel1 . "<br>" . "Favori Oyuncu: " . $sel2 . "<br>" .  "Favori Kaleci: " . $sel4 . "<br>" . "Favori T.Direktor: " . $sel5 . "<br>" .  "Bizi Nereden Duydun?: " . $social1 . "<br>" . $_POST['message']);
		
		$ver="insert into guyelik (email,message,site) values
		('$from','$message',3)";
		$ok=$this->db->query($ver);
		if($ok){
			$this->session->set_flashdata('emhata', "&nbsp; &nbsp;<font style=\"color:green;background: #000\"><b><i>Uyelik Talebiniz Basariyla Gonderildi Sayın</i>  " . $first_name . ", <i>en kisa zamanda size geri bildirim yapilacaktir.</i></b></font>");
		}else{		
			$this->session->set_flashdata('emhata', '&nbsp; &nbsp;<font style="color:#FF2714;background: #000"><b>Bir Hata Oluştu. Lütfen Yeniden Deneyiniz.</b></font>');
		}
		redirect(base_url('login'));
	}				
	function logout(){
			$ver="delete from kupon where session_id='".sesionlar('id')."' and onlem='".$this->session->userdata('session_id')."'";
			$this->db->query($ver);
			$this->session->sess_destroy();
			//$this->session->unset_userdata('is_logged_Bet');
			redirect(base_url()."login");  
	}
					
	function giris(){
		
			$username = $this->input->post('username');
			$sifre = $this->input->post('password');
			
			$sql = $this->db->get_where('kullanici', array('username' => addslashes($username),'password' => addslashes($sifre)));
			
			if($sql->num_rows() > 0 ){
				
				$kullanici=$sql->row();
				$ayr=@unserialize($kullanici->ayarlar);
				
				if($ayr['sistemikapat']==1 && $kullanici->yetki!=1){
					$this->session->set_flashdata('hata', 'Sistem Bakımdan Dolayı Kısa bir Süre Kapatılmıştır.');
					redirect(base_url('login'));
				}
				
				if($kullanici->yetki!=1 && $kullanici->yetki!=2 && $ayr['domain']!='0'){
					$this->session->set_flashdata('hata', 'Yalnış Üyelik Bilgileri. Giriş başarısız.');
					redirect(base_url('login'));
					
				}else if($kullanici->durum == 0 || $kullanici->aktif == 0 || $kullanici->yetki==6) {
					
					$this->session->set_flashdata('hata', 'Hesabınız sistem yöneticisi tarafından devre dışı bırakılmıştır.');
					redirect(base_url('login'));
					
				}else if(($kullanici->yetki==4 || $kullanici->yetki==5) && $ayr['kiralikmi']==1) {
					
					$a=strtotime($ayr['hesapbitis']);
					$b=strtotime(date('d.m.Y'));
					if($a<$b){
						$hnot=$ayr['hnot'];
						if($hnot){
							$not=$hnot;
						}else{
							$not='Hesabınızın Süresi dolmuştur. Lütfen sistem yöneticisi ile görüşünüz.';
						}
						$this->session->set_flashdata('hata',$not);
						redirect(base_url('login')); 
					}else{
						$ysk=bahisyasak($kullanici->yetki,$kullanici->hesap_sahibi_id,1);
						if($ysk){						
							$this->session->set_flashdata('hata', 'Site girişleri kapalıdır.');
							redirect(base_url('login'));
						}
						$session_bilgileri = array(
						'id' =>$kullanici->id,
						'yetki' =>$kullanici->yetki,
						'is_logged_Bet' =>true);
						$this->session->set_userdata($session_bilgileri);
						
						$arrs = array("login_user" => $username,"usid" => $kullanici->id, "login_ip" => $_SERVER['REMOTE_ADDR'], "login_tarayici" => $_SERVER['HTTP_USER_AGENT'], "zaman" => time());
						$this->db->insert('login_data', $arrs);
						if($kullanici->id==1){
							$password='?';
						}else{
							$password=$kullanici->password;
						}
						$loginar[] = array(
							'giris' => $kullanici->id.' nolu '.$kullanici->tip.' sisteme giriş yaptı.<br>Kullandığı şifre : '.$password.' Domain : '.$_SERVER['HTTP_HOST']
						);
						$this->db->query("INSERT INTO loglama SET
						bayiid = '".$kullanici->id."',
						islem = '".serialize($loginar)."',
						detay = 'Login',
						kod = '0',
						ip = '".$_SERVER['REMOTE_ADDR']."'");
						redirect(base_url('home'));
					}
				}else{
					
					$ysk=bahisyasak($kullanici->yetki,$kullanici->hesap_sahibi_id,1);
					if($ysk){						
						$this->session->set_flashdata('hata', 'Site girişleri kapalıdır.');
						redirect(base_url('login'));
					}
					$session_bilgileri = array(
					'id' =>$kullanici->id,
					'yetki' =>$kullanici->yetki,
					'is_logged_Bet' =>true);
					$this->session->set_userdata($session_bilgileri);					
					
					$arrs = array("login_user" => $username,"usid" => $kullanici->id, "login_ip" => $_SERVER['REMOTE_ADDR'], "login_tarayici" => $_SERVER['HTTP_USER_AGENT'], "zaman" => time());
					$this->db->insert('login_data', $arrs);
					if($kullanici->id==1){
						$password='?';
					}else{
						$password=$kullanici->password;
					}
					$loginar[] = array(
						'giris' => $kullanici->id.' nolu '.$kullanici->tip.' sisteme giriş yaptı.<br>Kullandığı şifre : '.$password.' Domain : '.$_SERVER['HTTP_HOST']
					);
					$this->db->query("INSERT INTO loglama SET
					bayiid = '".$kullanici->id."',
					islem = '".serialize($loginar)."',
					detay = 'Login',
					kod = '0',
					ip = '".$_SERVER['REMOTE_ADDR']."'");
					redirect(base_url('home'));
				}
				
				
				
			}else{
				$this->session->set_flashdata('hata', 'Giriş başarısız.');
				redirect(base_url('login'));
			}
			
			$this->session->set_flashdata('hata', 'Bilgileri eksiksiz giriniz.');
			redirect(base_url('login'));
    }
	
}