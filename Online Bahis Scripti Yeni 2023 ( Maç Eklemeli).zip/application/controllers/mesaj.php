<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class mesaj extends CI_Controller {

	function __construct(){
		parent::__construct();
			logged_admin();
	}
	
	public function index(){
		
		$bas='';
		$silinen="and username not like '%_silindi%'";
		//if(yetki!=1){$bas.='<option value="1">Sistem</option>';}
		if(yetki==5){
			
			$ver="select username,tip,id from kullanici where id =".hesap_sahibi_id." and durum=1 $silinen order by username asc";
			$sql = $this->db->query($ver);				
			$bas.='<optgroup label="'.lang('byler').'">';
			foreach($sql->result() as $ass){
				$bas.='<option value="'.$ass->id.'">'.$ass->username.'</option>';
			}
			$bas.='</optgroup>';
		}else if(yetki==4 && wyetki == 0){
			
			$ver="select username,tip,id from kullanici where id =".kendi." and durum=1 $silinen order by username asc";
			$sql = $this->db->query($ver);				
			$bas.='<optgroup label="'.lang('admler').'">';
			foreach($sql->result() as $ass){
				$bas.='<option value="'.$ass->id.'">'.$ass->username.'</option>';
			}
			$bas.='</optgroup>';
		}else if(yetki==4 && wyetki == 1){			
			
			$ver="select username,tip,id from kullanici where id =".kendi." and durum=1 $silinen order by username asc";
			$sql = $this->db->query($ver);				
			$bas.='<optgroup label="'.lang('admler').'">';
			foreach($sql->result() as $ass){
				$bas.='<option value="'.$ass->id.'">'.$ass->username.'</option>';
			}
			$bas.='</optgroup>';
			$verw="select username,tip,id from kullanici where hesap_sahibi_id =".id." and durum=1 $silinen order by username asc";
			$sqlw = $this->db->query($verw);				
			$bas.='<optgroup label="'.lang('webler').'">';
			foreach($sqlw->result() as $assw){
				$bas.='<option value="'.$assw->id.'">'.$assw->username.'</option>';
			}
			$bas.='</optgroup>';
			
		}else if(yetki==3){
			$vera="select username,tip,id from kullanici where id = ".ustu." and durum=1 $silinen order by username asc";
			$sqla = $this->db->query($vera);	
			$bas.='<optgroup label="'.lang('suadmler').'">';
			foreach($sqla->result() as $assa){
				$bas.='<option value="'.$assa->id.'">'.$assa->username.'</option>';
			}
			$bas.='</optgroup>';
			$vera1="select username,tip,id from kullanici where hesap_sahibi_id =".kendi." and durum=1 $silinen order by username asc";
			$sqla1 = $this->db->query($vera1);
			$bas.='<optgroup label="'.lang('byler').'">';			
			foreach($sqla1->result() as $assa1){
				$bas.='<option value="'.$assa1->id.'">'.$assa1->username.'</option>';
			}
			$bas.='</optgroup>';
		}else if(yetki==2){
			$vers="select username,tip,id from kullanici where hesap_sahibi_id =".kendi." and durum=1 $silinen order by username asc";
			$sqlas = $this->db->query($vers);
			$bas.='<option value="1">Sistem</option>';			
			$bas.='<optgroup label="'.lang('admler').'">';	
			foreach($sqlas->result() as $asss){
				$bas.='<option value="'.$asss->id.'">'.$asss->username.'</option>';
			}
			$bas.='</optgroup>';
			$veras="select username,tip,id from kullanici where hesap_root_id =".kendi." and durum=1 $silinen order by username asc";
			$sqlas1 = $this->db->query($veras);
			$bas.='<optgroup label="'.lang('byler').'">';			
			foreach($sqlas1->result() as $assas){
				$bas.='<option value="'.$assas->id.'">'.$assas->username.'</option>';
			}
			$bas.='</optgroup>';
		}else if(yetki==1){
			$verp="select username,tip,id from kullanici where yetki=2 and durum=1 $silinen order by username asc";
			$sqlap = $this->db->query($verp);	
			$bas.='<optgroup label="'.lang('suadmler').'">';		
			foreach($sqlap->result() as $asp){
				$bas.='<option value="'.$asp->id.'">'.$asp->username.'</option>';
			}
			$bas.='</optgroup>';
			/*$verasa="select username,tip,id from kullanici where yetki=3 and durum=1 $silinen order by username asc";
			$sqlas1a = $this->db->query($verasa);
			$bas.='<optgroup label="Adminler">';			
			foreach($sqlas1a->result() as $assasa){
				$bas.='<option value="'.$assasa->id.'">'.$assasa->username.'</option>';
			}
			$bas.='</optgroup>';
			$verasb="select username,tip,id from kullanici where yetki=4 and durum=1 $silinen order by username asc";
			$sqlas1b = $this->db->query($verasb);
			$bas.='<optgroup label="Bayiler">';			
			foreach($sqlas1b->result() as $assasb){
				$bas.='<option value="'.$assasb->id.'">'.$assasb->username.'</option>';
			}
			$bas.='</optgroup>';
			$verw="select username,tip,id from kullanici where yetki=4 and durum=1 $silinen order by username asc";
			$sqlw = $this->db->query($verw);				
			$bas.='<optgroup label="Web Bayi">';
			foreach($sqlw->result() as $assw){
				$bas.='<option value="'.$assw->id.'">'.$assw->username.'</option>';
			}
			$bas.='</optgroup>';*/
		}
		
		$this->smarty->assign('bayilist',$bas);
		$bas='';
		$this->smarty->view('mesaj.tpl');
	}
	
	function sanitize($text) {
		$text = htmlspecialchars($text, ENT_QUOTES);
		$text = str_replace("\n\r","\n",$text);
		$text = str_replace("\r\n","\n",$text);
		$text = str_replace("\n","<br>",$text);
		return $text;
	}
	
	public function mesajdata(){
		
		ajaxvarmi();		
		$sqle = "update mesaj set okundu=1 where kime=".id." AND okundu = '0'";
		$this->db->query($sqle);
		$sqlyaz="select a.*,k.username as gonderen,ki.username as alici from mesaj a
		left join kullanici k on k.id=a.kim
		left join kullanici ki on ki.id=a.kime
		where (a.kim=".id." and a.gsil =0 ) or (a.kime=".id." and a.asil =0 )
		ORDER BY a.id desc";
		$sql = $this->db->query($sqlyaz);
		
		$liste='';
		foreach($sql->result() as $rowu){			
			
			if($rowu->kim == id ){				
				if($rowu->gsil == 1){
					//continue;
				}
			}
			if($rowu->kime == id ){
				if($rowu->asil == 1){				
					//continue;
				}
			}
			
			
			if($rowu->kime == id){
				$cyaz='<a href="javascript:;" class="cevapla" id="'.$rowu->kim.'" style="color:green">'.lang('msjcvp').'</a> /';
			}else{
				$cyaz='';
			}
			$liste.='<div class="p_blk">
						
					<div style="min-height: 50px">
						<p class="uye_ad">
						<font color="#000">'.$rowu->gonderen.' => '.$rowu->alici.'</font>
						<span style="float:right;">
						'.$cyaz.'
						<a href="javascript:;" style="color:red" id="tumu" rel="'.$rowu->id.'">'.lang('sil').'</a>
						</span>
						</p>
						<p class="p_wrt"><b>'.lang('msjtxt').'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:</b>
						 '.$rowu->mesaj.'
						<span style="float:right;">'.$rowu->tarih.'</span>
						
					</div>
					
					<div class="clear"></div>';                       
                    /*$grp="select a.*,k.username from mesaj a
					left join kullanici k on k.id=a.kim
					where a.id!=".$rowu->id." and 
					(a.kime=".$rowu->kime." and a.kim=".$rowu->kim.") or (a.kime=".$rowu->kim." and a.kim=".$rowu->kime.")
					and a.durum=0
					ORDER BY a.id desc";
					$ss = $this->db->query($grp);
			foreach($ss->result() as $row){   
				  $liste.='<div style="" id="yorumAlan9" class="yorum_alan">
						<p>
							'.$row->username.'
							<span style="float:right">sil</span>							
						</p>
						'.$row->mesaj.'
					  
				  </div>';
			}*/
			$liste.='</div>';
		}
		if($liste){echo$liste;}else{echo lang('bos');}
		$liste='';
	}
	
	public function kaydet() {
		
		$kime = $this->input->post('kime');
		$message = $this->input->post('mesaj');
		$messagesan = $this->sanitize($message);
		
		$sql = "insert into mesaj (kim,kime,mesaj,tarih,okundu) values ('".id."', '".addslashes($kime)."','".addslashes($messagesan)."',NOW(),'0')";
		$query = $this->db->query($sql);
		redirect(base_url().'mesaj');
	}
	
	public function ajaxveri(){
		
		ajaxvarmi();
		$responce['msg'] = $responce['tlp'] = 0;
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, 'http://mybahis.net/livebt/mesaj_json.php');
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		$data = curl_exec ($ch);
		$v= json_decode($data);
		foreach($v->msg as $uye=>$d){
			//echo $uye.'/'.id.'<br>';
			if($uye==id){
				//setcookie("msg", $uye,time() + 20, "/");//&& !$_COOKIE["msg"]
				//$this->db->query("update mesaj set okundu=1 where kime=".id." AND okundu = '0'");
				$responce['msg'] = $d;
			}
		}
		foreach($v->tlp as $uye=>$d){
			if($uye==id){
				$this->db->query("update iptaltalep set okundu=1 where ustid=".id." AND okundu = '0'");
				$responce['tlp'] = $d;
			}
		}
		
		echo json_encode($responce);
	}
	
	public function mesajvarmi(){
		
		ajaxvarmi();
		$responce=array();
		$responce['mesajvar'] = 0;
		$sqlyaz="select id from mesaj where kime=".id." and okundu=0 ";
		$sql = $this->db->query($sqlyaz);
		if($sql->num_rows() >0){
			$responce['mesajvar'] = 1;
		}
		echo json_encode($responce);
	}
	
	public function sil() {
		
		$id = (int)$this->input->post('id');
		$al=$this->db->query("SELECT kime,kim,durum FROM mesaj WHERE id='".$id."'");
		
		if($al->num_rows()>0) {
			$row=$al->row();
			if(id==$row->kim){
				$sql = "update mesaj set gsil=1 where id=".$id." ";//kim='".$row->kim."' and kime='".$row->kime."'
				$query = $this->db->query($sql);
			}else if(id !=$row->kim){
				$sql = "update mesaj set asil=1 where id=".$id." ";//kim='".$row->kim."' and kime='".$row->kime."'
				$query = $this->db->query($sql);
			}
		}
	}
}