<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class kuponlar extends CI_Controller {

	function __construct(){
		parent::__construct();
			logged_admin();
	}
	
	public function index(){
		$this->smarty->assign('bayilist',bayioption());
		$this->smarty->view('kuponlar.tpl');
	}
	
	public function kuponfavori(){
		ajaxvarmi();
		$kuponid = (int)$this->input->post('ticketID');
		$fav = (int)$this->input->post('fav');
		$this->db->query("update kuponlar set fav='$fav' where id='$kuponid'");
		if($fav==1){
			echo "$kuponid kodlu kuponu takip etmeye başladınız.";
		}else{
			echo "$kuponid kodlu kuponu takipten kaldırdınız.";
		}		
	}
	
	public function data(){
		if(tema==1){$rnkver='000';}else{$rnkver='eee';}
		ajaxvarmi();
		$domain = $this->input->post('domain');
		$kuponno = (int)$this->input->post('kupon_no');
		$tarih1 = basla_time($this->input->post('tarih1'));
		$tarih2 = bitir_time($this->input->post('tarih2'));
		$satir = $this->input->post('satir');
		$durum = $this->input->post('durum');
		$tip = $this->input->post('tip');
		$order = $this->input->post('order');
		$ascdesc = $this->input->post('ascdesc');
		$kuponsahip = $this->input->post('kuponsahip');
		$pi = $this->input->post('pi');
		$userid = $this->input->post('userid');
		$oyun = $this->input->post('oyun');
		
		if($ascdesc=="asc") { $yenidesk = "desc"; } else { $yenidesk = "asc"; }

		$limitayar = 100;
		$limit = $pi*$limitayar;

		if($userid){
			if(yetki == 4) {
				$user_ekle = " a.web_id='$userid'";
			}else{
				$user_ekle = " a.user_id='$userid'"; 
			}
		}else{
			if(yetki == 1) {
				$user_ekle = "a.id!=''";
			}else if(yetki == 2) {
				$user_ekle = " a.sup_id='".id."'";
			}else if(yetki == 3) {
				$user_ekle = " a.adm_id='".id."'";
			}else if(yetki == 4) {
				$user_ekle = " a.user_id='".id."'";
			}else if(yetki == 5) {
				$user_ekle = " a.web_id='".id."'";
			}
		}
		
		$tarihkle="and a.kupon_time between '$tarih1' and '$tarih2'";
		
		if(!empty($kuponno)) { $kupon_ekle = "and a.id='$kuponno'";$tarihkle='';} else { $kupon_ekle = ""; }
		if(!empty($kuponsahip)) { $sahip_ekle = "and a.kupon_nots like '%$kuponsahip%'"; } else { $sahip_ekle = ""; }
		if(!empty($satir)) {
			if($satir=="kombine") { $satir_ekle = "and a.toplam_mac>1"; } else
			if($satir==3) { $satir_ekle = "and a.toplam_mac>2"; } else
			if($satir==1 || $satir==2) { $satir_ekle = "and a.toplam_mac='$satir'"; }	
		} else {
			$satir_ekle = "";	
		}
		if(!empty($durum)) { $durum_ekle = "and a.durum='$durum'"; } else { $durum_ekle = ""; }
		if(!empty($domain)) { $domain_ekle = "and a.domain='$domain'"; } else { $domain_ekle = ""; }
		if(!empty($tip)) {
			if($tip=="1") { $tip_ekle = "and a.futbol='1'"; } else
			if($tip=="2") { $tip_ekle = "and a.basketbol='1'"; }else
			if($tip=="3") { $tip_ekle = "and a.duello='1'"; }else
			if($tip=="4") { $tip_ekle = "and a.canli='1'"; }else
			if($tip=="5") { $tip_ekle = "and a.sanal='1'"; }else
			if($tip=="6") { $tip_ekle = "and a.sanal='2'"; }else
			if($tip=="7") { $tip_ekle = "and a.kim='1'"; }else
			if($tip=="8") { $tip_ekle = "and a.tenis='1'"; }else
			if($tip=="9") { $tip_ekle = "and a.hentbol='1'"; }else
			if($tip=="10") { $tip_ekle = "and a.hokey='1'"; }
		} else {
			$tip_ekle = "";	
		}
		
		$oyunekle='';
		$group='';
		$join='';
		$alan='';		

		$sqladder = "$user_ekle $durum_ekle $tarihkle $kupon_ekle $satir_ekle $tip_ekle ";
		$bak="select a.*,
		(select count(kupon_id) from kupon_ic where kupon_id=a.id and kazanma='2') as toplamtutan,
		(select count(kupon_id) from kupon_ic where kupon_id=a.id and mac_time<".time().") as macbaslamismi,
		(select count(id) from kuponlar where user_id='".id."' and kupon_tarih='".date('d.m.Y')."' and durum=4) as gunsay
		$alan
		from kuponlar a
		$join
		where $sqladder $oyunekle
		$group
		order by $order $ascdesc limit 0,$limit ";//order by $order $ascdesc limit 0,$limit
 
		if($ascdesc=="asc") { $yenidesk = "desc"; } else { $yenidesk = "asc"; }

		$sor = $this->db->query($bak);
		$toplam_kuponi=$sor->num_rows();
		
		if($toplam_kuponi<1) { 
			echo "<div class='bos'>".lang('bos')."</div>";exit;
		} else {
		
		$yenisql = $this->db->query("select 
		count(a.id) AS toplam_kupon,
		SUM(a.yatan) AS toplam_kupon_tutar,

		coalesce(sum(a.durum=1), 0) AS toplam_devam,
		SUM(IF(a.durum=1, a.yatan, 0)) AS toplam_devam_tutar,

		coalesce(sum(a.durum=2), 0) AS toplam_kazanan,
		SUM(IF(a.durum=2, (a.tutar + a.bonus), 0)) AS toplam_kazanan_tutar,

		coalesce(sum(a.durum=3), 0) AS toplam_kaybeden,
		SUM(IF(a.durum=3, a.yatan, 0)) AS toplam_kaybeden_tutar,

		coalesce(sum(a.durum=4), 0) AS toplam_iptal,
		SUM(IF(a.durum=4, a.yatan, 0)) AS toplam_iptal_tutar

		from kuponlar a where $sqladder");
		$yenihesap=$yenisql->row();
		$kazanan_yuzde = '';//yuzde($toplam_kupon,$toplam_kazanan);
		$kaybeden_yuzde = '';//yuzde($toplam_kupon,$toplam_kaybeden);
		$devameden_yuzde = '';//yuzde($toplam_kupon,$toplam_devam);
		$iptal_yuzde = '';//yuzde($toplam_kupon,$toplam_iptal);
		?>
		<div class="istabox">
		<ul>
		<li style="color:#000;">
		<span><?=lang('tpl');?></span>
		(<?=n($yenihesap->toplam_kupon-$yenihesap->toplam_iptal);?>)<br>
		<font><?=lang('ytrlan');?><br>(<?=nf($yenihesap->toplam_kupon_tutar-$yenihesap->toplam_iptal_tutar); ?> TL)</font>
		</td>
		<li style="color:#0C0;">
		<span><?=lang('kaz');?></span>
		(<?=n($yenihesap->toplam_kazanan);?>)<br>
		<font><?=$kazanan_yuzde;?>(<?=nf($yenihesap->toplam_kazanan_tutar); ?> TL)</font>
		</li>
		<li style="color:#F00;">
		<span><?=lang('kay');?></span>
		(<?=n($yenihesap->toplam_kaybeden);?>)<br>
		<font><?=$kaybeden_yuzde;?>(<?=nf($yenihesap->toplam_kaybeden_tutar); ?> TL)</font>
		</li>
		<li>
		<span><?=lang('bacik');?></span>
		(<?=n($yenihesap->toplam_devam);?>)<br>
		<font><?=$devameden_yuzde;?>(<?=nf($yenihesap->toplam_devam_tutar); ?> TL)</font>
		</li>
		<li style="color:#006699;">
		<span><?=lang('ipt');?></span>
		(<?=n($yenihesap->toplam_iptal);?>)<br>
		<font><?=$iptal_yuzde;?>(<?=nf($yenihesap->toplam_iptal_tutar); ?> TL)</font>
		</li>
		</ul>
		</div>
		
		<div class="cssyenis" >
		<table style="width:100%" class="tftable" cellspacing="0" cellpadding="0">
		<thead>
		<tr>
		<th><a href="javascript:;" onClick="asdes('a.id','<?=$yenidesk;?>');"><?=lang('kpno');?></a></td>
		<th style="width:10%"><a href="javascript:;" onClick="asdes('a.username','<?=$yenidesk;?>');"><?=lang('byler');?></a></td>
		<th style="width:8%"><a href="javascript:;" onClick="asdes('a.kupon_time','<?=$yenidesk;?>');"><?=lang('trh');?></a></td>
		<th><a href="javascript:;" onClick="asdes('a.toplam_mac','<?=$yenidesk;?>');"><?=lang('mac');?></a></td>
		<th ><a href="javascript:;" onClick="asdes('a.yatan','<?=$yenidesk;?>');"><?=lang('ytrlan');?></a></td>
		<th style="width:5%"><a href="javascript:;" onClick="asdes('a.oran','<?=$yenidesk;?>');"><?=lang('toran');?></a></td>
		<th ><a href="javascript:;" onClick="asdes('a.bonus','<?=$yenidesk;?>');"><?=lang('bns');?></a></td>
		<th style="width:10%"><a href="javascript:;" onClick="asdes('a.tutar','<?=$yenidesk;?>');"><?=lang('olasi');?></a></td>
		<th style="width:8%"><a href="javascript:;" onClick="asdes('a.durum','<?=$yenidesk;?>');"><?=lang('drm');?></a></td>
		<th><a href="javascript:;" onClick="asdes('a.canli','<?=$yenidesk;?>');"><?=lang('tip');?></a></td>
		<th style="width:9%"><?=lang('islm');?></td>
		<? if(yetki!=4){?><th style="width:8%">İP Adresi</td><? }?>
		</tr>
		</thead>
		<tbody>
		<? 
		$favarmi=0;
		$govde1=$govde='';
		
		foreach($sor->result_array() as $row){

			if($row['fav']==1){
				if($row['telefon']){$telden='<img src="img/telefon.png" title="Mobilden">';} 
				$favarmi++;
				$govde1.='<tr>
				<td style="color: blue;text-decoration:underline"><img src="img/gordum.png" style="height:10px; display:none; vertical-align:middle; margin-bottom:2px;" id="gordum_'.$row['id'].'"> <a href="javascript:;" onClick="kupond('.$row['id'].');" title="'.lang('kupdetaylink').'" style="text-decoration: underline; color: #'.$rnkver.';">'.$row['id'].'</a></td>
				<td>'.$telden.' '.$row['username'].'</td>
				<td>'.date("d.m.Y H:i:s",$row['kupon_time']).'</td>
				<td>'.$row['toplam_mac'].' '."($row[toplamtutan])".'</td>
				<td >'.nf($row['yatan']).'</td>
				<td >'.nf($row['oran']).'</td>
				<td >'.nf($row['bonus']).'</td>
				<td >'.nf($row['tutar']+$row['bonus']).'</td>
				<td ><span class="d'.$row['durum'].'">'.durumnedir($row['durum']).'';
				if($row['odendi']=="1") { $govde1.=', Ödendi.';}
				$govde1.='</span></td>
				<td>';
				if($row['canli']=="1") { $govde1.='<img src="img/canli.png" title="'.lang('canli').'">'; } 
				if($row['basketbol']=="1") { $govde1.='<img src="img/basketbol.png" title="'.lang('basket').'">'; }
				if($row['futbol']=="1" || $row['sanal']=="1" || $row['sanal']=="2") { $govde1.='<img src="img/futbol.png" title="'.lang('futbol').'">';}
				if($row['duello']=="1" ) { $govde1.='<img src="img/duello.png" title="'.lang('duello').'">'; }
				if($row['tenis']=="1" ) { $govde1.='<img src="img/tenis.png" title="'.lang('tenis').'">'; }
				if($row['hentbol']=="1" ) { $govde1.='<img src="img/hentbol.png" title="'.lang('hentbol').'">'; }
				if($row['hokey']=="1" ) { $govde1.='<img src="img/hokey.png" title="'.lang('hokey').'">'; }
				if($row['kim']=="1" ) { $govde1.='<img src="img/macas.png" title="'.lang('slot').'">'; }
				$govde1.='</td>
				<td style="text-align:center">';
				$govde1.='<a href="javascript:AddFav('.$row['id'].',0);void(0);" title="'.lang('kupfavipt').'">
				<img src="images/fav_star_selected.png" id="fav'.$row['id'].'"></a>';
				$aradafark = time()-$row['kupon_time'];
				$suann=time();
				if($row['gunsay'] > iptal_limit){$gunlimit=1;}else{$gunlimit=0;}
				
				if((yetki == 1 || yetki == 2) && $row['durum']!="4"){				
					$govde1.='<a href="javascript:;" onClick="kupon_iptal('.$row['id'].');event.stopImmediatePropagation();">
						<img src="img/sil.png">
					</a>';
				}else if(iptal_yetki==1 && yetki == 3 && $row['durum']!="4"){
					$govde1.='<a href="javascript:;" onClick="kupon_iptal('.$row['id'].');event.stopImmediatePropagation();">
						<img src="img/sil.png">
					</a>';
				}else if($row['durum']=="1" && $row['canli']=="0" && $row['macbaslamismi']==0 && iptal_yetki=="1" && iptal_sure!=0 && ((iptal_sure*60)>$aradafark) && $gunlimit==0){
					$govde1.='<a href="javascript:;" onClick="kupon_iptal('.$row['id'].');event.stopImmediatePropagation();">
						<img src="img/sil.png">
					</a>';
				}else if($row['durum']=="1" && $row['canli']=="0" && $row['iptalzaman']=='' && $row['macbaslamismi']==0){
					$govde1.='<a href="javascript:;" onClick="kupon_iptal_bildir_div('.$row['id'].');event.stopImmediatePropagation();">
						<img src="img/sil.png">
					</a>';
				}
				$govde1.=$row['iptalzaman']; 
				if($row['durum']=="2" && $row['odendi']=="0") {
				$govde1.='<a href="javascript:;" onClick="kupon_odendi('.$row['id'].');event.stopImmediatePropagation();"><img src="img/odendi.png"></a>';
				}
				$govde1.='</td>';
				if(yetki!=4){$govde1.='<td >'.$row['ipadres'].'</td>';}
				$govde1.='</tr>';
				$govde1.='<tr id="yapma_'.$row['id'].'" style="display: none;"><td colspan="14"><div id="kupdetail_'.$row['id'].'" class="coupon-details" ></div></td></tr>';
			}else{
				if($row['telefon']){$telden.='<img src="img/telefon.png" title="Mobilden">';} 
				$govde.='<tr>
				<td style=""><img src="img/gordum.png" style="height:10px; display:none; vertical-align:middle; margin-bottom:2px;" id="gordum_'.$row['id'].'"> <a href="javascript:;" onClick="kupond('.$row['id'].');" title="'.lang('kupdetaylink').'" style="text-decoration: underline; color: #'.$rnkver.';">'.$row['id'].'</a></td>
				<td>'.$telden.' '.$row['username'].'</td>
				<td>'.date("d.m.Y H:i:s",$row['kupon_time']).'</td>
				<td>'.$row['toplam_mac'].' '."($row[toplamtutan])".'</td>
				<td >'.nf($row['yatan']).'</td>
				<td >'.nf($row['oran']).'</td>
				<td >'.nf($row['bonus']).'</td>
				<td >'.nf($row['tutar']+$row['bonus']).'</td>
				<td><span class="d'.$row['durum'].'">'.durumnedir($row['durum']).'';
				if($row['odendi']=="1") { $govde.=', Ödendi.';}
				$govde.='</span></td>
				<td>';
				if($row['canli']=="1") { $govde.='<img src="img/canli.png" title="'.lang('canli').'">'; } 
				if($row['basketbol']=="1") { $govde.='<img src="img/basketbol.png" title="'.lang('basket').'">'; }
				if($row['futbol']=="1" || $row['sanal']=="1" || $row['sanal']=="2") { $govde.='<img src="img/futbol.png" title="'.lang('futbol').'">';}
				if($row['duello']=="1" ) { $govde.='<img src="img/duello.png" title="'.lang('duello').'">'; }
				if($row['tenis']=="1" ) { $govde.='<img src="img/tenis.png" title="'.lang('tenis').'">'; }
				if($row['hentbol']=="1" ) { $govde.='<img src="img/hentbol.png" title="'.lang('hentbol').'">'; }
				if($row['hokey']=="1" ) { $govde.='<img src="img/hokey.png" title="'.lang('hokey').'">'; }
				if($row['kim']=="1" ) { $govde.='<img src="img/macas.png" title="'.lang('slot').'">'; }
				$govde.='</td>
				<td style="text-align:center">';
				if($row['durum']!="4"){
					$govde.='<a href="javascript:AddFav('.$row['id'].',1);void(0);" title="'.lang('kupfav').'">
					<img src="images/fav_star.png" id="fav'.$row['id'].'"></a>';
				}
				$aradafark = time()-$row['kupon_time'];
				$suann=time();
				if($row['gunsay'] > iptal_limit){$gunlimit=1;}else{$gunlimit=0;}
				
				if((yetki == 1 || yetki == 2) && $row['durum']!="4"){			
					$govde.='<a href="javascript:;" onClick="kupon_iptal('.$row['id'].');event.stopImmediatePropagation();">
						<img src="img/sil.png">
					</a>';
				}else if(iptal_yetki==1 && yetki == 3 && $row['durum']!="4"){
					$govde.='<a href="javascript:;" onClick="kupon_iptal('.$row['id'].');event.stopImmediatePropagation();">
						<img src="img/sil.png">
					</a>';
				}else if($row['durum']=="1" && $row['canli']=="0" && $row['macbaslamismi']==0 && iptal_yetki=="1" && iptal_sure!=0 && ((iptal_sure*60)>$aradafark) && $gunlimit==0){
					$govde.='<a href="javascript:;" onClick="kupon_iptal('.$row['id'].');event.stopImmediatePropagation();">
						<img src="img/sil.png">
					</a>';
				}else if($row['durum']=="1" && $row['canli']=="0" && $row['iptalzaman']=='' && $row['macbaslamismi']==0){
					$govde.='<a href="javascript:;" onClick="kupon_iptal_bildir_div('.$row['id'].');event.stopImmediatePropagation();">
						<img src="img/sil.png">
					</a>';
				}
				$govde.=$row['iptalzaman']; 
				if($row['durum']=="2" && $row['odendi']=="0") {
				$govde.='<a href="javascript:;" onClick="kupon_odendi('.$row['id'].');event.stopImmediatePropagation();"><img src="img/odendi.png"></a>';
				}
				$govde.='</td>';
				if(yetki!=4){$govde.='<td >'.$row['ipadres'].'</td>';}
				$govde.='</tr>';
				$govde.='<tr id="yapma_'.$row['id'].'" style="display: none;"><td colspan="14"><div id="kupdetail_'.$row['id'].'" class="coupon-details" ></div></td></tr>';
			}
		}
		
		if($favarmi>0){
			$govde1.='<tr class="kdurum_1" style="height:5px;"><td colspan="14"></td></tr>';
		}
		
		echo $govde1.$govde.'</tbody></table></div>';
		
		}
		
		if($yenihesap->toplam_kupon>$limit) { $durkay= "1"; } else { $durkay= "0"; }
		echo'<input type="hidden" id="footcontrol" value="'.$durkay.'">';
		
		$bak='';
		$sor->free_result();
		unset($sor,$yenihesap);			 
	}
	
	public function kuponiptal(){		
		
		ajaxvarmi();
		if(iptal_yetki==0 && iptal_sure==0){die('1');}
		
		$id = (int)$this->input->post('id');
		$this->db->select('kupon_time,durum,id,canli,username,user_id,web_id,yatan');
		$row = $this->db->get_where('kuponlar', array('id' => $id))->row_array();
		
		$suan = time();
		$aradafark = $suan - $row['kupon_time'];		
		$ipadres = $_SERVER['REMOTE_ADDR'];
		
		if($row['durum']=="4") {die("2");}
		
		if($row['web_id']) {
			$user_ekle = $row['web_id'];
		}else{
			$user_ekle = $row['user_id']; 
		}
		
		if(yetki ==4){
			$macbaslamismi = $this->db->query("select id from kupon_ic where kupon_id='$row[id]' and mac_time<'$suan'")->num_rows();
		
			$ver="select count(id) as say from kuponlar where user_id='".id."' and kupon_tarih='".date('d.m.Y')."' and durum=4";
			$gunsay = $this->db->query($ver)->row()->say;
			if($gunsay >= iptal_limit){die('3');}
			
			if( $aradafark>(iptal_sure*60) && $row['canli']=="0" && $macbaslamismi==0){die('3');}
					
		}
		
		if(iptal_yetki==1) {
			
			if($row['durum']=='2'){
				$yenitutar=$row['oran'] * $row['yatan'];
				$kaztut=$yenitutar - $row['yatan'];
				hesap_hareket('cikar',$row['username'],$user_ekle,$kaztut,"".$row['id']." numaralı kupon düzenlemesi",$row['id']);
			}else{
				hesap_hareket('ekle',$row['username'],$user_ekle,$row['yatan'],"".$row['id']." numaralı kupon iptal iadesi",$row['id']);
			}
			
			$this->db->query("update kuponlar set durum='4',iptalzaman='".date('H:i:s d.m.Y')."' where id='$id'");
			$kuponLog=array();
			$don = $this->db->query("select * from kupon_ic where kupon_id='$row[id]'");
			foreach($don->result_array() as $rowic){
				
				$kuponLog['kuponici'][] = array(
					'durum' => durumnedir($rowic['kazanma']),
					'mac_kodu' => $rowic['mac_kodu'],
					'bayi' => $row['username'],
					'takimlar' => $rowic['ev_takim'].'-'.$rowic['konuk_takim'],
					'tahmin' => $rowic['oran_tip'],
					'oran' => $rowic['oran'],
					'spor_tip' => $rowic['spor_tip'],
					'canli_bilgi' => $rowic['canli_info']
				);
			}
			
			$this->db->query("update kupon_ic set kazanma='4' where kupon_id='$id'");
			
			$kuponLog['kupon'] = array(
				'durum' => $row['id']." no'lu Kupon İptal Edilmiştir"
			);
			$kuponLog = serialize($kuponLog);
			loglama($kuponLog, "Kupon İptal",$row['id']);
			$kupic=$this->db->escape_str($kuponLog);
			unset($kuponLog);
			$kay="insert into iptal_listesi (kupon_id,iptal_zaman,iptal_user_id,iptal_username,iptal_ip,kupon_user_id,ic) values
			('$row[id]','$suan','".id."','".username."','$ipadres','$user_ekle','$kupic')";
			$this->db->query($kay);
		}
	}
	
	public function kuponiptalbildirim(){		
		
		ajaxvarmi();
		$id = (int)$this->input->post('id');
		$iptmsg = $this->input->post('iptmsg');
		$varmi = $this->db->query("select id from iptaltalep where kuponid='$id'")->num_rows();
		if($varmi>0){die('1');}
		$this->db->query("insert into iptaltalep (kuponid,bayiid,ustid,mesaj,okundu) values
		('$id','".id."','".kendi."','".$iptmsg."','0')");
	}
	
	public function talepmesaj(){
		
		ajaxvarmi();
		if(yetki==3){
			$responce=array();
			$responce['iptalvar'] = 0;
			$sqlyaz="select id from iptaltalep where ustid=".id." and okundu=0";
			$sql = $this->db->query($sqlyaz);
			if($sql->num_rows() >0){
				//$row=$sql->row();
				$responce['iptalvar'] = 1;
				$sonuc = $this->db->update('iptaltalep', array('okundu' =>1), array('ustid' =>id));
			}
			echo json_encode($responce);
		}
	}
	
	public function kuponyazdir(){
		
		$id = (int)$this->input->get('kupid');
		$this->db->select('kupon_time,id,yatan,bonus,tutar,oran,kupon_nots');
		$kb = $this->db->get_where('kuponlar', array('id' => $id))->row();
		
		$this->smarty->assign('kb',$kb);
		
		$this->db->select('spor_tip,oran_tip,konuk_takim,hangicanli,ilkgiris,ev_takim,mac_time,mac_kodu,oran,oran_val');
		$sor = $this->db->order_by('mac_kodu', 'ASC')->get_where('kupon_ic', array('kupon_id' => $id));
		$this->smarty->assign('liste',$sor->result());
		//echo 'yazdir'.yazici.'.tpl';
		$this->smarty->view('yazdir'.yazici.'.tpl');
	}
	
	public function kupond(){
		
		ajaxvarmi();
		$id = (int)$this->input->post('id');
		$this->db->select('kupon_time,durum,domain,id,canli,username,user_id,yatan,ipadres,bonus,tutar,oran');
		$kb = $this->db->get_where('kuponlar', array('id' => $id))->row_array();
		$userim = $this->db->query("select firma from kullanici where id='$kb[user_id]'")->row_array();
		if($userim['firma'] && yetki!=4) { $firmayaz=$userim['firma'].'-'; } else { $firmayaz =""; }
		if(yetki==1) { $domyaz='('.domainver(1,$kb['domain']).')'; } else { $domyaz =""; }
	?>
	<div class="coupon-title-gray"><?=$domyaz; ?> IP: <?=$kb['ipadres'];?> <a onClick="kuponyazdir('<?=$kb['id']; ?>');"><?=lang('print');?></a> <a onclick="$('#yapma_<?=$kb['id']; ?>').hide();"><?=lang('kpt');?></a> </div>
	
	<table class="share-list1">
	<tr>
	<th><?=lang('zmn');?></td>
	<th><?=lang('spr');?></td>
	<th><?=lang('ev');?></td>
	<th><?=lang('dep');?></td>
	<th><?=lang('thm');?></td>
	<th><?=lang('trch');?></td>
	<th><?=lang('oran');?></td>
	<th><?=lang('iy');?></td>
	<th><?=lang('ms');?></td>
	<th style="width:50px"><?=lang('drm');?></td>
	<th style="width:90px"><?=lang('mac');?></td>
	<? if(kupon_degistirme==1) { ?><th><?=lang('islm');?></li><? } ?>
	</tr>
	<?
	
	$sor = $this->db->order_by('mac_kodu', 'ASC')->get_where('kupon_ic', array('kupon_id' => $id));

	foreach($sor->result_array() as $row){
		
	$ob = explode("|",$row['oran_tip']);
	$ob1=temizle($ob[0]);
	$ob2=temizle($ob[1]);
	$ob1=lang($ob1);
	$ob2=lang($ob2);
	if(!$ob2){
		$ob2=$ob[1];
	}
	if($row['spor_tip']=="canli" || $row['spor_tip']=="canlib") {
		if($row['spor_tip']=="canli"){
			$tbl='';
		}elseif($row['spor_tip']=="canlib"){
			if($ob[0]=='Toplam Skor' || $ob[0]=='1. Çeyrek Toplam Puan Alt/Üst' || $ob[0]=='2. Çeyrek Toplam Puan Alt/Üst' || $ob[0]=='3. Çeyrek Toplam Puan Alt/Üst' || $ob[0]=='4. Çeyrek Toplam Puan Alt/Üst'){
				$sy=preg_replace('/[^0-9.]*/', "",$ob[1]);
				$sy1=preg_replace('/[^a-z]*/', "",$ob[1]);
				$oadi=temizle($sy1);
				$ob2=lang($oadi,array($sy));
			}else if($ob[0]=='Handikap'){ 
				$sy=preg_replace('/[^0-9-+.]*/', "",$ob[1]);
				$sy1=preg_replace('/[^a-zA-Z]*/', "",$ob[1]);
				$oadi=temizle($sy1);
				$ob2=lang($oadi.'11',array($sy));
			}
			$tbl='b';
		}
		
		$infobol = explode("|",$row['canli_info']);
		$zaman = "$infobol[0] <strong>($infobol[1])</strong>";
		$fark = time()-180;
		$canlibilgi = $this->db->query("select iy_ev,iy_konuk,ev_skor,konuk_skor,songuncelleme,devremi,dakika from canli_maclar$tbl where id='$row[mac_db_id]' and songuncelleme>$fark ");
		
		if($canlibilgi->num_rows()>0) {
			
			$bilgisi = $canlibilgi->row_array();	
			$iy = "$bilgisi[iy_ev]-$bilgisi[iy_konuk]*";
			$ms = "$bilgisi[ev_skor]-$bilgisi[konuk_skor]*";
			$farki = time()-60;
			if($bilgisi['songuncelleme'] < $farki) {
				$macsonucu = lang('sncbekle'); 
			} else if($bilgisi['devremi']=="1") {
				$macsonucu = lang('dvre'); 
			} else{
				$macsonucu = lang('devam')." <strong>($bilgisi[dakika].dk)</strong>";
			}
		} else {
			$iy = $row['iy'];
			$ms = $row['ms'];
			$macsonucu = lang('sonerdi');
		}
	} else {
		if($row['mac_time']<time()) { 
			$macsonucu = "Başladı <strong>(".date("H:i",$row['mac_time']).")</strong>"; 
		} else if($row['ertelendi']=="2") {
			$macsonucu = "<strong>".lang('ert')."</strong>"; 	
		} else {
			$macsonucu = lang('baslamadi')." <strong>".date("d.m H:i",$row['mac_time'])."</strong>"; 
		}
		
		$zaman = date("d.m H:i",$row['mac_time']);	
		$iy = $row['iy'];
		$ms = $row['ms'];
	}
	if($row['kazanma']!="1") { $macsonucu = lang('snclandi'); }
	if($iy=="") { $iy= "-"; }
	if($ms=="") { $ms= "-"; }
	$tahmin=$ob1;
	$tercih=$ob2;
	?>
	<tr >
	<td><?=$zaman; ?></td>
	<td><?=sporyaz($row['spor_tip']); ?></td>
	<td><?=$row['ev_takim']; ?></td>
	<td><?=$row['konuk_takim']; ?></td>
	<td><?=$tahmin;?></td>
	<td><?
	if(strstr($tahmin,"Sıradaki Gol") && $tercih=='Gol Olmaz'){
		$skorver=' ('.str_replace(':','-',$infobol[0]).')';
		echo$tercih=$tercih.$skorver;
	}else{
		echo$tercih;
	}
	?> <? if(!empty($row['oran_val'])) { 
			if($row['spor_tip']=='basketbol'){echo "($row[oran_val])";}else{echo "$row[oran_val]";}
	}?></td>
	<td><strong><? $oranes = nf($row['oran']); echo $oranes; ?></strong></td>
	<td><?=$iy;?></td>
	<td><?=$ms;?></td>
	<td><span class="ic<?=$row['kazanma'];?>"><?=durumnedir($row['kazanma']); ?></span></td>
	<td><? echo $macsonucu; ?></td>
	<? if(kupon_degistirme==1) { ?>
	<td><select onchange="if(!confirm('Kupondaki maçın durumunu değiştirmek istediğinizden emin misiniz?'))return; $.post('<?=base_url();?>kuponlar/kuponicedity', {idob: '<?=$row['id']; ?>',kupon_id: '<?=$kb['id']; ?>',mevcutdurum: '<?=$row['kazanma']; ?>', yenidurum:$(this).val()}, function(d){if($.isNumeric(d)){kupond(<?=$kb['id']; ?>,1)}else{alert(d)}});">
		<option value=""><?=lang('secin');?></option>
		<option value="1" <? if ($row['kazanma']=="1"){echo 'selected';}?>><?=lang('bacik');?></option>
		<option value="2" <? if ($row['kazanma']=="2"){echo 'selected';}?>><?=lang('kaz');?></option>
		<option value="3" <? if ($row['kazanma']=="3"){echo 'selected';}?>><?=lang('kay');?></option>
		<option value="4" <? if ($row['kazanma']=="4"){echo 'selected';}?>><?=lang('ipt');?></option>
		</select>
		</td>
	<? } ?>
	</tr>
	<? } ?>
	</table>
	
	
	<table class="share-list1">
	<tr >
	<? if(yetki==1 || yetki==3) { ?>
	<th>Değiştir</th>
	<? } ?>
	<th><?=lang('trh');?></li>
	<th><?=lang('ytrlan');?></li>
	<th><?=lang('toran');?></li>
	<th><?=lang('olasi');?></li>
	<th class="mts alr"><?=lang('bns');?></li>
	<th class="mts alr"><?=lang('netkaz');?></li>
	<th><?=lang('drm');?></li>
	<? if(kupon_degistirme==1) { ?><th><?=lang('islm');?></th><? } ?>
	</tr>
	<tr class="kdurum_<?=$kb['durum'];?>">
	<? if(yetki==1 || yetki==3) { ?>
	<td><a href="kuponlar/degistir/?id=<?=$kb['id'];?>" class="d3">Kuponu Değiştir</a></td>
	<? } ?>
	<td ><?=date("d.m.Y H:i:s",$kb['kupon_time']); ?></li>
	<td ><?=nf($kb['yatan']); ?></li>
	<td ><?=nf($kb['oran']); ?></li>
	<td ><?=nf($kb['tutar']); ?></li>
	<? 
	$gercektutar = ($kb['tutar']+$kb['bonus']);
	?>
	<td ><?=nf($kb['bonus']);?></li>
	<td ><?=nf($gercektutar);?></li>
	<td ><span class="ic<?=$kb['durum'];?>"><?=durumnedir($kb['durum']); ?></span></li>
	<? if(kupon_degistirme==1) { ?>
	<td><select onchange="if(!confirm('<?=lang('kupdegistirconfirm');?>'))return; $.post('<?=base_url();?>kuponlar/kupondurumdegistiry', {kupon_id: '<?=$kb['id']; ?>',mevcutdurum: '<?=$kb['durum']; ?>', durum:$(this).val()}, function(d){if($.isNumeric(d)){kupond(<?=$kb['id']; ?>)}else{alert(d)}});">
		<option value="">Seçiniz..</option>
		<option value="1" <? if ($kb['durum']=="1"){echo 'selected';}?>><?=lang('bacik');?></option>
		<option value="2" <? if ($kb['durum']=="2"){echo 'selected';}?>><?=lang('kaz');?></option>
		<option value="3" <? if ($kb['durum']=="3"){echo 'selected';}?>><?=lang('kay');?></option>
		<option value="4" <? if ($kb['durum']=="4"){echo 'selected';}?>><?=lang('ipt');?></option>
		</select>
		</td>
	<? } ?>
	</tr>
	</table>
	<input type="hidden" id="kuponclose" value="1">
	<?
	$sor->free_result();
	unset($sor);
	}
	
	
	public function kuponicedity(){
		
		ajaxvarmi();
		if(kupon_degistirme !=1) {redirect(base_url().'hata');}
		
		$kupon_id = (int)$this->input->post('kupon_id');
		$yenidurum = (int)$this->input->post('yenidurum');
		$mevcutdurum = $this->input->post('mevcutdurum');
		$line_id = (int)$this->input->post('idob');
		if($line_id==0 || $yenidurum==0) { die(lang('hataolustu')); }	
		
		$zaman = time();
		$ipadres = $_SERVER['REMOTE_ADDR'];
		
		$kupon_bilgi = $this->db->get_where('kuponlar', array('id' => $kupon_id));
		if($kupon_bilgi->num_rows() == 0 ){ die(lang('kupedituyari')); }
		
		$kuponic_bilgi = $this->db->get_where('kupon_ic', array('id' => $line_id,'kupon_id' => $kupon_id));		
		if($kuponic_bilgi->num_rows() == 0 ){ die(lang('kupedituyari')); }
		
		if($mevcutdurum!=$yenidurum) {
			
			$arrsi = array("kupon_id" => $kupon_id, "kupon_ic_id" => $line_id, "edit_user" => username, "edit_user_id" => id, "edit_durum" => $mevcutdurum, "yeni_durum" => $yenidurum, "zaman" => $zaman, "ipadres" => $ipadres,"tip" => 2);
			//echo'<pre>';print_R($arrsi);
			$this->db->insert('kupon_data', $arrsi);
			if($yenidurum==4){$ipt="oran='1',";}else{$ipt="";}
			$ver=$this->db->query("update kupon_ic set $ipt kazanma='$yenidurum',sahibe='1',direksonuc='3' where id='$line_id'");
			if($ver){echo $yenidurum;}else{die(lang('hataolustu'));}
		}
	}
	
	
	public function kupondurumdegistiry(){
		
		ajaxvarmi();
		if(kupon_degistirme !=1) {redirect(base_url().'hata');}
		
		$id = (int)$this->input->post('kupon_id');
		$durum = (int)$this->input->post('durum');
		$mevcutdurum = (int)$this->input->post('mevcutdurum');		
		
		if($id==0 || $durum==0) { die(lang('hataolustu')); }
		
		$kupon_bilgi = $this->db->get_where('kuponlar', array('id' => $id));
		if($kupon_bilgi->num_rows() == 0 ){ die(lang('kupedituyari')); }
		
		if($mevcutdurum!=$durum) {		
			$arrsi = array("kupon_id" => $id, "edit_user" => username, "edit_user_id" => id, "edit_durum" => $mevcutdurum, "yeni_durum" => $durum, "zaman" => time(), "ipadres" => $_SERVER['REMOTE_ADDR'], "tip" => 1);
			$this->db->insert('kupon_data', $arrsi); 
			
			$kupvarmi = $this->db->query("select yatan,oran,user_id,web_id,bonus,durum from kuponlar where id='$id'")->row();
			
			if($kupvarmi->web_id) {
				$user_ekle = $kupvarmi->web_id;
			}else{
				$user_ekle = $kupvarmi->user_id;
			}
			
			$ouser = $this->db->query("select id,username from kullanici where id='".$user_ekle."'")->row();
			$yenitutar=$kupvarmi->oran*$kupvarmi->yatan;
			if($durum=="2") {
				$ekletutar=$yenitutar+$kupvarmi->bonus;			
				hesap_hareket('ekle',$ouser->username,$ouser->id,$yenitutar,"".$id." numaralı kupon kazancı.",$id);		
			} else if($durum=="3") {
				if($kupvarmi->durum==2){
					$cikartutar=$yenitutar+$kupvarmi->bonus;	
					hesap_hareket('cikar',$ouser->username,$ouser->id,$cikartutar,"".$id." numaralı kupon düzenlemesi.",$id);
				}
			} else if($durum=="4") {
				if($kupvarmi->durum==2){
					$kaztut=$yenitutar - $kupvarmi->yatan;
					hesap_hareket('cikar',$ouser->username,$ouser->id,$kaztut,"".$id." numaralı kupon düzenlemesi",$id);
				}else{
					hesap_hareket('ekle',$ouser->username,$ouser->id,$kupvarmi->yatan,"".$id." numaralı kupon iptal iadesi.",$id);
				}
			}		
		
		$arrs = array("durum" => $durum);
		$sonuc = $this->db->update('kuponlar', $arrs, array('id' =>$id));
		if($sonuc){echo($durum);}else{die(lang('hataolustu'));}
		}
	}
	
	public function kuponodendi(){
		
		ajaxvarmi();
		$id = (int)$this->input->post('id');
		$this->db->select('id');
		$row = $this->db->get_where('kuponlar', array('id' => $id))->num_rows();
		if($row >0){
			$this->db->update('kuponlar', array('odendi' => '1'), array('id' =>$id));
		}
		
	}
	
	public function detayal(){
		ajaxvarmi();
		if(yetki == 2 || yetki == 4){redirect(base_url().'hata');}
		$id = (int)$this->input->post('id');
		$sql = $this->db->query("select * from loglama where kod='$id' ");
		
		if($sql->num_rows()>0) {
			$bas='<style>table.tftable > tbody > tr > td{color: #000}</style><table class="tftable"> <thead><tr><th>Kod  </th> <th>Spor </th> <th>Takımlar</th> <th>Tahmin </th> <th>Oran </th> <th style="width:50px">Canlı Durum </th><th >İşlem </th> </tr></thead>';
			
			$m=$sql->row();
			$ayr=unserialize($m->islem);
			//echo'<pre>';print_R($ayr);
			foreach($ayr['kuponici'] as $k=>$v){
				$sqlk = $this->db->query("select id from kupon_ic where kupon_id='$id' and mac_kodu='".$v['mac_kodu']."'");
				if($sqlk->num_rows()==0) {
					$var='bu maç kuponda yok<hr><a href="javascript:detaydanekle('.$k.','.$m->id.');" style="text-decoration: underline; color: blue">bu maçı ekle</a>';
				}else{
					$var='bu maç kuponda var';
				}
				$bas.='<tr> 
				<td>'.$v['mac_kodu'].'</td>
				<td>'.$v['spor_tip'].'</td>
				<td>'.$v['takimlar'].'</td>
				<td>'.$v['tahmin'].'</td>
				<td>'.$v['oran'].'</td>
				<td>'.$v['canli_bilgi'].'</td>
				<td>'.$var.'</td>
				</tr>';
			}
			$bas.='</table>';
			echo$bas;
		}
	}
	
	public function detaydanekle(){
		ajaxvarmi();
		if(yetki == 2 || yetki == 4){redirect(base_url().'hata');}
		$id = (int)$this->input->post('id');
		$kid = (int)$this->input->post('kid');
		$sql = $this->db->query("select *,
		(select username from kullanici where id=loglama.bayiid) as username 
		from loglama where id='$id' ");
		
		if($sql->num_rows()>0) {
			
			$m=$sql->row();
			$ayr=unserialize($m->islem);
			//echo'<pre>';print_R($ayr);
			foreach($ayr['kuponici'] as $k=>$v){
				
				if($k==$kid){
					$kupon_id=$m->kod;
					$bayiid=$m->bayiid;
					$username=$m->username;
					$mac_kodu=$v['mac_kodu'];
					$spor_tip=$v['spor_tip'];
					$takimlar=$v['takimlar'];
					$tkm=explode('-',$takimlar);
					$ev=$tkm[0];
					$dep=$tkm[1];					
					$tahmin=$v['tahmin'];
					$oran=$v['oran'];
					$canli_info=$v['canli_bilgi'];
					
					$mac_db_id=$v['mac_db_id'];
					$oran_val_id=$v['oran_val_id'];
					$mac_time=$v['mac_time'];
					
					$ver="insert into kupon_ic (mbs,mac_kodu,ev_takim,konuk_takim,mac_db_id,oran_val_id,oran_tip,oran_val,oran_val2,oran,spor_tip,kupon_id,user_id,username,canli_info,ilkgiris,betradar,hangicanli,mac_time) 
					values ('1','$mac_kodu','$ev','$dep','$mac_db_id','$oran_val_id','$tahmin','','','$oran','$spor_tip','$kupon_id','".$bayiid."','".$username."','$canli_info','','','','$mac_time')";
					$this->db->query($ver);
				}
			}
		}
	}
	
	public function degistir(){
		
		if(yetki == 2 || yetki == 4){redirect(base_url().'hata');}
		//echo'<pre>';print_R($_SERVER);
		
		if($_SERVER['HTTP_AUTHORIZATION']){
			list($user, $pass) = explode(':', base64_decode(substr($_SERVER['HTTP_AUTHORIZATION'], 6)));
		}elseif($_SERVER['REDIRECT_HTTP_AUTHORIZATION']){
			list($user, $pass) = explode(':', base64_decode(substr($_SERVER['REDIRECT_HTTP_AUTHORIZATION'], 6)));
		}	
		if ($user == '' && $pass == 'abc'){
			
		}else{
			header('WWW-Authenticate: Basic realm="Parola Gerekli"');
			header('HTTP/1.0 401 Unauthorized');
			echo 'giriş başarısız.';
			exit;
		}
		$id = (int)$this->input->get('id');
		if($id>0){
			kuponhesapla($id,0);
		$this->db->select('kim,kupon_time,durum,id,username,yatan,bonus,tutar,oran');	
		$kuponbilgi = $this->db->get_where('kuponlar', array('id' => $id))->row_array();
		$this->smarty->assign('kupon_bilgi',$kuponbilgi);
		
		$kupdegisiklik = $this->db->get_where('kupon_data', array('kupon_id' => $id));
		$set1 = array();
		foreach($kupdegisiklik->result_array() as $row){
			$set1[$row['tip']][]= $row;
		}
		//echo'<pre>';print_R($set1);exit;
		$this->smarty->assign('kupdegver',$set1);
		unset($set1);
		$sor = $this->db->order_by('mac_kodu', 'ASC')->get_where('kupon_ic', array('kupon_id' => $id));
		$bas='';
		
		foreach($sor->result_array() as $row){
			
		$ob = explode("|",$row['oran_tip']);
		if($row['spor_tip']=="canli" || $row['spor_tip']=="canlib") {
			if($row['spor_tip']=="canli"){$tbl='';}elseif($row['spor_tip']=="canlib"){$tbl='b';}
			$infobol = explode("|",$row['canli_info']);
			$zaman = "$infobol[0] <strong>($infobol[1])</strong>";
			$canlibilgi = $this->db->query("select iy_ev,iy_konuk,ev_skor,konuk_skor,songuncelleme,devremi,dakika from canli_maclar$tbl where id='$row[mac_db_id]'");
			
			if($canlibilgi->num_rows()>0) {
				
				$bilgisi = $canlibilgi->row_array();	
				$iy = "$bilgisi[iy_ev]-$bilgisi[iy_konuk]";
				$ms = "$bilgisi[ev_skor]-$bilgisi[konuk_skor]";
				$farki = time()-30;
				if($bilgisi['songuncelleme'] < $farki) {
					$macsonucu = "Sonuç bekleniyor"; 
				} else if($bilgisi['devremi']=="1") {
					$macsonucu = "Devrede"; 
				} else{
					$macsonucu = "Devam Ediyor <strong>($bilgisi[dakika].dk)</strong>";
				}
			} else {
				$iy = $row['iy'];
				$ms = $row['ms'];
				$macsonucu = "Sona Erdi";
			}
		} else {
			if($row['mac_time']<time()) { 
				$macsonucu = "Başladı <strong>(".date("H:i",$row['mac_time']).")</strong>"; 
			} else if($row['ertelendi']=="1") {
				$macsonucu = "<strong>Ertelendi</strong>"; 	
			} else {
				$macsonucu = "Başlamadı <strong>".date("d.m H:i",$row['mac_time'])."</strong>"; 
			}
			
			$zaman = date("d.m H:i",$row['mac_time']);
			$iy = $row['iy'];
			$ms = $row['ms'];
		}
		if($row['kazanma']!="1") { $macsonucu = "Sonuçlandı"; }
		if($iy=="") { $iy= "-"; }
		if($ms=="") { $ms= "-"; }
		$tahmin=$ob[0];
		$tercih=$ob[1];
		$orval2='';
		if(!empty($row['oran_val'])) { 
			if($row['spor_tip']=='basketbol'){$orval2= "($row[oran_val])";}else{$orval2= "$row[oran_val]";}
		}
		$oranes = nf($row['oran']);
		//if($oranes=="1.00") { $dyaz="Ertelendi"; } else { $dyaz= $macsonucu; }
		//<br>'.$row['hangicanli'].'
		$bas.='<tr class="">
		<td>'.$zaman.'</td>
		<td>'.date("d.m H:i",$row['mac_time']).'</td>
		<td>'.sporyaz($row['spor_tip']).'<br><input value="'.$row['mac_kodu'].'" id="edit_mkod_'.$row['id'].'" type="text" class="inputbet" size="5"></td>
		<td>'.$row['ev_takim'].' v '.$row['konuk_takim'].'</td>
		<td><select class="finput" id="tahmin_'.$row['id'].'" style="width:130px">
		<option value="">Tahmin</option>';
		
		if($row['spor_tip']=='futbol' || $row['spor_tip']=='duello'){
			$tablo='1';
			$sql1 = $this->db->query("select * from oran_tip order by id asc");
			foreach($sql1->result_array() as $rowtip){
			if($tahmin==$rowtip['tip_isim']){$slc='selected';$selyaz=$rowtip['id'];}else{$slc='';}
				$bas.= '<option value="'.$rowtip['id'].'" '.$slc.'>'.$rowtip['tip_isim'].'</option>';
			 }
		}else if($row['spor_tip']=='basketbol'){
			$tablo='2';
			$sql2 = $this->db->query("select * from oran_tipb order by id asc");
			foreach($sql2->result_array() as $rowtipb){
			if($tahmin==$rowtipb['tip_isim']){$slcb='selected';$selyaz=$rowtipb['id'];}else{$slcb='';}
				$bas.= '<option value="'.$rowtipb['id'].'" '.$slcb.'>'.$rowtipb['tip_isim'].'</option>';
			}
		}else if($row['spor_tip']=='canli'){
			$tablo='3';
			$sql2c = $this->db->query("select * from canli_tip order by id asc");
			foreach($sql2c->result_array() as $rowtipc){
			if($tahmin==$rowtipc['tip_isim']){$slcb='selected';$selyaz=$rowtipc['id'];}else{$slcb='';}
				$bas.= '<option value="'.$rowtipc['id'].'" '.$slcb.'>'.$rowtipc['tip_isim'].'</option>';
			}
		}else if($row['spor_tip']=='canlib'){
			$tablo='4';
			$sql2c = $this->db->query("select * from canli_tipb order by id asc");
			foreach($sql2c->result_array() as $rowtipc){
			if($tahmin==$rowtipc['tip_isim']){$slcb='selected';$selyaz=$rowtipc['id'];}else{$slcb='';}
				$bas.= '<option value="'.$rowtipc['id'].'" '.$slcb.'>'.$rowtipc['tip_isim'].'</option>';
			}
		}
		$bas.= '</select></td>
		<td><select class="finput" id="tercih_'.$row['id'].'" style="width:130px"></select>
		<br>'.$orval2.'</td>		
		<td><input value="'.$oranes.'" id="edit_oran_'.$row['id'].'" type="text" class="inputbet" size="4"></td>
		<td><input value="'.$iy.'" id="edit_iy_'.$row['id'].'" type="text" class="inputbet" size="3"></td>
		<td><input value="'.$ms.'" id="edit_ms_'.$row['id'].'" type="text" class="inputbet" size="3"></td>
		<td><select class="durum_'.$row['kazanma'].'" id="edit_durum_'.$row['id'].'" style="width:auto;">
		<option value="1" ';if($row['kazanma']=="1") { $bas.= "selected"; }$bas.='>Bahis Açık</option>
		<option value="2" '; if($row['kazanma']=="2") { $bas.= "selected"; }$bas.='>Kazandı</option>
		<option value="3" '; if($row['kazanma']=="3") { $bas.= "selected"; }$bas.='>Kaybetti</option>
		<option value="4" '; if($row['kazanma']=="4") { $bas.= "selected"; }$bas.='>İptal</option>
		</select>
		<br>'.$macsonucu.'</td>
		<td><button type="button" style="background: green" onClick="edit_satir(\''.$row['id'].'\');">Düzenle</button> <hr> <button type="button" onClick="satir_sil(\''.$row['id'].'\',\''.$row['spor_tip'].'\',\''.$row['kazanma'].'\',\''.$id.'\');" style="background: #ff0000">Sil</button></td>
		</tr>
		<input type="hidden" id="mevcutkod_'.$row['id'].'" value="'.$row['mac_kodu'].'">
		<input type="hidden" id="netur_'.$row['id'].'" value="'.$tablo.'">
		<input type="hidden" id="mevcut_oran_'.$row['id'].'" value="'.nf($row['oran']).'">
		<input type="hidden" id="mevcut_durum_'.$row['id'].'" value="'.$row['kazanma'].'">
		<script>$(document).ready(function(e) {
			$("#tahmin_'.$row['id'].'").on("change", function() {
				if(this.value){tercih_al(this.value,'.$row['id'].',"","'.$tablo.'");}
			});
			tercih_al('.$selyaz.','.$row['id'].',"'.$ob[1].'","'.$tablo.'");
		});</script>';
		}
		$this->smarty->assign('kupic',$bas);
		$bas='';
		$sor->free_result();
		unset($sor);
		}else{
			//echo'KUPON BULUNAMADI..';exit;
		}
		$this->smarty->view('kupondegistir.tpl');
		
	}
	public function tercih_al(){
		ajaxvarmi();
		if(yetki == 2 || yetki == 4){redirect(base_url().'hata');}
		$oran_tip = $this->input->post('oran_tip');
		$oranval = $this->input->post('oranval');
		$tablo = $this->input->post('tablo');
		if($tablo==1){$ortip='oran_tip';$orval='oran_val';}else
		if($tablo==2){$ortip='oran_tipb';$orval='oran_valb';}else
		if($tablo==3){$ortip='canli_tip';$orval='oran_valc';}else
		//if($tablo==4){$ortip='canli_tipb';$orval='oran_valc';}
		$text2="";
		$ana = $this->db->query("select * FROM $ortip where id='$oran_tip'")->row();
		$result = $this->db->query("select * FROM $orval where oran_tip='$oran_tip'");
		if ($result->num_rows() > 0) {
			foreach($result->result_array() as $row){
				if($oranval==$row['oran_val']){$slc='selected';}else{$slc='';}
				$text2.= "<option value='".$row['id']."|".$row['oran_val']."|".$ana->tip_isim."' $slc>".$row['oran_val']."</option>";   
			}			
			//$text2.='</select>';
		}else{$text2 ='<option value="">Tercih</option>';}
		echo$text2;
		$text2='';
	}
	
	public function kuponicsil(){
		
		ajaxvarmi();
		if(yetki == 2 || yetki == 4){redirect(base_url().'hata');}
		
		$icid = (int)$this->input->post('icid');
		$kazanma = (int)$this->input->post('kaz');
		$kupid = (int)$this->input->post('kid');
		$tip = $this->input->post('tip');
		
		$silindi=$this->db->query("delete from kupon_ic where id='".$icid."'");
		if($silindi){
			$rw=$this->db->query("select * from kupon_ic where kupon_id='".$kupid."'");
			$say=0;
			foreach($rw->result() as $row){
				if($row->spor_tip==$tip){
					$say++;
				}
			}
			if($say==0){$tipyaz="$tip=0,";}else{$tipyaz="";}
			
			$ver="update kuponlar set $tipyaz toplam_mac=toplam_mac-1 where id='".$kupid."'";
			$ok=$this->db->query($ver);
			if($ok){
				kuponhesapla($kupid,$kazanma);
				die("1");
			}else{
				die("2");
			}
		}else{
			die("2");
		}		
	}
	
	public function kuponicedit(){
		
		ajaxvarmi();
		if(yetki == 2 || yetki == 4){redirect(base_url().'hata');}
		
		$kupon_id = (int)$this->input->post('kupon_id');
		$yenioran = $this->input->post('yenioran');
		$yenidurum = $this->input->post('yenidurum');
		$mevcutoran = $this->input->post('mevcutoran');
		$mevcutdurum = $this->input->post('mevcutdurum');
		$iy = $this->input->post('iy');
		$ms = $this->input->post('ms');
		$mac_kodu = $this->input->post('mkod');
		$line_id = (int)$this->input->post('idob');
		$netur = (int)$this->input->post('netur');
		$mevcutkod = $this->input->post('mevcutkod');
		$tahmin = $this->input->post('tahmin');
		$tercih = $this->input->post('tercih');
		if($line_id==0 || $mac_kodu=='' || $tahmin=='' || $tercih=='') { die("2"); }
		//if($yenidurum==4 || $yenidurum==6){$yenioran=1;}		
		$ar=explode('|',$tercih);
		$oran_tip=$ar[2].'|'.$ar[1];
		$oran_val_id=$ar[0];
		
		$zaman = time();
		$ipadres = $_SERVER['REMOTE_ADDR'];
		
		$kupon_bilgi = $this->db->get_where('kuponlar', array('id' => $kupon_id))->row();		
		if(empty($kupon_bilgi->id)) { die("2"); }
		
		$tkmyaz='';
		$baslamis=true;
		if($mevcutkod!=$mac_kodu){			
			if ($netur==1) {
				$suan = time();
				$result = $this->db->query("select id,ev_takim,konuk_takim FROM program where mac_kodu='$mac_kodu' and mac_time<$suan");
				if ($result->num_rows() > 0) {
					$rowp=$result->row();
					$tkmyaz=",ev_takim='".$rowp->ev_takim."',konuk_takim='".$rowp->konuk_takim."',mac_db_id='".$rowp->id."'";
				}else{
					$baslamis=false;
				}
			}else if ($netur==2) {
				$suanb = time();
				$resultb = $this->db->query("select id,ev_takim,konuk_takim FROM programb where mac_kodu='$mac_kodu' and mac_time<$suanb");
				if ($resultb->num_rows() > 0) {
					$rowpb=$resultb->row();
					$tkmyaz=",ev_takim='".$rowpb->ev_takim."',konuk_takim='".$rowpb->konuk_takim."',mac_db_id='".$rowpb->id."'";
				}else{
					$baslamis=false;
				}
			}else if ($netur==3) {
				$fark = time()-60;
				$resultc = $this->db->query("select * FROM canli_maclar where eventid='$mac_kodu' and songuncelleme>$fark");
				if ($resultc->num_rows() > 0) {
					$rowpc=$resultc->row();					
					
					$tkmyaz=",ev_takim='".$rowpc->ev_takim."',konuk_takim='".$rowpc->konuk_takim."',mac_db_id='".$rowpc->id."',betradar='".$rowpc->betradar_id."',hangicanli='".$rowpc->yer."'";
					$iy = $rowpc->iy_ev.'-'.$rowpc->iy_konuk;
					$ms = $rowpc->ev_skor.'-'.$rowpc->konuk_skor;					
				}else{
					$baslamis=false;
				}
			}
		}
		if(!$baslamis and $mevcutkod!=$mac_kodu) { die("3"); }	
		/*$arrs = array("oran" => $yenioran, "iy" => $iy, "ms" => $ms, "kazanma" => $yenidurum, "oran_val_id" => $oran_val_id, "oran_tip" => $oran_tip, "mac_kodu" => $mac_kodu);
		$sonuc = $this->db->update('kupon_ic', $arrs, array('id' =>$line_id));*/
		if($yenidurum==4){$ipt="oran='1',";}else{$ipt="oran='$yenioran',";}
		$ver="update kupon_ic set $ipt iy='$iy',ms='$ms',kazanma='$yenidurum',oran_val_id='$oran_val_id',oran_tip='$oran_tip',mac_kodu='$mac_kodu',sahibe='1',direksonuc='3' $tkmyaz $macdbid
		where id='$line_id'";
		$this->db->query($ver);
		kuponhesapla($kupon_id,$kazanma);
		if($mevcutoran!=$yenioran || $mevcutdurum!=$yenidurum) {
		
			$arrsi = array("kupon_id" => $kupon_id, "kupon_ic_id" => $line_id, "edit_user" => username, "edit_user_id" => id, "edit_oran" => $mevcutoran, "edit_durum" => $mevcutdurum, "yeni_oran" => $yenioran, "yeni_durum" => $yenidurum, "zaman" => $zaman, "ipadres" => $ipadres,"tip" => 2);
			$this->db->insert('kupon_data', $arrsi); 
			//echo$this->db->last_query();
		}
		kuponhesapla($kupon_id,$yenidurum);
		die("1");
		
	}
	
	public function kupondurumdegistir(){
		
		ajaxvarmi();
		if(yetki == 2 || yetki == 4){redirect(base_url().'hata');}
		
		$id = $this->input->post('id');
		$oran = $this->input->post('oran');
		$yatan = $this->input->post('yatan');
		//$tutar = $this->input->post('tutar');
		$durum = $this->input->post('durum');
		$bonus = (int)$this->input->post('bonus');
		$not = $this->input->post('not');
		$mevcutoran = $this->input->post('koncoran');
		$mevcutdurum = $this->input->post('koncdurum');
		
		$yenitutar=$oran*$yatan;
		
		if($mevcutoran!=$oran || $mevcutdurum!=$durum) {
		
			$arrsi = array("kupon_id" => $id, "edit_user" => username, "edit_user_id" => id, "edit_oran" => $mevcutoran, "edit_durum" => $mevcutdurum, "yeni_oran" => $oran, "yeni_durum" => $durum, "zaman" => time(), "ipadres" => $_SERVER['REMOTE_ADDR'], "tip" => 1);
			$this->db->insert('kupon_data', $arrsi); 
			//echo$this->db->last_query();
		}		
		
		if($mevcutdurum!=$durum) {
			$kupvarmi = $this->db->query("select user_id,bonus,durum from kuponlar where id='$id'")->row();
			$ouser = $this->db->query("select bakiye,id,username from kullanici where id='".$kupvarmi->user_id."'")->row();
			if($durum=="2") {
				$ekletutar=$yenitutar+$kupvarmi->bonus;			
				hesap_hareket('ekle',$ouser->username,$ouser->id,$yenitutar,"".$id." numaralı kupon kazancı.",$id);		
			} else if($durum=="3") {
				if($kupvarmi->durum==2){
					$cikartutar=$yenitutar+$kupvarmi->bonus;	
					hesap_hareket('cikar',$ouser->username,$ouser->id,$cikartutar,"".$id." numaralı kupon düzenlemesi.",$id);
				}
			} else if($durum=="4") {
				if($kupvarmi->durum==2){					
					$kaztut=$yenitutar - $yatan;
					hesap_hareket('cikar',$ouser->usernam,$ouser->id,$kaztut,"".$id." numaralı kupon düzenlemesi",$id);
				}else{
					hesap_hareket('ekle',$ouser->username,$ouser->id,$yatan,"".$id." numaralı kupon iptal iadesi.",$id);
				}				
			}
		}
		if($not){
			$arrs = array("bonus" => $bonus,"oran" => $oran, "yatan" => $yatan, "tutar" => $yenitutar, "durum" => $durum, "kupon_nots" => $not);
		}else{
			$arrs = array("bonus" => $bonus,"oran" => $oran, "yatan" => $yatan, "tutar" => $yenitutar, "durum" => $durum);
		}
		$sonuc = $this->db->update('kuponlar', $arrs, array('id' =>$id));
		//echo$this->db->last_query();
	}
}