<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class slot extends CI_Controller {

	function __construct(){
		parent::__construct();
			logged_admin();			
	}
	
	public function index(){
		if(detect_mobile()){
			$this->smarty->assign('mbl',1);
		}else{
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($ch, CURLOPT_USERAGENT, "Firefox/3.6.8");
			curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
			curl_setopt($ch, CURLOPT_URL, 'https://betgames9.betgames.tv/ext/game/odds/testpartner/8/0/decimal');
			$al = curl_exec($ch);
			curl_close($ch);
			preg_match_all('#<a data-odd-id=".*?".*?class="poker_odd btn btn-xs.*?">(.*?)</a>#si',$al,$od);
			preg_match('/"time_till_next_round":(.*?)},"s/si',$al,$sn);
			//echo'<pre>';print_r($od);exit;
			$kasa=trim($od[1][0]);
			$ben=trim($od[1][1]);
			$berabere=trim($od[1][2]);

			if(!is_numeric($kasa)){
				$kasa=str_replace(array('lost','won'),array(lang('kay'),lang('kaz')),$kasa);
			}
			if(!is_numeric($ben)){
				$ben=str_replace(array('lost','won'),array(lang('kay'),lang('kaz')),$ben);
			}
			if(!is_numeric($berabere)){
				$berabere=str_replace(array('lost','won'),array(lang('kay'),lang('kaz')),$berabere);
			}

			if(!is_numeric($kasa) && !is_numeric($ben) && !is_numeric($berabere)){
				echo'<script>$(function () {bet_disable();kuponsifirla();});</script>';
			}

			$snsi=$sn[1];
			if($snsi<1){
				$snyaz="<font>".lang('bhskpn')."</font><script>$(function () {bet_disable();kuponsifirla();});</script>";
			}else{
				$snyaz="<font id='snsi'>$snsi</font> sn<script>gerisay();</script>";
			}
			$this->smarty->assign('snyaz',$snyaz);
			$this->smarty->assign('kasa',$kasa);
			$this->smarty->assign('ben',$ben);
			$this->smarty->assign('berabere',$berabere);
			$this->smarty->assign('mbl',0);
		}
		
		$this->smarty->view('basmaca.tpl');
	}
	
	public function sonkupon(){
		
		if(yetki!=4 && yetki!=5) {
			echo "<div class='bos'>".lang('bos')."</div>";exit;
		}
		
		if(yetki == 4) {
			$user_ekle = " a.user_id='".id."'";
		}else if(yetki == 5) {
			$user_ekle = " a.web_id='".id."'";
		}
		$tarih = date("d.m.Y");	
		$ver="select kupon_nots,durum,tutar,id,yatan,kupon_time,oran from kuponlar a
		where $user_ekle and a.kim=1 and a.kupon_tarih='$tarih' order by id desc limit 10";
		$sor = $this->db->query($ver);		
		if($sor->num_rows()==0) { 
			echo "<div class='bos'>".lang('bos')."</div>";exit;
		}else{?>
			<table style="width:100%" class="tftable" cellspacing="0" cellpadding="0">
			<thead><tr>
			<th style="width:2%"><?=lang('trh');?></th>
			<th style="width:2%"><?=lang('trch');?></th>
			<th style="width:2%"><?=lang('ytrlan');?></th>
			<th style="width:2%"><?=lang('toran');?></th>
			<th style="width:2%"><?=lang('olasi');?></th>
			<th style="width:2%"><?=lang('drm');?></th>
			</tr></thead><tbody>
		<? 
			$govde='';
			foreach($sor->result_array() as $row){
				$oadi=temizle($row['kupon_nots']);
				$thmn=lang($oadi);
				$govde.='<tr >
				<td>'.date("d.m.Y H:i:s",$row['kupon_time']).'</td>
				<td >'.$thmn.'</td>
				<td >'.nf($row['yatan']).'</td>
				<td >'.nf($row['oran']).'</td>
				<td >'.nf($row['tutar']).'</td>
				<td class="d'.$row['durum'].'">'.durumnedir($row['durum']).'
				</tr>';
			}
			echo $govde.'</tbody></table></div>';
		}
	}
	
	public function kupondusur(){
		
		$oyunid = (int)$this->input->post("oyunid");
		$durum = (int)$this->input->post("durum");
		
		$sonkontrolc = $this->db->query("select tutar,id,yatan,username,web_id,user_id from kuponlar where id=".$oyunid." and durum='1'");		
		if($sonkontrolc->num_rows()==0) { die("3"); }
		
		$okmu=$this->db->query("update kuponlar set durum='$durum' where id=".$oyunid." ");
		if($okmu){
			
			$kupbilgi=$sonkontrolc->row();
			if($durum == 2){
				if($kupbilgi->web_id) {
					$user_ekle = $kupbilgi->web_id;
				}else{
					$user_ekle = $kupbilgi->user_id;
				}
			
				$ekletutar = $kupbilgi->tutar;
				
				hesap_hareket('ekle',$kupbilgi->username,$user_ekle,$ekletutar,"".$kupbilgi->id." numaralı KimKazanır? kupon kazancı",$kupbilgi->id);
			}
			die("1");
		}else{
			die("2");
		}
	}
	
	public function kuponok(){
		
		if(yetki!=4 && yetki!=5) {
			echo '<script>alert("'.lang('supolmaz').'");</script>';
			exit;
		}

		$al=decodekupon($_POST['val']);
		$dcv=explode(',',$al);
		$yatan=$dcv[0];
		$oran=$dcv[1];
		$kazanc=$dcv[2];
		$oranadi=addslashes($dcv[3]);
		$oddid=$dcv[4];
		
		$zaman = time();
		$tarih = date("d.m.Y");
		$ipadres = $_SERVER['REMOTE_ADDR'];
		
		$yenibakiye = bakiye-$yatan;
		if($yenibakiye<0 || direk==1){
			echo '<script>alert("'.lang('bakiolmaz').'");</script>';
			exit;
		}
		
		$web=0;
		if(yetki==5){
			$usid=ustbayi;
			$webid=id;
		}else{
			$webid=0;
			$usid=id;
		}
		
		$this->db->query("insert into kuponlar (user_id,web_id,adm_id,sup_id,username,oran,yatan,tutar,kupon_time,kim,toplam_mac,kupon_nots,durum,kupon_tarih,ipadres,bonus,mac_siralama,domain,kesinti) values
		('$usid','$webid','".kendi."','".ustu."','".username."','$oran','$yatan','$kazanc','$zaman','1','1','$oranadi','1','$tarih','$ipadres','0','',4,'0')");
		
		$kupid = (int)$this->db->insert_id();
		if($kupid>0){
			$this->db->query("update kullanici set bakiye=bakiye-$yatan where id=".id." ");
			echo $kupid.'yolla'.$oddid;exit;
		}else{
			echo '<script>alert("'.lang('hataolustu').'");</script>';
			exit;
		}
	}
	
	public function data(){
		$a = $this->input->post("a");
		if($a=='vid'){
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($ch, CURLOPT_USERAGENT, "Firefox/3.6.8");
			curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
			curl_setopt($ch, CURLOPT_URL, 'https://betgames9.betgames.tv/ext/game/odds/testpartner/8/0/decimal');
			$al = curl_exec($ch);
			curl_close($ch);
			preg_match('/"stream_name":"(.*?)","s/si',$al,$vidid);
			preg_match('/"draw_code":"(.*?)",/si',$al,$draw);
			$vidurl=$vidid[1];
			$drawid=$draw[1];
			?>
			<div class="savas_boxtitle"><?=lang('cnl');?> <span ><?=$drawid;?></span></div>
			<object id="player_api" name="player_api" data="https://betgames9.betgames.tv/dif/flowplayer/flowplayer.commercial-3.2.18.swf" type="application/x-shockwave-flash" style="width:550px; height:340px;">
			<param name="allowscriptaccess" value="always">
			<param name="quality" value="high"><param name="bgcolor" value="#000000">
			<param name="wmode" value="opaque">
			<param name="flashvars" value='config={"key":"#$7c2178b985818be426a","buffering":false,"showErrors":false,"canvas":{"background":"#000000 url(https://betgames9.betgames.tv/dif/flowplayer/coin.swf) no-repeat 50pct 50pct","backgroundGradient":"none"},"clip":{"url":"<?=$vidurl;?>","live":true,"provider":"rtmp","autoPlay":true,"scaling":"fit","bufferLength":5},"plugins":{"rtmp":{"url":"https://betgames9.betgames.tv/dif/flowplayer/flowplayer.rtmp-3.2.3.swf","netConnectionUrl":"rtmp://fml.D2CB.edgecastcdn.net/20D2CB/live","subscribe":true},"controls":{"backgroundColor":"transparent","backgroundGradient":"none","sliderColor":"#FFFFFF","sliderBorder":"1.5px solid rgba(160,160,160,0.7)","volumeSliderColor":"#BC2121","volumeBorder":"1.5px solid rgba(160,160,160,0.7)","timeColor":"#ffffff","durationColor":"#535353","tooltipColor":"rgba(255, 255, 255, 0.7)","tooltipTextColor":"#000000","all":false,"mute":true,"volume":true,"fullscreen":false,"time":false,"right":0,"bottom":5,"width":115}},"logo":null,"playerId":"player","playlist":[{"url":"<?=$vidurl;?>","live":true,"provider":"rtmp","autoPlay":true,"scaling":"fit","bufferLength":2}]}'>
			</object>
		<?}
	}
	
}