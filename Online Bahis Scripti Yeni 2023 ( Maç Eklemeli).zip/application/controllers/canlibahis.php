<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class canlibahis extends CI_Controller {

	function __construct(){
		parent::__construct();
			logged_admin();
			$this->userler=kendi.','.ustu.','.patron.','.id;
			//canlisil('');
			$kelimeler = explode(',', ckelime);
			$this->notLike = "";
			if(!empty(ckelime)){
				foreach($kelimeler as $keyword){
					if(trim($keyword)=="")
						continue;
					$this->notLike .= " AND a.ev_takim NOT LIKE '%".$this->db->escape_str($keyword)."%'";
					$this->notLike .= " AND a.konuk_takim NOT LIKE '%".$this->db->escape_str($keyword)."%'";
				}
			}
			$this->fark = time()-80;
	}
	
	public function index(){
		if(canliyasak >0 || canlibahis==0){redirect(base_url().'hata');}
		$this->smarty->view('canli.tpl');
		 
	}
	
	public function livegelecek(){
		ajaxvarmi();
		//title="'.$gelengun.'/'.$gunu.'/'.$saat[0].'/'.$altisaat.'"
		$suan = time()-3000;//
		$ver="select * from canli_maclar_gelecek where zaman > NOW() and zaman < DATE_SUB(NOW(), INTERVAL -6 HOUR) and songuncelleme>$suan and yer='".aktifcanli."' order by baslamasaat asc";
		$sor = $this->db->query($ver);
		$bas='';
		$startMinutes=6;
		$bugun=date('d');
		$altisaat= date('g',strtotime($startMinutes.' hours'));//$saat[0]<=$altisaat
		$gunu= date('d',strtotime($startMinutes.' hours'));//
		foreach($sor->result() as $ass){
			$ar=explode(' ',$ass->baslamasaat);
			$gu=explode('.',$ar[0]);
			$gelengun=$gu[0];
			$saat=explode(':',$ar[1]);
			//if($gelengun<$gunu && ($saat[0]<=$altisaat || $saat[0]>=$altisaat)){
			$bas.='<div class="e_active jq-event-row-cont" >         
			<div id="jq-event-id-153529810" class="row cf event-row jq-event-row odd" style="background:#84a7b2;color:#fff;font-size:14px"> 
			<div class="c_1" style="width:200px;padding-left:5px" >
			'.str_replace(' ',' / ',$ass->baslamasaat).'</div> 
			 
			<div class="">
			  <div class="team" style="width: 190px;font-size:14px" >'.$ass->ev_takim.'</div> 
			<div class="score">
			<img src="/img/icon_soccer-BD29B290C9CE321C12ED00624B2E471F.png" alt="Futbol" width="21" height="21" > 
			</div> 
			<div class="team" style="width: 240px;font-size:14px" >'.$ass->konuk_takim.'</div> 
			</div>
			</div>
			</div>';
			//}
		}
		echo $bas;
	}
	
	public function liveodds($mac_id,$farkliyaz,$x1=0){
		
		ajaxvarmi();
		$bas='';
		if(canliyasak >0 || canlibahis==0){
			$bas.='<div class="bos">'.lang('cbos').'</div>';
			echo ($bas);
			exit; 
		}
		if($mac_id){		
			if($x1){$x = $x1;}else{$x = $this->input->post("x");}
			if($x){
				$ekle="and b.oran_adi not in (".$x.")";
			}else{
				$ekle='';
			}
			$yeni='SELECT a.eventid,k.coranid,a.id,a.lig_adi,a.aktif,a.detay,a.dakika,a.ev_takim,a.konuk_takim,a.ev_skor,a.konuk_skor,a.devre,a.gol,a.sonoranguncelleme,
			(SELECT gizliler FROM coranver WHERE oranvalid=0 and lig_mac=0 and uye in('.$this->userler.') and gizliler=a.eventid and tip="aski") as surekliaski,
			(SELECT group_concat(oranvalid) FROM coranver WHERE lig_mac in(0,a.eventid) and uye in('.$this->userler.') and tip="gizlioranic") as gizlioranic,
			if(a.devre = "1. Yarı" and a.dakika >= '.canli_dk_kes.',1,0) as ilkyarigizle,
			GROUP_CONCAT(
			ct.tip_isim,"|",
			b.oran_adi,"|",
			   (		
				case				
				when c.tip="tumcanli" then CONCAT(ROUND(oranyuzdehesapla(b.oran,(c.oran+IFNULL(m.oran,0))),2))		
				when m.tip="maccanli" then CONCAT(ROUND(oranyuzdehesapla(b.oran,m.oran),2))		
				else CONCAT(ROUND(b.oran,2))
				end
				)	
			  ,"|",cv.oran_val,"|",b.yukselis,"|",b.dusus,"|",b.askida ORDER BY ct.sira asc,cv.sira asc
			) as sonoran

			FROM canli_maclar a
			left join kupon k on k.mac_kodu=a.eventid and session_id='.id.' and onlem="'.sesid.'"
			left join canli_oran b on b.mac_id=a.eventid and b.canli_tip not in((SELECT oranvalid FROM coranver WHERE lig_mac in(0,a.eventid) and uye in('.$this->userler.') and tip="gizlioran")) and b.canli_tip not in (1,28,24,3,52,53) '.$ekle.'
			
			left join canli_tip ct on ct.id=b.canli_tip and ct.durum=1
			left join oran_valc cv on cv.id=b.oran_adi
			
			left join coranver c on c.oranvalid=b.oran_adi and c.lig_mac = 0 and c.uye =(
			if(EXISTS(SELECT uye FROM coranver WHERE oranvalid=b.oran_adi and lig_mac = 0 and uye='.kendi.' and tip="tumcanli")
			,'.kendi.',if(EXISTS(SELECT uye FROM coranver WHERE oranvalid=b.oran_adi and lig_mac = 0 and uye='.ustu.' and tip="tumcanli"),'.ustu.','.patron.'))
			) and c.tip="tumcanli"

			left join coranver m on m.oranvalid=b.oran_adi and m.lig_mac = a.eventid and m.uye=(
			if(EXISTS(SELECT uye FROM coranver WHERE oranvalid=b.oran_adi and lig_mac = a.eventid and uye='.kendi.' and tip="maccanli")
			,'.kendi.',if(EXISTS(SELECT uye FROM coranver WHERE oranvalid=b.oran_adi and lig_mac = a.eventid and uye='.ustu.' and tip="maccanli"),'.ustu.','.patron.'))
			) and m.tip="maccanli"
		
			where
			a.eventid not in((SELECT gizliler FROM coranver WHERE oranvalid=0 and lig_mac=0 and uye in('.$this->userler.') and gizliler=a.eventid and tip="gizlimac"))
			and a.id='.$mac_id.'
			and a.lig_adi!=""
			and a.yer="'.aktifcanli.'"
			and a.sonoranguncelleme>'.$this->fark.'
			and a.dakika <='.canli_dk_kes1.'
			'.$this->notLike.'
			group by b.mac_id,a.adminid';
		
			$sor = $this->db->query($yeni);
			$toplam=$sor->num_rows();
			$mb=$sor->row();
			
			
			if ($toplam == 0 || count($mb->sonoran)==0) { 
				$bas.='<div class="bos">'.lang('cbos').'</div>';
				echo ($bas);
				exit; 
			}
			
			$surekli_aski_durum = surekli_aski_durum($mb->gol,$mb->sonoranguncelleme,$mb->surekliaski);
			if($surekli_aski_durum==1 || $mb->aktif=="0") { $aktifi = 0; } else { $aktifi = 1; }
	
			$arr = array();
			
			$bol=explode(',',$mb->sonoran);
			$gizlioranic=explode(',',$mb->gizlioranic);
			
			foreach($bol as $data){					
				$bol1=explode('|',$data);
				//$bol1[3]=($bol1[3].'d');	
				$arr[$bol1[0]][]= $bol1;
			}
			
			$renk=0;
			$bas.='<div class="extra-table-sports blueext">';
			
			if($mb->dakika<45) { $iyari= 'big-'; }else { $iyari= '';}
			if($mb->devre=="Devre arası") { $dkyaz= "Devre";}else 
			if($mb->dakika=="") { $dkyaz= "-"; }else 
			if(is_numeric($mb->dakika)) {$dkyaz=$mb->dakika." '";}
			
			$lg=explode('-',$mb->lig_adi);
			$dt=explode('|',$mb->detay);
			$corn=explode("-",$dt[0]);
			$sk=explode("-",$dt[1]);
			$kk=explode("-",$dt[5]);
			
			$bas.='<div class="new-tips-live soccer"> <div class="cnt0 sc"> <div class="title"> <div class="play"><i class="fa fa-clock-o"></i></div> <span>'.$dkyaz.'</span> </div> <div class="cnt sc"> <div class="league">'.$lg[0].' '.$lg[1].'</div> <table class="live-soccer-tracker"> <tbody><tr> <th>'.$mb->ev_takim.'</th> <th>'.$mb->ev_skor.':'.$mb->konuk_skor.'</th> <th>'.$mb->konuk_takim.'</th> </tr> <tr> <td><strong><i class="fa fa-square yellow"></i>'.lang('srk').'</strong></td> <td>'.(int)$sk[0].':'.(int)$sk[1].'</td> <td><strong><i class="fa fa-square yellow"></i>'.lang('srk').'</strong></td> </tr> <tr> <td><strong><i class="fa fa-square red"></i>'.lang('krk').'</strong></td> <td>'.(int)$kk[0].':'.(int)$kk[1].'</td> <td><strong><i class="fa fa-square red"></i>'.lang('krk').'</strong></td> </tr> <tr> <td><strong><i class="fa fa-flag "></i>'.lang('krn').'</strong></td> <td>'.(int)$corn[0].':'.(int)$corn[1].'</td> <td><strong><i class="fa fa-flag"></i>'.lang('krn').'</strong></td> </tr> </tbody></table> </div> </div> </div>';
			
			foreach ($arr as $tipbaslik => $veri) {
				
				if($renk % 2 == 0){$rdver='zebra';}else{$rdver='';}
				
				$saybe=count($veri);
				if($saybe==2 || strstr($tipbaslik,'Alt/Üst')){
					$cls= 2;
				}elseif($saybe==3){
					$cls= 3;
				}elseif($saybe==4){
					$cls= 4;
				}
				$tipbaslik=temizle($tipbaslik);
				$tipbaslik=lang($tipbaslik);
				/*if($tipbaslik=='Toplam Gol Sayısı' || $tipbaslik=='Ev Sahibi İlk Yarı Alt/Üst' || $tipbaslik=='İkinci Yarı Toplam Gol Alt/Üst' || $tipbaslik=='İlk Yarı Toplam Gol Alt/Üst' || $tipbaslik=='İlk Yarı Toplam Gol Alt/Üst' || $tipbaslik=='İlk Yarı Sonucu Alt/Üst' || $tipbaslik=='Ev Sahibi Maç Sonucu Alt/Üst' || $tipbaslik=='Maç Sonucu ve Toplam Goller' || $tipbaslik=='Deplasman Maç Sonucu Alt/Üst' || $tipbaslik=='Maç Sonucu Alt/Üst' || $saybe==2){$cls= "2";}elseif($tipbaslik=='Goller Ev Sahibi' || $tipbaslik=='Ev sahibi İlk Yarı Toplam Gol' || $tipbaslik=='Goller Deplasman' || $tipbaslik=='Deplasman İlk Yarı Toplam Gol' || $tipbaslik=='Deplasman'){$cls= "4";}else{$cls= "3";}*/
				
				$bas.='<div class="table-row-'.$cls.' '.$rdver.'">
				<div class="lenotip-title"><p>'.$tipbaslik.'</p></div><ul>';
				
				$odsay=0;
				foreach($veri as $ass1){
					
					$oran_id=$ass1[1];
					$oran_adi=$ass1[3];
					$oran=$ass1[2];
					$yukselis=$ass1[4];
					$dusus=$ass1[5];
					if(!empty(canli_koruma) && canli_koruma!='0.00' && $oran >= canli_koruma){
						$oran=canli_koruma;
					}
					$canli_kupon_sure = time()+(canli_kupon_sure * 60);
					$kuponekle = codekupon("$oran|".$mb->id."|".$oran_id."|".$canli_kupon_sure);	
					$cekle1='onClick="canliekle(\''.$kuponekle.'\');$(\'.icoran\').removeClass(\'active\');$(this).addClass(\'active\');"';
					
					if($oran_id==$mb->coranid){
						$seciliclass1='active';
						$ydus=yukdurumsec($yukselis,$dusus);
					}else{
						$ydus=yukdurum($yukselis,$dusus);
						$seciliclass1='';
					}
					if($aktifi==0 || $ass1[6]==0 || in_array($oran_id,$gizlioranic)) {
						$askclass1='ldisabled';
						$kupver1='';
					}else{
						$askclass1='';
						$kupver1=$cekle1;
					}
					
					if($oran<=1.00){
						$kupver1='';
						$oran='-';
					}
					if($askclass1 == 'ldisabled'){
						$oran='';
					}
					if($oran_adi=='Ev Sahibi ya da Beraberlik'){
						$oran_adi='1-X';
					}elseif($oran_adi=='Ev Sahibi ya da Deplasman'){
						$oran_adi='1-2';
					}elseif($oran_adi=='Deplasman ya da Beraberlik'){
						$oran_adi='2-X';
					}elseif($oran_adi=='Ev Sahibi (0:1)'){
						$oran_adi='1 (0:1)';
					}elseif($oran_adi=='Beraberlik (0:1)'){
						$oran_adi='X (0:1)';
					}elseif($oran_adi=='Deplasman (0:1)'){
						$oran_adi='2 (0:1)';
					}elseif($oran_adi=='Ev Sahibi (1:0)'){
						$oran_adi='1 (1:0)';
					}elseif($oran_adi=='Beraberlik (1:0)'){
						$oran_adi='X (1:0)';
					}elseif($oran_adi=='Deplasman (1:0)'){
						$oran_adi='2 (1:0)';
					}elseif($oran_adi=='Ev Sahibi Alt 2.5'){
						$oran_adi='1 Alt 2.5';
					}elseif($oran_adi=='Beraberlik Alt 2.5'){
						$oran_adi='X Alt 2.5';
					}elseif($oran_adi=='Deplasman Alt 2.5'){
						$oran_adi='2 Alt 2.5';
					}elseif($oran_adi=='Ev Sahibi Üst 2.5'){
						$oran_adi='1 Üst 2.5';
					}elseif($oran_adi=='Beraberlik Üst 2.5'){
						$oran_adi='X Üst 2.5';
					}elseif($oran_adi=='Deplasman Üst 2.5'){
						$oran_adi='2 Üst 2.5';
					}elseif($oran_adi=='1 Yener Gol Olur'){
						$oran_adi='1 Yener';
					}elseif($oran_adi=='2 Yener Gol Olur'){
						$oran_adi='2 Yener';
					}elseif($oran_adi=='Gol Olur Berabere Biter'){
						$oran_adi='Gol X';
					}
					$oadi=temizle($oran_adi);
					$oran_adi=lang($oadi);
					if(!$oran_adi){
						$oran_adi=$oran_adi;
					}
					$bas.='<li><strong>'.$oran_adi.'</strong><a href="javascript:;" '.$kupver1.' class="icoran '.$askclass1.' '.$ydus.' '.$seciliclass1.'"><span>'.$oran.'</span></a></li>';					
				}				
				$bas.='</ul></div>';
				$renk++;
			}
			$bas.='<a class="closeblue" onclick="orkapat('.$mb->eventid.');">Kapat</a></div>';			
		}
		
		if($farkliyaz==1){
			return $bas;
		}else{
			echo ($bas);
		}
		
	}
	
	public function livelist(){
		
		ajaxvarmi();
		$bas['ust']='';
		$gelenvent = $this->input->post("eventler");
		if(canliyasak >0 || canlibahis==0){
			$bas['ust'].='<div class="bos">'.lang('cbos').'</div>';
				echo json_encode($bas);
				exit; 
		}
		
		$yeni='SELECT a.adminid,a.lig_adi,k.coranid,k.mac_db_id,a.orsayi,a.eventid,a.gol,a.betradar_id,a.id,a.ev_takim,a.konuk_takim,a.aktif,a.dakika,a.devre,a.ev_skor,a.konuk_skor,a.sonoranguncelleme,
		(SELECT gizliler FROM coranver WHERE oranvalid=0 and lig_mac=0 and uye in('.$this->userler.') and gizliler=a.eventid and tip="aski") as surekliaski,
		(SELECT count(oranvalid) FROM coranver WHERE lig_mac in(0,a.eventid) and uye in('.$this->userler.') and tip="gizlioranic") as gizlioranic,
		GROUP_CONCAT(
		a.eventid,"|",
		b.oran_adi,"|",
		   (		
			case				
			when c.tip="tumcanli" then CONCAT(ROUND(oranyuzdehesapla(b.oran,(c.oran+IFNULL(m.oran,0))),2))		
			when m.tip="maccanli" then CONCAT(ROUND(oranyuzdehesapla(b.oran,m.oran),2))		
			else CONCAT(ROUND(b.oran,2))
			end
			)	
		  ,"|",b.yukselis,"|",b.dusus,"|",b.canli_tip,"|",b.askida,"|",cv.oran_val ORDER BY b.canli_tip asc,cv.sira asc
		) as sonoran

		FROM canli_maclar a
		left join kupon k on k.mac_db_id=a.id and session_id='.id.' and onlem="'.sesid.'"
		left join canli_oran b on b.mac_id=a.eventid and b.canli_tip not in((SELECT oranvalid FROM coranver WHERE lig_mac in(0,a.eventid) and uye in('.$this->userler.') and tip="gizlioran")) and b.canli_tip in (1,28,24,3,52,53,2,19)
		
		left join oran_valc cv on cv.id=b.oran_adi
		
		left join coranver c on c.oranvalid=b.oran_adi and c.lig_mac = 0 and c.uye =(
		if(EXISTS(SELECT uye FROM coranver WHERE oranvalid=b.oran_adi and lig_mac = 0 and uye='.kendi.' and tip="tumcanli")
		,'.kendi.',if(EXISTS(SELECT uye FROM coranver WHERE oranvalid=b.oran_adi and lig_mac = 0 and uye='.ustu.' and tip="tumcanli"),'.ustu.','.patron.'))
		) and c.tip="tumcanli"

		left join coranver m on m.oranvalid=b.oran_adi and m.lig_mac = a.eventid and m.uye=(
		if(EXISTS(SELECT uye FROM coranver WHERE oranvalid=b.oran_adi and lig_mac = a.eventid and uye='.kendi.' and tip="maccanli")
		,'.kendi.',if(EXISTS(SELECT uye FROM coranver WHERE oranvalid=b.oran_adi and lig_mac = a.eventid and uye='.ustu.' and tip="maccanli"),'.ustu.','.patron.'))
		) and m.tip="maccanli"
	
		where
		a.eventid not in((SELECT gizliler FROM coranver WHERE oranvalid=0 and lig_mac=0 and uye in('.$this->userler.') and gizliler=a.eventid and tip="gizlimac"))
		
		and a.sonoranguncelleme>'.$this->fark.'
		and a.dakika <='.canli_dk_kes1.'
		and a.lig_adi!=""
		and a.yer="'.aktifcanli.'"
		'.$this->notLike.'		
		and a.adminid=(if(a.adminid='.kendi.','.kendi.',0))
			
		group by b.mac_id,a.adminid
		order by a.id desc
		';
		/*and a.adminid =(case 
			when a.adminid='.kendi.' then '.kendi.'
			when a.adminid!='.kendi.' then 0
			end
		)*/
		$sor = $this->db->query($yeni);
		$toplam=$sor->num_rows();
		
		if ($toplam == 0) { 
			$bas['ust'].='<div class="bos">'.lang('cbos').'</div>';
			echo json_encode($bas);
			exit; 
		}
		
		$oddeve=0;
				
		$set = array();
		foreach($sor->result() as $mb1){
			$lg=explode('-',$mb1->lig_adi);
			$set[$lg[0].' '.$lg[1]][]= $mb1;
		}
		if(detect_mobile()){$giztyle='style="display:none !important;"';}else{$giztyle='';}
		foreach ($set as $ligadi => $data) {
			$bas['ust'].='<ul class="table-title-333121">
				<li></li>
				<li>'.$ligadi.'</li>
				<li> <strong>'.lang('thm').'</strong> <span>1</span> <span>X</span> <span>2</span> </li>
				<li '.$giztyle.'> <strong>'.lang('ksure').'</strong> <span>1</span> <span>X</span> <span>2</span> </li>
				<li '.$giztyle.'> <strong>'.lang('sgol').'</strong> <span>1</span> <span>X</span> <span>2</span> </li>
				<li></li>
				<li> <strong>'.lang('ua').'</strong> <span>'.lang('alt').'</span> <span>'.lang('ust').'</span> </li>
				<li>+</li>
				</ul>';
			foreach($data as $mb){
			
			$surekli_aski_durumo =surekli_aski_durum($mb->gol,$mb->sonoranguncelleme,$mb->surekliaski);
			if($surekli_aski_durumo==1 || $mb->aktif=="0") { $aktif = 0; } else { $aktif = 1; }				
							
			$arr = array();
			$oranlar = array();			
				
			$bol=explode(',',$mb->sonoran);
			//echo'<pre>';print_R($bol);
			foreach($bol as $data){
				$bol1=explode('|',$data);
				if($bol1[5]==2){
					//echo count($bol1);
				}
				//echo'<pre>';print_R($bol1);
				$arr[$bol1[0]][]= $bol1;
				
			}//exit;
			$altust=$iyaltustyaz=$altustyaz=$iyaltust=$sgol=$iygk1=$ms1=$iysira=$iyms1=$kv=$ky=$sd=$s0=$ms0=$s1=$cs2=$cs0=$ms2=$cs1=$gk1=$gk0=$gk2=$acoran='';
			$tmp=$iyal=0;
			$bunlarialma='';
			foreach ($arr as $tipbaslik => $veri1) {
				
				//echo'<pre>';print_R($veri1);
				foreach($veri1 as $k=>$veri){
					
					$evid=$veri[0];
					if($evid==$mb->eventid){
						//echo'<pre>';print_R($veri);				
					
						$oran_id=$veri[1];
						$oran=$veri[2];
						$yukselis=$veri[3];
						$dusus=$veri[4];
						$canli_tip=$veri[5];
						$oran_adi=$veri[7];
						
						//if ($canli_tip==2 && $tmp++ > 2) {continue;}
						if(!empty(canli_koruma) && canli_koruma!='0.00' && $oran >= canli_koruma){
							$oran=canli_koruma;
						}
						$canli_kupon_sure = time()+(canli_kupon_sure * 60);
						$kupverr = codekupon("$oran|".$mb->id."|".$oran_id."|".$canli_kupon_sure);
						$cekle='onClick="canliekle(\''.$kupverr.'\');$(\'.bu'.$mb->id.'\').removeClass(\'active\');$(this).addClass(\'active\');"';
						
						if($oran_id==$mb->coranid && $mb->id==$mb->mac_db_id){
							$seciliclass='active';
							$ydus=yukdurumsec($yukselis,$dusus);
						}else{
							$ydus=yukdurum($yukselis,$dusus);
							$seciliclass='';
						}
						
						if($aktif==0 || $veri[6]==0 || $mb->gizlioranic==$oran_id) {
							$askclass='ldisabled';
							$kupver='';
						}else{
							$askclass='';
							$kupver=$cekle;
						}
						if($askclass == 'ldisabled'){
							$oran='';
						}
						//$oranlar[$canli_tip][$oran_id]=array($ydus,$kupver,$oran);
						if($canli_tip==24){
							$sgol.='<a class="ratio-box bu'.$mb->id.' '.$askclass.' '.$seciliclass.' '.$ydus.'" href="#" id="" '.$kupver.'><span>'.$oran.'</span></a>';
							$bunlarialma.=$oran_id.',';
						}
						if($canli_tip==1){
							$ms1.='<a class="ratio-box bu'.$mb->id.' '.$askclass.' '.$seciliclass.' '.$ydus.'" href="#" id="" '.$kupver.'><span>'.$oran.'</span></a>';
							$bunlarialma.=$oran_id.',';
						}
						if($canli_tip==3 && $mb->dakika<45){
							$iyms1.='<a class="ratio-box bu'.$mb->id.' '.$askclass.' '.$seciliclass.' '.$ydus.'" href="#" id="" '.$kupver.'><span>'.$oran.'</span></a>';
							$bunlarialma.=$oran_id.',';
						}
						if($canli_tip==52 && $mb->dakika<45){
							$iysira.='<a class="ratio-box bu'.$mb->id.' '.$askclass.' '.$seciliclass.' '.$ydus.'" href="#" id="" '.$kupver.'><span>'.$oran.'</span></a>';
							$bunlarialma.=$oran_id.',';
						}
						if($canli_tip==28){
							$gk1.='<a class="ratio-box bu'.$mb->id.' '.$askclass.' '.$seciliclass.' '.$ydus.'" href="#" id="" '.$kupver.'><span>'.$oran.'</span></a>';
							$bunlarialma.=$oran_id.',';
						}
						if($canli_tip==53 && $mb->dakika<45){
							$iygk1.='<a class="ratio-box bu'.$mb->id.' '.$askclass.' '.$seciliclass.' '.$ydus.'" href="#" id="" '.$kupver.'><span>'.$oran.'</span></a>';
							$bunlarialma.=$oran_id.',';
						}	
						if($canli_tip==2){
							if ($tmp++ > 1) {continue;}
							$altustyaz='<span class="clear-box"><span>'.str_replace(array('Alt','Üst',' '),'',$oran_adi).'</span></span>';
							$altust.='<a class="ratio-box bu'.$mb->id.' '.$askclass.' '.$seciliclass.' '.$ydus.'" href="#" id="" '.$kupver.'><span>'.$oran.'</span></a>';
							$bunlarialma.=$oran_id.',';
						}
						if($canli_tip==19 && $mb->dakika<45){
							if ($iyal++ > 1) {continue;}
							$iyaltustyaz='<span class="clear-box"><span>'.str_replace(array('Alt','Üst',' '),'',$oran_adi).'</span></span>';
							$iyaltust.='<a class="ratio-box bu'.$mb->id.' '.$askclass.' '.$seciliclass.' '.$ydus.'" href="#" id="" '.$kupver.'><span>'.$oran.'</span></a>';
							$bunlarialma.=$oran_id.',';
						}
										  
					}
				}
			}
			
			$golsesi = time()-60;
			$golhtml='<span style="background-color:red;color:#fff;width:40px"><img src="'.base_url().'img/golvar.GIF" style="" height="10"> <ibrahim>Gooooll !</ibrahim></span>';
			if(!empty($mb->gol) && $mb->gol>$golsesi) {
				$golvar=$golhtml;
			}else{
				$golvar='';
			}
			
			if($mb->devre!='2. Yarı') { $devreyaz= $mb->devre; }else { $devreyaz= '';}
			if($mb->dakika<45) { $iyari= 'big-';$orsayidusur=23; }else { $iyari= '';$orsayidusur=14;}
			if($mb->devre=="Devre arası") { $dkyaz= lang('dvre');}else 
			if($mb->dakika=="") { $dkyaz= "-"; }else 
			if(is_numeric($mb->dakika)) {$dkyaz=$mb->dakika." '";}
			
			$bunlarialma=substr($bunlarialma,0,-1);
			
			if($mb->id==$gelenvent){
				
				$opened='block';
				$oracclass='extra-but-slcted-orange';				
				$acoran=$this->liveodds($mb->id,1,$bunlarialma);
				
			}else{
				
				$opened='none';
				$oracclass=$acoran='';
				
			}
			
			if($mb->betradar_id){
				$tvvarmi='
				<img src="/images/saha.png" rel="http://ls.betradar.com/ls/livescore/?/universalsoftwaresolutions/tr/Europe:Istanbul/page/sportcenter_custom/'.$mb->betradar_id.'" style="vertical-align: middle;cursor: pointer; width: 20px;padding: 0px" id="videoac" class="tvimg" onclick="javascript:void(0);">
				';
			}else{
				$tvvarmi='';
			}
			
			$oryaz=$mb->orsayi-$orsayidusur;
			$bas['ust'].='<input type="hidden" id="x_'.$mb->eventid.'" value="'.$bunlarialma.'">';
			$bas['ust'].='<ul class="table-'.$iyari.'match-333121">
				<li class="live">'.$dkyaz.'</li>
				<li>
					<em class="xcard hidden"><txt >0</txt></em>
					<span class="t1">'.$mb->ev_takim.'</span>
					<span class="score">'.$mb->ev_skor.':'.$mb->konuk_skor.'</span>
					<em class="xcard hidden"><txt >0</txt></em>
					<span class="t2 ">'.$mb->konuk_takim.'</span>';
					if($iyari){
						$bas['ust'].='<small><span style="float: right; margin-top: -15px; width: 65px;">'.lang('ms').'</span><span style="float: right; width: 40px; margin-top: -5px;">'.lang('iy').'</span></small>';
					}
				if($tvvarmi){
					$yeniac='<li id="tumac'.$mb->eventid.'" class="'.$oracclass.' oranstil"><span onclick="oran_ac('.$mb->id.');">+'.$oryaz.'</span> '.$tvvarmi.'</li>';
				}else{
					$yeniac='<li onclick="oran_ac('.$mb->id.');" id="tumac'.$mb->eventid.'" class="'.$oracclass.' oranstil">+'.$oryaz.'</li>';
				}
				$bas['ust'].='</li>
				<li>'.$ms1.''.$iyms1.'</li>
				<li '.$giztyle.'>'.$gk1.''.$iygk1.'</li>
				<li '.$giztyle.'>'.$sgol.''.$iysira.'</li>
				<li>'.$altustyaz.''.$altust.''.$iyaltustyaz.''.$iyaltust.'</li>
				'.$yeniac.'
				</ul>
				<div id="betdetail_'.$mb->id.'" class="orkapatall" style="display: '.$opened.';">'.$acoran.'</div>';
			$oddeve++;
		}
		}
		echo json_encode($bas);
	}
	
	public function macsonuclari(){
		
		$bas='';
		for($i=0; $i<(date("d")); $i++) {
			$otarih = strtotime("-".$i." days");
			$bas.='<option value="'.date("Y-m-d",$otarih).'">'.date("d.m.Y",$otarih).'</option>';
		}
		$this->smarty->assign('trh',$bas);
		$this->smarty->view('macsonuclari.tpl');
	}
	
	public function macsonuclaridata(){
	
	ajaxvarmi();
	$tarih = $this->input->post('tarih');
	$takim = $this->input->post('takim');
	$url = "http://www.sahadan.com/LiveScores/LiveScoresAjax.aspx?seq=-1&txtDate=".date('d.m.Y',strtotime($tarih))."&iddaa=0&canli=0&allIddaa=0&ddlGrup=&CM=1&st=1&au=0&duel=0";
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/13.0.782.112 Safari/535.1");	
	curl_setopt($ch, CURLOPT_TIMEOUT, 60);
	curl_setopt($ch, CURLOPT_REFERER, "http://www.sahadan.com/");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
	curl_setopt($ch, CURLOPT_URL, $url);
	$page = curl_exec ($ch);
	curl_close ($ch);	

	$tamammi=0;	
	preg_match_all('#C1M(.*?);#Ssie',$page,$sonuc_satirlari);	
		
	if(!empty($sonuc_satirlari[1])){
	?>
	<table class="tftable" style="width:100%" cellspacing="0" cellpadding="0">
		<thead><tr>
		<th style="text-align:right"><?=lang('ev');?></th>
		<th style="text-align:center;width:20px"><?=lang('ms');?></th>		
		<th><?=lang('dep');?></th>		
		<th><?=lang('iy');?></th>		
		</tr></thead><tbody>
	<?
	foreach($sonuc_satirlari[1] as $ss){
			$satir_parcalari = explode(',',$ss);
			$ev_takim = str_replace(array("'"),'',$satir_parcalari[11]);
			$konuk_takim = str_replace(array("'"),'',$satir_parcalari[12]);
			$iyskor = str_replace(array("'"),'',$satir_parcalari[13]);
			$skor = str_replace(array("'"),'',$satir_parcalari[14]);
			$eventid = str_replace(array("'"),'',$satir_parcalari[9]);
			$ligadi = str_replace(array("'"),'',$satir_parcalari[5]).' - '.str_replace(array("'"),'',$satir_parcalari[2]);
			//echo'<pre>';print_r($satir_parcalari);
			$flag = str_replace(array("'"),'',$satir_parcalari[4]);
			$ikitakimda = "".$ev_takim."".$konuk_takim."";
			if((!empty($takim) && stristr($ikitakimda,$takim)) || empty($takim)) {
				
	?>
	<tr class="bas">
	<td style="width:200px; padding:3px; text-align:right;"><?=$ev_takim;?></td>
	<td style="width:50px; padding:3px; text-align:center; font-weight:bold;" class="skorbo" title="Maç Sonucu"><?=$skor;?></td>
	<td style="width:200px; padding:3px;"><?=$konuk_takim;?></td>
	<td style="width:50px; padding:3px;" title="İlk Yarı Sonucu"><?=$iyskor;?></td>
	</tr>
	<? } ?>
	<? } ?>
	</tbody></table>
	<?
	}
	}

}
