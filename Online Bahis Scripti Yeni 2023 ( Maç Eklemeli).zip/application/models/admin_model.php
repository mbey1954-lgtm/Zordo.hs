<?php class admin_model extends CI_Model{
   var $dosya_yolu;
    function __construct() {       
					parent::__construct();
					//$this->ana_menu();    
					//$this->alt_menu();    
					//$this->alt_menu_is();    
    }
	
	function kurum_getir(){
		$s = $this->db->query("select * from fatura_kurum where durum=1 or durum=3 order by kurum asc");
		return $s->result();		
	}	
	
	function sorgu_cek($tablo,$where){
		$s = $this->db->query("select * from ".$tablo." ".$where." limit 1");
		return $s->row();		
	}
	
	function sorgu_cek_kontrol($tablo,$where){
		$s = $this->db->query("SELECT * FROM ".$tablo." ".$where." ");
		if ($s->num_rows() > 0) {
            return true;
        } else {
            return false;
        }	
	}
	
	function fatura_rapor_model($whereString,$start,$limit,$paymentmi=''){
		if($paymentmi==1){
		$bayisec="";		
		}else{
		$bayisec=",(SELECT kullanici_adi  FROM bayi_bilgileri where id=a.bayi_id) as bayi";
		}
		$sql = $this->db->query("SELECT  a.*,
				(SELECT kurum from fatura_kurum where id=a.kurum_id) as kurum								
				$bayisec						
				from fatura a
				where id!=0 ".$whereString."
				 LIMIT $start , $limit");
		return $sql->result();
	}
	
	function pagin_toplam_sayfa($tablo,$whereString){
		$sql = $this->db->query("SELECT COUNT(id) AS tpl FROM ".$tablo." a  where a.id!=0 ".$whereString."");
		return $sql->row()->tpl;
	}
	
	function toplam_tutarlar_model($tablo,$whereString,$alan){
		foreach ($alan as $veri){
		$sum[]="sum(".$veri.") as ".$veri." ";
		}		
		$sql = $this->db->query("SELECT ".implode(",",$sum)." from ".$tablo." a where a.id!=0 " . $whereString . "");
		return $sql->row();
	}
	
	function checkUsername($username){
								$this->db->where('id', $username);
								$query = $this->db->get('tanimgetir');
								if ($query->num_rows() > 0){
									return true;
								}
								else{
									return false;
								}
}
function toplam_kayit_getirme($tablo,$where,$alan='id') {
								$sql=$this->db->query('select count(`'.$alan.'`) as `toplam` from `'.$tablo.'` '.$where);
								$rs=$sql->row();
								//show_error('* Abone evraklar� onays�z.');
								/*write_file(getcwd().'/sinif_listeleme.csv', $export);
								 $this->cache->write($sorgu, 'cached-name');
								 $this->cache->delete('cached-name')
								  $this->cache->get('cached-name');
								 */
								return $rs->toplam;
}

	function count_posts()
								 {
								  return $this->db->count_all_results('ogrenci');
								 }
    
	function get_result($key, $page="0")  
    {  
								 $query = $this->db->query("  
								  SELECT *  
								  FROM ogrenci   
								  WHERE ad LIKE '%$key%'  
								  LIMIT $page,5  
								 ");  
								  
								 $nums = $this->db->query('SELECT FOUND_ROWS() as total');  
								  
								   
								 if($query->num_rows() > 0)  
								 {  
								  $result = array(  
								   'result' => $query->result_array(),  
								   'total' =>  $nums->row()->total  
								  );  
								  return $result;  
								 }  
								 else return FALSE;  
    }  
 function do_upload() {
								$filename = 'resim_' . time() . '_' . rand(0, 9);
								$config = array(
								'allowed_types' => 'jpg|jpeg|gif|png',
								'upload_path' => $this->dosya_yolu,
								'file_name' => $filename,
								'max_size' => 2000
								);
								$this->load->library('upload', $config);
								$this->upload->do_upload();
								$image_data = $this->upload->data();
								$config = array(
								'image_library' => 'gd2',
								'source_image' => $image_data['full_path'],
								'new_image' => $this->dosya_yolu.'/uploads',
								'file_name' => $filename,
								'maintain_ration' => true,
								'width' => 150,
								'height' => 100
								);
								$this->load->library('image_lib', $config);
								$this->image_lib->resize();
}

	function oklgetir($id)
    {    
	     $this->db->select('tanimgetir.id,tanimgetir.tur,ogrenci.okul,ogrenci.nosu,tanimgetir.isim');
         $this->db->from('ogrenci');
         $this->db->join('tanimgetir', 'tanimgetir.id = ogrenci.okul');
         $this->db->where('ogrenci.nosu',$id );
         $this->db->where('tanimgetir.tur','2' );
         $s = $this->db->get();if ($s->num_rows() > 0){$row = $s->row();
		 $row1 = $row->isim;}else{$row1 = '0';}
		 return $row1;   
    }
	
	function bolumgetir() {
        $s = $this->db->query("SELECT * FROM tanimgetir where tur='1'  ");
            return $row = $s->result_object();
    }
	function okulgetir() {
        $s = $this->db->query("SELECT * FROM tanimgetir where tur='2'  ");
            return $row = $s->result_object();
    }
	function yurtgetir() {
        $s = $this->db->query("SELECT * FROM tanimgetir where tur='4'  ");
            return $row = $s->result_object();
    }
	function danismangetir() {
        $s = $this->db->query("SELECT * FROM tanimgetir where tur='3'  ");
            return $row = $s->result_object();
    }
	function yakinlikgetir() {
        $s = $this->db->query("SELECT * FROM tanimgetir where tur='3'  ");
            return $row = $s->result_object();
    }
	function meslekgetir() {
        $s = $this->db->query("SELECT * FROM tanimgetir where tur='3'  ");
            return $row = $s->result_object();
    }
	function insert($data,$table){
             $_query = $this->db->insert($table,$data);
        if ($_query) {
           
            return true;
        } else {
            
            return false;
        }
    }
     function select($id)   {        
            $s = $this->db->query("SELECT * FROM ogrenci where id=$id ");
             $row = $s->result_object();
			 echo json_encode($row);
        
    } function selectaile($id)   {        
            $s = $this->db->query("SELECT * FROM aile where id=$id ");
            return $row = $s->result_object();
        
    }  
    function tekid($id)
	{
		$query = $this->db->get_where('ogrenci',array('id'=>$id));
		return $query->result();		
	}
     function popup($links,$isim){$atts = array(
              'width'      => '1200',
              'height'     => '740',
              'scrollbars' => 'yes','left' => '100',
              'status'     => 'yes',
              'resizable'  => 'yes',
              'screenx'    => '0',
              'screeny'    => '0'
            );

       return $pop= anchor_popup($links, $isim, $atts);
}	
     function arama($first_name)  
    {  
        // Fonksiyona g�nderilen de�eri sql injection'a kar�� filtreden ge�iriyorum.  
        $first_name = $this->db->escape_str($first_name);  
        $this->db->select('*');  
        $this->db->from('ogrenci');  
        $this->db->like('ad',$first_name);  
         
        // Sonucu geriye d�nd�r�yoruz.  
        return $this->db->get()->result();  
    } 
	function sil($id)   {        
            $this->db->delete('aile', array('id' => $id)); 
			 $this->db->delete('ogrenci', array('id' => $id)); 
           
        
    } function get_item_row($table,$column,$arr)  
    {  
     $query = $this->db->get_where($table,$arr);  
     if($query->num_rows() > 0)  
     {  
      $res = $query->row();  
      return $res->$column;  
     }else return FALSE;  
    }  
    function get_users(){
 
  $sql = "SELECT * FROM ogrenci WHERE id =  '$id' ";
  
  $query = $this->db->query($sql);
 
  if ( $query->result() )
    {
      return $query->result();
    }
      else
    {
      return array();
    }
  }   function get_username($where)  
 {  
  $query = $this->db->query("  
   SELECT DISTINCT ad  
   FROM ogrenci  
   WHERE $where  
  ");  
  
  $result = $query->row();  
    
  if($query->num_rows() > 0)  
  {  
   return $query->result_array();  
  }  
    
 }    	
}	