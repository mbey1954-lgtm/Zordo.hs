<?php
class Membership_model extends CI_Model{

	function validate()
	{
		$this->db->where('username',$this->input->post('username'));
		$this->db->where('sb',$this->input->post('subeler'));
		$this->db->where('password',$this->input->post('password'));
		$query = $this->db->get('membership');		
		if($query->num_rows() == 1) {
			return $query->result();
		}
	}
	function get_user($username)  
     {  
      $query = $this->db->get_where('membership',array('username'=>$username));  
      if($query->num_rows() > 0) return FALSE;  
      else return TRUE;  
     } 
	 
	 
	function kullanici_adi_parola_ile_al($tablo,$kullanici_adi,$parola)
    {
        $sql = "SELECT * FROM ".$tablo." WHERE kullanici_adi=? AND parola=? ";
        $query = $this->db->query( $sql, array($kullanici_adi, $parola ));

        if( $query->num_rows() > 0 )
            return $query->row();

        return FALSE;
    }
	function yonetici_giris_al($kullanici_adi,$parola)
    {
        $sql = "SELECT * FROM yonetici WHERE yonetici_kullanici_adi=? AND yonetici_sifre=?";
        $query = $this->db->query( $sql, array($kullanici_adi, $parola));

        if( $query->num_rows() > 0 )
            return $query->row();

        return FALSE;
    }
	function create_member($data)
	{
		$new_member_insert_data = array(
			'firstname' => $data['adi'],
			'lastname' => $data['soyadi'],
			'email' => $data['email'],
			'username' => $data['kuladi'],
			'sb' => $data['subeler'],
			'password' => md5($data['sifre'])			
		);
		$insert = $this->db->insert('membership',$new_member_insert_data);
		return $insert;
	}
}

?>