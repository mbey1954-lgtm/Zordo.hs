<?php class bayi_model extends CI_Model{
    function __construct() {       
					parent::__construct();
					  
    }
	
	function bayi_hesap_hareket($tablo,$whereString,$start,$limit){
		$s = $this->db->query("select a.*,
		(SELECT kullanici_adi  FROM bayi_bilgileri where id=a.bayi_id) as bayi
		from ".$tablo." a where a.id!=0 ".$whereString." LIMIT $start , $limit");
		return $s->result();	
	}
	
	function bayi_listesi($tablo,$whereString,$start,$limit){
		$s = $this->db->query("select * from ".$tablo." where id!=0 
		".$whereString." order by id desc LIMIT $start , $limit");
		return $s->result();		
	}
	
	
}	