<?php
class pag_model extends CI_Model{

 function __construct(){
 
		parent::__construct();
 
	}
 
function get_results($terms = array(), $limit, $offset){
	$this->db->select('*');
	if(count($terms) > 0){
		if(array_key_exists('ad', $terms)){
 			//$ww = " ogrenci.ad LIKE('%" . $terms['ad'] . "%') ";
			//$this->db->where(" ogrenci.ad LIKE('%" . $terms['ad'] . "%') ");
			$this->db->where("(ogrenci.ad like '%$terms[ad]%' )");
		}
		if(array_key_exists('cins', $terms)){
			$this->db->where("(ogrenci.cinsiyet = $terms[cins] )");
		}
		if(array_key_exists('soyad', $terms)){
			$this->db->where("(ogrenci.soyad like '%$terms[soyad]%' )");		
		}
		if(array_key_exists('puan1', $terms)&array_key_exists('puan2', $terms)){
			$this->db->where("(ogrenci.puan BETWEEN $terms[puan1] AND $terms[puan2])");		
		}
	}
    $this->db->order_by('ogrenci.id', 'DESC'); 
	$this->db->limit($limit, $offset);
	$query = $this->db->get('ogrenci');
 /*$count = $this->db->query('SELECT FOUND_ROWS() as rowcount');
									$say =$count->row();
									 $tot= $say->rowcount;*/
	
	return $tab= $query->result();
 
	//$result = array();
	/*$result = array(  
									   'sorgu' => $tab,  
									   'total' => $tot  
									  ); 
									  return $result;*/
} 
 function hep($terms = array()){
 
	$this->db->select('*');
 $this->db->SQL_CALC_FOUND_ROWS();
 
	if(count($terms) > 0){
 
		if(array_key_exists('ad', $terms)){
 			//$ww = " ogrenci.ad LIKE('%" . $terms['ad'] . "%') ";
			//$this->db->where(" ogrenci.ad LIKE('%" . $terms['ad'] . "%') ");
			$this->db->where("(ogrenci.ad like '%$terms[ad]%' )");
		}
		if(array_key_exists('cins', $terms)){
			$this->db->where("(ogrenci.cinsiyet = $terms[cins] )");
		}
		if(array_key_exists('soyad', $terms)){
			$this->db->where("(ogrenci.soyad like '%$terms[soyad]%' )");		
		}
		if(array_key_exists('puan1', $terms)&array_key_exists('puan2', $terms)){
			$this->db->where("(ogrenci.puan BETWEEN $terms[puan1] AND $terms[puan2])");		
		}
	}
	$query = $this->db->get('ogrenci');
 $count = $this->db->query('SELECT FOUND_ROWS() as rowcount');
									$say =$count->row();
									return $tot= $say->rowcount;
	
 
}
}