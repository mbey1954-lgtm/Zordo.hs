<?php class odeme_kullanici_model extends CI_Model{
    function __construct() {       
					parent::__construct();
					  
    }
	
	function odeme_kullanici_fatura_update($id,$userid='',$durumne){
		$paidDate = time();
		if($userid==''){
			$askida=' ';
			$nebu=' , odenen_kanal="-1" ,odenme_zamani=' . $paidDate . ' ';
		}else{
			$askida=', odenen_kanal=' . $userid . ',odenme_zamani=' . $paidDate . ' ';
			$nebu="";
		}
		//$userid =='' ? $askida=' ' : $askida=', odenen_kanal=' . $userid . ',odenme_zamani=' . $paidDate . ' ' ;
		$s = $this->db->query('UPDATE fatura set odeme_durumu ='.$durumne.' '.$askida.' '.$nebu.' where id='.$id.' ');
		if ($s) {
            return true;
        } else {
            return false;
        }	
	}
	function odeme_kullanici_hareket_kayit($islem,$paymentUserId, $referenceId, $amount,$banka='') {      
		
		$amount = number_format($amount, 2, '.', '');	   
		$result =$this->db->query("select bakiye from ekran_uye where id='" . $paymentUserId . "'");
		$eski_bakiyesi = $result->row()->bakiye;		
			if($islem=='ekle'){
				$sonraki=$eski_bakiyesi+$amount;
				$guncelle="bakiye = bakiye + '".$amount."' ";
			}else{
				$sonraki=$eski_bakiyesi-$amount;
				$guncelle="bakiye='".$sonraki."'";
			}		
		$record=array(
		'odeme_ekrani_id'=>$paymentUserId,
		'islem'=>$referenceId,
		'tl'=>$amount,
		'onceki'=>$eski_bakiyesi,
		'sonraki'=>$sonraki,
		'banka'=>$banka
		);
		
		$result = $this->db->insert("odeme_ekrani_bakiye_yeni",$record);
		$this->db->query("UPDATE ekran_uye  SET $guncelle WHERE id = $paymentUserId");
		//$result = $this->db->update("ekran_uye",$record1,array("id"=>$paymentUserId));
        //echo $this->db->last_query();
        if ($result) {
            return true;
        } else {
            return false;
        }
    }
}	