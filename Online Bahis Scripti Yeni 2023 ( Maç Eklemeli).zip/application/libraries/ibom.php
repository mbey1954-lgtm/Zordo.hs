<?php
class a
{
    private static $isim = 'yusuf';
 
    public static function isimGetir()
    {
        echo self::$isim;
    }
}
 
a::isimGetir();
?>
