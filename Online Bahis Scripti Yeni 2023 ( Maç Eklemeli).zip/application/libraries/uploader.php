<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
* Created by JetBrains PhpStorm.
* User: kabin-ekibi > wyrus
* Date: 27.06.2011
* Time: 12:06
*/
class Uploader{
    private $file;
    private $upload_dir;
    private $new_name;
    private $types=array('jpg','gif','png');
    private $ext;
    public function __construct(){

    }
    public function __set($name,$value){
        $this->$name=$value;
    }
    /*
* @return array('status','fileName','fileDir');
*/
    public function upload(){
        $status=self::check_type();
        if($status['status'] =="error"){
            return $status;
        }else{
            if($this->new_name){
                $this->new_name=$this->new_name.'.'.self::extension();
            }else{
                $this->new_name=self::newname();
            }
            $yukle = move_uploaded_file($this->file['tmp_name'],$_SERVER['DOCUMENT_ROOT'].'/'.$this->upload_dir.'/'.$this->new_name);
            if(!$yukle){
                $sonuc['status']="error";
                $sonuc['msg']="Dosya yüklenirken bir hata oluştu.";
            }else{
                $sonuc['status']="complete";
                $sonuc['fileName']=$this->new_name;
                $sonuc['fileDir']=$this->upload_dir;
            }
            return $sonuc;
        }
    }
    private function check_type(){
        $this->ext = self::extension();
        if(!in_array($this->ext,$this->types)){
            $sonuc['status']="error";
            $sonuc['msg']="Dosya tipi desteklenmiyor.";
            return $sonuc;
        }else{
            return true;
        }
    }
    private function extension(){
        return end(explode('.',$this->file['name']));
    }
    private function newname(){
        $ext = self::extension();
        $time = time();
        $rand = rand(0,9999);
        $newname = $rand.'-'.$time.'-elsin.'.$ext;//Anagram
        return $newname;
    }
}
 