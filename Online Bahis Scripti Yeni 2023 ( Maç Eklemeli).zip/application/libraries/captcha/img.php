<?php



include 'captcha.php';


$captcha = new Captcha();


$captcha->generate();




?>