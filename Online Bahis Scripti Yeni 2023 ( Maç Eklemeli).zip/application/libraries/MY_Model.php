<?php if (!defined('BASEPATH')) exit('No direct script access allowed');  
      
    class MY_model extends Model {  
       
        function MY_model()  
        {  
            parent::Model();  
        }  
      
     function get_item_row($table,$column,$arr)  
     {  
      $query = $this->db->get_where($table,$arr);  
      if($query->num_rows() > 0)  
      {  
       $res = $query->row();  
       return $res->$column;  
      }else return FALSE;  
     }  
       
    }  