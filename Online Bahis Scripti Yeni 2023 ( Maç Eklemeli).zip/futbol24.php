<?php
error_reporting(0);

$gelen_ev = str_replace('-',' ',strtolower($_GET['ev_takim']));
$gelen_konuk = str_replace('-',' ',strtolower($_GET['konuk_takim']));

function aranacak($str) {
	$bol = explode(" ",$str);
	$aranacak='';
	for($i=0; $i<count($bol); $i++) {
	if(strlen($bol[$i])>2) {
		$aranacak .= "$bol[$i],";
	}	
	}
	return $aranacak;	
}


function strposa($haystack, $needle, $offset=0) {
    if(!is_array($needle)) $needle = array($needle);
    foreach($needle as $query) {
        if(@strpos($haystack, $query, $offset) !== false) return true; // stop on first true result
    }
    return false;
}

$ev_ara = aranacak($gelen_ev);
$ev_bol = explode(",",$ev_ara);
$konuk_ara = aranacak($gelen_konuk);
$konuk_bol = explode(",",$konuk_ara);

$tarih = date('Ymd',$_GET['tarih']);//20151106

//echo "<h4>Futbol24</h4>";
// FUTBOL24
//$url = "http://www.futbol24.com/f24/u/liveNow_15.xml?_=1423310169708";
$url = "http://www.futbol24.com/matchDayXml/?Day=".$tarih."&_=".time();
$refere = "http://www.futbol24.com";
$cerez = getcwd().'/f24.txt';

$ch  = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_COOKIEFILE, $cerez);
curl_setopt($ch, CURLOPT_COOKIEJAR, $cerez);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
//curl_setopt($ch, CURLOPT_REFERER, $refere);
curl_setopt($ch, CURLOPT_TIMEOUT, 10);
curl_setopt($ch, CURLOPT_ENCODING, "gzip, deflate");
curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:35.0) Gecko/20100101 Firefox/35.0');
$kaynak = curl_exec($ch);
curl_close($ch);

//echo'<pre>';print_R($kaynak);exit;

$xml = simplexml_load_string($kaynak) or die('kaynak alınamadı');

//echo$xml = simplexml_load_file($url); //or die("kaynak alınamadı.");
$toplam = count($xml->Mecze->M);

for($i=0; $i<$toplam; $i++) {
	$mac = $xml->Mecze->M[$i]->attributes();
	$ev_takim = strtolower($mac->HN);
	$konuk_takim = strtolower($mac->GN);
	$iy = $mac->S2;
	$ms = $mac->S1;
	$bitis = $mac->MStan;
	if($bitis==1) {
		$bitti = "<strong>Bitti</strong>";
	} else {
		$bitti = "Devam"; 
	}
	$sonuc_ev = strposa($ev_takim, $ev_bol);
	$sonuc_konuk = strposa($konuk_takim, $konuk_bol);
	$id = $_GET['evoid'];
	if(($sonuc_ev==true || $sonuc_konuk==true)) {
		echo "$bitti - $ev_takim - $konuk_takim - ($iy) - ($ms)
		<a href='javascript:;' onClick=\"isle('$iy','$ms','$id');\"  style='color:inherit; font-weight:bold;'>[İŞLE]</a>
		<hr>";
	}	
}

/////parimatch
/*echo'<br>parimatch.com<br> ';
if($_GET['hangi']==2){$tur=2;}else{$tur=21;}

//$tarih1 = date('Ydm',$_GET['tarih']);//20151106
	
$url1='https://www.parimatch.com/en/res.html?&Date='.$tarih.'&SK='.$tur;

$ch  = curl_init();
curl_setopt($ch, CURLOPT_URL, $url1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
//curl_setopt($ch, CURLOPT_REFERER, $refere);
curl_setopt($ch, CURLOPT_ENCODING, "gzip, deflate");
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
$kaynak = curl_exec($ch);

preg_match('/<Table.*?>.*?<\/[\s]*table>/s', $kaynak, $table_html);
preg_match_all("#<tr EN=.*?>(.*?)<\/[\s]*tr>#si", @$table_html[0], $matches);
//echo'<pre>';print_R($matches);exit;

foreach($matches[1] as $row_html) {
	preg_match_all("#<td.*?>(.*?)<\/[\s]*td>#si", $row_html, $td_matches);
	$row = array();
	for($i=0; $i<count($td_matches[1]); $i++){
	  $td = strip_tags(html_entity_decode($td_matches[1][$i]));
	  $row[$i] = $td;
	}

	if(count($row) > 0){
		if(strstr($row[3],'(')){
			
			$etkm=$row[1];
			$ktkm=$row[2];
			$olmasin=1;
			$olmamasi_gereken = array("corn.","ball poss.(%)","fouls","corners","y.card","yellow cards");
			for($k=0; $k<count($olmamasi_gereken); $k++) {
				if(strstr($etkm,$olmamasi_gereken[$k])) { $olmasin=0; }
				if(strstr($ktkm,$olmamasi_gereken[$k])) { $olmasin=0; }
			}
			if($olmasin==1){
			//echo'<pre>';print_R($row);
			$skr=str_replace(array("(",")"),'',$row[3]);
			$sk=explode(' ',$skr);
			list($mse,$msk)=$ibul=explode(':',$sk[0]);
			list($iye,$iyk)=$ibul=explode(':',$sk[1]);
			if(is_numeric($iye) && $iye!='' && is_numeric($iyk) && $iyk!='' && is_numeric($mse) && $mse!=''&& is_numeric($msk) && $msk!=''){
				
				echo$sonuc_ev1 = strposa($etkm, $ev_bol);
				echo$sonuc_konuk1 = strposa($ktkm, $konuk_bol);
				$id = $_GET['evoid'];
				
				if(($sonuc_ev1==true || $sonuc_konuk1==true)) {
					$iy=$iye.'-'.$iyk;
					$ms=$mse.'-'.$msk;
				
					echo "$etkm - $ktkm - ($iy) - ($ms)
					<a href='javascript:;' onClick=\"isle('$iy','$ms','$id');\"  style='color:inherit; font-weight:bold;'>[İŞLE]</a>
					<hr>";
				}
			}
			}
		}
	}
}*/